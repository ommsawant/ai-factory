import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c74894a2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { resolveAirJamBrowserRouterBasename } from "/node_modules/.vite/deps/@air-jam_sdk.js?v=c74894a2";
import "/node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/src/styles.css";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c74894a2"; const StrictMode = __vite__cjsImport3_react["StrictMode"];
import __vite__cjsImport4_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=c74894a2"; const createRoot = __vite__cjsImport4_reactDom_client["createRoot"];
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=c74894a2";
import { App } from "/src/app.tsx";
import "/src/index.css";
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(StrictMode, { children: /* @__PURE__ */ jsxDEV(BrowserRouter, { basename: resolveAirJamBrowserRouterBasename(), children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "D:/AiFactory/src/main.tsx",
    lineNumber: 17,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/AiFactory/src/main.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "D:/AiFactory/src/main.tsx",
    lineNumber: 15,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNO0FBWE4sU0FBU0EsMENBQTBDO0FBQ25ELE9BQU87QUFDUCxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxXQUFXO0FBQ3BCLE9BQU87QUFFUEYsV0FBV0csU0FBU0MsZUFBZSxNQUFNLENBQUUsRUFBRUM7QUFBQUEsRUFDM0MsdUJBQUMsY0FDQyxpQ0FBQyxpQkFBYyxVQUFVUCxtQ0FBbUMsR0FDMUQsaUNBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUksS0FETjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFDRiIsIm5hbWVzIjpbInJlc29sdmVBaXJKYW1Ccm93c2VyUm91dGVyQmFzZW5hbWUiLCJTdHJpY3RNb2RlIiwiY3JlYXRlUm9vdCIsIkJyb3dzZXJSb3V0ZXIiLCJBcHAiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogRW50cnkgcG9pbnQuIE1vdW50cyB0aGUgUmVhY3QgdHJlZSArIHRoZSBBaXIgSmFtLWF3YXJlIHJvdXRlciBiYXNlbmFtZSBzb1xuICogdGhlIEFyY2FkZSBzaGVsbCBjYW4gZW1iZWQgdGhpcyBnYW1lIHVuZGVyIGl0cyBvd24gcGF0aCB3aXRob3V0IGJyZWFraW5nXG4gKiByb3V0aW5nLiBBbGwgYWN0dWFsIEFpciBKYW0gd2lyaW5nIGhhcHBlbnMgaW5zaWRlIGAuL2FwcGAuXG4gKi9cbmltcG9ydCB7IHJlc29sdmVBaXJKYW1Ccm93c2VyUm91dGVyQmFzZW5hbWUgfSBmcm9tIFwiQGFpci1qYW0vc2RrXCI7XG5pbXBvcnQgXCJAYWlyLWphbS9zZGsvc3R5bGVzLmNzc1wiO1xuaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgeyBCcm93c2VyUm91dGVyIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEFwcCB9IGZyb20gXCIuL2FwcFwiO1xuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcblxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikhKS5yZW5kZXIoXG4gIDxTdHJpY3RNb2RlPlxuICAgIDxCcm93c2VyUm91dGVyIGJhc2VuYW1lPXtyZXNvbHZlQWlySmFtQnJvd3NlclJvdXRlckJhc2VuYW1lKCl9PlxuICAgICAgPEFwcCAvPlxuICAgIDwvQnJvd3NlclJvdXRlcj5cbiAgPC9TdHJpY3RNb2RlPixcbik7XG4iXSwiZmlsZSI6IkQ6L0FpRmFjdG9yeS9zcmMvbWFpbi50c3gifQ==