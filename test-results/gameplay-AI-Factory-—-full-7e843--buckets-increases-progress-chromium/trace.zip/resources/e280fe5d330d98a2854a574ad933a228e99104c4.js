import {
  external_exports
} from "/node_modules/.vite/deps/chunk-KQIFYUJI.js?v=c74894a2";
import "/node_modules/.vite/deps/chunk-DP4XHQAG.js?v=c74894a2";

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/metadata.js
var GAME_CATEGORIES = [
  "party",
  "arcade",
  "puzzle",
  "music",
  "sports",
  "strategy",
  "creative",
  "showcase",
  "other"
];
var GAME_INPUT_MODALITIES = [
  "buttons",
  "joystick",
  "touch",
  "motion",
  "text",
  "audio"
];
var slugSchema = external_exports.string().min(2).max(64).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, {
  message: "slug must be lowercase kebab-case (e.g. `my-cool-game`)"
});
var playerCountSchema = external_exports.number().int().min(1).max(16);
var semverRangeSchema = external_exports.string().min(1).max(64).regex(/^[\^~<>=\d][\d\w\s.\-+<>=^~|*x]*$/, {
  message: "supportedSdkRange must be a valid semver range"
});
var maintainerSchema = external_exports.object({
  name: external_exports.string().min(1).max(80),
  handle: external_exports.string().min(1).max(80).optional(),
  url: external_exports.string().url().max(500).optional()
});
var airJamGameMetadataSchema = external_exports.object({
  /** Fixed identifier for the contract version. Lets us evolve safely later. */
  version: external_exports.literal(1).default(1),
  /** Stable URL-safe slug. */
  slug: slugSchema,
  /** Human-readable display name shown in the catalog. */
  name: external_exports.string().min(1).max(80),
  /** One- to two-sentence description for catalog cards. Keep under ~240 chars. */
  tagline: external_exports.string().min(1).max(240),
  /** Broad taxonomy category. Use `other` sparingly. */
  category: external_exports.enum(GAME_CATEGORIES),
  /** Inclusive minimum player count. */
  minPlayers: playerCountSchema,
  /** Inclusive maximum player count. */
  maxPlayers: playerCountSchema,
  /** At least one input modality the controller uses. */
  inputModalities: external_exports.array(external_exports.enum(GAME_INPUT_MODALITIES)).min(1).max(GAME_INPUT_MODALITIES.length),
  /** Semver range of `@air-jam/sdk` this game is known to run against. */
  supportedSdkRange: semverRangeSchema,
  /** The person or team responsible for this game. */
  maintainer: maintainerSchema,
  /** Optional content advisory for age-sensitive catalog sorting. */
  ageRating: external_exports.enum(["all-ages", "teen", "mature"]).optional(),
  /** Optional short list of keyword tags for search. */
  tags: external_exports.array(external_exports.string().min(1).max(32)).max(12).optional()
}).refine((value) => value.minPlayers <= value.maxPlayers, {
  message: "minPlayers must be <= maxPlayers",
  path: ["minPlayers"]
});
var defineAirJamGameMetadata = (input) => Object.freeze(
  airJamGameMetadataSchema.parse({
    version: 1,
    ...input
  })
);
var parseAirJamGameMetadata = (value) => {
  const result = airJamGameMetadataSchema.safeParse(value);
  if (result.success) {
    return { ok: true, data: result.data };
  }
  return { ok: false, error: result.error };
};
export {
  GAME_CATEGORIES,
  GAME_INPUT_MODALITIES,
  airJamGameMetadataSchema,
  defineAirJamGameMetadata,
  parseAirJamGameMetadata
};
//# sourceMappingURL=@air-jam_sdk_metadata.js.map
