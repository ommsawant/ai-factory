import {
  AIR_JAM_PREVIEW_CLOSE_RESULT,
  generateControllerId,
  isPreviewCloseRequestMessage,
  readPreviewControllerDeviceIdFromLocation,
  useAirJamHost
} from "/node_modules/.vite/deps/chunk-YTXXUP4X.js?v=c74894a2";
import {
  arcadeSurfaceRuntimeIdentitySchema,
  createControllerBridgeCloseMessage,
  createControllerBridgeEmitMessage,
  createControllerBridgeRequestMessage,
  parseControllerBridgeAttachMessage,
  parseControllerBridgeCloseMessage,
  parseControllerBridgeEventMessage,
  parseControllerBridgeResponseMessage,
  readChildHostRuntimeParams,
  readEmbeddedControllerRuntimeParams,
  useAirJamController
} from "/node_modules/.vite/deps/chunk-FTUKOCBU.js?v=c74894a2";
import {
  AIRJAM_DEV_LOG_EVENTS,
  AIR_JAM_ARCADE_SURFACE_STORE_DOMAIN,
  AIR_JAM_DEFAULT_STORE_DOMAIN,
  AIR_JAM_SDK_VERSION,
  AirJamProvider,
  CONTROLLER_PATH,
  Check,
  Copy,
  DEFAULT_PLATFORM_SETTINGS,
  DEFAULT_ROOM_PLATFORM_SETTINGS,
  DEFAULT_SERVER_PORT,
  Maximize2,
  Minimize2,
  PlatformSettingsBoundary,
  PlatformSettingsRuntime,
  RefreshCw,
  RotateCcw,
  RuntimeOwnerRegistryContext,
  SessionScopeContext,
  controllerInputSchema,
  controllerJoinSchema,
  controllerLeaveSchema,
  controllerRuntimeContext,
  controllerStateSchema,
  controllerSystemSchema,
  create,
  createAirJamDiagnosticError,
  createBridgeHandshake,
  emitAirJamDevRuntimeEvent,
  emitAirJamDiagnostic,
  getEffectiveAudioVolume,
  hostBootstrapSchema,
  hostCreateRoomSchema,
  hostReconnectSchema,
  hostRemoveControllerSchema,
  hostResetRoomSchema,
  hostRuntimeContext,
  mergeRoomPlatformSettingsSnapshot,
  onAirJamDiagnostic,
  playerProfilePatchSchema,
  resolveImplicitReplicatedStoreDomainFromWindow,
  resolveProjectRuntimeTopology,
  roomCodeSchema,
  setAirJamDiagnosticsEnabled,
  toRoomPlatformSettingsSnapshot,
  updateDevBrowserLogContext,
  useAirJamContext,
  useAirJamState,
  useAssertSessionScope,
  useClaimSessionRuntimeOwner,
  useInheritedPlatformSettings,
  usePlatformAudioSettings,
  usePlatformSettings,
  usePlatformSettingsRuntimeStatus,
  useResolvedPlatformSettingsSnapshot,
  useShallow,
  useStore,
  v2HandshakeSchema
} from "/node_modules/.vite/deps/chunk-B6OEUIDA.js?v=c74894a2";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-GZR6XUHA.js?v=c74894a2";
import {
  external_exports
} from "/node_modules/.vite/deps/chunk-KQIFYUJI.js?v=c74894a2";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-DOQUEKBH.js?v=c74894a2";
import {
  __commonJS,
  __publicField,
  __toESM
} from "/node_modules/.vite/deps/chunk-DP4XHQAG.js?v=c74894a2";

// node_modules/.pnpm/howler@2.2.4/node_modules/howler/dist/howler.js
var require_howler = __commonJS({
  "node_modules/.pnpm/howler@2.2.4/node_modules/howler/dist/howler.js"(exports) {
    (function() {
      "use strict";
      var HowlerGlobal2 = function() {
        this.init();
      };
      HowlerGlobal2.prototype = {
        /**
         * Initialize the global Howler object.
         * @return {Howler}
         */
        init: function() {
          var self = this || Howler3;
          self._counter = 1e3;
          self._html5AudioPool = [];
          self.html5PoolSize = 10;
          self._codecs = {};
          self._howls = [];
          self._muted = false;
          self._volume = 1;
          self._canPlayEvent = "canplaythrough";
          self._navigator = typeof window !== "undefined" && window.navigator ? window.navigator : null;
          self.masterGain = null;
          self.noAudio = false;
          self.usingWebAudio = true;
          self.autoSuspend = true;
          self.ctx = null;
          self.autoUnlock = true;
          self._setup();
          return self;
        },
        /**
         * Get/set the global volume for all sounds.
         * @param  {Float} vol Volume from 0.0 to 1.0.
         * @return {Howler/Float}     Returns self or current volume.
         */
        volume: function(vol) {
          var self = this || Howler3;
          vol = parseFloat(vol);
          if (!self.ctx) {
            setupAudioContext();
          }
          if (typeof vol !== "undefined" && vol >= 0 && vol <= 1) {
            self._volume = vol;
            if (self._muted) {
              return self;
            }
            if (self.usingWebAudio) {
              self.masterGain.gain.setValueAtTime(vol, Howler3.ctx.currentTime);
            }
            for (var i = 0; i < self._howls.length; i++) {
              if (!self._howls[i]._webAudio) {
                var ids = self._howls[i]._getSoundIds();
                for (var j = 0; j < ids.length; j++) {
                  var sound = self._howls[i]._soundById(ids[j]);
                  if (sound && sound._node) {
                    sound._node.volume = sound._volume * vol;
                  }
                }
              }
            }
            return self;
          }
          return self._volume;
        },
        /**
         * Handle muting and unmuting globally.
         * @param  {Boolean} muted Is muted or not.
         */
        mute: function(muted) {
          var self = this || Howler3;
          if (!self.ctx) {
            setupAudioContext();
          }
          self._muted = muted;
          if (self.usingWebAudio) {
            self.masterGain.gain.setValueAtTime(muted ? 0 : self._volume, Howler3.ctx.currentTime);
          }
          for (var i = 0; i < self._howls.length; i++) {
            if (!self._howls[i]._webAudio) {
              var ids = self._howls[i]._getSoundIds();
              for (var j = 0; j < ids.length; j++) {
                var sound = self._howls[i]._soundById(ids[j]);
                if (sound && sound._node) {
                  sound._node.muted = muted ? true : sound._muted;
                }
              }
            }
          }
          return self;
        },
        /**
         * Handle stopping all sounds globally.
         */
        stop: function() {
          var self = this || Howler3;
          for (var i = 0; i < self._howls.length; i++) {
            self._howls[i].stop();
          }
          return self;
        },
        /**
         * Unload and destroy all currently loaded Howl objects.
         * @return {Howler}
         */
        unload: function() {
          var self = this || Howler3;
          for (var i = self._howls.length - 1; i >= 0; i--) {
            self._howls[i].unload();
          }
          if (self.usingWebAudio && self.ctx && typeof self.ctx.close !== "undefined") {
            self.ctx.close();
            self.ctx = null;
            setupAudioContext();
          }
          return self;
        },
        /**
         * Check for codec support of specific extension.
         * @param  {String} ext Audio file extention.
         * @return {Boolean}
         */
        codecs: function(ext) {
          return (this || Howler3)._codecs[ext.replace(/^x-/, "")];
        },
        /**
         * Setup various state values for global tracking.
         * @return {Howler}
         */
        _setup: function() {
          var self = this || Howler3;
          self.state = self.ctx ? self.ctx.state || "suspended" : "suspended";
          self._autoSuspend();
          if (!self.usingWebAudio) {
            if (typeof Audio !== "undefined") {
              try {
                var test = new Audio();
                if (typeof test.oncanplaythrough === "undefined") {
                  self._canPlayEvent = "canplay";
                }
              } catch (e) {
                self.noAudio = true;
              }
            } else {
              self.noAudio = true;
            }
          }
          try {
            var test = new Audio();
            if (test.muted) {
              self.noAudio = true;
            }
          } catch (e) {
          }
          if (!self.noAudio) {
            self._setupCodecs();
          }
          return self;
        },
        /**
         * Check for browser support for various codecs and cache the results.
         * @return {Howler}
         */
        _setupCodecs: function() {
          var self = this || Howler3;
          var audioTest = null;
          try {
            audioTest = typeof Audio !== "undefined" ? new Audio() : null;
          } catch (err) {
            return self;
          }
          if (!audioTest || typeof audioTest.canPlayType !== "function") {
            return self;
          }
          var mpegTest = audioTest.canPlayType("audio/mpeg;").replace(/^no$/, "");
          var ua = self._navigator ? self._navigator.userAgent : "";
          var checkOpera = ua.match(/OPR\/(\d+)/g);
          var isOldOpera = checkOpera && parseInt(checkOpera[0].split("/")[1], 10) < 33;
          var checkSafari = ua.indexOf("Safari") !== -1 && ua.indexOf("Chrome") === -1;
          var safariVersion = ua.match(/Version\/(.*?) /);
          var isOldSafari = checkSafari && safariVersion && parseInt(safariVersion[1], 10) < 15;
          self._codecs = {
            mp3: !!(!isOldOpera && (mpegTest || audioTest.canPlayType("audio/mp3;").replace(/^no$/, ""))),
            mpeg: !!mpegTest,
            opus: !!audioTest.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/, ""),
            ogg: !!audioTest.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ""),
            oga: !!audioTest.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ""),
            wav: !!(audioTest.canPlayType('audio/wav; codecs="1"') || audioTest.canPlayType("audio/wav")).replace(/^no$/, ""),
            aac: !!audioTest.canPlayType("audio/aac;").replace(/^no$/, ""),
            caf: !!audioTest.canPlayType("audio/x-caf;").replace(/^no$/, ""),
            m4a: !!(audioTest.canPlayType("audio/x-m4a;") || audioTest.canPlayType("audio/m4a;") || audioTest.canPlayType("audio/aac;")).replace(/^no$/, ""),
            m4b: !!(audioTest.canPlayType("audio/x-m4b;") || audioTest.canPlayType("audio/m4b;") || audioTest.canPlayType("audio/aac;")).replace(/^no$/, ""),
            mp4: !!(audioTest.canPlayType("audio/x-mp4;") || audioTest.canPlayType("audio/mp4;") || audioTest.canPlayType("audio/aac;")).replace(/^no$/, ""),
            weba: !!(!isOldSafari && audioTest.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, "")),
            webm: !!(!isOldSafari && audioTest.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, "")),
            dolby: !!audioTest.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/, ""),
            flac: !!(audioTest.canPlayType("audio/x-flac;") || audioTest.canPlayType("audio/flac;")).replace(/^no$/, "")
          };
          return self;
        },
        /**
         * Some browsers/devices will only allow audio to be played after a user interaction.
         * Attempt to automatically unlock audio on the first user interaction.
         * Concept from: http://paulbakaus.com/tutorials/html5/web-audio-on-ios/
         * @return {Howler}
         */
        _unlockAudio: function() {
          var self = this || Howler3;
          if (self._audioUnlocked || !self.ctx) {
            return;
          }
          self._audioUnlocked = false;
          self.autoUnlock = false;
          if (!self._mobileUnloaded && self.ctx.sampleRate !== 44100) {
            self._mobileUnloaded = true;
            self.unload();
          }
          self._scratchBuffer = self.ctx.createBuffer(1, 1, 22050);
          var unlock = function(e) {
            while (self._html5AudioPool.length < self.html5PoolSize) {
              try {
                var audioNode = new Audio();
                audioNode._unlocked = true;
                self._releaseHtml5Audio(audioNode);
              } catch (e2) {
                self.noAudio = true;
                break;
              }
            }
            for (var i = 0; i < self._howls.length; i++) {
              if (!self._howls[i]._webAudio) {
                var ids = self._howls[i]._getSoundIds();
                for (var j = 0; j < ids.length; j++) {
                  var sound = self._howls[i]._soundById(ids[j]);
                  if (sound && sound._node && !sound._node._unlocked) {
                    sound._node._unlocked = true;
                    sound._node.load();
                  }
                }
              }
            }
            self._autoResume();
            var source = self.ctx.createBufferSource();
            source.buffer = self._scratchBuffer;
            source.connect(self.ctx.destination);
            if (typeof source.start === "undefined") {
              source.noteOn(0);
            } else {
              source.start(0);
            }
            if (typeof self.ctx.resume === "function") {
              self.ctx.resume();
            }
            source.onended = function() {
              source.disconnect(0);
              self._audioUnlocked = true;
              document.removeEventListener("touchstart", unlock, true);
              document.removeEventListener("touchend", unlock, true);
              document.removeEventListener("click", unlock, true);
              document.removeEventListener("keydown", unlock, true);
              for (var i2 = 0; i2 < self._howls.length; i2++) {
                self._howls[i2]._emit("unlock");
              }
            };
          };
          document.addEventListener("touchstart", unlock, true);
          document.addEventListener("touchend", unlock, true);
          document.addEventListener("click", unlock, true);
          document.addEventListener("keydown", unlock, true);
          return self;
        },
        /**
         * Get an unlocked HTML5 Audio object from the pool. If none are left,
         * return a new Audio object and throw a warning.
         * @return {Audio} HTML5 Audio object.
         */
        _obtainHtml5Audio: function() {
          var self = this || Howler3;
          if (self._html5AudioPool.length) {
            return self._html5AudioPool.pop();
          }
          var testPlay = new Audio().play();
          if (testPlay && typeof Promise !== "undefined" && (testPlay instanceof Promise || typeof testPlay.then === "function")) {
            testPlay.catch(function() {
              console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.");
            });
          }
          return new Audio();
        },
        /**
         * Return an activated HTML5 Audio object to the pool.
         * @return {Howler}
         */
        _releaseHtml5Audio: function(audio) {
          var self = this || Howler3;
          if (audio._unlocked) {
            self._html5AudioPool.push(audio);
          }
          return self;
        },
        /**
         * Automatically suspend the Web Audio AudioContext after no sound has played for 30 seconds.
         * This saves processing/energy and fixes various browser-specific bugs with audio getting stuck.
         * @return {Howler}
         */
        _autoSuspend: function() {
          var self = this;
          if (!self.autoSuspend || !self.ctx || typeof self.ctx.suspend === "undefined" || !Howler3.usingWebAudio) {
            return;
          }
          for (var i = 0; i < self._howls.length; i++) {
            if (self._howls[i]._webAudio) {
              for (var j = 0; j < self._howls[i]._sounds.length; j++) {
                if (!self._howls[i]._sounds[j]._paused) {
                  return self;
                }
              }
            }
          }
          if (self._suspendTimer) {
            clearTimeout(self._suspendTimer);
          }
          self._suspendTimer = setTimeout(function() {
            if (!self.autoSuspend) {
              return;
            }
            self._suspendTimer = null;
            self.state = "suspending";
            var handleSuspension = function() {
              self.state = "suspended";
              if (self._resumeAfterSuspend) {
                delete self._resumeAfterSuspend;
                self._autoResume();
              }
            };
            self.ctx.suspend().then(handleSuspension, handleSuspension);
          }, 3e4);
          return self;
        },
        /**
         * Automatically resume the Web Audio AudioContext when a new sound is played.
         * @return {Howler}
         */
        _autoResume: function() {
          var self = this;
          if (!self.ctx || typeof self.ctx.resume === "undefined" || !Howler3.usingWebAudio) {
            return;
          }
          if (self.state === "running" && self.ctx.state !== "interrupted" && self._suspendTimer) {
            clearTimeout(self._suspendTimer);
            self._suspendTimer = null;
          } else if (self.state === "suspended" || self.state === "running" && self.ctx.state === "interrupted") {
            self.ctx.resume().then(function() {
              self.state = "running";
              for (var i = 0; i < self._howls.length; i++) {
                self._howls[i]._emit("resume");
              }
            });
            if (self._suspendTimer) {
              clearTimeout(self._suspendTimer);
              self._suspendTimer = null;
            }
          } else if (self.state === "suspending") {
            self._resumeAfterSuspend = true;
          }
          return self;
        }
      };
      var Howler3 = new HowlerGlobal2();
      var Howl3 = function(o) {
        var self = this;
        if (!o.src || o.src.length === 0) {
          console.error("An array of source files must be passed with any new Howl.");
          return;
        }
        self.init(o);
      };
      Howl3.prototype = {
        /**
         * Initialize a new Howl group object.
         * @param  {Object} o Passed in properties for this group.
         * @return {Howl}
         */
        init: function(o) {
          var self = this;
          if (!Howler3.ctx) {
            setupAudioContext();
          }
          self._autoplay = o.autoplay || false;
          self._format = typeof o.format !== "string" ? o.format : [o.format];
          self._html5 = o.html5 || false;
          self._muted = o.mute || false;
          self._loop = o.loop || false;
          self._pool = o.pool || 5;
          self._preload = typeof o.preload === "boolean" || o.preload === "metadata" ? o.preload : true;
          self._rate = o.rate || 1;
          self._sprite = o.sprite || {};
          self._src = typeof o.src !== "string" ? o.src : [o.src];
          self._volume = o.volume !== void 0 ? o.volume : 1;
          self._xhr = {
            method: o.xhr && o.xhr.method ? o.xhr.method : "GET",
            headers: o.xhr && o.xhr.headers ? o.xhr.headers : null,
            withCredentials: o.xhr && o.xhr.withCredentials ? o.xhr.withCredentials : false
          };
          self._duration = 0;
          self._state = "unloaded";
          self._sounds = [];
          self._endTimers = {};
          self._queue = [];
          self._playLock = false;
          self._onend = o.onend ? [{ fn: o.onend }] : [];
          self._onfade = o.onfade ? [{ fn: o.onfade }] : [];
          self._onload = o.onload ? [{ fn: o.onload }] : [];
          self._onloaderror = o.onloaderror ? [{ fn: o.onloaderror }] : [];
          self._onplayerror = o.onplayerror ? [{ fn: o.onplayerror }] : [];
          self._onpause = o.onpause ? [{ fn: o.onpause }] : [];
          self._onplay = o.onplay ? [{ fn: o.onplay }] : [];
          self._onstop = o.onstop ? [{ fn: o.onstop }] : [];
          self._onmute = o.onmute ? [{ fn: o.onmute }] : [];
          self._onvolume = o.onvolume ? [{ fn: o.onvolume }] : [];
          self._onrate = o.onrate ? [{ fn: o.onrate }] : [];
          self._onseek = o.onseek ? [{ fn: o.onseek }] : [];
          self._onunlock = o.onunlock ? [{ fn: o.onunlock }] : [];
          self._onresume = [];
          self._webAudio = Howler3.usingWebAudio && !self._html5;
          if (typeof Howler3.ctx !== "undefined" && Howler3.ctx && Howler3.autoUnlock) {
            Howler3._unlockAudio();
          }
          Howler3._howls.push(self);
          if (self._autoplay) {
            self._queue.push({
              event: "play",
              action: function() {
                self.play();
              }
            });
          }
          if (self._preload && self._preload !== "none") {
            self.load();
          }
          return self;
        },
        /**
         * Load the audio file.
         * @return {Howler}
         */
        load: function() {
          var self = this;
          var url = null;
          if (Howler3.noAudio) {
            self._emit("loaderror", null, "No audio support.");
            return;
          }
          if (typeof self._src === "string") {
            self._src = [self._src];
          }
          for (var i = 0; i < self._src.length; i++) {
            var ext, str;
            if (self._format && self._format[i]) {
              ext = self._format[i];
            } else {
              str = self._src[i];
              if (typeof str !== "string") {
                self._emit("loaderror", null, "Non-string found in selected audio sources - ignoring.");
                continue;
              }
              ext = /^data:audio\/([^;,]+);/i.exec(str);
              if (!ext) {
                ext = /\.([^.]+)$/.exec(str.split("?", 1)[0]);
              }
              if (ext) {
                ext = ext[1].toLowerCase();
              }
            }
            if (!ext) {
              console.warn('No file extension was found. Consider using the "format" property or specify an extension.');
            }
            if (ext && Howler3.codecs(ext)) {
              url = self._src[i];
              break;
            }
          }
          if (!url) {
            self._emit("loaderror", null, "No codec support for selected audio sources.");
            return;
          }
          self._src = url;
          self._state = "loading";
          if (window.location.protocol === "https:" && url.slice(0, 5) === "http:") {
            self._html5 = true;
            self._webAudio = false;
          }
          new Sound2(self);
          if (self._webAudio) {
            loadBuffer(self);
          }
          return self;
        },
        /**
         * Play a sound or resume previous playback.
         * @param  {String/Number} sprite   Sprite name for sprite playback or sound id to continue previous.
         * @param  {Boolean} internal Internal Use: true prevents event firing.
         * @return {Number}          Sound ID.
         */
        play: function(sprite, internal) {
          var self = this;
          var id = null;
          if (typeof sprite === "number") {
            id = sprite;
            sprite = null;
          } else if (typeof sprite === "string" && self._state === "loaded" && !self._sprite[sprite]) {
            return null;
          } else if (typeof sprite === "undefined") {
            sprite = "__default";
            if (!self._playLock) {
              var num = 0;
              for (var i = 0; i < self._sounds.length; i++) {
                if (self._sounds[i]._paused && !self._sounds[i]._ended) {
                  num++;
                  id = self._sounds[i]._id;
                }
              }
              if (num === 1) {
                sprite = null;
              } else {
                id = null;
              }
            }
          }
          var sound = id ? self._soundById(id) : self._inactiveSound();
          if (!sound) {
            return null;
          }
          if (id && !sprite) {
            sprite = sound._sprite || "__default";
          }
          if (self._state !== "loaded") {
            sound._sprite = sprite;
            sound._ended = false;
            var soundId = sound._id;
            self._queue.push({
              event: "play",
              action: function() {
                self.play(soundId);
              }
            });
            return soundId;
          }
          if (id && !sound._paused) {
            if (!internal) {
              self._loadQueue("play");
            }
            return sound._id;
          }
          if (self._webAudio) {
            Howler3._autoResume();
          }
          var seek = Math.max(0, sound._seek > 0 ? sound._seek : self._sprite[sprite][0] / 1e3);
          var duration = Math.max(0, (self._sprite[sprite][0] + self._sprite[sprite][1]) / 1e3 - seek);
          var timeout = duration * 1e3 / Math.abs(sound._rate);
          var start = self._sprite[sprite][0] / 1e3;
          var stop = (self._sprite[sprite][0] + self._sprite[sprite][1]) / 1e3;
          sound._sprite = sprite;
          sound._ended = false;
          var setParams = function() {
            sound._paused = false;
            sound._seek = seek;
            sound._start = start;
            sound._stop = stop;
            sound._loop = !!(sound._loop || self._sprite[sprite][2]);
          };
          if (seek >= stop) {
            self._ended(sound);
            return;
          }
          var node = sound._node;
          if (self._webAudio) {
            var playWebAudio = function() {
              self._playLock = false;
              setParams();
              self._refreshBuffer(sound);
              var vol = sound._muted || self._muted ? 0 : sound._volume;
              node.gain.setValueAtTime(vol, Howler3.ctx.currentTime);
              sound._playStart = Howler3.ctx.currentTime;
              if (typeof node.bufferSource.start === "undefined") {
                sound._loop ? node.bufferSource.noteGrainOn(0, seek, 86400) : node.bufferSource.noteGrainOn(0, seek, duration);
              } else {
                sound._loop ? node.bufferSource.start(0, seek, 86400) : node.bufferSource.start(0, seek, duration);
              }
              if (timeout !== Infinity) {
                self._endTimers[sound._id] = setTimeout(self._ended.bind(self, sound), timeout);
              }
              if (!internal) {
                setTimeout(function() {
                  self._emit("play", sound._id);
                  self._loadQueue();
                }, 0);
              }
            };
            if (Howler3.state === "running" && Howler3.ctx.state !== "interrupted") {
              playWebAudio();
            } else {
              self._playLock = true;
              self.once("resume", playWebAudio);
              self._clearTimer(sound._id);
            }
          } else {
            var playHtml5 = function() {
              node.currentTime = seek;
              node.muted = sound._muted || self._muted || Howler3._muted || node.muted;
              node.volume = sound._volume * Howler3.volume();
              node.playbackRate = sound._rate;
              try {
                var play = node.play();
                if (play && typeof Promise !== "undefined" && (play instanceof Promise || typeof play.then === "function")) {
                  self._playLock = true;
                  setParams();
                  play.then(function() {
                    self._playLock = false;
                    node._unlocked = true;
                    if (!internal) {
                      self._emit("play", sound._id);
                    } else {
                      self._loadQueue();
                    }
                  }).catch(function() {
                    self._playLock = false;
                    self._emit("playerror", sound._id, "Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");
                    sound._ended = true;
                    sound._paused = true;
                  });
                } else if (!internal) {
                  self._playLock = false;
                  setParams();
                  self._emit("play", sound._id);
                }
                node.playbackRate = sound._rate;
                if (node.paused) {
                  self._emit("playerror", sound._id, "Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");
                  return;
                }
                if (sprite !== "__default" || sound._loop) {
                  self._endTimers[sound._id] = setTimeout(self._ended.bind(self, sound), timeout);
                } else {
                  self._endTimers[sound._id] = function() {
                    self._ended(sound);
                    node.removeEventListener("ended", self._endTimers[sound._id], false);
                  };
                  node.addEventListener("ended", self._endTimers[sound._id], false);
                }
              } catch (err) {
                self._emit("playerror", sound._id, err);
              }
            };
            if (node.src === "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA") {
              node.src = self._src;
              node.load();
            }
            var loadedNoReadyState = window && window.ejecta || !node.readyState && Howler3._navigator.isCocoonJS;
            if (node.readyState >= 3 || loadedNoReadyState) {
              playHtml5();
            } else {
              self._playLock = true;
              self._state = "loading";
              var listener = function() {
                self._state = "loaded";
                playHtml5();
                node.removeEventListener(Howler3._canPlayEvent, listener, false);
              };
              node.addEventListener(Howler3._canPlayEvent, listener, false);
              self._clearTimer(sound._id);
            }
          }
          return sound._id;
        },
        /**
         * Pause playback and save current position.
         * @param  {Number} id The sound ID (empty to pause all in group).
         * @return {Howl}
         */
        pause: function(id) {
          var self = this;
          if (self._state !== "loaded" || self._playLock) {
            self._queue.push({
              event: "pause",
              action: function() {
                self.pause(id);
              }
            });
            return self;
          }
          var ids = self._getSoundIds(id);
          for (var i = 0; i < ids.length; i++) {
            self._clearTimer(ids[i]);
            var sound = self._soundById(ids[i]);
            if (sound && !sound._paused) {
              sound._seek = self.seek(ids[i]);
              sound._rateSeek = 0;
              sound._paused = true;
              self._stopFade(ids[i]);
              if (sound._node) {
                if (self._webAudio) {
                  if (!sound._node.bufferSource) {
                    continue;
                  }
                  if (typeof sound._node.bufferSource.stop === "undefined") {
                    sound._node.bufferSource.noteOff(0);
                  } else {
                    sound._node.bufferSource.stop(0);
                  }
                  self._cleanBuffer(sound._node);
                } else if (!isNaN(sound._node.duration) || sound._node.duration === Infinity) {
                  sound._node.pause();
                }
              }
            }
            if (!arguments[1]) {
              self._emit("pause", sound ? sound._id : null);
            }
          }
          return self;
        },
        /**
         * Stop playback and reset to start.
         * @param  {Number} id The sound ID (empty to stop all in group).
         * @param  {Boolean} internal Internal Use: true prevents event firing.
         * @return {Howl}
         */
        stop: function(id, internal) {
          var self = this;
          if (self._state !== "loaded" || self._playLock) {
            self._queue.push({
              event: "stop",
              action: function() {
                self.stop(id);
              }
            });
            return self;
          }
          var ids = self._getSoundIds(id);
          for (var i = 0; i < ids.length; i++) {
            self._clearTimer(ids[i]);
            var sound = self._soundById(ids[i]);
            if (sound) {
              sound._seek = sound._start || 0;
              sound._rateSeek = 0;
              sound._paused = true;
              sound._ended = true;
              self._stopFade(ids[i]);
              if (sound._node) {
                if (self._webAudio) {
                  if (sound._node.bufferSource) {
                    if (typeof sound._node.bufferSource.stop === "undefined") {
                      sound._node.bufferSource.noteOff(0);
                    } else {
                      sound._node.bufferSource.stop(0);
                    }
                    self._cleanBuffer(sound._node);
                  }
                } else if (!isNaN(sound._node.duration) || sound._node.duration === Infinity) {
                  sound._node.currentTime = sound._start || 0;
                  sound._node.pause();
                  if (sound._node.duration === Infinity) {
                    self._clearSound(sound._node);
                  }
                }
              }
              if (!internal) {
                self._emit("stop", sound._id);
              }
            }
          }
          return self;
        },
        /**
         * Mute/unmute a single sound or all sounds in this Howl group.
         * @param  {Boolean} muted Set to true to mute and false to unmute.
         * @param  {Number} id    The sound ID to update (omit to mute/unmute all).
         * @return {Howl}
         */
        mute: function(muted, id) {
          var self = this;
          if (self._state !== "loaded" || self._playLock) {
            self._queue.push({
              event: "mute",
              action: function() {
                self.mute(muted, id);
              }
            });
            return self;
          }
          if (typeof id === "undefined") {
            if (typeof muted === "boolean") {
              self._muted = muted;
            } else {
              return self._muted;
            }
          }
          var ids = self._getSoundIds(id);
          for (var i = 0; i < ids.length; i++) {
            var sound = self._soundById(ids[i]);
            if (sound) {
              sound._muted = muted;
              if (sound._interval) {
                self._stopFade(sound._id);
              }
              if (self._webAudio && sound._node) {
                sound._node.gain.setValueAtTime(muted ? 0 : sound._volume, Howler3.ctx.currentTime);
              } else if (sound._node) {
                sound._node.muted = Howler3._muted ? true : muted;
              }
              self._emit("mute", sound._id);
            }
          }
          return self;
        },
        /**
         * Get/set the volume of this sound or of the Howl group. This method can optionally take 0, 1 or 2 arguments.
         *   volume() -> Returns the group's volume value.
         *   volume(id) -> Returns the sound id's current volume.
         *   volume(vol) -> Sets the volume of all sounds in this Howl group.
         *   volume(vol, id) -> Sets the volume of passed sound id.
         * @return {Howl/Number} Returns self or current volume.
         */
        volume: function() {
          var self = this;
          var args = arguments;
          var vol, id;
          if (args.length === 0) {
            return self._volume;
          } else if (args.length === 1 || args.length === 2 && typeof args[1] === "undefined") {
            var ids = self._getSoundIds();
            var index = ids.indexOf(args[0]);
            if (index >= 0) {
              id = parseInt(args[0], 10);
            } else {
              vol = parseFloat(args[0]);
            }
          } else if (args.length >= 2) {
            vol = parseFloat(args[0]);
            id = parseInt(args[1], 10);
          }
          var sound;
          if (typeof vol !== "undefined" && vol >= 0 && vol <= 1) {
            if (self._state !== "loaded" || self._playLock) {
              self._queue.push({
                event: "volume",
                action: function() {
                  self.volume.apply(self, args);
                }
              });
              return self;
            }
            if (typeof id === "undefined") {
              self._volume = vol;
            }
            id = self._getSoundIds(id);
            for (var i = 0; i < id.length; i++) {
              sound = self._soundById(id[i]);
              if (sound) {
                sound._volume = vol;
                if (!args[2]) {
                  self._stopFade(id[i]);
                }
                if (self._webAudio && sound._node && !sound._muted) {
                  sound._node.gain.setValueAtTime(vol, Howler3.ctx.currentTime);
                } else if (sound._node && !sound._muted) {
                  sound._node.volume = vol * Howler3.volume();
                }
                self._emit("volume", sound._id);
              }
            }
          } else {
            sound = id ? self._soundById(id) : self._sounds[0];
            return sound ? sound._volume : 0;
          }
          return self;
        },
        /**
         * Fade a currently playing sound between two volumes (if no id is passed, all sounds will fade).
         * @param  {Number} from The value to fade from (0.0 to 1.0).
         * @param  {Number} to   The volume to fade to (0.0 to 1.0).
         * @param  {Number} len  Time in milliseconds to fade.
         * @param  {Number} id   The sound id (omit to fade all sounds).
         * @return {Howl}
         */
        fade: function(from, to, len, id) {
          var self = this;
          if (self._state !== "loaded" || self._playLock) {
            self._queue.push({
              event: "fade",
              action: function() {
                self.fade(from, to, len, id);
              }
            });
            return self;
          }
          from = Math.min(Math.max(0, parseFloat(from)), 1);
          to = Math.min(Math.max(0, parseFloat(to)), 1);
          len = parseFloat(len);
          self.volume(from, id);
          var ids = self._getSoundIds(id);
          for (var i = 0; i < ids.length; i++) {
            var sound = self._soundById(ids[i]);
            if (sound) {
              if (!id) {
                self._stopFade(ids[i]);
              }
              if (self._webAudio && !sound._muted) {
                var currentTime = Howler3.ctx.currentTime;
                var end = currentTime + len / 1e3;
                sound._volume = from;
                sound._node.gain.setValueAtTime(from, currentTime);
                sound._node.gain.linearRampToValueAtTime(to, end);
              }
              self._startFadeInterval(sound, from, to, len, ids[i], typeof id === "undefined");
            }
          }
          return self;
        },
        /**
         * Starts the internal interval to fade a sound.
         * @param  {Object} sound Reference to sound to fade.
         * @param  {Number} from The value to fade from (0.0 to 1.0).
         * @param  {Number} to   The volume to fade to (0.0 to 1.0).
         * @param  {Number} len  Time in milliseconds to fade.
         * @param  {Number} id   The sound id to fade.
         * @param  {Boolean} isGroup   If true, set the volume on the group.
         */
        _startFadeInterval: function(sound, from, to, len, id, isGroup) {
          var self = this;
          var vol = from;
          var diff = to - from;
          var steps = Math.abs(diff / 0.01);
          var stepLen = Math.max(4, steps > 0 ? len / steps : len);
          var lastTick = Date.now();
          sound._fadeTo = to;
          sound._interval = setInterval(function() {
            var tick = (Date.now() - lastTick) / len;
            lastTick = Date.now();
            vol += diff * tick;
            vol = Math.round(vol * 100) / 100;
            if (diff < 0) {
              vol = Math.max(to, vol);
            } else {
              vol = Math.min(to, vol);
            }
            if (self._webAudio) {
              sound._volume = vol;
            } else {
              self.volume(vol, sound._id, true);
            }
            if (isGroup) {
              self._volume = vol;
            }
            if (to < from && vol <= to || to > from && vol >= to) {
              clearInterval(sound._interval);
              sound._interval = null;
              sound._fadeTo = null;
              self.volume(to, sound._id);
              self._emit("fade", sound._id);
            }
          }, stepLen);
        },
        /**
         * Internal method that stops the currently playing fade when
         * a new fade starts, volume is changed or the sound is stopped.
         * @param  {Number} id The sound id.
         * @return {Howl}
         */
        _stopFade: function(id) {
          var self = this;
          var sound = self._soundById(id);
          if (sound && sound._interval) {
            if (self._webAudio) {
              sound._node.gain.cancelScheduledValues(Howler3.ctx.currentTime);
            }
            clearInterval(sound._interval);
            sound._interval = null;
            self.volume(sound._fadeTo, id);
            sound._fadeTo = null;
            self._emit("fade", id);
          }
          return self;
        },
        /**
         * Get/set the loop parameter on a sound. This method can optionally take 0, 1 or 2 arguments.
         *   loop() -> Returns the group's loop value.
         *   loop(id) -> Returns the sound id's loop value.
         *   loop(loop) -> Sets the loop value for all sounds in this Howl group.
         *   loop(loop, id) -> Sets the loop value of passed sound id.
         * @return {Howl/Boolean} Returns self or current loop value.
         */
        loop: function() {
          var self = this;
          var args = arguments;
          var loop, id, sound;
          if (args.length === 0) {
            return self._loop;
          } else if (args.length === 1) {
            if (typeof args[0] === "boolean") {
              loop = args[0];
              self._loop = loop;
            } else {
              sound = self._soundById(parseInt(args[0], 10));
              return sound ? sound._loop : false;
            }
          } else if (args.length === 2) {
            loop = args[0];
            id = parseInt(args[1], 10);
          }
          var ids = self._getSoundIds(id);
          for (var i = 0; i < ids.length; i++) {
            sound = self._soundById(ids[i]);
            if (sound) {
              sound._loop = loop;
              if (self._webAudio && sound._node && sound._node.bufferSource) {
                sound._node.bufferSource.loop = loop;
                if (loop) {
                  sound._node.bufferSource.loopStart = sound._start || 0;
                  sound._node.bufferSource.loopEnd = sound._stop;
                  if (self.playing(ids[i])) {
                    self.pause(ids[i], true);
                    self.play(ids[i], true);
                  }
                }
              }
            }
          }
          return self;
        },
        /**
         * Get/set the playback rate of a sound. This method can optionally take 0, 1 or 2 arguments.
         *   rate() -> Returns the first sound node's current playback rate.
         *   rate(id) -> Returns the sound id's current playback rate.
         *   rate(rate) -> Sets the playback rate of all sounds in this Howl group.
         *   rate(rate, id) -> Sets the playback rate of passed sound id.
         * @return {Howl/Number} Returns self or the current playback rate.
         */
        rate: function() {
          var self = this;
          var args = arguments;
          var rate, id;
          if (args.length === 0) {
            id = self._sounds[0]._id;
          } else if (args.length === 1) {
            var ids = self._getSoundIds();
            var index = ids.indexOf(args[0]);
            if (index >= 0) {
              id = parseInt(args[0], 10);
            } else {
              rate = parseFloat(args[0]);
            }
          } else if (args.length === 2) {
            rate = parseFloat(args[0]);
            id = parseInt(args[1], 10);
          }
          var sound;
          if (typeof rate === "number") {
            if (self._state !== "loaded" || self._playLock) {
              self._queue.push({
                event: "rate",
                action: function() {
                  self.rate.apply(self, args);
                }
              });
              return self;
            }
            if (typeof id === "undefined") {
              self._rate = rate;
            }
            id = self._getSoundIds(id);
            for (var i = 0; i < id.length; i++) {
              sound = self._soundById(id[i]);
              if (sound) {
                if (self.playing(id[i])) {
                  sound._rateSeek = self.seek(id[i]);
                  sound._playStart = self._webAudio ? Howler3.ctx.currentTime : sound._playStart;
                }
                sound._rate = rate;
                if (self._webAudio && sound._node && sound._node.bufferSource) {
                  sound._node.bufferSource.playbackRate.setValueAtTime(rate, Howler3.ctx.currentTime);
                } else if (sound._node) {
                  sound._node.playbackRate = rate;
                }
                var seek = self.seek(id[i]);
                var duration = (self._sprite[sound._sprite][0] + self._sprite[sound._sprite][1]) / 1e3 - seek;
                var timeout = duration * 1e3 / Math.abs(sound._rate);
                if (self._endTimers[id[i]] || !sound._paused) {
                  self._clearTimer(id[i]);
                  self._endTimers[id[i]] = setTimeout(self._ended.bind(self, sound), timeout);
                }
                self._emit("rate", sound._id);
              }
            }
          } else {
            sound = self._soundById(id);
            return sound ? sound._rate : self._rate;
          }
          return self;
        },
        /**
         * Get/set the seek position of a sound. This method can optionally take 0, 1 or 2 arguments.
         *   seek() -> Returns the first sound node's current seek position.
         *   seek(id) -> Returns the sound id's current seek position.
         *   seek(seek) -> Sets the seek position of the first sound node.
         *   seek(seek, id) -> Sets the seek position of passed sound id.
         * @return {Howl/Number} Returns self or the current seek position.
         */
        seek: function() {
          var self = this;
          var args = arguments;
          var seek, id;
          if (args.length === 0) {
            if (self._sounds.length) {
              id = self._sounds[0]._id;
            }
          } else if (args.length === 1) {
            var ids = self._getSoundIds();
            var index = ids.indexOf(args[0]);
            if (index >= 0) {
              id = parseInt(args[0], 10);
            } else if (self._sounds.length) {
              id = self._sounds[0]._id;
              seek = parseFloat(args[0]);
            }
          } else if (args.length === 2) {
            seek = parseFloat(args[0]);
            id = parseInt(args[1], 10);
          }
          if (typeof id === "undefined") {
            return 0;
          }
          if (typeof seek === "number" && (self._state !== "loaded" || self._playLock)) {
            self._queue.push({
              event: "seek",
              action: function() {
                self.seek.apply(self, args);
              }
            });
            return self;
          }
          var sound = self._soundById(id);
          if (sound) {
            if (typeof seek === "number" && seek >= 0) {
              var playing = self.playing(id);
              if (playing) {
                self.pause(id, true);
              }
              sound._seek = seek;
              sound._ended = false;
              self._clearTimer(id);
              if (!self._webAudio && sound._node && !isNaN(sound._node.duration)) {
                sound._node.currentTime = seek;
              }
              var seekAndEmit = function() {
                if (playing) {
                  self.play(id, true);
                }
                self._emit("seek", id);
              };
              if (playing && !self._webAudio) {
                var emitSeek = function() {
                  if (!self._playLock) {
                    seekAndEmit();
                  } else {
                    setTimeout(emitSeek, 0);
                  }
                };
                setTimeout(emitSeek, 0);
              } else {
                seekAndEmit();
              }
            } else {
              if (self._webAudio) {
                var realTime = self.playing(id) ? Howler3.ctx.currentTime - sound._playStart : 0;
                var rateSeek = sound._rateSeek ? sound._rateSeek - sound._seek : 0;
                return sound._seek + (rateSeek + realTime * Math.abs(sound._rate));
              } else {
                return sound._node.currentTime;
              }
            }
          }
          return self;
        },
        /**
         * Check if a specific sound is currently playing or not (if id is provided), or check if at least one of the sounds in the group is playing or not.
         * @param  {Number}  id The sound id to check. If none is passed, the whole sound group is checked.
         * @return {Boolean} True if playing and false if not.
         */
        playing: function(id) {
          var self = this;
          if (typeof id === "number") {
            var sound = self._soundById(id);
            return sound ? !sound._paused : false;
          }
          for (var i = 0; i < self._sounds.length; i++) {
            if (!self._sounds[i]._paused) {
              return true;
            }
          }
          return false;
        },
        /**
         * Get the duration of this sound. Passing a sound id will return the sprite duration.
         * @param  {Number} id The sound id to check. If none is passed, return full source duration.
         * @return {Number} Audio duration in seconds.
         */
        duration: function(id) {
          var self = this;
          var duration = self._duration;
          var sound = self._soundById(id);
          if (sound) {
            duration = self._sprite[sound._sprite][1] / 1e3;
          }
          return duration;
        },
        /**
         * Returns the current loaded state of this Howl.
         * @return {String} 'unloaded', 'loading', 'loaded'
         */
        state: function() {
          return this._state;
        },
        /**
         * Unload and destroy the current Howl object.
         * This will immediately stop all sound instances attached to this group.
         */
        unload: function() {
          var self = this;
          var sounds = self._sounds;
          for (var i = 0; i < sounds.length; i++) {
            if (!sounds[i]._paused) {
              self.stop(sounds[i]._id);
            }
            if (!self._webAudio) {
              self._clearSound(sounds[i]._node);
              sounds[i]._node.removeEventListener("error", sounds[i]._errorFn, false);
              sounds[i]._node.removeEventListener(Howler3._canPlayEvent, sounds[i]._loadFn, false);
              sounds[i]._node.removeEventListener("ended", sounds[i]._endFn, false);
              Howler3._releaseHtml5Audio(sounds[i]._node);
            }
            delete sounds[i]._node;
            self._clearTimer(sounds[i]._id);
          }
          var index = Howler3._howls.indexOf(self);
          if (index >= 0) {
            Howler3._howls.splice(index, 1);
          }
          var remCache = true;
          for (i = 0; i < Howler3._howls.length; i++) {
            if (Howler3._howls[i]._src === self._src || self._src.indexOf(Howler3._howls[i]._src) >= 0) {
              remCache = false;
              break;
            }
          }
          if (cache && remCache) {
            delete cache[self._src];
          }
          Howler3.noAudio = false;
          self._state = "unloaded";
          self._sounds = [];
          self = null;
          return null;
        },
        /**
         * Listen to a custom event.
         * @param  {String}   event Event name.
         * @param  {Function} fn    Listener to call.
         * @param  {Number}   id    (optional) Only listen to events for this sound.
         * @param  {Number}   once  (INTERNAL) Marks event to fire only once.
         * @return {Howl}
         */
        on: function(event, fn, id, once) {
          var self = this;
          var events = self["_on" + event];
          if (typeof fn === "function") {
            events.push(once ? { id, fn, once } : { id, fn });
          }
          return self;
        },
        /**
         * Remove a custom event. Call without parameters to remove all events.
         * @param  {String}   event Event name.
         * @param  {Function} fn    Listener to remove. Leave empty to remove all.
         * @param  {Number}   id    (optional) Only remove events for this sound.
         * @return {Howl}
         */
        off: function(event, fn, id) {
          var self = this;
          var events = self["_on" + event];
          var i = 0;
          if (typeof fn === "number") {
            id = fn;
            fn = null;
          }
          if (fn || id) {
            for (i = 0; i < events.length; i++) {
              var isId = id === events[i].id;
              if (fn === events[i].fn && isId || !fn && isId) {
                events.splice(i, 1);
                break;
              }
            }
          } else if (event) {
            self["_on" + event] = [];
          } else {
            var keys = Object.keys(self);
            for (i = 0; i < keys.length; i++) {
              if (keys[i].indexOf("_on") === 0 && Array.isArray(self[keys[i]])) {
                self[keys[i]] = [];
              }
            }
          }
          return self;
        },
        /**
         * Listen to a custom event and remove it once fired.
         * @param  {String}   event Event name.
         * @param  {Function} fn    Listener to call.
         * @param  {Number}   id    (optional) Only listen to events for this sound.
         * @return {Howl}
         */
        once: function(event, fn, id) {
          var self = this;
          self.on(event, fn, id, 1);
          return self;
        },
        /**
         * Emit all events of a specific type and pass the sound id.
         * @param  {String} event Event name.
         * @param  {Number} id    Sound ID.
         * @param  {Number} msg   Message to go with event.
         * @return {Howl}
         */
        _emit: function(event, id, msg) {
          var self = this;
          var events = self["_on" + event];
          for (var i = events.length - 1; i >= 0; i--) {
            if (!events[i].id || events[i].id === id || event === "load") {
              setTimeout((function(fn) {
                fn.call(this, id, msg);
              }).bind(self, events[i].fn), 0);
              if (events[i].once) {
                self.off(event, events[i].fn, events[i].id);
              }
            }
          }
          self._loadQueue(event);
          return self;
        },
        /**
         * Queue of actions initiated before the sound has loaded.
         * These will be called in sequence, with the next only firing
         * after the previous has finished executing (even if async like play).
         * @return {Howl}
         */
        _loadQueue: function(event) {
          var self = this;
          if (self._queue.length > 0) {
            var task = self._queue[0];
            if (task.event === event) {
              self._queue.shift();
              self._loadQueue();
            }
            if (!event) {
              task.action();
            }
          }
          return self;
        },
        /**
         * Fired when playback ends at the end of the duration.
         * @param  {Sound} sound The sound object to work with.
         * @return {Howl}
         */
        _ended: function(sound) {
          var self = this;
          var sprite = sound._sprite;
          if (!self._webAudio && sound._node && !sound._node.paused && !sound._node.ended && sound._node.currentTime < sound._stop) {
            setTimeout(self._ended.bind(self, sound), 100);
            return self;
          }
          var loop = !!(sound._loop || self._sprite[sprite][2]);
          self._emit("end", sound._id);
          if (!self._webAudio && loop) {
            self.stop(sound._id, true).play(sound._id);
          }
          if (self._webAudio && loop) {
            self._emit("play", sound._id);
            sound._seek = sound._start || 0;
            sound._rateSeek = 0;
            sound._playStart = Howler3.ctx.currentTime;
            var timeout = (sound._stop - sound._start) * 1e3 / Math.abs(sound._rate);
            self._endTimers[sound._id] = setTimeout(self._ended.bind(self, sound), timeout);
          }
          if (self._webAudio && !loop) {
            sound._paused = true;
            sound._ended = true;
            sound._seek = sound._start || 0;
            sound._rateSeek = 0;
            self._clearTimer(sound._id);
            self._cleanBuffer(sound._node);
            Howler3._autoSuspend();
          }
          if (!self._webAudio && !loop) {
            self.stop(sound._id, true);
          }
          return self;
        },
        /**
         * Clear the end timer for a sound playback.
         * @param  {Number} id The sound ID.
         * @return {Howl}
         */
        _clearTimer: function(id) {
          var self = this;
          if (self._endTimers[id]) {
            if (typeof self._endTimers[id] !== "function") {
              clearTimeout(self._endTimers[id]);
            } else {
              var sound = self._soundById(id);
              if (sound && sound._node) {
                sound._node.removeEventListener("ended", self._endTimers[id], false);
              }
            }
            delete self._endTimers[id];
          }
          return self;
        },
        /**
         * Return the sound identified by this ID, or return null.
         * @param  {Number} id Sound ID
         * @return {Object}    Sound object or null.
         */
        _soundById: function(id) {
          var self = this;
          for (var i = 0; i < self._sounds.length; i++) {
            if (id === self._sounds[i]._id) {
              return self._sounds[i];
            }
          }
          return null;
        },
        /**
         * Return an inactive sound from the pool or create a new one.
         * @return {Sound} Sound playback object.
         */
        _inactiveSound: function() {
          var self = this;
          self._drain();
          for (var i = 0; i < self._sounds.length; i++) {
            if (self._sounds[i]._ended) {
              return self._sounds[i].reset();
            }
          }
          return new Sound2(self);
        },
        /**
         * Drain excess inactive sounds from the pool.
         */
        _drain: function() {
          var self = this;
          var limit = self._pool;
          var cnt = 0;
          var i = 0;
          if (self._sounds.length < limit) {
            return;
          }
          for (i = 0; i < self._sounds.length; i++) {
            if (self._sounds[i]._ended) {
              cnt++;
            }
          }
          for (i = self._sounds.length - 1; i >= 0; i--) {
            if (cnt <= limit) {
              return;
            }
            if (self._sounds[i]._ended) {
              if (self._webAudio && self._sounds[i]._node) {
                self._sounds[i]._node.disconnect(0);
              }
              self._sounds.splice(i, 1);
              cnt--;
            }
          }
        },
        /**
         * Get all ID's from the sounds pool.
         * @param  {Number} id Only return one ID if one is passed.
         * @return {Array}    Array of IDs.
         */
        _getSoundIds: function(id) {
          var self = this;
          if (typeof id === "undefined") {
            var ids = [];
            for (var i = 0; i < self._sounds.length; i++) {
              ids.push(self._sounds[i]._id);
            }
            return ids;
          } else {
            return [id];
          }
        },
        /**
         * Load the sound back into the buffer source.
         * @param  {Sound} sound The sound object to work with.
         * @return {Howl}
         */
        _refreshBuffer: function(sound) {
          var self = this;
          sound._node.bufferSource = Howler3.ctx.createBufferSource();
          sound._node.bufferSource.buffer = cache[self._src];
          if (sound._panner) {
            sound._node.bufferSource.connect(sound._panner);
          } else {
            sound._node.bufferSource.connect(sound._node);
          }
          sound._node.bufferSource.loop = sound._loop;
          if (sound._loop) {
            sound._node.bufferSource.loopStart = sound._start || 0;
            sound._node.bufferSource.loopEnd = sound._stop || 0;
          }
          sound._node.bufferSource.playbackRate.setValueAtTime(sound._rate, Howler3.ctx.currentTime);
          return self;
        },
        /**
         * Prevent memory leaks by cleaning up the buffer source after playback.
         * @param  {Object} node Sound's audio node containing the buffer source.
         * @return {Howl}
         */
        _cleanBuffer: function(node) {
          var self = this;
          var isIOS = Howler3._navigator && Howler3._navigator.vendor.indexOf("Apple") >= 0;
          if (!node.bufferSource) {
            return self;
          }
          if (Howler3._scratchBuffer && node.bufferSource) {
            node.bufferSource.onended = null;
            node.bufferSource.disconnect(0);
            if (isIOS) {
              try {
                node.bufferSource.buffer = Howler3._scratchBuffer;
              } catch (e) {
              }
            }
          }
          node.bufferSource = null;
          return self;
        },
        /**
         * Set the source to a 0-second silence to stop any downloading (except in IE).
         * @param  {Object} node Audio node to clear.
         */
        _clearSound: function(node) {
          var checkIE = /MSIE |Trident\//.test(Howler3._navigator && Howler3._navigator.userAgent);
          if (!checkIE) {
            node.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA";
          }
        }
      };
      var Sound2 = function(howl) {
        this._parent = howl;
        this.init();
      };
      Sound2.prototype = {
        /**
         * Initialize a new Sound object.
         * @return {Sound}
         */
        init: function() {
          var self = this;
          var parent = self._parent;
          self._muted = parent._muted;
          self._loop = parent._loop;
          self._volume = parent._volume;
          self._rate = parent._rate;
          self._seek = 0;
          self._paused = true;
          self._ended = true;
          self._sprite = "__default";
          self._id = ++Howler3._counter;
          parent._sounds.push(self);
          self.create();
          return self;
        },
        /**
         * Create and setup a new sound object, whether HTML5 Audio or Web Audio.
         * @return {Sound}
         */
        create: function() {
          var self = this;
          var parent = self._parent;
          var volume = Howler3._muted || self._muted || self._parent._muted ? 0 : self._volume;
          if (parent._webAudio) {
            self._node = typeof Howler3.ctx.createGain === "undefined" ? Howler3.ctx.createGainNode() : Howler3.ctx.createGain();
            self._node.gain.setValueAtTime(volume, Howler3.ctx.currentTime);
            self._node.paused = true;
            self._node.connect(Howler3.masterGain);
          } else if (!Howler3.noAudio) {
            self._node = Howler3._obtainHtml5Audio();
            self._errorFn = self._errorListener.bind(self);
            self._node.addEventListener("error", self._errorFn, false);
            self._loadFn = self._loadListener.bind(self);
            self._node.addEventListener(Howler3._canPlayEvent, self._loadFn, false);
            self._endFn = self._endListener.bind(self);
            self._node.addEventListener("ended", self._endFn, false);
            self._node.src = parent._src;
            self._node.preload = parent._preload === true ? "auto" : parent._preload;
            self._node.volume = volume * Howler3.volume();
            self._node.load();
          }
          return self;
        },
        /**
         * Reset the parameters of this sound to the original state (for recycle).
         * @return {Sound}
         */
        reset: function() {
          var self = this;
          var parent = self._parent;
          self._muted = parent._muted;
          self._loop = parent._loop;
          self._volume = parent._volume;
          self._rate = parent._rate;
          self._seek = 0;
          self._rateSeek = 0;
          self._paused = true;
          self._ended = true;
          self._sprite = "__default";
          self._id = ++Howler3._counter;
          return self;
        },
        /**
         * HTML5 Audio error listener callback.
         */
        _errorListener: function() {
          var self = this;
          self._parent._emit("loaderror", self._id, self._node.error ? self._node.error.code : 0);
          self._node.removeEventListener("error", self._errorFn, false);
        },
        /**
         * HTML5 Audio canplaythrough listener callback.
         */
        _loadListener: function() {
          var self = this;
          var parent = self._parent;
          parent._duration = Math.ceil(self._node.duration * 10) / 10;
          if (Object.keys(parent._sprite).length === 0) {
            parent._sprite = { __default: [0, parent._duration * 1e3] };
          }
          if (parent._state !== "loaded") {
            parent._state = "loaded";
            parent._emit("load");
            parent._loadQueue();
          }
          self._node.removeEventListener(Howler3._canPlayEvent, self._loadFn, false);
        },
        /**
         * HTML5 Audio ended listener callback.
         */
        _endListener: function() {
          var self = this;
          var parent = self._parent;
          if (parent._duration === Infinity) {
            parent._duration = Math.ceil(self._node.duration * 10) / 10;
            if (parent._sprite.__default[1] === Infinity) {
              parent._sprite.__default[1] = parent._duration * 1e3;
            }
            parent._ended(self);
          }
          self._node.removeEventListener("ended", self._endFn, false);
        }
      };
      var cache = {};
      var loadBuffer = function(self) {
        var url = self._src;
        if (cache[url]) {
          self._duration = cache[url].duration;
          loadSound(self);
          return;
        }
        if (/^data:[^;]+;base64,/.test(url)) {
          var data = atob(url.split(",")[1]);
          var dataView = new Uint8Array(data.length);
          for (var i = 0; i < data.length; ++i) {
            dataView[i] = data.charCodeAt(i);
          }
          decodeAudioData(dataView.buffer, self);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open(self._xhr.method, url, true);
          xhr.withCredentials = self._xhr.withCredentials;
          xhr.responseType = "arraybuffer";
          if (self._xhr.headers) {
            Object.keys(self._xhr.headers).forEach(function(key) {
              xhr.setRequestHeader(key, self._xhr.headers[key]);
            });
          }
          xhr.onload = function() {
            var code = (xhr.status + "")[0];
            if (code !== "0" && code !== "2" && code !== "3") {
              self._emit("loaderror", null, "Failed loading audio file with status: " + xhr.status + ".");
              return;
            }
            decodeAudioData(xhr.response, self);
          };
          xhr.onerror = function() {
            if (self._webAudio) {
              self._html5 = true;
              self._webAudio = false;
              self._sounds = [];
              delete cache[url];
              self.load();
            }
          };
          safeXhrSend(xhr);
        }
      };
      var safeXhrSend = function(xhr) {
        try {
          xhr.send();
        } catch (e) {
          xhr.onerror();
        }
      };
      var decodeAudioData = function(arraybuffer, self) {
        var error = function() {
          self._emit("loaderror", null, "Decoding audio data failed.");
        };
        var success = function(buffer) {
          if (buffer && self._sounds.length > 0) {
            cache[self._src] = buffer;
            loadSound(self, buffer);
          } else {
            error();
          }
        };
        if (typeof Promise !== "undefined" && Howler3.ctx.decodeAudioData.length === 1) {
          Howler3.ctx.decodeAudioData(arraybuffer).then(success).catch(error);
        } else {
          Howler3.ctx.decodeAudioData(arraybuffer, success, error);
        }
      };
      var loadSound = function(self, buffer) {
        if (buffer && !self._duration) {
          self._duration = buffer.duration;
        }
        if (Object.keys(self._sprite).length === 0) {
          self._sprite = { __default: [0, self._duration * 1e3] };
        }
        if (self._state !== "loaded") {
          self._state = "loaded";
          self._emit("load");
          self._loadQueue();
        }
      };
      var setupAudioContext = function() {
        if (!Howler3.usingWebAudio) {
          return;
        }
        try {
          if (typeof AudioContext !== "undefined") {
            Howler3.ctx = new AudioContext();
          } else if (typeof webkitAudioContext !== "undefined") {
            Howler3.ctx = new webkitAudioContext();
          } else {
            Howler3.usingWebAudio = false;
          }
        } catch (e) {
          Howler3.usingWebAudio = false;
        }
        if (!Howler3.ctx) {
          Howler3.usingWebAudio = false;
        }
        var iOS = /iP(hone|od|ad)/.test(Howler3._navigator && Howler3._navigator.platform);
        var appVersion = Howler3._navigator && Howler3._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
        var version = appVersion ? parseInt(appVersion[1], 10) : null;
        if (iOS && version && version < 9) {
          var safari = /safari/.test(Howler3._navigator && Howler3._navigator.userAgent.toLowerCase());
          if (Howler3._navigator && !safari) {
            Howler3.usingWebAudio = false;
          }
        }
        if (Howler3.usingWebAudio) {
          Howler3.masterGain = typeof Howler3.ctx.createGain === "undefined" ? Howler3.ctx.createGainNode() : Howler3.ctx.createGain();
          Howler3.masterGain.gain.setValueAtTime(Howler3._muted ? 0 : Howler3._volume, Howler3.ctx.currentTime);
          Howler3.masterGain.connect(Howler3.ctx.destination);
        }
        Howler3._setup();
      };
      if (typeof define === "function" && define.amd) {
        define([], function() {
          return {
            Howler: Howler3,
            Howl: Howl3
          };
        });
      }
      if (typeof exports !== "undefined") {
        exports.Howler = Howler3;
        exports.Howl = Howl3;
      }
      if (typeof global !== "undefined") {
        global.HowlerGlobal = HowlerGlobal2;
        global.Howler = Howler3;
        global.Howl = Howl3;
        global.Sound = Sound2;
      } else if (typeof window !== "undefined") {
        window.HowlerGlobal = HowlerGlobal2;
        window.Howler = Howler3;
        window.Howl = Howl3;
        window.Sound = Sound2;
      }
    })();
    (function() {
      "use strict";
      HowlerGlobal.prototype._pos = [0, 0, 0];
      HowlerGlobal.prototype._orientation = [0, 0, -1, 0, 1, 0];
      HowlerGlobal.prototype.stereo = function(pan) {
        var self = this;
        if (!self.ctx || !self.ctx.listener) {
          return self;
        }
        for (var i = self._howls.length - 1; i >= 0; i--) {
          self._howls[i].stereo(pan);
        }
        return self;
      };
      HowlerGlobal.prototype.pos = function(x, y, z) {
        var self = this;
        if (!self.ctx || !self.ctx.listener) {
          return self;
        }
        y = typeof y !== "number" ? self._pos[1] : y;
        z = typeof z !== "number" ? self._pos[2] : z;
        if (typeof x === "number") {
          self._pos = [x, y, z];
          if (typeof self.ctx.listener.positionX !== "undefined") {
            self.ctx.listener.positionX.setTargetAtTime(self._pos[0], Howler.ctx.currentTime, 0.1);
            self.ctx.listener.positionY.setTargetAtTime(self._pos[1], Howler.ctx.currentTime, 0.1);
            self.ctx.listener.positionZ.setTargetAtTime(self._pos[2], Howler.ctx.currentTime, 0.1);
          } else {
            self.ctx.listener.setPosition(self._pos[0], self._pos[1], self._pos[2]);
          }
        } else {
          return self._pos;
        }
        return self;
      };
      HowlerGlobal.prototype.orientation = function(x, y, z, xUp, yUp, zUp) {
        var self = this;
        if (!self.ctx || !self.ctx.listener) {
          return self;
        }
        var or = self._orientation;
        y = typeof y !== "number" ? or[1] : y;
        z = typeof z !== "number" ? or[2] : z;
        xUp = typeof xUp !== "number" ? or[3] : xUp;
        yUp = typeof yUp !== "number" ? or[4] : yUp;
        zUp = typeof zUp !== "number" ? or[5] : zUp;
        if (typeof x === "number") {
          self._orientation = [x, y, z, xUp, yUp, zUp];
          if (typeof self.ctx.listener.forwardX !== "undefined") {
            self.ctx.listener.forwardX.setTargetAtTime(x, Howler.ctx.currentTime, 0.1);
            self.ctx.listener.forwardY.setTargetAtTime(y, Howler.ctx.currentTime, 0.1);
            self.ctx.listener.forwardZ.setTargetAtTime(z, Howler.ctx.currentTime, 0.1);
            self.ctx.listener.upX.setTargetAtTime(xUp, Howler.ctx.currentTime, 0.1);
            self.ctx.listener.upY.setTargetAtTime(yUp, Howler.ctx.currentTime, 0.1);
            self.ctx.listener.upZ.setTargetAtTime(zUp, Howler.ctx.currentTime, 0.1);
          } else {
            self.ctx.listener.setOrientation(x, y, z, xUp, yUp, zUp);
          }
        } else {
          return or;
        }
        return self;
      };
      Howl.prototype.init = /* @__PURE__ */ (function(_super) {
        return function(o) {
          var self = this;
          self._orientation = o.orientation || [1, 0, 0];
          self._stereo = o.stereo || null;
          self._pos = o.pos || null;
          self._pannerAttr = {
            coneInnerAngle: typeof o.coneInnerAngle !== "undefined" ? o.coneInnerAngle : 360,
            coneOuterAngle: typeof o.coneOuterAngle !== "undefined" ? o.coneOuterAngle : 360,
            coneOuterGain: typeof o.coneOuterGain !== "undefined" ? o.coneOuterGain : 0,
            distanceModel: typeof o.distanceModel !== "undefined" ? o.distanceModel : "inverse",
            maxDistance: typeof o.maxDistance !== "undefined" ? o.maxDistance : 1e4,
            panningModel: typeof o.panningModel !== "undefined" ? o.panningModel : "HRTF",
            refDistance: typeof o.refDistance !== "undefined" ? o.refDistance : 1,
            rolloffFactor: typeof o.rolloffFactor !== "undefined" ? o.rolloffFactor : 1
          };
          self._onstereo = o.onstereo ? [{ fn: o.onstereo }] : [];
          self._onpos = o.onpos ? [{ fn: o.onpos }] : [];
          self._onorientation = o.onorientation ? [{ fn: o.onorientation }] : [];
          return _super.call(this, o);
        };
      })(Howl.prototype.init);
      Howl.prototype.stereo = function(pan, id) {
        var self = this;
        if (!self._webAudio) {
          return self;
        }
        if (self._state !== "loaded") {
          self._queue.push({
            event: "stereo",
            action: function() {
              self.stereo(pan, id);
            }
          });
          return self;
        }
        var pannerType = typeof Howler.ctx.createStereoPanner === "undefined" ? "spatial" : "stereo";
        if (typeof id === "undefined") {
          if (typeof pan === "number") {
            self._stereo = pan;
            self._pos = [pan, 0, 0];
          } else {
            return self._stereo;
          }
        }
        var ids = self._getSoundIds(id);
        for (var i = 0; i < ids.length; i++) {
          var sound = self._soundById(ids[i]);
          if (sound) {
            if (typeof pan === "number") {
              sound._stereo = pan;
              sound._pos = [pan, 0, 0];
              if (sound._node) {
                sound._pannerAttr.panningModel = "equalpower";
                if (!sound._panner || !sound._panner.pan) {
                  setupPanner(sound, pannerType);
                }
                if (pannerType === "spatial") {
                  if (typeof sound._panner.positionX !== "undefined") {
                    sound._panner.positionX.setValueAtTime(pan, Howler.ctx.currentTime);
                    sound._panner.positionY.setValueAtTime(0, Howler.ctx.currentTime);
                    sound._panner.positionZ.setValueAtTime(0, Howler.ctx.currentTime);
                  } else {
                    sound._panner.setPosition(pan, 0, 0);
                  }
                } else {
                  sound._panner.pan.setValueAtTime(pan, Howler.ctx.currentTime);
                }
              }
              self._emit("stereo", sound._id);
            } else {
              return sound._stereo;
            }
          }
        }
        return self;
      };
      Howl.prototype.pos = function(x, y, z, id) {
        var self = this;
        if (!self._webAudio) {
          return self;
        }
        if (self._state !== "loaded") {
          self._queue.push({
            event: "pos",
            action: function() {
              self.pos(x, y, z, id);
            }
          });
          return self;
        }
        y = typeof y !== "number" ? 0 : y;
        z = typeof z !== "number" ? -0.5 : z;
        if (typeof id === "undefined") {
          if (typeof x === "number") {
            self._pos = [x, y, z];
          } else {
            return self._pos;
          }
        }
        var ids = self._getSoundIds(id);
        for (var i = 0; i < ids.length; i++) {
          var sound = self._soundById(ids[i]);
          if (sound) {
            if (typeof x === "number") {
              sound._pos = [x, y, z];
              if (sound._node) {
                if (!sound._panner || sound._panner.pan) {
                  setupPanner(sound, "spatial");
                }
                if (typeof sound._panner.positionX !== "undefined") {
                  sound._panner.positionX.setValueAtTime(x, Howler.ctx.currentTime);
                  sound._panner.positionY.setValueAtTime(y, Howler.ctx.currentTime);
                  sound._panner.positionZ.setValueAtTime(z, Howler.ctx.currentTime);
                } else {
                  sound._panner.setPosition(x, y, z);
                }
              }
              self._emit("pos", sound._id);
            } else {
              return sound._pos;
            }
          }
        }
        return self;
      };
      Howl.prototype.orientation = function(x, y, z, id) {
        var self = this;
        if (!self._webAudio) {
          return self;
        }
        if (self._state !== "loaded") {
          self._queue.push({
            event: "orientation",
            action: function() {
              self.orientation(x, y, z, id);
            }
          });
          return self;
        }
        y = typeof y !== "number" ? self._orientation[1] : y;
        z = typeof z !== "number" ? self._orientation[2] : z;
        if (typeof id === "undefined") {
          if (typeof x === "number") {
            self._orientation = [x, y, z];
          } else {
            return self._orientation;
          }
        }
        var ids = self._getSoundIds(id);
        for (var i = 0; i < ids.length; i++) {
          var sound = self._soundById(ids[i]);
          if (sound) {
            if (typeof x === "number") {
              sound._orientation = [x, y, z];
              if (sound._node) {
                if (!sound._panner) {
                  if (!sound._pos) {
                    sound._pos = self._pos || [0, 0, -0.5];
                  }
                  setupPanner(sound, "spatial");
                }
                if (typeof sound._panner.orientationX !== "undefined") {
                  sound._panner.orientationX.setValueAtTime(x, Howler.ctx.currentTime);
                  sound._panner.orientationY.setValueAtTime(y, Howler.ctx.currentTime);
                  sound._panner.orientationZ.setValueAtTime(z, Howler.ctx.currentTime);
                } else {
                  sound._panner.setOrientation(x, y, z);
                }
              }
              self._emit("orientation", sound._id);
            } else {
              return sound._orientation;
            }
          }
        }
        return self;
      };
      Howl.prototype.pannerAttr = function() {
        var self = this;
        var args = arguments;
        var o, id, sound;
        if (!self._webAudio) {
          return self;
        }
        if (args.length === 0) {
          return self._pannerAttr;
        } else if (args.length === 1) {
          if (typeof args[0] === "object") {
            o = args[0];
            if (typeof id === "undefined") {
              if (!o.pannerAttr) {
                o.pannerAttr = {
                  coneInnerAngle: o.coneInnerAngle,
                  coneOuterAngle: o.coneOuterAngle,
                  coneOuterGain: o.coneOuterGain,
                  distanceModel: o.distanceModel,
                  maxDistance: o.maxDistance,
                  refDistance: o.refDistance,
                  rolloffFactor: o.rolloffFactor,
                  panningModel: o.panningModel
                };
              }
              self._pannerAttr = {
                coneInnerAngle: typeof o.pannerAttr.coneInnerAngle !== "undefined" ? o.pannerAttr.coneInnerAngle : self._coneInnerAngle,
                coneOuterAngle: typeof o.pannerAttr.coneOuterAngle !== "undefined" ? o.pannerAttr.coneOuterAngle : self._coneOuterAngle,
                coneOuterGain: typeof o.pannerAttr.coneOuterGain !== "undefined" ? o.pannerAttr.coneOuterGain : self._coneOuterGain,
                distanceModel: typeof o.pannerAttr.distanceModel !== "undefined" ? o.pannerAttr.distanceModel : self._distanceModel,
                maxDistance: typeof o.pannerAttr.maxDistance !== "undefined" ? o.pannerAttr.maxDistance : self._maxDistance,
                refDistance: typeof o.pannerAttr.refDistance !== "undefined" ? o.pannerAttr.refDistance : self._refDistance,
                rolloffFactor: typeof o.pannerAttr.rolloffFactor !== "undefined" ? o.pannerAttr.rolloffFactor : self._rolloffFactor,
                panningModel: typeof o.pannerAttr.panningModel !== "undefined" ? o.pannerAttr.panningModel : self._panningModel
              };
            }
          } else {
            sound = self._soundById(parseInt(args[0], 10));
            return sound ? sound._pannerAttr : self._pannerAttr;
          }
        } else if (args.length === 2) {
          o = args[0];
          id = parseInt(args[1], 10);
        }
        var ids = self._getSoundIds(id);
        for (var i = 0; i < ids.length; i++) {
          sound = self._soundById(ids[i]);
          if (sound) {
            var pa = sound._pannerAttr;
            pa = {
              coneInnerAngle: typeof o.coneInnerAngle !== "undefined" ? o.coneInnerAngle : pa.coneInnerAngle,
              coneOuterAngle: typeof o.coneOuterAngle !== "undefined" ? o.coneOuterAngle : pa.coneOuterAngle,
              coneOuterGain: typeof o.coneOuterGain !== "undefined" ? o.coneOuterGain : pa.coneOuterGain,
              distanceModel: typeof o.distanceModel !== "undefined" ? o.distanceModel : pa.distanceModel,
              maxDistance: typeof o.maxDistance !== "undefined" ? o.maxDistance : pa.maxDistance,
              refDistance: typeof o.refDistance !== "undefined" ? o.refDistance : pa.refDistance,
              rolloffFactor: typeof o.rolloffFactor !== "undefined" ? o.rolloffFactor : pa.rolloffFactor,
              panningModel: typeof o.panningModel !== "undefined" ? o.panningModel : pa.panningModel
            };
            var panner = sound._panner;
            if (!panner) {
              if (!sound._pos) {
                sound._pos = self._pos || [0, 0, -0.5];
              }
              setupPanner(sound, "spatial");
              panner = sound._panner;
            }
            panner.coneInnerAngle = pa.coneInnerAngle;
            panner.coneOuterAngle = pa.coneOuterAngle;
            panner.coneOuterGain = pa.coneOuterGain;
            panner.distanceModel = pa.distanceModel;
            panner.maxDistance = pa.maxDistance;
            panner.refDistance = pa.refDistance;
            panner.rolloffFactor = pa.rolloffFactor;
            panner.panningModel = pa.panningModel;
          }
        }
        return self;
      };
      Sound.prototype.init = /* @__PURE__ */ (function(_super) {
        return function() {
          var self = this;
          var parent = self._parent;
          self._orientation = parent._orientation;
          self._stereo = parent._stereo;
          self._pos = parent._pos;
          self._pannerAttr = parent._pannerAttr;
          _super.call(this);
          if (self._stereo) {
            parent.stereo(self._stereo);
          } else if (self._pos) {
            parent.pos(self._pos[0], self._pos[1], self._pos[2], self._id);
          }
        };
      })(Sound.prototype.init);
      Sound.prototype.reset = /* @__PURE__ */ (function(_super) {
        return function() {
          var self = this;
          var parent = self._parent;
          self._orientation = parent._orientation;
          self._stereo = parent._stereo;
          self._pos = parent._pos;
          self._pannerAttr = parent._pannerAttr;
          if (self._stereo) {
            parent.stereo(self._stereo);
          } else if (self._pos) {
            parent.pos(self._pos[0], self._pos[1], self._pos[2], self._id);
          } else if (self._panner) {
            self._panner.disconnect(0);
            self._panner = void 0;
            parent._refreshBuffer(self);
          }
          return _super.call(this);
        };
      })(Sound.prototype.reset);
      var setupPanner = function(sound, type) {
        type = type || "spatial";
        if (type === "spatial") {
          sound._panner = Howler.ctx.createPanner();
          sound._panner.coneInnerAngle = sound._pannerAttr.coneInnerAngle;
          sound._panner.coneOuterAngle = sound._pannerAttr.coneOuterAngle;
          sound._panner.coneOuterGain = sound._pannerAttr.coneOuterGain;
          sound._panner.distanceModel = sound._pannerAttr.distanceModel;
          sound._panner.maxDistance = sound._pannerAttr.maxDistance;
          sound._panner.refDistance = sound._pannerAttr.refDistance;
          sound._panner.rolloffFactor = sound._pannerAttr.rolloffFactor;
          sound._panner.panningModel = sound._pannerAttr.panningModel;
          if (typeof sound._panner.positionX !== "undefined") {
            sound._panner.positionX.setValueAtTime(sound._pos[0], Howler.ctx.currentTime);
            sound._panner.positionY.setValueAtTime(sound._pos[1], Howler.ctx.currentTime);
            sound._panner.positionZ.setValueAtTime(sound._pos[2], Howler.ctx.currentTime);
          } else {
            sound._panner.setPosition(sound._pos[0], sound._pos[1], sound._pos[2]);
          }
          if (typeof sound._panner.orientationX !== "undefined") {
            sound._panner.orientationX.setValueAtTime(sound._orientation[0], Howler.ctx.currentTime);
            sound._panner.orientationY.setValueAtTime(sound._orientation[1], Howler.ctx.currentTime);
            sound._panner.orientationZ.setValueAtTime(sound._orientation[2], Howler.ctx.currentTime);
          } else {
            sound._panner.setOrientation(sound._orientation[0], sound._orientation[1], sound._orientation[2]);
          }
        } else {
          sound._panner = Howler.ctx.createStereoPanner();
          sound._panner.pan.setValueAtTime(sound._stereo, Howler.ctx.currentTime);
        }
        sound._panner.connect(sound._node);
        if (!sound._paused) {
          sound._parent.pause(sound._id, true).play(sound._id, true);
        }
      };
    })();
  }
});

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-TGRTEWYV.js
var createActionError = (meta, message) => new Error(
  `[${meta.contractKind ?? "action"}:${meta.gameId}.${meta.actionName}] ${message}`
);
var createAgentActionMetadata = (payload, options) => ({
  description: options == null ? void 0 : options.description,
  payload: {
    ...payload,
    description: (options == null ? void 0 : options.payloadDescription) ?? payload.description
  },
  resultDescription: options == null ? void 0 : options.resultDescription
});
var defineAgentActionInput = (parse, metadata) => ({
  parse,
  metadata
});
var parseFiniteNumber = (payload, meta) => {
  const nextValue = typeof payload === "number" && Number.isFinite(payload) ? payload : typeof payload === "string" ? Number(payload) : Number.NaN;
  if (!Number.isFinite(nextValue)) {
    throw createActionError(meta, "expected a finite number payload");
  }
  return nextValue;
};
var parseStringValue = (payload, meta) => {
  if (typeof payload !== "string") {
    throw createActionError(meta, "expected a string payload");
  }
  return payload;
};
var parseBooleanValue = (payload, meta) => {
  if (typeof payload === "boolean") {
    return payload;
  }
  if (payload === "true" || payload === "1") {
    return true;
  }
  if (payload === "false" || payload === "0") {
    return false;
  }
  throw createActionError(meta, "expected a boolean payload");
};
var parseEnumValue = (values, payload, meta) => {
  if (typeof payload !== "string" || !values.includes(payload)) {
    throw createActionError(meta, `expected one of: ${values.join(", ")}`);
  }
  return payload;
};
var noneInput = (options) => defineAgentActionInput(
  () => void 0,
  createAgentActionMetadata({ kind: "none" }, options)
);
var numberInput = (options) => defineAgentActionInput(
  parseFiniteNumber,
  createAgentActionMetadata({ kind: "number" }, options)
);
var stringInput = (options) => defineAgentActionInput(
  parseStringValue,
  createAgentActionMetadata({ kind: "string" }, options)
);
var booleanInput = (options) => defineAgentActionInput(
  parseBooleanValue,
  createAgentActionMetadata({ kind: "boolean" }, options)
);
var enumInput = (values, options) => defineAgentActionInput(
  (payload, meta) => parseEnumValue(values, payload, meta),
  createAgentActionMetadata(
    {
      kind: "enum",
      allowedValues: [...values]
    },
    options
  )
);
var jsonInput = (options) => defineAgentActionInput(
  (payload) => payload,
  createAgentActionMetadata({ kind: "json" }, options)
);
function customInput(optionsOrParse, maybeParse) {
  if (typeof optionsOrParse === "function") {
    return defineAgentActionInput(
      optionsOrParse,
      createAgentActionMetadata({ kind: "json" })
    );
  }
  if (typeof maybeParse === "function") {
    return defineAgentActionInput(
      maybeParse,
      createAgentActionMetadata(
        {
          kind: optionsOrParse.payloadKind ?? "json",
          allowedValues: optionsOrParse.allowedValues
        },
        optionsOrParse
      )
    );
  }
  throw new Error("Invalid agent action input definition.");
}
var zodInput = (schema, options) => defineAgentActionInput(
  (payload, meta) => {
    const result = schema.safeParse(payload);
    if (result.success) {
      return result.data;
    }
    const firstIssue = result.error.issues[0];
    throw createActionError(
      meta,
      (firstIssue == null ? void 0 : firstIssue.message) ?? "payload failed schema validation"
    );
  },
  createAgentActionMetadata({ kind: "json" }, options)
);
var agentActionInput = {
  none: noneInput,
  number: numberInput,
  string: stringInput,
  boolean: booleanInput,
  enum: enumInput,
  json: jsonInput,
  custom: customInput,
  zod: zodInput
};
var agentStore = () => ({});
var defineAirJamAgentStores = (stores) => stores;
var agentAction = {
  participant: (target, options) => ({
    target: {
      kind: "participant",
      actionName: target.actionName,
      ...target.storeDomain ? { storeDomain: target.storeDomain } : {}
    },
    description: options.description,
    availability: options.availability,
    input: options.input,
    toPayload: options.toPayload,
    resultDescription: options.resultDescription
  }),
  host: (target, options) => ({
    target: {
      kind: "host",
      actionName: target.actionName,
      ...target.storeDomain ? { storeDomain: target.storeDomain } : {}
    },
    description: options.description,
    availability: options.availability,
    input: options.input,
    toPayload: options.toPayload,
    resultDescription: options.resultDescription
  })
};
var defineAirJamAgentContract = (contract) => contract;

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-6CMB356F.js
var AIRJAM_HOST_BRIDGE_REQUEST = "AIRJAM_HOST_BRIDGE_REQUEST";
var AIRJAM_HOST_BRIDGE_ATTACH = "AIRJAM_HOST_BRIDGE_ATTACH";
var AIRJAM_HOST_BRIDGE_EVENT = "AIRJAM_HOST_BRIDGE_EVENT";
var AIRJAM_HOST_BRIDGE_EMIT = "AIRJAM_HOST_BRIDGE_EMIT";
var AIRJAM_HOST_BRIDGE_CLOSE = "AIRJAM_HOST_BRIDGE_CLOSE";
var AIRJAM_HOST_BRIDGE_RESPONSE = "AIRJAM_HOST_BRIDGE_RESPONSE";
var hostBridgeClientEvents = [
  "host:state",
  "host:signal",
  "host:play_sound",
  "host:system",
  "host:state_sync"
];
var hostBridgeServerEvents = [
  "connect",
  "disconnect",
  "airjam:state_sync_request",
  "server:controllerJoined",
  "server:controllerLeft",
  "server:playerUpdated",
  "server:input",
  "server:error",
  "server:state",
  "server:hostLeft",
  "server:playSound",
  "airjam:action_rpc",
  "server:closeChild"
];
var hostBridgeRequestSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_HOST_BRIDGE_REQUEST),
  payload: external_exports.object({
    handshake: v2HandshakeSchema,
    roomId: external_exports.string().min(1),
    capabilityToken: external_exports.string().min(1),
    arcadeSurface: arcadeSurfaceRuntimeIdentitySchema
  }).strict()
}).strict();
var hostBridgeAttachSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_HOST_BRIDGE_ATTACH),
  payload: external_exports.object({
    handshake: v2HandshakeSchema,
    snapshot: external_exports.object({
      roomId: external_exports.string().min(1),
      capabilityToken: external_exports.string().min(1),
      connected: external_exports.boolean(),
      socketId: external_exports.string().optional(),
      players: external_exports.array(external_exports.unknown()),
      state: external_exports.unknown().optional(),
      arcadeSurface: arcadeSurfaceRuntimeIdentitySchema
    }).strict()
  }).strict()
}).strict();
var hostBridgeEventSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_HOST_BRIDGE_EVENT),
  payload: external_exports.object({
    event: external_exports.enum(hostBridgeServerEvents),
    args: external_exports.array(external_exports.unknown()),
    requestId: external_exports.string().min(1).optional()
  }).strict()
}).strict();
var hostBridgeEmitSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_HOST_BRIDGE_EMIT),
  payload: external_exports.object({
    event: external_exports.enum(hostBridgeClientEvents),
    args: external_exports.array(external_exports.unknown()),
    requestId: external_exports.string().min(1).optional()
  }).strict()
}).strict();
var hostBridgeResponseSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_HOST_BRIDGE_RESPONSE),
  payload: external_exports.object({
    requestId: external_exports.string().min(1),
    ack: external_exports.unknown()
  }).strict()
}).strict();
var hostBridgeCloseSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_HOST_BRIDGE_CLOSE),
  payload: external_exports.object({
    reason: external_exports.string().optional()
  }).strict()
}).strict();
var createHostBridgeRequestMessage = (payload) => ({
  type: AIRJAM_HOST_BRIDGE_REQUEST,
  payload: {
    handshake: createBridgeHandshake({
      sdkVersion: AIR_JAM_SDK_VERSION,
      runtimeKind: "arcade-host-iframe",
      capabilityFlags: {
        hostBridge: true
      }
    }),
    roomId: payload.roomId,
    capabilityToken: payload.capabilityToken,
    arcadeSurface: payload.arcadeSurface
  }
});
var splitHostBridgeArgs = (args) => {
  const maybeOptions = args[args.length - 1];
  const hasOptions = typeof maybeOptions === "object" && maybeOptions !== null && "requestId" in maybeOptions;
  return {
    eventArgs: hasOptions ? args.slice(0, -1) : args,
    ...hasOptions && maybeOptions.requestId ? { requestId: maybeOptions.requestId } : {}
  };
};
var createHostBridgeEmitMessage = (event, ...args) => {
  const { eventArgs, requestId } = splitHostBridgeArgs(args);
  return {
    type: AIRJAM_HOST_BRIDGE_EMIT,
    payload: {
      event,
      args: eventArgs,
      ...requestId ? { requestId } : {}
    }
  };
};
var createHostBridgeResponseMessage = (requestId, ack) => ({
  type: AIRJAM_HOST_BRIDGE_RESPONSE,
  payload: {
    requestId,
    ack
  }
});
var createHostBridgeCloseMessage = (reason) => ({
  type: AIRJAM_HOST_BRIDGE_CLOSE,
  payload: {
    reason
  }
});
var parseHostBridgeAttachMessage = (value) => {
  const result = hostBridgeAttachSchema.safeParse(value);
  return result.success ? result.data : null;
};
var parseHostBridgeEventMessage = (value) => {
  const result = hostBridgeEventSchema.safeParse(value);
  return result.success ? result.data : null;
};
var parseHostBridgeResponseMessage = (value) => {
  const result = hostBridgeResponseSchema.safeParse(value);
  return result.success ? result.data : null;
};
var parseHostBridgeCloseMessage = (value) => {
  const result = hostBridgeCloseSchema.safeParse(value);
  return result.success ? result.data : null;
};

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-YXHH3MQT.js
var isVirtualNetwork = (ip) => {
  if (ip.startsWith("192.168.64.") || ip.startsWith("192.168.65.")) {
    return true;
  }
  if (ip.startsWith("172.17.")) {
    return true;
  }
  if (ip.startsWith("172.18.") || ip.startsWith("172.19.")) {
    return true;
  }
  if (ip.startsWith("169.254.")) {
    return true;
  }
  return false;
};
var scoreIp = (ip) => {
  if (ip.startsWith("192.168.")) {
    const parts = ip.split(".");
    const thirdOctet = parseInt(parts[2] || "0", 10);
    if (thirdOctet < 64) {
      return 100 - thirdOctet;
    }
    return 10;
  }
  if (ip.startsWith("10.")) {
    return 50;
  }
  if (/^172\.(1[6-9]|2[0-9]|3[01])\./.test(ip)) {
    return 30;
  }
  return 0;
};
var getLocalNetworkIp = () => {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || typeof RTCPeerConnection === "undefined") {
      resolve(null);
      return;
    }
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
    });
    const candidates = [];
    let candidateGatheringComplete = false;
    const resolveOnce = (ip) => {
      pc.close();
      resolve(ip);
    };
    const timeout = setTimeout(() => {
      if (candidateGatheringComplete) {
        pickBestCandidate();
      } else {
        setTimeout(() => {
          pickBestCandidate();
        }, 500);
      }
    }, 3e3);
    const pickBestCandidate = () => {
      if (candidates.length === 0) {
        resolveOnce(null);
        return;
      }
      candidates.sort((a, b) => b.score - a.score);
      const best = candidates[0];
      clearTimeout(timeout);
      resolveOnce(best.ip);
    };
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        const candidate = event.candidate.candidate;
        const match = candidate.match(/([0-9]{1,3}(\.[0-9]{1,3}){3})/);
        if (match) {
          const ip = match[1];
          if (ip === "127.0.0.1") {
            return;
          }
          const isPrivate = ip.startsWith("192.168.") || ip.startsWith("10.") || /^172\.(1[6-9]|2[0-9]|3[01])\./.test(ip);
          if (isPrivate && !isVirtualNetwork(ip)) {
            const score = scoreIp(ip);
            candidates.push({ ip, score });
          }
        }
      } else {
        candidateGatheringComplete = true;
        setTimeout(() => {
          pickBestCandidate();
        }, 200);
      }
    };
    pc.createDataChannel("");
    pc.createOffer().then((offer) => pc.setLocalDescription(offer)).catch(() => {
      clearTimeout(timeout);
      resolveOnce(null);
    });
  });
};
var UrlBuilder = class {
  constructor() {
    __publicField(this, "cachedLocalIp", null);
    __publicField(this, "ipDetectionPromise", null);
  }
  /**
   * Get the local network IP address with caching.
   * First call triggers detection, subsequent calls return cached value.
   */
  async getLocalIp() {
    if (this.cachedLocalIp !== null) {
      return this.cachedLocalIp;
    }
    if (this.ipDetectionPromise !== null) {
      return this.ipDetectionPromise;
    }
    this.ipDetectionPromise = getLocalNetworkIp().then((ip) => {
      this.cachedLocalIp = ip;
      this.ipDetectionPromise = null;
      return ip;
    });
    return this.ipDetectionPromise;
  }
  /**
   * Clear the cached IP address.
   * Useful for testing or when network changes are detected.
   */
  clearCache() {
    this.cachedLocalIp = null;
    this.ipDetectionPromise = null;
  }
  /**
   * Normalize a URL for mobile access.
   * Replaces localhost with the local network IP.
   */
  async normalizeForMobile(url) {
    if (typeof window === "undefined") return url;
    try {
      const urlObj = new URL(url);
      if (urlObj.hostname === "localhost" || urlObj.hostname === "127.0.0.1") {
        const localIp = await this.getLocalIp();
        if (localIp) {
          urlObj.hostname = localIp;
          return urlObj.toString();
        }
        urlObj.hostname = window.location.hostname;
        return urlObj.toString();
      }
      return url;
    } catch {
      return url;
    }
  }
  /**
   * Build a controller URL with room code.
   * Controller is always at {baseUrl}/controller (standardized convention).
   * Automatically uses local IP when running on localhost.
   */
  async buildControllerUrl(roomId, options) {
    const path = CONTROLLER_PATH;
    if (options == null ? void 0 : options.host) {
      const url2 = new URL(path, this.normalizeOrigin(options.host));
      url2.searchParams.set("room", roomId);
      if (options.capabilityToken) {
        url2.searchParams.set("aj_controller_cap", options.capabilityToken);
      }
      return url2.toString();
    }
    let base;
    if (typeof window === "undefined") {
      base = `http://localhost:${DEFAULT_SERVER_PORT}`;
    } else {
      const currentUrl = new URL(window.location.href);
      if (!this.isLocalhost(currentUrl.hostname)) {
        base = currentUrl.origin;
      } else {
        const localIp = await this.getLocalIp();
        if (localIp) {
          const port = currentUrl.port;
          base = port ? `http://${localIp}:${port}` : `http://${localIp}`;
        } else {
          base = currentUrl.origin;
        }
      }
    }
    const url = new URL(path, base);
    url.searchParams.set("room", roomId);
    if (options == null ? void 0 : options.capabilityToken) {
      url.searchParams.set("aj_controller_cap", options.capabilityToken);
    }
    return url.toString();
  }
  /**
   * Resolve the server URL.
   * Uses explicit URL if provided, otherwise infers from window location.
   */
  resolveServerUrl(explicit) {
    if (explicit) {
      return this.normalizeOrigin(explicit);
    }
    if (typeof window !== "undefined") {
      const url = new URL(window.location.href);
      url.port = String(DEFAULT_SERVER_PORT);
      return url.origin;
    }
    return `http://localhost:${DEFAULT_SERVER_PORT}`;
  }
  /**
   * Check if a hostname is localhost.
   */
  isLocalhost(hostname) {
    return hostname === "localhost" || hostname === "127.0.0.1" || hostname === "[::1]";
  }
  /**
   * Normalize an origin string to ensure it has a protocol.
   */
  normalizeOrigin(origin) {
    if (!origin.includes("://")) {
      return `http://${origin}`;
    }
    return origin;
  }
};
var urlBuilder = new UrlBuilder();

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/index.js
var import_react = __toESM(require_react());
var import_howler = __toESM(require_howler());
var import_jsx_runtime = __toESM(require_jsx_runtime());
var import_react2 = __toESM(require_react());
var import_react3 = __toESM(require_react());
var import_react4 = __toESM(require_react());
var import_react5 = __toESM(require_react());
var import_react6 = __toESM(require_react());
var import_react7 = __toESM(require_react());
var import_react8 = __toESM(require_react());
var import_react9 = __toESM(require_react());
var import_react10 = __toESM(require_react());
var import_react11 = __toESM(require_react());
var import_jsx_runtime2 = __toESM(require_jsx_runtime());
var import_react12 = __toESM(require_react());
var import_react13 = __toESM(require_react());
var import_jsx_runtime3 = __toESM(require_jsx_runtime());
var import_react14 = __toESM(require_react());
var import_jsx_runtime4 = __toESM(require_jsx_runtime());
var import_jsx_runtime5 = __toESM(require_jsx_runtime());
var import_react15 = __toESM(require_react());
var validateArcadeBridgeAttachEpoch = (lastEpoch, identity) => {
  if (lastEpoch !== null && identity.epoch < lastEpoch) {
    return { ok: false };
  }
  return { ok: true, nextLast: identity.epoch };
};
var BRIDGE_HANDSHAKE_TIMEOUT_MS = 2e3;
var BRIDGE_ACK_TIMEOUT_MS = 5e3;
var CONTROLLER_BRIDGE_RUNTIME_KIND = "arcade-controller-runtime";
var BRIDGE_TRANSIENT_CLOSE_REASONS = /* @__PURE__ */ new Set(["game_unloaded", "replaced"]);
var BRIDGE_TRANSIENT_FAILURE_REASONS = /* @__PURE__ */ new Set(["handshake_timeout"]);
var normalizeControllerEmitArgs = (event, args) => {
  if (event !== "controller:action_rpc") {
    return args;
  }
  const [payload, ...rest] = args;
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return args;
  }
  const actionPayload = payload;
  if (actionPayload.payload !== null) {
    return args;
  }
  return [{ ...actionPayload, payload: void 0 }, ...rest];
};
var DirectControllerRealtimeClient = class {
  constructor(socket) {
    this.socket = socket;
  }
  get connected() {
    return this.socket.connected;
  }
  get id() {
    return this.socket.id;
  }
  connect() {
    this.socket.connect();
    return this;
  }
  disconnect() {
    this.socket.disconnect();
    return this;
  }
  on(event, listener) {
    this.socket.on(event, listener);
    return this;
  }
  off(event, listener) {
    if (!listener) {
      this.socket.off(event);
      return this;
    }
    this.socket.off(event, listener);
    return this;
  }
  emit(event, ...args) {
    this.socket.emit.call(this.socket, event, ...normalizeControllerEmitArgs(event, args));
    return this;
  }
  emitWithAck(event, ...args) {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(
          new Error(
            `Timed out waiting for acknowledgement for realtime event "${event}".`
          )
        );
      }, BRIDGE_ACK_TIMEOUT_MS);
      this.socket.emit.call(
        this.socket,
        event,
        ...normalizeControllerEmitArgs(event, args),
        (ack) => {
          clearTimeout(timeoutId);
          resolve(ack);
        }
      );
    });
  }
};
var EmbeddedControllerBridgeClient = class {
  constructor() {
    __publicField(this, "connected", false);
    __publicField(this, "id");
    __publicField(this, "listeners", /* @__PURE__ */ new Map());
    __publicField(this, "port", null);
    __publicField(this, "connectTimeout", null);
    __publicField(this, "reconnectTimeout", null);
    __publicField(this, "requested", false);
    __publicField(this, "lastAttachedArcadeEpoch", null);
    __publicField(this, "allowReconnect", true);
    __publicField(this, "pendingAcks", /* @__PURE__ */ new Map());
  }
  connect() {
    var _a, _b;
    const runtimeParams = readEmbeddedControllerRuntimeParams();
    if (!runtimeParams || typeof window === "undefined") {
      this.fail("Embedded controller bridge runtime params missing.", {
        reason: "runtime_params_missing"
      });
      return this;
    }
    if (this.connected || this.requested) {
      return this;
    }
    this.allowReconnect = true;
    this.clearReconnectTimeout();
    this.clearPort(false);
    this.requested = true;
    const channel = new MessageChannel();
    this.port = channel.port1;
    this.port.onmessage = (event) => {
      this.handlePortMessage(event.data);
    };
    (_b = (_a = this.port).start) == null ? void 0 : _b.call(_a);
    this.connectTimeout = setTimeout(() => {
      this.fail("Embedded controller bridge handshake timed out.", {
        reason: "handshake_timeout",
        runtimeParams
      });
    }, BRIDGE_HANDSHAKE_TIMEOUT_MS);
    window.parent.postMessage(
      createControllerBridgeRequestMessage({
        roomId: runtimeParams.room,
        controllerId: runtimeParams.controllerId,
        arcadeSurface: runtimeParams.arcadeSurface
      }),
      "*",
      [channel.port2]
    );
    this.emitRuntimeEvent(
      AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeRequested,
      "Embedded controller bridge requested",
      "info",
      runtimeParams,
      {
        gameId: runtimeParams.arcadeSurface.gameId,
        surfaceKind: runtimeParams.arcadeSurface.kind
      }
    );
    return this;
  }
  disconnect() {
    this.allowReconnect = false;
    this.clearReconnectTimeout();
    if (this.port) {
      this.port.postMessage(createControllerBridgeCloseMessage("detached"));
    }
    this.clearPort(true, "detached");
    return this;
  }
  on(event, listener) {
    const eventKey = String(event);
    const current = this.listeners.get(eventKey) ?? /* @__PURE__ */ new Set();
    current.add(listener);
    this.listeners.set(eventKey, current);
    return this;
  }
  off(event, listener) {
    const eventKey = String(event);
    const current = this.listeners.get(eventKey);
    if (!current) {
      return this;
    }
    if (!listener) {
      this.listeners.delete(eventKey);
      return this;
    }
    current.delete(listener);
    if (current.size === 0) {
      this.listeners.delete(eventKey);
    }
    return this;
  }
  emit(event, ...args) {
    if (!this.port || !this.connected) {
      return this;
    }
    const bridgeEvent = event;
    const normalizedArgs = normalizeControllerEmitArgs(event, args);
    this.port.postMessage(
      createControllerBridgeEmitMessage(
        bridgeEvent,
        ...normalizedArgs
      )
    );
    return this;
  }
  emitWithAck(event, ...args) {
    var _a, _b;
    if (!this.port || !this.connected) {
      return Promise.reject(
        new Error(
          `Cannot emit acknowledged realtime event "${event}" because the embedded controller bridge is not connected.`
        )
      );
    }
    const requestId = ((_b = (_a = globalThis.crypto) == null ? void 0 : _a.randomUUID) == null ? void 0 : _b.call(_a)) ?? `ack-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      var _a2;
      const timeoutId = setTimeout(() => {
        this.pendingAcks.delete(requestId);
        reject(
          new Error(
            `Timed out waiting for acknowledgement for bridge event "${event}".`
          )
        );
      }, BRIDGE_ACK_TIMEOUT_MS);
      this.pendingAcks.set(requestId, {
        resolve: (ack) => resolve(ack),
        reject,
        timeoutId
      });
      const bridgeEvent = event;
      const normalizedArgs = normalizeControllerEmitArgs(event, args);
      (_a2 = this.port) == null ? void 0 : _a2.postMessage(
        createControllerBridgeEmitMessage(
          bridgeEvent,
          ...normalizedArgs,
          { requestId }
        )
      );
    });
  }
  handlePortMessage(message) {
    const responseMessage = parseControllerBridgeResponseMessage(message);
    if (responseMessage) {
      const pending = this.pendingAcks.get(responseMessage.payload.requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timeoutId);
      this.pendingAcks.delete(responseMessage.payload.requestId);
      pending.resolve(responseMessage.payload.ack);
      return;
    }
    const attachMessage = parseControllerBridgeAttachMessage(message);
    if (attachMessage) {
      if (attachMessage.payload.handshake.runtimeKind !== "arcade-controller-runtime" || attachMessage.payload.handshake.capabilityFlags.controllerBridge !== true) {
        this.fail("Embedded controller bridge handshake rejected.", {
          reason: "handshake_rejected",
          runtimeParams: readEmbeddedControllerRuntimeParams()
        });
        return;
      }
      const snapshot = attachMessage.payload.snapshot;
      const epochResult = validateArcadeBridgeAttachEpoch(
        this.lastAttachedArcadeEpoch,
        snapshot.arcadeSurface
      );
      if (!epochResult.ok) {
        this.fail(
          "Embedded controller bridge attach rejected: stale arcade surface epoch.",
          {
            reason: "stale_arcade_surface_epoch",
            runtimeParams: readEmbeddedControllerRuntimeParams(),
            data: {
              attachedEpoch: snapshot.arcadeSurface.epoch,
              previousEpoch: this.lastAttachedArcadeEpoch
            }
          }
        );
        return;
      }
      this.lastAttachedArcadeEpoch = epochResult.nextLast;
      this.emitRuntimeEvent(
        AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeAttached,
        "Embedded controller bridge attached",
        "info",
        readEmbeddedControllerRuntimeParams(),
        {
          connected: snapshot.connected,
          socketId: snapshot.socketId,
          hasPlayer: Boolean(snapshot.player)
        }
      );
      this.id = snapshot.socketId ?? snapshot.controllerId;
      this.requested = false;
      this.clearConnectTimeout();
      if (snapshot.connected && !this.connected) {
        this.connected = true;
        this.notify("connect");
      } else if (!snapshot.connected) {
        this.connected = false;
      }
      if (snapshot.player) {
        this.notify("server:welcome", {
          controllerId: snapshot.controllerId,
          roomId: snapshot.roomId,
          player: snapshot.player,
          players: snapshot.players
        });
      }
      if (snapshot.state) {
        this.notify("server:state", {
          roomId: snapshot.roomId,
          state: snapshot.state
        });
      }
      return;
    }
    const eventMessage = parseControllerBridgeEventMessage(message);
    if (eventMessage) {
      const { event, args } = eventMessage.payload;
      if (event === "connect") {
        this.connected = true;
      }
      if (event === "disconnect") {
        this.connected = false;
      }
      this.notify(
        event,
        ...args
      );
      return;
    }
    const closeMessage = parseControllerBridgeCloseMessage(message);
    if (closeMessage) {
      this.emitRuntimeEvent(
        AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeClosed,
        "Embedded controller bridge closed",
        "info",
        readEmbeddedControllerRuntimeParams(),
        { reason: closeMessage.payload.reason }
      );
      this.clearPort(true, closeMessage.payload.reason);
      this.scheduleReconnect(
        closeMessage.payload.reason,
        BRIDGE_TRANSIENT_CLOSE_REASONS
      );
    }
  }
  fail(reason, options) {
    this.emitRuntimeEvent(
      AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeRejected,
      reason,
      "warn",
      (options == null ? void 0 : options.runtimeParams) ?? readEmbeddedControllerRuntimeParams(),
      {
        reason: (options == null ? void 0 : options.reason) ?? reason,
        ...options == null ? void 0 : options.data
      }
    );
    this.clearPort(false);
    this.scheduleReconnect(options == null ? void 0 : options.reason, BRIDGE_TRANSIENT_FAILURE_REASONS);
    this.notify("disconnect", reason);
  }
  clearPort(notifyDisconnect, reason) {
    const shouldNotify = notifyDisconnect && (this.connected || this.requested);
    this.clearConnectTimeout();
    this.requested = false;
    this.connected = false;
    this.id = void 0;
    this.lastAttachedArcadeEpoch = null;
    if (this.port) {
      this.port.onmessage = null;
      this.port.close();
      this.port = null;
    }
    for (const pending of this.pendingAcks.values()) {
      clearTimeout(pending.timeoutId);
      pending.reject(
        new Error(
          "Embedded controller bridge disconnected before acknowledgement."
        )
      );
    }
    this.pendingAcks.clear();
    if (shouldNotify) {
      this.notify("disconnect", reason);
    }
  }
  scheduleReconnect(reason, transientReasons) {
    if (!this.allowReconnect || !transientReasons.has(reason ?? "")) {
      return;
    }
    this.clearReconnectTimeout();
    this.reconnectTimeout = setTimeout(() => {
      this.reconnectTimeout = null;
      this.connect();
    }, 50);
  }
  clearConnectTimeout() {
    if (!this.connectTimeout) {
      return;
    }
    clearTimeout(this.connectTimeout);
    this.connectTimeout = null;
  }
  clearReconnectTimeout() {
    if (!this.reconnectTimeout) {
      return;
    }
    clearTimeout(this.reconnectTimeout);
    this.reconnectTimeout = null;
  }
  emitRuntimeEvent(event, message, level, runtimeParams, data) {
    emitAirJamDevRuntimeEvent({
      event,
      message,
      level,
      role: "controller",
      roomId: runtimeParams == null ? void 0 : runtimeParams.room,
      controllerId: runtimeParams == null ? void 0 : runtimeParams.controllerId,
      runtimeEpoch: runtimeParams == null ? void 0 : runtimeParams.arcadeSurface.epoch,
      runtimeKind: CONTROLLER_BRIDGE_RUNTIME_KIND,
      data
    });
  }
  notify(event, ...args) {
    const current = this.listeners.get(event);
    if (!current) {
      return;
    }
    for (const listener of current) {
      listener(...args);
    }
  }
};
var embeddedControllerClient = null;
var directControllerClients = /* @__PURE__ */ new WeakMap();
var isEmbeddedControllerRuntime = () => readEmbeddedControllerRuntimeParams() !== null;
var getControllerRealtimeClient = (getSocket) => {
  if (!isEmbeddedControllerRuntime()) {
    const socket = getSocket("controller");
    const existing = directControllerClients.get(socket);
    if (existing) {
      return existing;
    }
    const client = new DirectControllerRealtimeClient(socket);
    directControllerClients.set(socket, client);
    return client;
  }
  if (!embeddedControllerClient) {
    embeddedControllerClient = new EmbeddedControllerBridgeClient();
  }
  return embeddedControllerClient;
};
var BRIDGE_HANDSHAKE_TIMEOUT_MS2 = 2e3;
var BRIDGE_ACK_TIMEOUT_MS2 = 5e3;
var HOST_BRIDGE_RUNTIME_KIND = "arcade-host-runtime";
var BRIDGE_TRANSIENT_CLOSE_REASONS2 = /* @__PURE__ */ new Set(["game_unloaded", "replaced"]);
var BRIDGE_TRANSIENT_FAILURE_REASONS2 = /* @__PURE__ */ new Set(["handshake_timeout"]);
var DirectHostRealtimeClient = class {
  constructor(socket) {
    this.socket = socket;
  }
  get connected() {
    return this.socket.connected;
  }
  get id() {
    return this.socket.id;
  }
  connect() {
    this.socket.connect();
    return this;
  }
  disconnect() {
    this.socket.disconnect();
    return this;
  }
  on(event, listener) {
    this.socket.on(event, listener);
    return this;
  }
  off(event, listener) {
    if (!listener) {
      this.socket.off(event);
      return this;
    }
    this.socket.off(event, listener);
    return this;
  }
  emit(event, ...args) {
    this.socket.emit.call(this.socket, event, ...args);
    return this;
  }
  emitWithAck(event, ...args) {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(
          new Error(
            `Timed out waiting for acknowledgement for realtime event "${event}".`
          )
        );
      }, BRIDGE_ACK_TIMEOUT_MS2);
      this.socket.emit.call(this.socket, event, ...args, (ack) => {
        clearTimeout(timeoutId);
        resolve(ack);
      });
    });
  }
};
var EmbeddedHostBridgeClient = class {
  constructor() {
    __publicField(this, "connected", false);
    __publicField(this, "id");
    __publicField(this, "listeners", /* @__PURE__ */ new Map());
    __publicField(this, "port", null);
    __publicField(this, "connectTimeout", null);
    __publicField(this, "reconnectTimeout", null);
    __publicField(this, "requested", false);
    __publicField(this, "lastAttachedArcadeEpoch", null);
    __publicField(this, "allowReconnect", true);
    __publicField(this, "pendingAcks", /* @__PURE__ */ new Map());
  }
  connect() {
    var _a, _b;
    const runtimeParams = readChildHostRuntimeParams();
    if (!runtimeParams || typeof window === "undefined") {
      this.fail("Embedded host bridge runtime params missing.", {
        reason: "runtime_params_missing"
      });
      return this;
    }
    if (this.connected || this.requested) {
      return this;
    }
    this.allowReconnect = true;
    this.clearReconnectTimeout();
    this.clearPort(false);
    this.requested = true;
    const channel = new MessageChannel();
    this.port = channel.port1;
    this.port.onmessage = (event) => {
      this.handlePortMessage(event.data);
    };
    (_b = (_a = this.port).start) == null ? void 0 : _b.call(_a);
    this.connectTimeout = setTimeout(() => {
      this.fail("Embedded host bridge handshake timed out.", {
        reason: "handshake_timeout",
        runtimeParams
      });
    }, BRIDGE_HANDSHAKE_TIMEOUT_MS2);
    window.parent.postMessage(
      createHostBridgeRequestMessage({
        roomId: runtimeParams.room,
        capabilityToken: runtimeParams.capabilityToken,
        arcadeSurface: runtimeParams.arcadeSurface
      }),
      "*",
      [channel.port2]
    );
    this.emitRuntimeEvent(
      AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeRequested,
      "Embedded host bridge requested",
      "info",
      runtimeParams,
      {
        capabilityExpiresAt: runtimeParams.capabilityExpiresAt,
        gameId: runtimeParams.arcadeSurface.gameId,
        surfaceKind: runtimeParams.arcadeSurface.kind
      }
    );
    return this;
  }
  disconnect() {
    this.allowReconnect = false;
    this.clearReconnectTimeout();
    if (this.port) {
      this.port.postMessage(createHostBridgeCloseMessage("detached"));
    }
    this.clearPort(true, "detached");
    return this;
  }
  on(event, listener) {
    const eventKey = String(event);
    const current = this.listeners.get(eventKey) ?? /* @__PURE__ */ new Set();
    current.add(listener);
    this.listeners.set(eventKey, current);
    return this;
  }
  off(event, listener) {
    const eventKey = String(event);
    const current = this.listeners.get(eventKey);
    if (!current) {
      return this;
    }
    if (!listener) {
      this.listeners.delete(eventKey);
      return this;
    }
    current.delete(listener);
    if (current.size === 0) {
      this.listeners.delete(eventKey);
    }
    return this;
  }
  emit(event, ...args) {
    if (!this.port || !this.connected) {
      return this;
    }
    const bridgeEvent = event;
    this.port.postMessage(
      createHostBridgeEmitMessage(
        bridgeEvent,
        ...args
      )
    );
    return this;
  }
  emitWithAck(event, ...args) {
    var _a, _b;
    if (!this.port || !this.connected) {
      return Promise.reject(
        new Error(
          `Cannot emit acknowledged realtime event "${event}" because the embedded host bridge is not connected.`
        )
      );
    }
    const requestId = ((_b = (_a = globalThis.crypto) == null ? void 0 : _a.randomUUID) == null ? void 0 : _b.call(_a)) ?? `ack-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    return new Promise((resolve, reject) => {
      var _a2;
      const timeoutId = setTimeout(() => {
        this.pendingAcks.delete(requestId);
        reject(
          new Error(
            `Timed out waiting for acknowledgement for bridge event "${event}".`
          )
        );
      }, BRIDGE_ACK_TIMEOUT_MS2);
      this.pendingAcks.set(requestId, {
        resolve: (ack) => resolve(ack),
        reject,
        timeoutId
      });
      const bridgeEvent = event;
      (_a2 = this.port) == null ? void 0 : _a2.postMessage(
        createHostBridgeEmitMessage(
          bridgeEvent,
          ...args,
          { requestId }
        )
      );
    });
  }
  handlePortMessage(message) {
    const responseMessage = parseHostBridgeResponseMessage(message);
    if (responseMessage) {
      const pending = this.pendingAcks.get(responseMessage.payload.requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timeoutId);
      this.pendingAcks.delete(responseMessage.payload.requestId);
      pending.resolve(responseMessage.payload.ack);
      return;
    }
    const attachMessage = parseHostBridgeAttachMessage(message);
    if (attachMessage) {
      if (attachMessage.payload.handshake.runtimeKind !== "arcade-host-runtime" || attachMessage.payload.handshake.capabilityFlags.hostBridge !== true) {
        this.fail("Embedded host bridge handshake rejected.", {
          reason: "handshake_rejected",
          runtimeParams: readChildHostRuntimeParams()
        });
        return;
      }
      const snapshot = attachMessage.payload.snapshot;
      const epochResult = validateArcadeBridgeAttachEpoch(
        this.lastAttachedArcadeEpoch,
        snapshot.arcadeSurface
      );
      if (!epochResult.ok) {
        this.fail(
          "Embedded host bridge attach rejected: stale arcade surface epoch.",
          {
            reason: "stale_arcade_surface_epoch",
            runtimeParams: readChildHostRuntimeParams(),
            data: {
              attachedEpoch: snapshot.arcadeSurface.epoch,
              previousEpoch: this.lastAttachedArcadeEpoch
            }
          }
        );
        return;
      }
      this.lastAttachedArcadeEpoch = epochResult.nextLast;
      this.emitRuntimeEvent(
        AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeAttached,
        "Embedded host bridge attached",
        "info",
        readChildHostRuntimeParams(),
        {
          connected: snapshot.connected,
          socketId: snapshot.socketId,
          playerCount: snapshot.players.length
        }
      );
      this.id = snapshot.socketId ?? snapshot.roomId;
      this.requested = false;
      this.clearConnectTimeout();
      if (snapshot.connected && !this.connected) {
        this.connected = true;
        this.notify("connect");
      } else if (!snapshot.connected) {
        this.connected = false;
      }
      for (const player of snapshot.players) {
        this.notify("server:controllerJoined", player);
      }
      if (snapshot.state) {
        this.notify("server:state", {
          roomId: snapshot.roomId,
          state: snapshot.state
        });
      }
      return;
    }
    const eventMessage = parseHostBridgeEventMessage(message);
    if (eventMessage) {
      const { event, args, requestId } = eventMessage.payload;
      if (event === "connect") {
        this.connected = true;
      }
      if (event === "disconnect") {
        this.connected = false;
      }
      if (event === "airjam:action_rpc" && requestId && this.port) {
        const [payload] = args;
        this.notify(event, payload, (ack) => {
          var _a;
          (_a = this.port) == null ? void 0 : _a.postMessage(
            createHostBridgeResponseMessage(requestId, ack)
          );
        });
        return;
      }
      this.notify(event, ...args);
      return;
    }
    const closeMessage = parseHostBridgeCloseMessage(message);
    if (closeMessage) {
      this.emitRuntimeEvent(
        AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeClosed,
        "Embedded host bridge closed",
        "info",
        readChildHostRuntimeParams(),
        { reason: closeMessage.payload.reason }
      );
      this.clearPort(true, closeMessage.payload.reason);
      this.scheduleReconnect(
        closeMessage.payload.reason,
        BRIDGE_TRANSIENT_CLOSE_REASONS2
      );
    }
  }
  fail(reason, options) {
    this.emitRuntimeEvent(
      AIRJAM_DEV_LOG_EVENTS.runtime.embeddedBridgeRejected,
      reason,
      "warn",
      (options == null ? void 0 : options.runtimeParams) ?? readChildHostRuntimeParams(),
      {
        reason: (options == null ? void 0 : options.reason) ?? reason,
        ...options == null ? void 0 : options.data
      }
    );
    this.clearPort(false);
    this.scheduleReconnect(options == null ? void 0 : options.reason, BRIDGE_TRANSIENT_FAILURE_REASONS2);
    this.notify("disconnect", reason);
  }
  clearPort(notifyDisconnect, reason) {
    const shouldNotify = notifyDisconnect && (this.connected || this.requested);
    this.clearConnectTimeout();
    this.requested = false;
    this.connected = false;
    this.id = void 0;
    this.lastAttachedArcadeEpoch = null;
    if (this.port) {
      this.port.onmessage = null;
      this.port.close();
      this.port = null;
    }
    for (const pending of this.pendingAcks.values()) {
      clearTimeout(pending.timeoutId);
      pending.reject(
        new Error("Embedded host bridge disconnected before acknowledgement.")
      );
    }
    this.pendingAcks.clear();
    if (shouldNotify) {
      this.notify("disconnect", reason);
    }
  }
  scheduleReconnect(reason, transientReasons) {
    if (!this.allowReconnect || !transientReasons.has(reason ?? "")) {
      return;
    }
    this.clearReconnectTimeout();
    this.reconnectTimeout = setTimeout(() => {
      this.reconnectTimeout = null;
      this.connect();
    }, 50);
  }
  clearConnectTimeout() {
    if (!this.connectTimeout) {
      return;
    }
    clearTimeout(this.connectTimeout);
    this.connectTimeout = null;
  }
  clearReconnectTimeout() {
    if (!this.reconnectTimeout) {
      return;
    }
    clearTimeout(this.reconnectTimeout);
    this.reconnectTimeout = null;
  }
  emitRuntimeEvent(event, message, level, runtimeParams, data) {
    emitAirJamDevRuntimeEvent({
      event,
      message,
      level,
      role: "host",
      roomId: runtimeParams == null ? void 0 : runtimeParams.room,
      runtimeEpoch: runtimeParams == null ? void 0 : runtimeParams.arcadeSurface.epoch,
      runtimeKind: HOST_BRIDGE_RUNTIME_KIND,
      data
    });
  }
  notify(event, ...args) {
    const current = this.listeners.get(event);
    if (!current) {
      return;
    }
    for (const listener of current) {
      listener(...args);
    }
  }
};
var embeddedHostClient = null;
var directHostClients = /* @__PURE__ */ new WeakMap();
var isEmbeddedHostRuntime = () => readChildHostRuntimeParams() !== null;
var getHostRealtimeClient = (getSocket) => {
  if (!isEmbeddedHostRuntime()) {
    const socket = getSocket("host");
    const existing = directHostClients.get(socket);
    if (existing) {
      return existing;
    }
    const client = new DirectHostRealtimeClient(socket);
    directHostClients.set(socket, client);
    return client;
  }
  if (!embeddedHostClient) {
    embeddedHostClient = new EmbeddedHostBridgeClient();
  }
  return embeddedHostClient;
};
function detectSoundCategory(config) {
  if (config.category) {
    return config.category;
  }
  if (config.loop && config.html5) {
    return "music";
  }
  return "sfx";
}
var AudioManager = class {
  constructor(manifest) {
    __publicField(this, "sounds", /* @__PURE__ */ new Map());
    __publicField(this, "categories", /* @__PURE__ */ new Map());
    __publicField(this, "manifest", {});
    __publicField(this, "_muted", false);
    __publicField(this, "socket", null);
    __publicField(this, "roomId", null);
    __publicField(this, "role", null);
    __publicField(this, "activeSoundIds", /* @__PURE__ */ new Map());
    __publicField(this, "audioSettings", DEFAULT_PLATFORM_SETTINGS.audio);
    if (manifest) {
      this.load(manifest);
    }
  }
  destroy() {
  }
  getCategory(soundId) {
    return this.categories.get(soundId) ?? "sfx";
  }
  setSocket(socket, roomId, role) {
    this.socket = socket;
    if (roomId) this.roomId = roomId;
    if (role) this.role = role;
  }
  async init() {
    if (!import_howler.Howler.ctx) {
      return false;
    }
    if (import_howler.Howler.ctx.state === "suspended") {
      try {
        await import_howler.Howler.ctx.resume();
      } catch {
        return false;
      }
    }
    return import_howler.Howler.ctx.state === "running";
  }
  isReady() {
    return import_howler.Howler.ctx !== null && import_howler.Howler.ctx.state === "running";
  }
  load(manifest) {
    this.manifest = { ...this.manifest, ...manifest };
    Object.entries(manifest).forEach(([key, config]) => {
      if (this.sounds.has(key)) return;
      const category = detectSoundCategory(config);
      this.categories.set(key, category);
      const baseVolume = config.volume ?? 1;
      const effectiveVolume = getEffectiveAudioVolume(
        this.audioSettings,
        category
      );
      const sound = new import_howler.Howl({
        src: config.src,
        volume: baseVolume * effectiveVolume,
        loop: config.loop ?? false,
        html5: config.html5 ?? false,
        sprite: config.sprite,
        preload: true
      });
      this.sounds.set(key, sound);
    });
  }
  applyPlatformAudioSettings(settings) {
    this.audioSettings = settings;
    this.activeSoundIds.forEach((info, howlSoundId) => {
      const sound = this.sounds.get(info.soundId);
      if (!sound) {
        return;
      }
      const config = this.manifest[info.soundId];
      const baseVolume = (config == null ? void 0 : config.volume) ?? 1;
      const effectiveVolume = getEffectiveAudioVolume(settings, info.category);
      sound.volume(baseVolume * effectiveVolume, howlSoundId);
    });
    this.sounds.forEach((sound, soundId) => {
      const category = this.categories.get(soundId) ?? "sfx";
      const config = this.manifest[soundId];
      const baseVolume = (config == null ? void 0 : config.volume) ?? 1;
      const effectiveVolume = getEffectiveAudioVolume(settings, category);
      sound.volume(baseVolume * effectiveVolume);
    });
  }
  play(id, options) {
    const {
      remote = false,
      target,
      volume,
      loop,
      sprite,
      pitch,
      fadeInMs,
      onEnd
    } = options || {};
    void this.init();
    if (remote) {
      this.playRemote(id, target, volume, loop);
      return null;
    }
    return this.playLocal(id, volume, loop, sprite, pitch, fadeInMs, onEnd);
  }
  playLocal(id, volume, loop, sprite, pitch, fadeInMs, onEnd) {
    if (!this.isReady()) {
      return null;
    }
    const sound = this.sounds.get(id);
    if (!sound) {
      console.warn(`Sound "${id}" not found`);
      return null;
    }
    const category = this.getCategory(id);
    const config = this.manifest[id];
    const baseVolume = (config == null ? void 0 : config.volume) ?? 1;
    const effectiveVolume = getEffectiveAudioVolume(
      this.audioSettings,
      category
    );
    const finalVolume = volume !== void 0 ? volume * effectiveVolume : baseVolume * effectiveVolume;
    const soundId = sound.play(sprite);
    this.activeSoundIds.set(soundId, { soundId: id, category });
    sound.once(
      "end",
      () => {
        this.activeSoundIds.delete(soundId);
        onEnd == null ? void 0 : onEnd(soundId);
      },
      soundId
    );
    if (fadeInMs && fadeInMs > 0) {
      sound.volume(0, soundId);
      sound.fade(0, finalVolume, fadeInMs, soundId);
    } else {
      sound.volume(finalVolume, soundId);
    }
    if (loop !== void 0) sound.loop(loop, soundId);
    if (pitch !== void 0) sound.rate(pitch, soundId);
    return soundId;
  }
  playRemote(id, target, volume, loop) {
    if (!this.socket || !this.roomId) return;
    if (this.isHost()) {
      this.socket.emit("host:play_sound", {
        roomId: this.roomId,
        targetControllerId: target,
        soundId: id,
        volume,
        loop
      });
      return;
    }
    this.socket.emit("controller:play_sound", {
      roomId: this.roomId,
      soundId: id,
      volume,
      loop
    });
  }
  isHost() {
    return this.role === "host";
  }
  playSpatial(id, pos, sprite) {
    void this.init();
    const soundId = this.playLocal(id, void 0, void 0, sprite);
    if (soundId !== null) {
      const sound = this.sounds.get(id);
      if (sound) {
        sound.pos(pos.x, pos.y, pos.z, soundId);
        sound.pannerAttr(
          {
            panningModel: "HRTF",
            refDistance: 1,
            maxDistance: 1e3,
            rolloffFactor: 1,
            distanceModel: "inverse"
          },
          soundId
        );
      }
    }
    return soundId;
  }
  stop(id, soundId) {
    if (id) {
      const sound = this.sounds.get(id);
      sound == null ? void 0 : sound.stop(soundId);
      if (soundId !== void 0) {
        this.activeSoundIds.delete(soundId);
      } else {
        this.activeSoundIds.forEach((info, howlSoundId) => {
          if (info.soundId === id) {
            this.activeSoundIds.delete(howlSoundId);
          }
        });
      }
      return;
    }
    import_howler.Howler.stop();
    this.activeSoundIds.clear();
  }
  fadeOutAndStop(id, soundId, durationMs) {
    const sound = this.sounds.get(id);
    if (!sound) {
      this.activeSoundIds.delete(soundId);
      return;
    }
    if (durationMs <= 0) {
      sound.stop(soundId);
      this.activeSoundIds.delete(soundId);
      return;
    }
    const config = this.manifest[id];
    const category = this.getCategory(id);
    const fromVolume = ((config == null ? void 0 : config.volume) ?? 1) * getEffectiveAudioVolume(this.audioSettings, category);
    sound.fade(fromVolume, 0, durationMs, soundId);
    globalThis.setTimeout(() => {
      sound.stop(soundId);
      this.activeSoundIds.delete(soundId);
    }, durationMs);
  }
  volume(vol, id, soundId) {
    if (id) {
      const sound = this.sounds.get(id);
      if (!sound) {
        return;
      }
      if (soundId !== void 0) {
        sound.volume(vol, soundId);
      } else {
        sound.volume(vol);
      }
      return;
    }
    import_howler.Howler.volume(vol);
  }
  mute(muted, id, soundId) {
    if (id) {
      const sound = this.sounds.get(id);
      sound == null ? void 0 : sound.mute(muted, soundId);
      return;
    }
    this._muted = muted;
    import_howler.Howler.mute(muted);
  }
  isMuted() {
    return this._muted;
  }
  setListenerPos(x, y, z) {
    import_howler.Howler.pos(x, y, z);
  }
  setListenerOrientation(x, y, z, xUp, yUp, zUp) {
    import_howler.Howler.orientation(x, y, z, xUp, yUp, zUp);
  }
};
var globalInitialized = false;
var audioManagerContext = (0, import_react.createContext)(null);
var audioRuntimeStatusContext = (0, import_react.createContext)(
  null
);
var audioRuntimeControlsContext = (0, import_react.createContext)(
  null
);
function AudioRuntime({
  manifest,
  children
}) {
  const { manager, status, controls } = useOwnedAudio(manifest);
  useRemoteSound(manifest, manager);
  return (0, import_jsx_runtime.jsx)(audioRuntimeStatusContext.Provider, { value: status, children: (0, import_jsx_runtime.jsx)(audioRuntimeControlsContext.Provider, { value: controls, children: (0, import_jsx_runtime.jsx)(audioManagerContext.Provider, { value: manager, children }) }) });
}
function useAudio() {
  const manager = (0, import_react.useContext)(audioManagerContext);
  if (!manager) {
    throw new Error("useAudio must be used within an AudioRuntime");
  }
  return manager;
}
function useAudioRuntimeStatus() {
  const status = (0, import_react.useContext)(audioRuntimeStatusContext);
  if (!status) {
    throw new Error(
      "useAudioRuntimeStatus must be used within an AudioRuntime"
    );
  }
  return status;
}
function useAudioRuntimeControls() {
  const controls = (0, import_react.useContext)(audioRuntimeControlsContext);
  if (!controls) {
    throw new Error(
      "useAudioRuntimeControls must be used within an AudioRuntime"
    );
  }
  return controls;
}
function useOwnedAudio(manifest) {
  const { store, getSocket } = useAirJamContext();
  const roomId = useStore(store, (state) => state.roomId);
  const role = useStore(store, (state) => state.role);
  const platformSettings = useResolvedPlatformSettingsSnapshot();
  const platformSettingsStatus = usePlatformSettingsRuntimeStatus();
  const platformSettingsReady = platformSettingsStatus === "ready";
  const manager = (0, import_react.useMemo)(
    () => new AudioManager(manifest),
    [manifest]
  );
  const [status, setStatus] = (0, import_react.useState)(
    () => globalInitialized && platformSettingsReady ? "ready" : "idle"
  );
  const retry = (0, import_react.useCallback)(async () => {
    if (!platformSettingsReady) {
      setStatus("idle");
      return false;
    }
    const ready = await manager.init();
    if (ready) {
      globalInitialized = true;
      setStatus("ready");
      return true;
    }
    setStatus((current) => current === "ready" ? current : "blocked");
    return false;
  }, [manager, platformSettingsReady]);
  (0, import_react.useEffect)(() => {
    if (!platformSettingsReady) {
      return;
    }
    manager.applyPlatformAudioSettings(platformSettings.audio);
  }, [manager, platformSettings.audio, platformSettingsReady]);
  (0, import_react.useEffect)(() => {
    if (platformSettingsReady) {
      return;
    }
    setStatus("idle");
  }, [platformSettingsReady]);
  (0, import_react.useEffect)(() => {
    if (role && roomId) {
      const directSocket = getSocket(role);
      if (!directSocket) {
        manager.setSocket(null, roomId, role);
        return;
      }
      const realtimeClient = role === "controller" ? getControllerRealtimeClient(() => directSocket) : getHostRealtimeClient(() => directSocket);
      manager.setSocket(realtimeClient, roomId, role);
    }
  }, [manager, role, roomId, getSocket]);
  (0, import_react.useEffect)(() => {
    return () => {
      manager.destroy();
    };
  }, [manager]);
  (0, import_react.useEffect)(() => {
    void retry();
  }, [retry]);
  (0, import_react.useEffect)(() => {
    if (status === "ready") {
      return;
    }
    const handleInteraction = () => {
      void retry();
    };
    window.addEventListener("click", handleInteraction);
    window.addEventListener("touchstart", handleInteraction);
    window.addEventListener("keydown", handleInteraction);
    window.addEventListener("pointerdown", handleInteraction);
    window.addEventListener("mousedown", handleInteraction);
    return () => {
      window.removeEventListener("click", handleInteraction);
      window.removeEventListener("touchstart", handleInteraction);
      window.removeEventListener("keydown", handleInteraction);
      window.removeEventListener("pointerdown", handleInteraction);
      window.removeEventListener("mousedown", handleInteraction);
    };
  }, [retry, status]);
  return {
    manager,
    status,
    controls: {
      retry
    }
  };
}
var isManifestSoundId = (manifest, soundId) => typeof soundId === "string" && Object.prototype.hasOwnProperty.call(manifest, soundId);
function useRemoteSound(manifest, audio) {
  const { getSocket, store } = useAirJamContext();
  const role = useStore(store, (state) => state.role);
  const connectionStatus = useStore(store, (state) => state.connectionStatus);
  const socket = (0, import_react.useMemo)(() => {
    if (role !== "controller") {
      return null;
    }
    const directSocket = getSocket("controller");
    if (!directSocket) {
      return null;
    }
    return getControllerRealtimeClient(() => directSocket);
  }, [getSocket, role]);
  const enabled = role === "controller" && connectionStatus === "connected";
  (0, import_react.useEffect)(() => {
    if (!socket || !enabled) {
      return;
    }
    const handlePlaySound = (payload) => {
      if (!isManifestSoundId(manifest, payload.id)) {
        return;
      }
      audio.play(payload.id, {
        volume: payload.volume,
        loop: payload.loop
      });
    };
    socket.on("server:playSound", handlePlaySound);
    return () => {
      socket.off("server:playSound", handlePlaySound);
    };
  }, [audio, enabled, manifest, socket]);
}
function useAudioCategoryVolume(category) {
  const settingsStatus = usePlatformSettingsRuntimeStatus();
  const settings = useResolvedPlatformSettingsSnapshot();
  if (settingsStatus !== "ready") {
    return 0;
  }
  if (category === "master") {
    return settings.audio.masterVolume;
  }
  return getEffectiveAudioVolume(settings.audio, category);
}
function useMusicVolume() {
  return useAudioCategoryVolume("music");
}
function MusicPlaylist({
  tracks,
  playing,
  order = "sequence",
  fadeMs = 1e3,
  startIndex = 0
}) {
  const audio = useAudio();
  const status = useAudioRuntimeStatus();
  const activeRef = (0, import_react2.useRef)(null);
  const generationRef = (0, import_react2.useRef)(0);
  const tracksRef = (0, import_react2.useRef)(tracks);
  const tracksKey = (0, import_react2.useMemo)(() => tracks.join("\0"), [tracks]);
  tracksRef.current = tracks;
  (0, import_react2.useEffect)(() => {
    const generation = generationRef.current + 1;
    generationRef.current = generation;
    let disposed = false;
    const stopActive = () => {
      const active = activeRef.current;
      if (!active) {
        return;
      }
      activeRef.current = null;
      audio.fadeOutAndStop(active.trackId, active.soundId, fadeMs);
    };
    const getNextIndex = (currentIndex) => {
      const currentTracks = tracksRef.current;
      if (currentTracks.length <= 1) {
        return 0;
      }
      if (order === "shuffle") {
        const randomOffset = Math.floor(
          Math.random() * (currentTracks.length - 1)
        );
        return (currentIndex + 1 + randomOffset) % currentTracks.length;
      }
      return (currentIndex + 1) % currentTracks.length;
    };
    const startTrack = (trackIndex) => {
      const currentTracks = tracksRef.current;
      if (disposed || generationRef.current !== generation || !playing || status !== "ready" || currentTracks.length === 0) {
        return;
      }
      const normalizedIndex = (trackIndex % currentTracks.length + currentTracks.length) % currentTracks.length;
      const trackId = currentTracks[normalizedIndex];
      const soundId = audio.play(trackId, {
        fadeInMs: fadeMs,
        loop: false,
        onEnd: (endedSoundId) => {
          const active = activeRef.current;
          if (disposed || generationRef.current !== generation || !active || active.trackId !== trackId || active.soundId !== endedSoundId) {
            return;
          }
          activeRef.current = null;
          startTrack(getNextIndex(normalizedIndex));
        }
      });
      if (soundId !== null) {
        activeRef.current = { trackId, soundId };
      }
    };
    stopActive();
    if (playing && status === "ready" && tracksRef.current.length > 0) {
      startTrack(startIndex);
    }
    return () => {
      disposed = true;
      stopActive();
    };
  }, [audio, fadeMs, order, playing, startIndex, status, tracksKey]);
  return null;
}
var useConnectionStatus = () => {
  const { store } = useAirJamContext();
  return useStore(store, (state) => state.connectionStatus);
};
var DEFAULT_CONTROLLER_TICK_MS = 16;
var useControllerTick = (callback, options = {}) => {
  useAssertSessionScope("controller", "useControllerTick");
  const { enabled = true, intervalMs = DEFAULT_CONTROLLER_TICK_MS } = options;
  const callbackRef = (0, import_react3.useRef)(callback);
  (0, import_react3.useEffect)(() => {
    callbackRef.current = callback;
  }, [callback]);
  (0, import_react3.useEffect)(() => {
    if (!enabled) {
      return;
    }
    if (typeof window === "undefined") {
      return;
    }
    let tick = 0;
    let lastTime = performance.now();
    const intervalId = window.setInterval(() => {
      const now = performance.now();
      const deltaMs = now - lastTime;
      lastTime = now;
      tick += 1;
      callbackRef.current({
        now,
        deltaMs,
        deltaSeconds: deltaMs / 1e3,
        tick
      });
    }, intervalMs);
    return () => {
      window.clearInterval(intervalId);
    };
  }, [enabled, intervalMs]);
};
var DEFAULT_MAX_TOASTS = 3;
var DEFAULT_TOAST_DURATION_MS = 2200;
var buildToastId = () => `toast_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
var useControllerToasts = (options = {}) => {
  useAssertSessionScope("controller", "useControllerToasts");
  const { getSocket } = useAirJamContext();
  const socket = (0, import_react4.useMemo)(
    () => getControllerRealtimeClient((role) => getSocket(role)),
    [getSocket]
  );
  const maxToasts = options.maxToasts ?? DEFAULT_MAX_TOASTS;
  const defaultDurationMs = options.defaultDurationMs ?? DEFAULT_TOAST_DURATION_MS;
  const [toasts, setToasts] = (0, import_react4.useState)([]);
  const toastTimeoutsRef = (0, import_react4.useRef)(
    /* @__PURE__ */ new Map()
  );
  const dismissToast = (0, import_react4.useCallback)((toastId) => {
    const timeout = toastTimeoutsRef.current.get(toastId);
    if (timeout) {
      clearTimeout(timeout);
      toastTimeoutsRef.current.delete(toastId);
    }
    setToasts((previous) => previous.filter((toast) => toast.id !== toastId));
  }, []);
  const clearToasts = (0, import_react4.useCallback)(() => {
    for (const timeout of toastTimeoutsRef.current.values()) {
      clearTimeout(timeout);
    }
    toastTimeoutsRef.current.clear();
    setToasts([]);
  }, []);
  (0, import_react4.useEffect)(() => {
    if (!socket) {
      return;
    }
    const handleSignal = (signal) => {
      if (signal.type !== "TOAST") {
        return;
      }
      const toast = {
        ...signal.payload,
        id: buildToastId(),
        receivedAt: Date.now()
      };
      setToasts((previous) => [toast, ...previous].slice(0, maxToasts));
      const duration = toast.duration ?? defaultDurationMs;
      if (duration <= 0) {
        return;
      }
      const timeout = setTimeout(() => {
        dismissToast(toast.id);
      }, duration);
      toastTimeoutsRef.current.set(toast.id, timeout);
    };
    socket.on("server:signal", handleSignal);
    return () => {
      socket.off("server:signal", handleSignal);
    };
  }, [defaultDurationMs, dismissToast, maxToasts, socket]);
  (0, import_react4.useEffect)(
    () => () => {
      for (const timeout of toastTimeoutsRef.current.values()) {
        clearTimeout(timeout);
      }
      toastTimeoutsRef.current.clear();
    },
    []
  );
  return {
    toasts,
    latestToast: toasts[0] ?? null,
    dismissToast,
    clearToasts
  };
};
var useGetInput = () => {
  useAssertSessionScope("host", "useGetInput");
  const { inputManager } = useAirJamContext();
  return (0, import_react5.useCallback)(
    (controllerId) => {
      if (!inputManager) {
        return void 0;
      }
      return inputManager.getInput(controllerId);
    },
    [inputManager]
  );
};
var DEFAULT_HOST_TICK_MS = 16;
var DEFAULT_HOST_MAX_DELTA_MS = 250;
var DEFAULT_HOST_MAX_STEPS_PER_FRAME = 5;
var useHostTick = (options) => {
  useAssertSessionScope("host", "useHostTick");
  const {
    onTick,
    enabled = true,
    mode = "raf",
    intervalMs = DEFAULT_HOST_TICK_MS,
    maxDeltaMs = DEFAULT_HOST_MAX_DELTA_MS,
    maxStepsPerFrame = DEFAULT_HOST_MAX_STEPS_PER_FRAME,
    onFrame
  } = options;
  const tickIntervalMs = Math.max(1, intervalMs);
  const frameDeltaCapMs = Math.max(tickIntervalMs, maxDeltaMs);
  const frameStepCap = Math.max(1, maxStepsPerFrame);
  const onTickRef = (0, import_react6.useRef)(onTick);
  const onFrameRef = (0, import_react6.useRef)(onFrame);
  (0, import_react6.useEffect)(() => {
    onTickRef.current = onTick;
  }, [onTick]);
  (0, import_react6.useEffect)(() => {
    onFrameRef.current = onFrame;
  }, [onFrame]);
  (0, import_react6.useEffect)(() => {
    if (!enabled) {
      return;
    }
    if (typeof window === "undefined") {
      return;
    }
    let tick = 0;
    let frameCount = 0;
    let lastTime = performance.now();
    if (mode === "interval") {
      const intervalId = window.setInterval(() => {
        const now = performance.now();
        const deltaMs = now - lastTime;
        lastTime = now;
        tick += 1;
        onTickRef.current({
          now,
          deltaMs,
          deltaSeconds: deltaMs / 1e3,
          tick
        });
      }, tickIntervalMs);
      return () => {
        window.clearInterval(intervalId);
      };
    }
    let rafId = 0;
    if (mode === "fixed") {
      let accumulatorMs = 0;
      const frame2 = (now) => {
        var _a;
        const frameDeltaMs = Math.max(
          0,
          Math.min(now - lastTime, frameDeltaCapMs)
        );
        frameCount += 1;
        lastTime = now;
        accumulatorMs += frameDeltaMs;
        let stepsThisFrame = 0;
        while (accumulatorMs >= tickIntervalMs && stepsThisFrame < frameStepCap) {
          tick += 1;
          onTickRef.current({
            now,
            deltaMs: tickIntervalMs,
            deltaSeconds: tickIntervalMs / 1e3,
            tick
          });
          accumulatorMs -= tickIntervalMs;
          stepsThisFrame += 1;
        }
        if (stepsThisFrame === frameStepCap) {
          accumulatorMs = 0;
        }
        (_a = onFrameRef.current) == null ? void 0 : _a.call(onFrameRef, {
          now,
          deltaMs: frameDeltaMs,
          deltaSeconds: frameDeltaMs / 1e3,
          frame: frameCount,
          fixedStepAlpha: Math.min(1, accumulatorMs / tickIntervalMs)
        });
        rafId = window.requestAnimationFrame(frame2);
      };
      rafId = window.requestAnimationFrame(frame2);
      return () => {
        window.cancelAnimationFrame(rafId);
      };
    }
    const frame = (now) => {
      const deltaMs = now - lastTime;
      lastTime = now;
      tick += 1;
      onTickRef.current({
        now,
        deltaMs,
        deltaSeconds: deltaMs / 1e3,
        tick
      });
      rafId = window.requestAnimationFrame(frame);
    };
    rafId = window.requestAnimationFrame(frame);
    return () => {
      window.cancelAnimationFrame(rafId);
    };
  }, [enabled, mode, tickIntervalMs, frameDeltaCapMs, frameStepCap]);
};
var HOST_AUDIO_MUTE_STORAGE_KEY_PREFIX = "air-jam-host-audio-muted:";
var getHostAudioMuteStorageKey = (scope) => `${HOST_AUDIO_MUTE_STORAGE_KEY_PREFIX}${scope}`;
var readHostAudioMutePreference = (storageKey, fallback) => {
  if (typeof window === "undefined") {
    return fallback;
  }
  const raw = window.localStorage.getItem(storageKey);
  if (raw === "true") {
    return true;
  }
  if (raw === "false") {
    return false;
  }
  return fallback;
};
var persistHostAudioMutePreference = (storageKey, muted) => {
  if (typeof window === "undefined") {
    return;
  }
  window.localStorage.setItem(storageKey, muted ? "true" : "false");
};
var useHostAudioMutePreference = (scope, defaultMuted = false) => {
  const storageKey = (0, import_react7.useMemo)(() => getHostAudioMuteStorageKey(scope), [scope]);
  const [muted, setMutedState] = (0, import_react7.useState)(
    () => readHostAudioMutePreference(storageKey, defaultMuted)
  );
  (0, import_react7.useEffect)(() => {
    setMutedState(readHostAudioMutePreference(storageKey, defaultMuted));
  }, [defaultMuted, storageKey]);
  (0, import_react7.useEffect)(() => {
    if (typeof window === "undefined") {
      return;
    }
    const handleStorage = (event) => {
      if (event.storageArea !== window.localStorage) {
        return;
      }
      if (event.key !== storageKey) {
        return;
      }
      setMutedState(readHostAudioMutePreference(storageKey, defaultMuted));
    };
    window.addEventListener("storage", handleStorage);
    return () => {
      window.removeEventListener("storage", handleStorage);
    };
  }, [defaultMuted, storageKey]);
  const setMuted = (0, import_react7.useCallback)(
    (nextMuted) => {
      setMutedState(nextMuted);
      persistHostAudioMutePreference(storageKey, nextMuted);
    },
    [storageKey]
  );
  const toggleMuted = (0, import_react7.useCallback)(() => {
    setMutedState((current) => {
      const nextMuted = !current;
      persistHostAudioMutePreference(storageKey, nextMuted);
      return nextMuted;
    });
  }, [storageKey]);
  return {
    muted,
    setMuted,
    toggleMuted
  };
};
var isRpcSerializable = (value, seen = /* @__PURE__ */ new WeakSet()) => {
  if (value === null || value === void 0) {
    return true;
  }
  const valueType = typeof value;
  if (valueType === "string" || valueType === "boolean") {
    return true;
  }
  if (valueType === "number") {
    return Number.isFinite(value);
  }
  if (valueType === "function" || valueType === "symbol" || valueType === "bigint") {
    return false;
  }
  if (valueType !== "object") {
    return false;
  }
  const objectValue = value;
  if (seen.has(objectValue)) {
    return false;
  }
  seen.add(objectValue);
  if (objectValue instanceof Date) {
    return true;
  }
  if (Array.isArray(objectValue)) {
    return objectValue.every((entry) => isRpcSerializable(entry, seen));
  }
  const prototype = Object.getPrototypeOf(objectValue);
  if (prototype !== Object.prototype && prototype !== null) {
    return false;
  }
  for (const entry of Object.values(objectValue)) {
    if (!isRpcSerializable(entry, seen)) {
      return false;
    }
  }
  return true;
};
var useInputWriter = () => {
  useAssertSessionScope("controller", "useInputWriter");
  const { store, getSocket } = useAirJamContext();
  return (0, import_react8.useCallback)(
    (input) => {
      if (typeof input !== "object" || input === null || Array.isArray(input)) {
        emitAirJamDiagnostic({
          code: "AJ_INPUT_WRITER_INVALID_SHAPE",
          severity: "warn",
          message: "Input writer payload must be a plain object."
        });
        return false;
      }
      if (!isRpcSerializable(input)) {
        emitAirJamDiagnostic({
          code: "AJ_INPUT_WRITER_NOT_SERIALIZABLE",
          severity: "warn",
          message: "Input writer payload must be RPC-serializable."
        });
        return false;
      }
      const state = store.getState();
      if (!state.roomId || !state.controllerId) {
        emitAirJamDiagnostic({
          code: "AJ_INPUT_WRITER_SESSION_NOT_READY",
          severity: "warn",
          message: "Input writer blocked: room/controller session is not ready."
        });
        return false;
      }
      const socket = getControllerRealtimeClient((role) => getSocket(role));
      if (!socket.connected) {
        emitAirJamDiagnostic({
          code: "AJ_INPUT_WRITER_SOCKET_DISCONNECTED",
          severity: "warn",
          message: "Input writer blocked: controller socket is disconnected."
        });
        return false;
      }
      const payload = controllerInputSchema.safeParse({
        roomId: state.roomId,
        controllerId: state.controllerId,
        input
      });
      if (!payload.success) {
        emitAirJamDiagnostic({
          code: "AJ_INPUT_WRITER_SCHEMA_INVALID",
          severity: "warn",
          message: "Input writer payload failed controller input schema validation.",
          details: {
            issueCount: payload.error.issues.length
          }
        });
        return false;
      }
      socket.emit("controller:input", payload.data);
      return true;
    },
    [getSocket, store]
  );
};
var usePlayers = () => {
  const { store } = useAirJamContext();
  return useStore(
    store,
    useShallow((state) => state.players)
  );
};
var useRoom = () => {
  const { store } = useAirJamContext();
  return useStore(
    store,
    useShallow((state) => ({
      roomId: state.roomId,
      runtimeState: state.runtimeState,
      mode: state.mode
    }))
  );
};
var useSendSignal = () => {
  useAssertSessionScope("host", "useSendSignal");
  const { getSocket } = useAirJamContext();
  const sendSignal = (0, import_react9.useCallback)(
    (type, payload, targetId) => {
      const socket = getHostRealtimeClient((role) => getSocket(role));
      if (!socket || !socket.connected) {
        return;
      }
      const signal = {
        targetId,
        type,
        payload
      };
      socket.emit("host:signal", signal);
    },
    [getSocket]
  );
  return sendSignal;
};
var AIR_JAM_RUNTIME_INSPECTION_KEY = "__airJamRuntimeInspection";
var createHostRuntimeInspectionContract = (api) => ({
  role: "host",
  roomId: api.roomId,
  joinUrl: api.joinUrl,
  joinUrlStatus: api.joinUrlStatus,
  connectionStatus: api.connectionStatus,
  players: api.players,
  controllers: api.controllers,
  lastError: api.lastError,
  mode: api.mode,
  runtimeState: api.runtimeState
});
var createControllerRuntimeInspectionContract = (api) => ({
  role: "controller",
  roomId: api.roomId,
  controllerId: api.controllerId,
  connectionStatus: api.connectionStatus,
  players: api.players,
  selfPlayer: api.selfPlayer,
  lastError: api.lastError,
  runtimeState: api.runtimeState,
  controllerOrientation: api.controllerOrientation,
  stateMessage: api.stateMessage,
  roomSettings: api.roomSettings
});
var isRecord = (value) => typeof value === "object" && value !== null;
var isHostRuntimeInspectionContract = (value) => isRecord(value) && value.role === "host" && typeof value.roomId === "string" && typeof value.joinUrl === "string" && typeof value.joinUrlStatus === "string" && typeof value.connectionStatus === "string" && Array.isArray(value.players) && Array.isArray(value.controllers) && typeof value.mode === "string" && typeof value.runtimeState === "string";
var isControllerRuntimeInspectionContract = (value) => isRecord(value) && value.role === "controller" && (typeof value.roomId === "string" || value.roomId === null) && (typeof value.controllerId === "string" || value.controllerId === null) && typeof value.connectionStatus === "string" && Array.isArray(value.players) && typeof value.runtimeState === "string" && typeof value.controllerOrientation === "string" && isRecord(value.roomSettings) && isRecord(value.roomSettings.audio) && isRecord(value.roomSettings.previewControllers);
var readRuntimeInspectionContract = (target) => {
  const candidate = target[AIR_JAM_RUNTIME_INSPECTION_KEY];
  if (isHostRuntimeInspectionContract(candidate)) {
    return candidate;
  }
  if (isControllerRuntimeInspectionContract(candidate)) {
    return candidate;
  }
  return null;
};
var publishRuntimeInspectionContract = (target, contract) => {
  const hostTarget = target;
  if (contract) {
    hostTarget[AIR_JAM_RUNTIME_INSPECTION_KEY] = contract;
    return;
  }
  delete hostTarget[AIR_JAM_RUNTIME_INSPECTION_KEY];
};
var useHostRuntimeInspectionContract = () => createHostRuntimeInspectionContract(useAirJamHost());
var useControllerRuntimeInspectionContract = () => createControllerRuntimeInspectionContract(useAirJamController());
var createScopedSessionProvider = (scope) => {
  const ScopedSessionProvider = ({
    children,
    ...providerProps
  }) => {
    const runtimeOwnersRef = (0, import_react11.useRef)(/* @__PURE__ */ new Map());
    const claimOwner = (0, import_react11.useCallback)(
      (kind, token, hookName) => {
        const existing = runtimeOwnersRef.current.get(kind);
        if (existing && existing.token !== token) {
          throw createAirJamDiagnosticError(
            "AJ_DUPLICATE_SESSION_OWNER",
            `${hookName} mounted while another ${kind} already owns this session provider. Mount one runtime owner hook per provider tree and use useAirJamHost() or useAirJamController() in child components instead.`,
            {
              scope,
              kind,
              hookName,
              existingHookName: existing.hookName
            }
          );
        }
        runtimeOwnersRef.current.set(kind, { token, hookName });
        return () => {
          const current = runtimeOwnersRef.current.get(kind);
          if ((current == null ? void 0 : current.token) === token) {
            runtimeOwnersRef.current.delete(kind);
          }
        };
      },
      []
    );
    return (0, import_jsx_runtime2.jsx)(SessionScopeContext.Provider, { value: scope, children: (0, import_jsx_runtime2.jsx)(RuntimeOwnerRegistryContext.Provider, { value: { claimOwner }, children: (0, import_jsx_runtime2.jsx)(AirJamProvider, { ...providerProps, surfaceRole: scope, children }) }) });
  };
  return ScopedSessionProvider;
};
var HostSessionProvider = createScopedSessionProvider("host");
var ControllerSessionProvider = createScopedSessionProvider("controller");
var DEVICE_ID_STORAGE_KEY = "airjam_controller_device_id";
var ROOM_BINDINGS_STORAGE_KEY = "airjam_controller_room_bindings";
var getLocalStorage = () => {
  if (typeof window === "undefined") {
    return null;
  }
  try {
    return window.localStorage;
  } catch {
    return null;
  }
};
var generateControllerDeviceId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return `d_${crypto.randomUUID()}`;
  }
  return `d_${generateControllerId()}_${Date.now().toString(36)}`;
};
var getOrCreateControllerDeviceId = () => {
  return getOrCreateControllerDeviceIdFromStorage(getLocalStorage());
};
var getOrCreateControllerDeviceIdFromStorage = (storage) => {
  if (!storage) {
    return generateControllerDeviceId();
  }
  const existing = storage.getItem(DEVICE_ID_STORAGE_KEY);
  if (existing && existing.trim().length >= 8) {
    return existing;
  }
  const created = generateControllerDeviceId();
  storage.setItem(DEVICE_ID_STORAGE_KEY, created);
  return created;
};
var readRoomBindings = (storage) => {
  if (!storage) {
    return {};
  }
  const raw = storage.getItem(ROOM_BINDINGS_STORAGE_KEY);
  if (!raw) {
    return {};
  }
  try {
    const parsed = JSON.parse(raw);
    const next = {};
    for (const [key, value] of Object.entries(parsed)) {
      if (key.trim().length > 0 && typeof value === "string") {
        next[key] = value;
      }
    }
    return next;
  } catch {
    return {};
  }
};
var writeRoomBindings = (storage, bindings) => {
  if (!storage) {
    return;
  }
  storage.setItem(ROOM_BINDINGS_STORAGE_KEY, JSON.stringify(bindings));
};
var readControllerRoomBinding = (roomId) => {
  return readControllerRoomBindingFromStorage(getLocalStorage(), roomId);
};
var readControllerRoomBindingFromStorage = (storage, roomId) => {
  const bindings = readRoomBindings(storage);
  const binding = bindings[roomId.toUpperCase()];
  return typeof binding === "string" && binding.trim().length >= 3 ? binding : null;
};
var writeControllerRoomBinding = (roomId, controllerId) => {
  writeControllerRoomBindingToStorage(getLocalStorage(), roomId, controllerId);
};
var writeControllerRoomBindingToStorage = (storage, roomId, controllerId) => {
  if (!roomId || !controllerId) {
    return;
  }
  const bindings = readRoomBindings(storage);
  bindings[roomId.toUpperCase()] = controllerId;
  writeRoomBindings(storage, bindings);
};
var clearControllerRoomBinding = (roomId) => {
  clearControllerRoomBindingFromStorage(getLocalStorage(), roomId);
};
var clearControllerRoomBindingFromStorage = (storage, roomId) => {
  const normalized = roomId.toUpperCase();
  const bindings = readRoomBindings(storage);
  if (!(normalized in bindings)) {
    return;
  }
  delete bindings[normalized];
  writeRoomBindings(storage, bindings);
};
var readEmbeddedHostChildSession = () => {
  const raw = readChildHostRuntimeParams();
  if (!raw) {
    return null;
  }
  return {
    roomId: roomCodeSchema.parse(raw.room.toUpperCase()),
    joinUrl: raw.joinUrl,
    topology: raw.topology,
    arcadeSurface: raw.arcadeSurface
  };
};
var readEmbeddedControllerChildSession = () => {
  const raw = readEmbeddedControllerRuntimeParams();
  if (!raw) {
    return null;
  }
  return {
    roomId: roomCodeSchema.parse(raw.room.toUpperCase()),
    controllerId: raw.controllerId,
    topology: raw.topology,
    arcadeSurface: raw.arcadeSurface,
    ...raw.playerProfile ? { playerProfile: raw.playerProfile } : {}
  };
};
var detectRunMode = () => {
  if (typeof window === "undefined") {
    return "standalone";
  }
  try {
    return window.self !== window.top ? "platform" : "standalone";
  } catch {
    return "platform";
  }
};
var getRoomFromLocation = () => {
  if (typeof window === "undefined") {
    return null;
  }
  const params = new URLSearchParams(window.location.search);
  const code = params.get("room");
  return code ? code.toUpperCase() : null;
};
var getControllerCapabilityTokenFromLocation = () => {
  if (typeof window === "undefined") {
    return null;
  }
  const params = new URLSearchParams(window.location.search);
  return params.get("aj_controller_cap");
};
var resolveControllerJoinSource = ({
  embeddedRoomId,
  optionRoomId,
  urlRoomId
}) => {
  if (embeddedRoomId) {
    return "embedded";
  }
  if (optionRoomId) {
    return "options";
  }
  if (urlRoomId) {
    return "url";
  }
  return "unknown";
};
var useControllerRuntimeApi = (options, hookName) => {
  useAssertSessionScope("controller", hookName);
  useClaimSessionRuntimeOwner("controller-runtime", hookName);
  const { store, getSocket, disconnectSocket } = useAirJamContext();
  const nicknameRef = (0, import_react12.useRef)(options.nickname ?? "");
  const avatarIdRef = (0, import_react12.useRef)(options.avatarId ?? "");
  (0, import_react12.useEffect)(() => {
    nicknameRef.current = options.nickname ?? "";
  }, [options.nickname]);
  (0, import_react12.useEffect)(() => {
    avatarIdRef.current = options.avatarId ?? "";
  }, [options.avatarId]);
  const embeddedController = (0, import_react12.useMemo)(
    () => readEmbeddedControllerChildSession(),
    []
  );
  const urlRoomId = (0, import_react12.useMemo)(() => getRoomFromLocation(), []);
  const locationCapabilityToken = (0, import_react12.useMemo)(
    () => getControllerCapabilityTokenFromLocation(),
    []
  );
  const capabilityToken = options.capabilityToken === void 0 ? locationCapabilityToken : options.capabilityToken;
  const previewDeviceId = (0, import_react12.useMemo)(
    () => readPreviewControllerDeviceIdFromLocation(),
    []
  );
  const joinSource = (0, import_react12.useMemo)(
    () => resolveControllerJoinSource({
      embeddedRoomId: embeddedController == null ? void 0 : embeddedController.roomId,
      optionRoomId: options.roomId ?? null,
      urlRoomId
    }),
    [embeddedController == null ? void 0 : embeddedController.roomId, options.roomId, urlRoomId]
  );
  const parsedRoomId = (0, import_react12.useMemo)(() => {
    const code = (embeddedController == null ? void 0 : embeddedController.roomId) ?? options.roomId ?? urlRoomId;
    if (!code) return null;
    try {
      return roomCodeSchema.parse(code.toUpperCase());
    } catch {
      return null;
    }
  }, [options.roomId, embeddedController, urlRoomId]);
  const deviceId = (0, import_react12.useMemo)(() => {
    if (embeddedController) {
      return null;
    }
    if (previewDeviceId) {
      return previewDeviceId;
    }
    return getOrCreateControllerDeviceId();
  }, [embeddedController, previewDeviceId]);
  const controllerId = (0, import_react12.useMemo)(() => {
    if (embeddedController == null ? void 0 : embeddedController.controllerId) {
      return embeddedController.controllerId;
    }
    if (options.controllerId) {
      return options.controllerId;
    }
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const urlControllerId = params.get("controllerId");
      if (urlControllerId) return urlControllerId;
    }
    if (parsedRoomId) {
      const persistedControllerId = readControllerRoomBinding(parsedRoomId);
      if (persistedControllerId) {
        return persistedControllerId;
      }
    }
    return generateControllerId();
  }, [options.controllerId, embeddedController, parsedRoomId]);
  const onStateRef = (0, import_react12.useRef)(
    options.onState
  );
  (0, import_react12.useEffect)(() => {
    onStateRef.current = options.onState;
  }, [options.onState]);
  const activeControllerId = useStore(store, (state) => state.controllerId);
  (0, import_react12.useEffect)(() => {
    updateDevBrowserLogContext({
      role: "controller",
      traceId: void 0,
      roomId: parsedRoomId ?? void 0,
      controllerId: activeControllerId ?? controllerId ?? void 0
    });
  }, [activeControllerId, controllerId, parsedRoomId]);
  (0, import_react12.useEffect)(() => {
    return () => {
      updateDevBrowserLogContext({
        role: void 0,
        roomId: void 0,
        controllerId: void 0
      });
    };
  }, []);
  const [reconnectKey, setReconnectKey] = (0, import_react12.useState)(0);
  const leaveIssuedRef = (0, import_react12.useRef)(false);
  const emitControllerRuntimeEvent = (0, import_react12.useCallback)(
    ({
      event,
      level = "info",
      message,
      roomId,
      data
    }) => {
      emitAirJamDevRuntimeEvent({
        event,
        level,
        message,
        role: "controller",
        roomId,
        controllerId,
        data
      });
    },
    [controllerId]
  );
  const lastObservedStateVersionRef = (0, import_react12.useRef)(null);
  const emittedInvariantKeysRef = (0, import_react12.useRef)(/* @__PURE__ */ new Set());
  const emitInvariantOnce = (0, import_react12.useCallback)(
    ({
      code,
      roomId,
      data,
      message
    }) => {
      const key = `${roomId ?? "unknown"}:${code}`;
      if (emittedInvariantKeysRef.current.has(key)) {
        return;
      }
      emittedInvariantKeysRef.current.add(key);
      emitControllerRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.invariantViolation,
        level: "warn",
        message,
        roomId,
        data: {
          code,
          ...data
        }
      });
    },
    [emitControllerRuntimeEvent]
  );
  const socket = (0, import_react12.useMemo)(
    () => parsedRoomId ? getControllerRealtimeClient((role) => getSocket(role)) : null,
    [parsedRoomId, getSocket]
  );
  const reconnect = (0, import_react12.useCallback)(() => {
    if (!parsedRoomId) return;
    socket == null ? void 0 : socket.disconnect();
    if (!embeddedController) {
      disconnectSocket("controller");
    }
    setReconnectKey((prev) => prev + 1);
  }, [parsedRoomId, disconnectSocket, socket, embeddedController]);
  const leave = (0, import_react12.useCallback)(async () => {
    const storeState = store.getState();
    const activeControllerId2 = storeState.controllerId;
    if (!socket || !parsedRoomId || !activeControllerId2) {
      return { ok: false, message: "Not connected" };
    }
    if (!socket.connected) {
      return { ok: true };
    }
    const payload = controllerLeaveSchema.safeParse({
      roomId: parsedRoomId,
      controllerId: activeControllerId2
    });
    if (!payload.success) {
      return {
        ok: false,
        message: payload.error.message
      };
    }
    const applyLocalLeaveState = () => {
      if (parsedRoomId) {
        clearControllerRoomBinding(parsedRoomId);
      }
      const latestState = store.getState();
      latestState.removePlayer(activeControllerId2);
      latestState.setControllerId(null);
      latestState.setStatus("disconnected");
      latestState.resetRuntimeState();
    };
    leaveIssuedRef.current = true;
    if (embeddedController) {
      socket.emit("controller:leave", payload.data);
      applyLocalLeaveState();
      return { ok: true };
    }
    return await new Promise((resolve) => {
      socket.emit(
        "controller:leave",
        payload.data,
        (ack) => {
          if (ack.ok) {
            applyLocalLeaveState();
          }
          resolve(ack);
        }
      );
    });
  }, [embeddedController, parsedRoomId, socket, store]);
  (0, import_react12.useEffect)(() => {
    if (!socket) return;
    const handleSignal = (signal) => {
      if (signal.type !== "HAPTIC") return;
      if (typeof navigator === "undefined" || !navigator.vibrate) return;
      const payload = signal.payload;
      switch (payload.pattern) {
        case "light":
          navigator.vibrate(10);
          break;
        case "medium":
          navigator.vibrate(30);
          break;
        case "heavy":
          navigator.vibrate([50, 20, 50]);
          break;
        case "success":
          navigator.vibrate([10, 30, 10]);
          break;
        case "failure":
          navigator.vibrate([50, 50, 50, 50]);
          break;
        case "custom":
          if (Array.isArray(payload.sequence)) {
            navigator.vibrate(payload.sequence);
          } else if (typeof payload.sequence === "number") {
            navigator.vibrate(payload.sequence);
          }
          break;
      }
    };
    socket.on("server:signal", handleSignal);
    return () => {
      socket.off("server:signal", handleSignal);
    };
  }, [socket]);
  (0, import_react12.useEffect)(() => {
    if (typeof window === "undefined" || !previewDeviceId || embeddedController || !socket) {
      return;
    }
    const handleMessage = (event) => {
      if (event.source !== window.parent) {
        return;
      }
      if (!isPreviewCloseRequestMessage(event.data)) {
        return;
      }
      void leave().catch(() => ({ ok: false })).then((ack) => {
        window.parent.postMessage(
          {
            type: AIR_JAM_PREVIEW_CLOSE_RESULT,
            ok: ack.ok
          },
          "*"
        );
        socket.disconnect();
        disconnectSocket("controller");
      });
    };
    window.addEventListener("message", handleMessage);
    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, [disconnectSocket, embeddedController, leave, previewDeviceId, socket]);
  (0, import_react12.useEffect)(() => {
    if (!previewDeviceId || !parsedRoomId || embeddedController || !socket) {
      return;
    }
    return () => {
      const controllerIdForLeave = store.getState().controllerId;
      if (leaveIssuedRef.current || !controllerIdForLeave || !socket.connected) {
        return;
      }
      leaveIssuedRef.current = true;
      socket.emit(
        "controller:leave",
        {
          roomId: parsedRoomId,
          controllerId: controllerIdForLeave
        },
        () => {
        }
      );
    };
  }, [embeddedController, parsedRoomId, previewDeviceId, socket, store]);
  (0, import_react12.useEffect)(() => {
    var _a, _b, _c, _d;
    const storeState = store.getState();
    storeState.setMode(detectRunMode());
    storeState.setRole("controller");
    storeState.setRoomId(parsedRoomId);
    storeState.setStatus(parsedRoomId ? "connecting" : "idle");
    storeState.setError(void 0);
    lastObservedStateVersionRef.current = null;
    emittedInvariantKeysRef.current.clear();
    if (!parsedRoomId || !socket || !controllerId) {
      storeState.setStatus("idle");
      return;
    }
    storeState.setControllerId(controllerId);
    if (((_a = embeddedController == null ? void 0 : embeddedController.playerProfile) == null ? void 0 : _a.label) || ((_b = embeddedController == null ? void 0 : embeddedController.playerProfile) == null ? void 0 : _b.avatarId)) {
      const fallbackPlayer = {
        id: controllerId,
        label: ((_c = embeddedController.playerProfile) == null ? void 0 : _c.label) || nicknameRef.current || "Player",
        ...((_d = embeddedController.playerProfile) == null ? void 0 : _d.avatarId) ? { avatarId: embeddedController.playerProfile.avatarId } : avatarIdRef.current ? { avatarId: avatarIdRef.current } : {}
      };
      storeState.upsertPlayer(fallbackPlayer);
    }
    const handleConnect = () => {
      emitControllerRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.socketConnected,
        message: "Controller socket connected",
        roomId: parsedRoomId ?? void 0,
        data: {
          socketId: socket.id,
          connected: socket.connected
        }
      });
      store.getState().setStatus("connected");
      if (embeddedController) {
        return;
      }
      const payload = controllerJoinSchema.parse({
        roomId: parsedRoomId,
        controllerId,
        deviceId: deviceId ?? void 0,
        nickname: nicknameRef.current || void 0,
        avatarId: avatarIdRef.current || void 0,
        capabilityToken: capabilityToken ?? void 0
      });
      emitControllerRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.controllerJoinRequested,
        message: "Controller requested room join",
        roomId: payload.roomId,
        data: {
          joinSource,
          controllerId: payload.controllerId,
          hasNickname: Boolean(payload.nickname),
          hasAvatarId: Boolean(payload.avatarId),
          hasCapabilityToken: Boolean(payload.capabilityToken)
        }
      });
      socket.emit("controller:join", payload, (ack) => {
        const latestState = store.getState();
        if (!ack.ok) {
          if (ack.code === "ROOM_NOT_FOUND") {
            clearControllerRoomBinding(parsedRoomId);
          }
          latestState.setError(ack.message ?? "Unable to join room");
          latestState.setStatus("disconnected");
          latestState.resetRuntimeState();
          return;
        }
        if (ack.controllerId) {
          latestState.setControllerId(ack.controllerId);
          writeControllerRoomBinding(parsedRoomId, ack.controllerId);
        }
        latestState.setStatus("connected");
      });
    };
    const handleDisconnect = (reason) => {
      emitControllerRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.socketDisconnected,
        message: "Controller socket disconnected",
        roomId: parsedRoomId ?? void 0,
        data: {
          socketId: socket.id,
          reason
        }
      });
      const latestState = store.getState();
      if (reason) {
        latestState.setError(reason);
      }
      latestState.setStatus("disconnected");
      latestState.resetRuntimeState();
      lastObservedStateVersionRef.current = null;
    };
    const handleConnectError = (error) => {
      emitControllerRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.socketConnectError,
        level: "warn",
        message: "Controller socket connect error",
        roomId: parsedRoomId ?? void 0,
        data: {
          message: error.message,
          name: error.name
        }
      });
    };
    const handleWelcome = (payload) => {
      const latestState = store.getState();
      const storeRoomId = latestState.roomId;
      if (storeRoomId && payload.roomId.toUpperCase() !== storeRoomId.toUpperCase()) {
        return;
      }
      if (!storeRoomId && payload.roomId) {
        latestState.setRoomId(payload.roomId);
      }
      writeControllerRoomBinding(payload.roomId, payload.controllerId);
      if (Array.isArray(payload.players)) {
        latestState.resetPlayers();
        payload.players.forEach((player) => {
          latestState.upsertPlayer(player);
        });
      }
      if (!payload.player) {
        latestState.setError(
          "Welcome message received but no player profile included."
        );
        return;
      }
      latestState.upsertPlayer(payload.player);
    };
    const handleControllerJoined = (payload) => {
      if (!payload.player) {
        return;
      }
      store.getState().upsertPlayer(payload.player);
    };
    const handleControllerLeft = (payload) => {
      store.getState().removePlayer(payload.controllerId);
    };
    const handleState = (payload) => {
      var _a2;
      if (payload.roomId !== parsedRoomId) return;
      emitControllerRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.controllerStateReceived,
        message: "Controller received state update",
        roomId: payload.roomId,
        data: {
          runtimeState: payload.state.runtimeState,
          orientation: payload.state.orientation,
          stateVersion: payload.state.stateVersion,
          hasMessage: payload.state.message !== void 0
        }
      });
      const latestState = store.getState();
      const previousRuntimeState = latestState.runtimeState;
      const nextRuntimeState = payload.state.runtimeState ?? previousRuntimeState;
      const incomingVersion = payload.state.stateVersion;
      const previousVersion = lastObservedStateVersionRef.current;
      if (typeof incomingVersion === "number") {
        if (previousVersion === null) {
          emitControllerRuntimeEvent({
            event: AIRJAM_DEV_LOG_EVENTS.runtime.stateVersionReceived,
            message: "Controller received initial room state version",
            roomId: payload.roomId,
            data: {
              stateVersion: incomingVersion,
              relation: "initial"
            }
          });
        } else if (incomingVersion <= previousVersion) {
          emitControllerRuntimeEvent({
            event: AIRJAM_DEV_LOG_EVENTS.runtime.stateVersionReceived,
            level: "warn",
            message: "Controller received non-monotonic room state version",
            roomId: payload.roomId,
            data: {
              stateVersion: incomingVersion,
              previousStateVersion: previousVersion,
              relation: "non_monotonic"
            }
          });
          emitInvariantOnce({
            code: "state_version_non_monotonic",
            roomId: payload.roomId,
            message: "Received non-monotonic room state version in controller runtime",
            data: {
              stateVersion: incomingVersion,
              previousStateVersion: previousVersion
            }
          });
        } else if (incomingVersion !== previousVersion + 1) {
          emitControllerRuntimeEvent({
            event: AIRJAM_DEV_LOG_EVENTS.runtime.stateVersionReceived,
            message: "Controller detected room state version gap",
            roomId: payload.roomId,
            data: {
              stateVersion: incomingVersion,
              previousStateVersion: previousVersion,
              relation: "gap"
            }
          });
        }
        lastObservedStateVersionRef.current = previousVersion === null ? incomingVersion : Math.max(previousVersion, incomingVersion);
      }
      if (typeof incomingVersion === "number" && nextRuntimeState !== previousRuntimeState) {
        emitControllerRuntimeEvent({
          event: AIRJAM_DEV_LOG_EVENTS.runtime.phaseTransition,
          message: "Controller runtime phase transition",
          roomId: payload.roomId,
          data: {
            from: previousRuntimeState,
            to: nextRuntimeState,
            source: "server_state",
            stateVersion: incomingVersion
          }
        });
      }
      if (payload.state.runtimeState) {
        latestState.setRuntimeState(payload.state.runtimeState);
      }
      if (payload.state.orientation) {
        latestState.setControllerOrientation(payload.state.orientation);
      }
      if (payload.state.message !== void 0) {
        latestState.setStateMessage(payload.state.message);
      }
      if (payload.state.roomSettings) {
        latestState.setRoomSettings(payload.state.roomSettings);
      }
      (_a2 = onStateRef.current) == null ? void 0 : _a2.call(onStateRef, payload.state);
    };
    const handleHostLeft = (payload) => {
      const latestState = store.getState();
      if (parsedRoomId) {
        clearControllerRoomBinding(parsedRoomId);
      }
      latestState.setError(payload.reason);
      latestState.setStatus("disconnected");
      latestState.resetRuntimeState();
      lastObservedStateVersionRef.current = null;
      setTimeout(() => {
        socket.disconnect();
        if (!embeddedController) {
          disconnectSocket("controller");
        }
        setReconnectKey((prev) => prev + 1);
      }, 1e3);
    };
    const handleError = (payload) => {
      store.getState().setError(payload.message);
    };
    const handlePlayerUpdated = (payload) => {
      store.getState().upsertPlayer(payload.player);
    };
    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);
    socket.on("connect_error", handleConnectError);
    socket.on("server:welcome", handleWelcome);
    socket.on("server:controllerJoined", handleControllerJoined);
    socket.on("server:controllerLeft", handleControllerLeft);
    socket.on("server:state", handleState);
    socket.on("server:hostLeft", handleHostLeft);
    socket.on("server:error", handleError);
    socket.on("server:playerUpdated", handlePlayerUpdated);
    if (socket.connected) {
      handleConnect();
    } else {
      socket.connect();
    }
    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      socket.off("connect_error", handleConnectError);
      socket.off("server:welcome", handleWelcome);
      socket.off("server:controllerJoined", handleControllerJoined);
      socket.off("server:controllerLeft", handleControllerLeft);
      socket.off("server:state", handleState);
      socket.off("server:hostLeft", handleHostLeft);
      socket.off("server:error", handleError);
      socket.off("server:playerUpdated", handlePlayerUpdated);
    };
  }, [
    parsedRoomId,
    reconnectKey,
    socket,
    controllerId,
    embeddedController,
    store,
    disconnectSocket,
    emitControllerRuntimeEvent,
    deviceId,
    joinSource,
    capabilityToken,
    emitInvariantOnce
  ]);
  const setNickname = (0, import_react12.useCallback)((value) => {
    nicknameRef.current = value;
  }, []);
  const setAvatarId = (0, import_react12.useCallback)((value) => {
    avatarIdRef.current = value;
  }, []);
  const updatePlayerProfile = (0, import_react12.useCallback)(
    (patch) => {
      const parsedPatch = playerProfilePatchSchema.safeParse(patch);
      if (!parsedPatch.success) {
        return Promise.resolve({
          ok: false,
          message: parsedPatch.error.message
        });
      }
      if (!socket || !parsedRoomId) {
        return Promise.resolve({ ok: false, message: "Not connected" });
      }
      const controllerIdForPatch = store.getState().controllerId;
      if (!controllerIdForPatch) {
        return Promise.resolve({ ok: false, message: "No controller id" });
      }
      const payload = {
        roomId: parsedRoomId,
        controllerId: controllerIdForPatch,
        patch: parsedPatch.data
      };
      if (embeddedController) {
        socket.emit("controller:updatePlayerProfile", payload);
        return Promise.resolve({ ok: true });
      }
      return new Promise((resolve) => {
        socket.emit(
          "controller:updatePlayerProfile",
          payload,
          (ack) => {
            resolve(ack);
          }
        );
      });
    },
    [parsedRoomId, socket, store, embeddedController]
  );
  const sendSystemCommand = (0, import_react12.useCallback)(
    (command) => {
      const storeState = store.getState();
      if (!parsedRoomId || !storeState.controllerId || !socket) return;
      if (!socket.connected) return;
      const payload = controllerSystemSchema.safeParse({
        roomId: parsedRoomId,
        command
      });
      if (payload.success) {
        socket.emit("controller:system", payload.data);
      }
    },
    [parsedRoomId, socket, store]
  );
  return (0, import_react12.useMemo)(
    () => ({
      sendSystemCommand,
      setNickname,
      setAvatarId,
      updatePlayerProfile,
      leave,
      reconnect,
      socket
    }),
    [
      leave,
      reconnect,
      sendSystemCommand,
      setAvatarId,
      setNickname,
      socket,
      updatePlayerProfile
    ]
  );
};
var HOST_BOOTSTRAP_TIMEOUT_MESSAGE = "Host bootstrap timed out. The deployed Air Jam server may be out of sync with this client.";
var useHostRuntimeApi = (options, hookName) => {
  useAssertSessionScope("host", hookName);
  useClaimSessionRuntimeOwner("host-runtime", hookName);
  const { config, store, getSocket, disconnectSocket, inputManager } = useAirJamContext();
  const embeddedHost = (0, import_react13.useMemo)(() => readEmbeddedHostChildSession(), []);
  const shouldConnect = true;
  const storeRoomId = useStore(store, (s) => s.roomId);
  const parsedRoomId = (0, import_react13.useMemo)(() => {
    if (embeddedHost) {
      return embeddedHost.roomId;
    }
    if (storeRoomId) {
      return roomCodeSchema.parse(storeRoomId.toUpperCase());
    }
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const paramRoom = params.get("room");
      if (paramRoom) {
        const result = roomCodeSchema.safeParse(paramRoom.toUpperCase());
        if (result.success) return result.data;
      }
    }
    if (options.roomId) {
      return roomCodeSchema.parse(options.roomId.toUpperCase());
    }
    return null;
  }, [options.roomId, storeRoomId, embeddedHost]);
  const [controllerCapability, setControllerCapability] = (0, import_react13.useState)(null);
  const joinUrlBuildKey = (0, import_react13.useMemo)(
    () => parsedRoomId ? `${parsedRoomId}\0${config.publicHost ?? ""}\0${(controllerCapability == null ? void 0 : controllerCapability.token) ?? ""}` : null,
    [config.publicHost, controllerCapability == null ? void 0 : controllerCapability.token, parsedRoomId]
  );
  const [computedJoinUrl, setComputedJoinUrl] = (0, import_react13.useState)({
    key: null,
    url: "",
    error: false
  });
  const onPlayerJoinRef = (0, import_react13.useRef)(options.onPlayerJoin);
  const onPlayerLeaveRef = (0, import_react13.useRef)(options.onPlayerLeave);
  const parsedRoomIdRef = (0, import_react13.useRef)(parsedRoomId);
  (0, import_react13.useEffect)(() => {
    onPlayerJoinRef.current = options.onPlayerJoin;
    onPlayerLeaveRef.current = options.onPlayerLeave;
  }, [options.onPlayerJoin, options.onPlayerLeave]);
  (0, import_react13.useEffect)(() => {
    parsedRoomIdRef.current = parsedRoomId;
  }, [parsedRoomId]);
  const socket = (0, import_react13.useMemo)(
    () => shouldConnect ? getHostRealtimeClient((role) => getSocket(role)) : null,
    [shouldConnect, getSocket]
  );
  const setRegisteredRoomId = useStore(store, (s) => s.setRegisteredRoomId);
  const hydrateHostRoster = (0, import_react13.useCallback)(
    (players, controllers) => {
      const latestState = store.getState();
      latestState.resetPlayers();
      players == null ? void 0 : players.forEach((player) => {
        latestState.upsertPlayer(player);
      });
      latestState.resetControllerSessions();
      controllers == null ? void 0 : controllers.forEach((controller) => {
        latestState.upsertControllerSession(controller);
      });
    },
    [store]
  );
  const canEmitAuthoritativeHostState = (0, import_react13.useCallback)(
    (roomId) => {
      if (!socket || !socket.connected || !roomId) {
        return false;
      }
      const latestState = store.getState();
      return latestState.registeredRoomId === roomId && latestState.hostArcadeRestore.phase === "idle";
    },
    [socket, store]
  );
  const emitHostRuntimeEvent = (0, import_react13.useCallback)(
    ({
      event,
      level = "info",
      message,
      roomId,
      data
    }) => {
      emitAirJamDevRuntimeEvent({
        event,
        level,
        message,
        role: "host",
        roomId,
        data
      });
    },
    []
  );
  const lastObservedStateVersionRef = (0, import_react13.useRef)(null);
  const emittedInvariantKeysRef = (0, import_react13.useRef)(/* @__PURE__ */ new Set());
  const emitInvariantOnce = (0, import_react13.useCallback)(
    ({
      code,
      roomId,
      data,
      message
    }) => {
      const key = `${roomId ?? "unknown"}:${code}`;
      if (emittedInvariantKeysRef.current.has(key)) {
        return;
      }
      emittedInvariantKeysRef.current.add(key);
      emitHostRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.invariantViolation,
        level: "warn",
        message,
        roomId,
        data: {
          code,
          ...data
        }
      });
    },
    [emitHostRuntimeEvent]
  );
  const sendState = (0, import_react13.useCallback)(
    (state) => {
      const activeSocket = socket;
      const activeRoomId = parsedRoomIdRef.current;
      if (!activeSocket || !canEmitAuthoritativeHostState(activeRoomId)) {
        return false;
      }
      const payload = controllerStateSchema.safeParse({
        roomId: activeRoomId,
        state
      });
      if (!payload.success) {
        return false;
      }
      activeSocket.emit("host:state", payload.data);
      return true;
    },
    [canEmitAuthoritativeHostState, socket]
  );
  const setRuntimeState = (0, import_react13.useCallback)(
    (runtimeState) => {
      const activeRoomId = parsedRoomIdRef.current;
      if (store.getState().runtimeState === runtimeState) {
        return;
      }
      if (!canEmitAuthoritativeHostState(activeRoomId)) {
        return;
      }
      sendState({ runtimeState });
    },
    [canEmitAuthoritativeHostState, sendState, store]
  );
  const pauseRuntime = (0, import_react13.useCallback)(() => {
    setRuntimeState("paused");
  }, [setRuntimeState]);
  const resumeRuntime = (0, import_react13.useCallback)(() => {
    setRuntimeState("playing");
  }, [setRuntimeState]);
  const sendSignal = (0, import_react13.useCallback)(
    (type, payload, targetId) => {
      if (!socket || !socket.connected) {
        return;
      }
      const signal = {
        targetId,
        type,
        payload
      };
      socket.emit("host:signal", signal);
    },
    [socket]
  );
  const reconnect = (0, import_react13.useCallback)(() => {
    socket == null ? void 0 : socket.disconnect();
    if (!embeddedHost) {
      disconnectSocket("host");
    }
    if (socket) {
      socket.connect();
    }
  }, [socket, embeddedHost, disconnectSocket]);
  const removeController = (0, import_react13.useCallback)(
    async (controllerId) => {
      const activeRoomId = parsedRoomIdRef.current;
      if (!socket || !activeRoomId) {
        return {
          ok: false,
          message: "Host is not connected to a room."
        };
      }
      const payload = hostRemoveControllerSchema.parse({
        roomId: activeRoomId,
        controllerId
      });
      return socket.emitWithAck("host:removeController", payload);
    },
    [socket]
  );
  const resetRoom = (0, import_react13.useCallback)(async () => {
    const activeRoomId = parsedRoomIdRef.current;
    if (!socket || !activeRoomId) {
      return {
        ok: false,
        message: "Host is not connected to a room."
      };
    }
    const payload = hostResetRoomSchema.parse({
      roomId: activeRoomId
    });
    emitHostRuntimeEvent({
      event: AIRJAM_DEV_LOG_EVENTS.runtime.hostResetRoomRequested,
      message: "Host requested local room reset",
      roomId: activeRoomId
    });
    const ack = await socket.emitWithAck(
      "host:resetRoom",
      payload
    );
    if (!ack.ok || !ack.roomId) {
      return ack;
    }
    const latestState = store.getState();
    latestState.setStatus("connected");
    latestState.setRoomId(ack.roomId);
    latestState.setError(void 0);
    latestState.clearHostArcadeRestore();
    latestState.resetRuntimeState();
    hydrateHostRoster(ack.players, ack.controllers);
    setRegisteredRoomId(ack.roomId);
    setControllerCapability(ack.controllerCapability ?? null);
    if (typeof window !== "undefined") {
      sessionStorage.setItem("airjam_room_id", ack.roomId);
    }
    return ack;
  }, [
    emitHostRuntimeEvent,
    hydrateHostRoster,
    setRegisteredRoomId,
    socket,
    store
  ]);
  (0, import_react13.useEffect)(() => {
    if (embeddedHost == null ? void 0 : embeddedHost.joinUrl) {
      return;
    }
    if (!parsedRoomId || !joinUrlBuildKey) {
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const url = await urlBuilder.buildControllerUrl(parsedRoomId, {
          host: config.publicHost,
          capabilityToken: controllerCapability == null ? void 0 : controllerCapability.token
        });
        if (!cancelled) {
          setComputedJoinUrl({
            key: joinUrlBuildKey,
            url,
            error: false
          });
        }
      } catch {
        if (!cancelled) {
          setComputedJoinUrl({
            key: joinUrlBuildKey,
            url: "",
            error: true
          });
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [
    parsedRoomId,
    embeddedHost == null ? void 0 : embeddedHost.joinUrl,
    config.publicHost,
    controllerCapability == null ? void 0 : controllerCapability.token,
    joinUrlBuildKey
  ]);
  const joinUrl = (embeddedHost == null ? void 0 : embeddedHost.joinUrl) ? embeddedHost.joinUrl : computedJoinUrl.key === joinUrlBuildKey ? computedJoinUrl.url : "";
  const joinUrlStatus = (embeddedHost == null ? void 0 : embeddedHost.joinUrl) ? "ready" : !joinUrlBuildKey ? "loading" : computedJoinUrl.key !== joinUrlBuildKey ? "loading" : computedJoinUrl.error ? "unavailable" : computedJoinUrl.url ? "ready" : "loading";
  const reconnectRetryTimeoutRef = (0, import_react13.useRef)(
    null
  );
  const setDevHostTraceId = (0, import_react13.useCallback)((traceId) => {
    updateDevBrowserLogContext({ traceId });
  }, []);
  (0, import_react13.useEffect)(() => {
    updateDevBrowserLogContext({
      role: "host",
      roomId: parsedRoomId ?? void 0
    });
  }, [parsedRoomId]);
  (0, import_react13.useEffect)(() => {
    return () => {
      updateDevBrowserLogContext({
        role: void 0,
        roomId: void 0,
        traceId: void 0
      });
    };
  }, []);
  const hostGrantResponseSchema = (0, import_react13.useMemo)(
    () => external_exports.object({
      hostGrant: external_exports.string().min(1)
    }),
    []
  );
  (0, import_react13.useEffect)(() => {
    const storeState = store.getState();
    const initialRoomId = parsedRoomIdRef.current;
    storeState.setMode(detectRunMode());
    storeState.setRole("host");
    if (initialRoomId) {
      storeState.setRoomId(initialRoomId);
    }
    storeState.setStatus("connecting");
    storeState.setError(void 0);
    lastObservedStateVersionRef.current = null;
    emittedInvariantKeysRef.current.clear();
    if (!shouldConnect || !socket) {
      storeState.setStatus("idle");
      return;
    }
    const registerHost = async () => {
      if (embeddedHost) {
        const childRoomId = embeddedHost.roomId;
        const latestState = store.getState();
        latestState.setStatus("connected");
        latestState.setRoomId(childRoomId);
        hydrateHostRoster();
        setRegisteredRoomId(childRoomId);
        setControllerCapability(null);
        return;
      }
      const resolveBootstrapPayload = async () => {
        if (!config.hostGrantEndpoint) {
          return hostBootstrapSchema.parse({
            appId: config.appId,
            hostSessionKind: config.hostSessionKind
          });
        }
        const response = await fetch(config.hostGrantEndpoint, {
          method: "POST",
          credentials: "include",
          headers: {
            "content-type": "application/json"
          },
          body: JSON.stringify(config.appId ? { appId: config.appId } : {})
        });
        if (!response.ok) {
          throw new Error(`Failed to fetch host grant (${response.status})`);
        }
        const parsed = hostGrantResponseSchema.safeParse(
          await response.json()
        );
        if (!parsed.success) {
          throw new Error("Invalid host grant response");
        }
        return hostBootstrapSchema.parse({
          hostGrant: parsed.data.hostGrant,
          hostSessionKind: config.hostSessionKind
        });
      };
      let bootstrapPayload;
      try {
        bootstrapPayload = await resolveBootstrapPayload();
      } catch (error) {
        const latestState = store.getState();
        const message = error instanceof Error ? error.message : "Failed to resolve host bootstrap grant";
        emitAirJamDiagnostic({
          code: "AJ_HOST_BOOTSTRAP_FAILED",
          severity: "error",
          message,
          details: {
            stage: "resolve_bootstrap_payload",
            hasAppId: Boolean(config.appId),
            hasHostGrantEndpoint: Boolean(config.hostGrantEndpoint)
          }
        });
        latestState.setError(message);
        latestState.setStatus("disconnected");
        latestState.clearHostArcadeRestore();
        setRegisteredRoomId(null);
        setDevHostTraceId(void 0);
        setControllerCapability(null);
        return;
      }
      let bootstrapAck;
      try {
        bootstrapAck = await socket.emitWithAck(
          "host:bootstrap",
          bootstrapPayload
        );
      } catch (error) {
        const latestState = store.getState();
        const message = error instanceof Error && error.message.includes(
          'Timed out waiting for acknowledgement for realtime event "host:bootstrap".'
        ) ? HOST_BOOTSTRAP_TIMEOUT_MESSAGE : error instanceof Error ? error.message : "Failed to authorize host";
        emitAirJamDiagnostic({
          code: "AJ_HOST_BOOTSTRAP_FAILED",
          severity: "error",
          message,
          details: {
            stage: "bootstrap_ack_timeout",
            hasAppId: Boolean(config.appId),
            hasHostGrantEndpoint: Boolean(config.hostGrantEndpoint)
          }
        });
        latestState.setError(message);
        latestState.setStatus("disconnected");
        latestState.clearHostArcadeRestore();
        setRegisteredRoomId(null);
        setDevHostTraceId(void 0);
        setControllerCapability(null);
        return;
      }
      if (!bootstrapAck.ok) {
        const latestState = store.getState();
        const message = bootstrapAck.message ?? "Failed to authorize host";
        emitAirJamDiagnostic({
          code: "AJ_HOST_BOOTSTRAP_FAILED",
          severity: "error",
          message,
          details: {
            stage: "bootstrap_ack",
            ackCode: bootstrapAck.code,
            hasAppId: Boolean(config.appId),
            hasHostGrantEndpoint: Boolean(config.hostGrantEndpoint)
          }
        });
        latestState.setError(message);
        latestState.setStatus("disconnected");
        latestState.clearHostArcadeRestore();
        setRegisteredRoomId(null);
        setDevHostTraceId(void 0);
        setControllerCapability(null);
        return;
      }
      setDevHostTraceId(bootstrapAck.traceId);
      const createNewRoom = (reason = "bootstrap", details) => {
        const latestState = store.getState();
        latestState.clearHostArcadeRestore();
        latestState.resetPlayers();
        setRegisteredRoomId(null);
        setControllerCapability(null);
        const payload = hostCreateRoomSchema.parse({
          maxPlayers: config.maxPlayers
        });
        emitHostRuntimeEvent({
          event: AIRJAM_DEV_LOG_EVENTS.runtime.hostCreateRoomRequested,
          message: "Host requested room creation",
          data: {
            reason,
            maxPlayers: payload.maxPlayers,
            ...details
          }
        });
        socket.emit("host:createRoom", payload, (ack) => {
          const latestState2 = store.getState();
          if (!ack.ok) {
            latestState2.setError(ack.message ?? "Failed to create room");
            latestState2.setStatus("disconnected");
            setRegisteredRoomId(null);
            setDevHostTraceId(void 0);
            setControllerCapability(null);
            return;
          }
          if (ack.roomId) {
            latestState2.setStatus("connected");
            latestState2.setRoomId(ack.roomId);
            latestState2.clearHostArcadeRestore();
            hydrateHostRoster(ack.players, ack.controllers);
            setRegisteredRoomId(ack.roomId);
            setControllerCapability(ack.controllerCapability ?? null);
            if (typeof window !== "undefined") {
              sessionStorage.setItem("airjam_room_id", ack.roomId);
            }
            return;
          }
          latestState2.setError("Server did not return room ID");
          latestState2.setStatus("disconnected");
          setDevHostTraceId(void 0);
          setControllerCapability(null);
        });
      };
      if (typeof window !== "undefined") {
        const savedRoomId = sessionStorage.getItem("airjam_room_id");
        if (savedRoomId) {
          const reconnectPayload = hostReconnectSchema.parse({
            roomId: savedRoomId
          });
          const maxReconnectAttempts = 12;
          const reconnectRetryDelayMs = 250;
          const attemptReconnect = (attempt) => {
            store.getState().setHostArcadeRestore({
              phase: "awaiting_ack",
              session: null
            });
            emitHostRuntimeEvent({
              event: AIRJAM_DEV_LOG_EVENTS.runtime.hostReconnectRequested,
              message: "Host requested room reconnect",
              roomId: reconnectPayload.roomId,
              data: {
                attempt,
                source: "session_storage_restore"
              }
            });
            socket.emit(
              "host:reconnect",
              reconnectPayload,
              (ack) => {
                const latestState = store.getState();
                if (ack.ok && ack.roomId) {
                  latestState.setStatus("connected");
                  latestState.setRoomId(ack.roomId);
                  hydrateHostRoster(ack.players, ack.controllers);
                  setControllerCapability(ack.controllerCapability ?? null);
                  latestState.setHostArcadeRestore(
                    ack.arcadeSession ? {
                      phase: "pending_restore",
                      session: ack.arcadeSession
                    } : {
                      phase: "idle",
                      session: null
                    }
                  );
                  setRegisteredRoomId(ack.roomId);
                  return;
                }
                if (ack.code === "ALREADY_CONNECTED" && attempt < maxReconnectAttempts) {
                  emitHostRuntimeEvent({
                    event: AIRJAM_DEV_LOG_EVENTS.runtime.hostReconnectRetryScheduled,
                    message: "Host reconnect retry scheduled",
                    roomId: reconnectPayload.roomId,
                    data: {
                      attempt,
                      nextAttempt: attempt + 1,
                      retryDelayMs: reconnectRetryDelayMs,
                      ackCode: ack.code
                    }
                  });
                  reconnectRetryTimeoutRef.current = setTimeout(() => {
                    reconnectRetryTimeoutRef.current = null;
                    attemptReconnect(attempt + 1);
                  }, reconnectRetryDelayMs);
                  return;
                }
                latestState.clearHostArcadeRestore();
                if (typeof window !== "undefined") {
                  sessionStorage.removeItem("airjam_room_id");
                }
                setControllerCapability(null);
                createNewRoom("reconnect_fallback", {
                  attempt,
                  ackCode: ack.code,
                  ackMessage: ack.message
                });
              }
            );
          };
          attemptReconnect(0);
          return;
        }
      }
      createNewRoom();
    };
    const handleConnect = () => {
      emitHostRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.socketConnected,
        message: "Host socket connected",
        roomId: parsedRoomIdRef.current ?? void 0,
        data: {
          socketId: socket.id,
          connected: socket.connected
        }
      });
      store.getState().setStatus("connecting");
      void registerHost();
    };
    const handleDisconnect = (reason) => {
      emitHostRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.socketDisconnected,
        message: "Host socket disconnected",
        roomId: parsedRoomIdRef.current ?? void 0,
        data: {
          socketId: socket.id,
          reason
        }
      });
      store.getState().setStatus("disconnected");
      store.getState().resetPlayers();
      store.getState().resetRuntimeState();
      lastObservedStateVersionRef.current = null;
      setRegisteredRoomId(null);
      setDevHostTraceId(void 0);
    };
    const handleConnectError = (error) => {
      emitAirJamDevRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.socketConnectError,
        level: "warn",
        message: "Host socket connect error",
        role: "host",
        roomId: parsedRoomIdRef.current ?? void 0,
        data: {
          message: error.message,
          name: error.name
        }
      });
    };
    const handleJoin = (payload) => {
      store.getState().upsertControllerSession(payload);
      if (!payload.player) {
        return;
      }
      store.getState().upsertPlayer(payload.player);
      setTimeout(() => {
        var _a;
        (_a = onPlayerJoinRef.current) == null ? void 0 : _a.call(onPlayerJoinRef, payload.player);
      }, 0);
    };
    const handleLeave = (payload) => {
      var _a;
      const latestState = store.getState();
      latestState.removePlayer(payload.controllerId);
      latestState.removeControllerSession(payload.controllerId);
      (_a = onPlayerLeaveRef.current) == null ? void 0 : _a.call(onPlayerLeaveRef, payload.controllerId);
    };
    const handlePlayerUpdated = (payload) => {
      const latestState = store.getState();
      latestState.upsertPlayer(payload.player);
      const existingSession = latestState.controllerSessions.find(
        (controller) => controller.controllerId === payload.player.id
      );
      if (existingSession) {
        latestState.upsertControllerSession({
          ...existingSession,
          player: payload.player
        });
      }
    };
    const handleInput = (payload) => {
      if (inputManager) {
        inputManager.handleInput(payload);
      }
    };
    const handleState = (payload) => {
      const activeRoomId = parsedRoomIdRef.current;
      if (!activeRoomId || payload.roomId !== activeRoomId) return;
      emitHostRuntimeEvent({
        event: AIRJAM_DEV_LOG_EVENTS.runtime.hostStateReceived,
        message: "Host received state update",
        roomId: payload.roomId,
        data: {
          runtimeState: payload.state.runtimeState,
          orientation: payload.state.orientation,
          stateVersion: payload.state.stateVersion,
          hasMessage: payload.state.message !== void 0
        }
      });
      const latestState = store.getState();
      const previousRuntimeState = latestState.runtimeState;
      const nextRuntimeState = payload.state.runtimeState ?? previousRuntimeState;
      const incomingVersion = payload.state.stateVersion;
      const previousVersion = lastObservedStateVersionRef.current;
      if (typeof incomingVersion === "number") {
        if (previousVersion === null) {
          emitHostRuntimeEvent({
            event: AIRJAM_DEV_LOG_EVENTS.runtime.stateVersionReceived,
            message: "Host received initial room state version",
            roomId: payload.roomId,
            data: {
              stateVersion: incomingVersion,
              relation: "initial"
            }
          });
        } else if (incomingVersion <= previousVersion) {
          emitHostRuntimeEvent({
            event: AIRJAM_DEV_LOG_EVENTS.runtime.stateVersionReceived,
            level: "warn",
            message: "Host received non-monotonic room state version",
            roomId: payload.roomId,
            data: {
              stateVersion: incomingVersion,
              previousStateVersion: previousVersion,
              relation: "non_monotonic"
            }
          });
          emitInvariantOnce({
            code: "state_version_non_monotonic",
            roomId: payload.roomId,
            message: "Received non-monotonic room state version in host runtime",
            data: {
              stateVersion: incomingVersion,
              previousStateVersion: previousVersion
            }
          });
        } else if (incomingVersion !== previousVersion + 1) {
          emitHostRuntimeEvent({
            event: AIRJAM_DEV_LOG_EVENTS.runtime.stateVersionReceived,
            message: "Host detected room state version gap",
            roomId: payload.roomId,
            data: {
              stateVersion: incomingVersion,
              previousStateVersion: previousVersion,
              relation: "gap"
            }
          });
        }
        lastObservedStateVersionRef.current = previousVersion === null ? incomingVersion : Math.max(previousVersion, incomingVersion);
      }
      if (typeof incomingVersion === "number" && nextRuntimeState !== previousRuntimeState) {
        emitHostRuntimeEvent({
          event: AIRJAM_DEV_LOG_EVENTS.runtime.phaseTransition,
          message: "Host runtime phase transition",
          roomId: payload.roomId,
          data: {
            from: previousRuntimeState,
            to: nextRuntimeState,
            source: "server_state",
            stateVersion: incomingVersion
          }
        });
      }
      if (payload.state.runtimeState) {
        latestState.setRuntimeState(payload.state.runtimeState);
      }
      if (payload.state.orientation) {
        latestState.setControllerOrientation(payload.state.orientation);
      }
      if (payload.state.message !== void 0) {
        latestState.setStateMessage(payload.state.message);
      }
    };
    const handleError = (payload) => {
      store.getState().setError(payload.message);
    };
    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);
    socket.on("connect_error", handleConnectError);
    socket.on("server:controllerJoined", handleJoin);
    socket.on("server:controllerLeft", handleLeave);
    socket.on("server:playerUpdated", handlePlayerUpdated);
    socket.on("server:input", handleInput);
    socket.on("server:error", handleError);
    socket.on("server:state", handleState);
    if (socket.connected) {
      handleConnect();
    } else {
      socket.connect();
    }
    return () => {
      if (reconnectRetryTimeoutRef.current) {
        clearTimeout(reconnectRetryTimeoutRef.current);
        reconnectRetryTimeoutRef.current = null;
      }
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      socket.off("connect_error", handleConnectError);
      socket.off("server:controllerJoined", handleJoin);
      socket.off("server:controllerLeft", handleLeave);
      socket.off("server:playerUpdated", handlePlayerUpdated);
      socket.off("server:input", handleInput);
      socket.off("server:error", handleError);
      socket.off("server:state", handleState);
      setDevHostTraceId(void 0);
    };
  }, [
    config.maxPlayers,
    config.appId,
    config.hostGrantEndpoint,
    config.hostSessionKind,
    embeddedHost,
    shouldConnect,
    socket,
    store,
    inputManager,
    setRegisteredRoomId,
    setDevHostTraceId,
    hostGrantResponseSchema,
    emitHostRuntimeEvent,
    emitInvariantOnce,
    hydrateHostRoster
  ]);
  const getInput = (0, import_react13.useCallback)(
    (controllerId) => {
      if (!inputManager) {
        return void 0;
      }
      return inputManager.getInput(controllerId);
    },
    [inputManager]
  );
  return (0, import_react13.useMemo)(
    () => ({
      roomId: parsedRoomId ?? "",
      joinUrl,
      joinUrlStatus,
      pauseRuntime,
      resumeRuntime,
      setRuntimeState,
      sendState,
      sendSignal,
      reconnect,
      removeController,
      resetRoom,
      socket: socket ?? getHostRealtimeClient((role) => getSocket(role)),
      getInput
    }),
    [
      getInput,
      getSocket,
      joinUrl,
      joinUrlStatus,
      parsedRoomId,
      pauseRuntime,
      reconnect,
      removeController,
      resetRoom,
      resumeRuntime,
      sendSignal,
      sendState,
      setRuntimeState,
      socket
    ]
  );
};
var HostRuntimeInspectionPublisher = () => {
  const inspection = useHostRuntimeInspectionContract();
  (0, import_react10.useEffect)(() => {
    if (typeof window === "undefined") {
      return;
    }
    publishRuntimeInspectionContract(window, inspection);
    return () => {
      var _a;
      if (((_a = readRuntimeInspectionContract(window)) == null ? void 0 : _a.role) === "host") {
        publishRuntimeInspectionContract(window, null);
      }
    };
  }, [inspection]);
  return null;
};
var ControllerRuntimeInspectionPublisher = () => {
  const inspection = useControllerRuntimeInspectionContract();
  (0, import_react10.useEffect)(() => {
    if (typeof window === "undefined") {
      return;
    }
    publishRuntimeInspectionContract(window, inspection);
    return () => {
      var _a;
      if (((_a = readRuntimeInspectionContract(window)) == null ? void 0 : _a.role) === "controller") {
        publishRuntimeInspectionContract(window, null);
      }
    };
  }, [inspection]);
  return null;
};
var HostRuntimeOwner = ({
  children,
  roomId,
  onPlayerJoin,
  onPlayerLeave
}) => {
  const runtime = useHostRuntimeApi(
    {
      roomId,
      onPlayerJoin,
      onPlayerLeave
    },
    "AirJamHostRuntime"
  );
  return (0, import_jsx_runtime3.jsxs)(hostRuntimeContext.Provider, { value: runtime, children: [
    (0, import_jsx_runtime3.jsx)(HostRuntimeInspectionPublisher, {}),
    children
  ] });
};
var ControllerRuntimeOwner = ({
  children,
  roomId,
  nickname,
  avatarId,
  controllerId,
  capabilityToken,
  onState
}) => {
  const runtime = useControllerRuntimeApi(
    {
      roomId,
      nickname,
      avatarId,
      controllerId,
      capabilityToken,
      onState
    },
    "AirJamControllerRuntime"
  );
  return (0, import_jsx_runtime3.jsxs)(controllerRuntimeContext.Provider, { value: runtime, children: [
    (0, import_jsx_runtime3.jsx)(ControllerRuntimeInspectionPublisher, {}),
    children
  ] });
};
var AirJamHostRuntime = ({
  children,
  roomId,
  onPlayerJoin,
  onPlayerLeave,
  ...providerProps
}) => {
  return (0, import_jsx_runtime3.jsx)(HostSessionProvider, { ...providerProps, children: (0, import_jsx_runtime3.jsx)(PlatformSettingsBoundary, { children: (0, import_jsx_runtime3.jsx)(
    HostRuntimeOwner,
    {
      roomId,
      onPlayerJoin,
      onPlayerLeave,
      children
    }
  ) }) });
};
var AirJamControllerRuntime = ({
  children,
  roomId,
  nickname,
  avatarId,
  controllerId,
  capabilityToken,
  onState,
  ...providerProps
}) => {
  return (0, import_jsx_runtime3.jsx)(ControllerSessionProvider, { ...providerProps, children: (0, import_jsx_runtime3.jsx)(PlatformSettingsBoundary, { children: (0, import_jsx_runtime3.jsx)(
    ControllerRuntimeOwner,
    {
      roomId,
      nickname,
      avatarId,
      controllerId,
      capabilityToken,
      onState,
      children
    }
  ) }) });
};
var standardMatchPhases = [
  "lobby",
  "countdown",
  "playing",
  "ended"
];
var isStandardMatchPhase = (value) => {
  return standardMatchPhases.includes(value);
};
var isActiveMatchPhase = (phase) => {
  return phase === "countdown" || phase === "playing";
};
var isEndedMatchPhase = (phase) => {
  return phase === "ended";
};
var toShellMatchPhase = (phase) => {
  if (phase === "countdown") {
    return "playing";
  }
  return phase;
};
var toError = (value) => {
  if (value instanceof Error) {
    return value;
  }
  if (typeof value === "string") {
    return new Error(value);
  }
  return new Error("Unknown runtime error");
};
var isEmbeddedRuntime = () => typeof window !== "undefined" && typeof window.parent !== "undefined" && window.parent !== window;
var roleLabel = (role) => role === "host" ? "Host runtime" : "Controller runtime";
var mono = "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, monospace";
var errorSurface = {
  bg: "#0a0a0a",
  panel: "#141414",
  panelBorder: "rgba(255, 255, 255, 0.08)",
  inset: "#0c0c0c",
  insetBorder: "rgba(255, 255, 255, 0.06)",
  text: "#fafafa",
  muted: "#a3a3a3",
  dim: "#737373",
  zOverlay: 2147483e3
};
var iconSize = 16;
var createErrorDigest = (error) => {
  const input = `${error.name}:${error.message}:${error.stack ?? ""}`;
  let hash = 0;
  for (let index = 0; index < input.length; index += 1) {
    hash = hash * 31 + input.charCodeAt(index) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
};
var copyTextToClipboard = async (text) => {
  if (typeof navigator !== "undefined" && navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
    await navigator.clipboard.writeText(text);
    return;
  }
  if (typeof document === "undefined") {
    throw new Error("Clipboard is unavailable");
  }
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  textarea.style.pointerEvents = "none";
  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();
  const succeeded = typeof document.execCommand === "function" ? document.execCommand("copy") : false;
  document.body.removeChild(textarea);
  if (!succeeded) {
    throw new Error("Copy command failed");
  }
};
var createCopyPayload = ({
  role,
  roomId,
  appId,
  error,
  digest,
  isEmbedded
}) => {
  const lines = [
    "AirJam Runtime Error",
    `Role: ${role}`,
    `Digest: ${digest}`,
    `Embedded: ${isEmbedded ? "yes" : "no"}`,
    roomId ? `Room: ${roomId}` : null,
    appId ? `App ID: ${appId}` : null,
    `Error: ${error.message || "Unknown error"}`,
    "",
    "Stack:",
    error.stack ?? "(no stack)"
  ].filter((line) => line !== null);
  return lines.join("\n");
};
var btnRow = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "0.35rem",
  borderRadius: "0.5rem",
  padding: "0.5rem 0.75rem",
  fontSize: "0.8125rem",
  fontWeight: 600,
  cursor: "pointer",
  fontFamily: "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif"
};
var DefaultFallback = ({
  role,
  roomId,
  appId,
  error,
  reset,
  reload,
  isEmbedded
}) => {
  const digest = createErrorDigest(error);
  const [isMinimized, setIsMinimized] = (0, import_react14.useState)(false);
  const [copyState, setCopyState] = (0, import_react14.useState)(
    "idle"
  );
  const copyResetTimeoutRef = (0, import_react14.useRef)(null);
  (0, import_react14.useEffect)(() => {
    return () => {
      if (copyResetTimeoutRef.current !== null && typeof window !== "undefined") {
        window.clearTimeout(copyResetTimeoutRef.current);
      }
    };
  }, []);
  const scheduleCopyStatusReset = (0, import_react14.useCallback)(() => {
    if (typeof window === "undefined") {
      return;
    }
    if (copyResetTimeoutRef.current !== null) {
      window.clearTimeout(copyResetTimeoutRef.current);
    }
    copyResetTimeoutRef.current = window.setTimeout(() => {
      setCopyState("idle");
      copyResetTimeoutRef.current = null;
    }, 1800);
  }, []);
  const handleCopy = (0, import_react14.useCallback)(async () => {
    try {
      await copyTextToClipboard(
        createCopyPayload({
          role,
          roomId,
          appId,
          error,
          isEmbedded,
          digest
        })
      );
      setCopyState("copied");
      scheduleCopyStatusReset();
    } catch {
      setCopyState("failed");
      scheduleCopyStatusReset();
    }
  }, [appId, digest, error, isEmbedded, role, roomId, scheduleCopyStatusReset]);
  const copyButtonLabel = copyState === "copied" ? "Copied" : copyState === "failed" ? "Copy failed" : "Copy details";
  const CopyGlyph = copyState === "copied" ? (0, import_jsx_runtime4.jsx)(Check, { size: iconSize, strokeWidth: 2, "aria-hidden": true }) : (0, import_jsx_runtime4.jsx)(Copy, { size: iconSize, strokeWidth: 2, "aria-hidden": true });
  if (isMinimized) {
    return (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
      (0, import_jsx_runtime4.jsx)(
        "div",
        {
          "aria-hidden": true,
          style: {
            position: "fixed",
            inset: 0,
            zIndex: errorSurface.zOverlay,
            background: "rgba(10, 10, 10, 0.72)"
          }
        }
      ),
      (0, import_jsx_runtime4.jsxs)(
        "div",
        {
          style: {
            position: "fixed",
            bottom: "1rem",
            right: "1rem",
            zIndex: errorSurface.zOverlay + 1,
            maxWidth: "min(22rem, calc(100vw - 2rem))",
            borderRadius: "0.625rem",
            border: `1px solid ${errorSurface.panelBorder}`,
            background: errorSurface.panel,
            boxShadow: "0 16px 48px rgba(0, 0, 0, 0.55)",
            padding: "0.75rem 0.85rem"
          },
          children: [
            (0, import_jsx_runtime4.jsxs)(
              "div",
              {
                style: {
                  display: "flex",
                  alignItems: "flex-start",
                  justifyContent: "space-between",
                  gap: "0.5rem"
                },
                children: [
                  (0, import_jsx_runtime4.jsxs)("div", { style: { minWidth: 0 }, children: [
                    (0, import_jsx_runtime4.jsx)(
                      "div",
                      {
                        style: {
                          fontSize: "0.6875rem",
                          fontWeight: 600,
                          letterSpacing: "0.02em",
                          color: errorSurface.dim,
                          textTransform: "uppercase"
                        },
                        children: "AirJam · runtime error"
                      }
                    ),
                    (0, import_jsx_runtime4.jsxs)(
                      "div",
                      {
                        style: {
                          marginTop: "0.25rem",
                          fontSize: "0.75rem",
                          color: errorSurface.muted,
                          fontFamily: mono,
                          lineHeight: 1.4,
                          wordBreak: "break-word"
                        },
                        children: [
                          role,
                          " · ",
                          digest
                        ]
                      }
                    )
                  ] }),
                  (0, import_jsx_runtime4.jsx)(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIsMinimized(false),
                      "aria-label": "Expand error panel",
                      title: "Expand error panel",
                      style: {
                        ...btnRow,
                        flexShrink: 0,
                        border: `1px solid ${errorSurface.panelBorder}`,
                        background: errorSurface.inset,
                        color: errorSurface.text,
                        padding: "0.4rem"
                      },
                      children: (0, import_jsx_runtime4.jsx)(Maximize2, { size: iconSize, strokeWidth: 2, "aria-hidden": true })
                    }
                  )
                ]
              }
            ),
            (0, import_jsx_runtime4.jsxs)(
              "div",
              {
                style: {
                  marginTop: "0.65rem",
                  display: "flex",
                  flexWrap: "wrap",
                  gap: "0.4rem"
                },
                children: [
                  (0, import_jsx_runtime4.jsxs)(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        void handleCopy();
                      },
                      style: {
                        ...btnRow,
                        border: `1px solid ${errorSurface.panelBorder}`,
                        background: "transparent",
                        color: errorSurface.muted
                      },
                      children: [
                        CopyGlyph,
                        copyButtonLabel
                      ]
                    }
                  ),
                  (0, import_jsx_runtime4.jsxs)(
                    "button",
                    {
                      type: "button",
                      onClick: reload,
                      style: {
                        ...btnRow,
                        border: "none",
                        background: errorSurface.text,
                        color: errorSurface.bg
                      },
                      children: [
                        (0, import_jsx_runtime4.jsx)(RefreshCw, { size: iconSize, strokeWidth: 2, "aria-hidden": true }),
                        "Reload"
                      ]
                    }
                  )
                ]
              }
            )
          ]
        }
      )
    ] });
  }
  return (0, import_jsx_runtime4.jsx)(
    "div",
    {
      style: {
        minHeight: "100vh",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: errorSurface.bg,
        padding: "1.5rem 1rem",
        boxSizing: "border-box"
      },
      children: (0, import_jsx_runtime4.jsxs)(
        "div",
        {
          style: {
            position: "relative",
            width: "100%",
            maxWidth: "42rem",
            borderRadius: "0.625rem",
            border: `1px solid ${errorSurface.panelBorder}`,
            background: errorSurface.panel,
            boxShadow: "0 24px 64px rgba(0, 0, 0, 0.45)",
            padding: "1.25rem 1.35rem",
            boxSizing: "border-box"
          },
          children: [
            (0, import_jsx_runtime4.jsx)(
              "button",
              {
                type: "button",
                onClick: () => setIsMinimized(true),
                "aria-label": "Minimize error panel",
                title: "Minimize error panel",
                style: {
                  ...btnRow,
                  position: "absolute",
                  top: "0.85rem",
                  right: "0.85rem",
                  padding: "0.4rem",
                  border: `1px solid ${errorSurface.panelBorder}`,
                  background: errorSurface.inset,
                  color: errorSurface.muted
                },
                children: (0, import_jsx_runtime4.jsx)(Minimize2, { size: iconSize, strokeWidth: 2, "aria-hidden": true })
              }
            ),
            (0, import_jsx_runtime4.jsxs)(
              "div",
              {
                style: {
                  fontSize: "0.6875rem",
                  fontWeight: 500,
                  letterSpacing: "0.04em",
                  color: errorSurface.dim,
                  textTransform: "uppercase",
                  paddingRight: "2.5rem"
                },
                children: [
                  "AirJam · runtime error · ",
                  role
                ]
              }
            ),
            (0, import_jsx_runtime4.jsx)(
              "h1",
              {
                style: {
                  marginTop: "0.65rem",
                  marginBottom: 0,
                  fontSize: "1.25rem",
                  lineHeight: 1.25,
                  fontWeight: 600,
                  color: errorSurface.text,
                  fontFamily: "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif"
                },
                children: "Something went wrong"
              }
            ),
            (0, import_jsx_runtime4.jsxs)(
              "p",
              {
                style: {
                  marginTop: "0.45rem",
                  marginBottom: 0,
                  fontSize: "0.8125rem",
                  color: errorSurface.muted,
                  lineHeight: 1.45
                },
                children: [
                  roleLabel(role),
                  " hit an error. Details below."
                ]
              }
            ),
            (0, import_jsx_runtime4.jsxs)(
              "div",
              {
                style: {
                  marginTop: "1rem",
                  border: `1px solid ${errorSurface.insetBorder}`,
                  borderRadius: "0.5rem",
                  background: errorSurface.inset,
                  padding: "0.75rem 0.85rem",
                  fontSize: "0.75rem",
                  color: errorSurface.muted,
                  fontFamily: mono,
                  lineHeight: 1.5,
                  wordBreak: "break-word"
                },
                children: [
                  (0, import_jsx_runtime4.jsxs)("div", { children: [
                    (0, import_jsx_runtime4.jsx)("span", { style: { color: errorSurface.dim }, children: "Digest " }),
                    digest
                  ] }),
                  roomId ? (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: "0.35rem" }, children: [
                    (0, import_jsx_runtime4.jsx)("span", { style: { color: errorSurface.dim }, children: "Room " }),
                    roomId
                  ] }) : null,
                  (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: "0.35rem" }, children: [
                    (0, import_jsx_runtime4.jsx)("span", { style: { color: errorSurface.dim }, children: "Error " }),
                    error.message || "Unknown error"
                  ] })
                ]
              }
            ),
            (0, import_jsx_runtime4.jsxs)(
              "details",
              {
                style: {
                  marginTop: "0.75rem",
                  fontSize: "0.75rem",
                  color: errorSurface.muted
                },
                children: [
                  (0, import_jsx_runtime4.jsx)(
                    "summary",
                    {
                      style: {
                        cursor: "pointer",
                        fontWeight: 500,
                        color: errorSurface.muted,
                        listStyle: "none"
                      },
                      children: "Stack trace"
                    }
                  ),
                  (0, import_jsx_runtime4.jsx)(
                    "pre",
                    {
                      style: {
                        marginTop: "0.5rem",
                        marginBottom: 0,
                        overflowX: "auto",
                        whiteSpace: "pre-wrap",
                        wordBreak: "break-word",
                        border: `1px solid ${errorSurface.insetBorder}`,
                        borderRadius: "0.45rem",
                        background: errorSurface.inset,
                        padding: "0.65rem 0.75rem",
                        color: errorSurface.muted,
                        fontFamily: mono,
                        fontSize: "0.6875rem",
                        lineHeight: 1.45
                      },
                      children: error.stack ?? error.message
                    }
                  )
                ]
              }
            ),
            (0, import_jsx_runtime4.jsxs)(
              "div",
              {
                style: {
                  marginTop: "1.1rem",
                  display: "flex",
                  flexWrap: "wrap",
                  alignItems: "center",
                  gap: "0.45rem"
                },
                children: [
                  (0, import_jsx_runtime4.jsxs)(
                    "button",
                    {
                      type: "button",
                      onClick: reload,
                      style: {
                        ...btnRow,
                        border: "none",
                        background: errorSurface.text,
                        color: errorSurface.bg
                      },
                      children: [
                        (0, import_jsx_runtime4.jsx)(RefreshCw, { size: iconSize, strokeWidth: 2, "aria-hidden": true }),
                        "Reload"
                      ]
                    }
                  ),
                  (0, import_jsx_runtime4.jsxs)(
                    "button",
                    {
                      type: "button",
                      onClick: reset,
                      style: {
                        ...btnRow,
                        border: `1px solid ${errorSurface.panelBorder}`,
                        background: "transparent",
                        color: errorSurface.text
                      },
                      children: [
                        (0, import_jsx_runtime4.jsx)(RotateCcw, { size: iconSize, strokeWidth: 2, "aria-hidden": true }),
                        "Try again"
                      ]
                    }
                  ),
                  (0, import_jsx_runtime4.jsxs)(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        void handleCopy();
                      },
                      style: {
                        ...btnRow,
                        border: `1px solid ${errorSurface.panelBorder}`,
                        background: "transparent",
                        color: errorSurface.muted
                      },
                      children: [
                        CopyGlyph,
                        copyButtonLabel
                      ]
                    }
                  )
                ]
              }
            ),
            isEmbedded ? (0, import_jsx_runtime4.jsx)(
              "p",
              {
                style: {
                  marginTop: "0.85rem",
                  marginBottom: 0,
                  fontSize: "0.6875rem",
                  color: errorSurface.dim,
                  lineHeight: 1.4,
                  fontFamily: mono
                },
                children: "Embedded: if reload loops, exit and relaunch from the Arcade shell."
              }
            ) : null
          ]
        }
      )
    }
  );
};
var AirJamErrorBoundary = class extends import_react14.Component {
  constructor() {
    super(...arguments);
    __publicField(this, "state", {
      error: null
    });
    __publicField(this, "handleReset", () => {
      this.setState({ error: null });
    });
    __publicField(this, "handleReload", () => {
      if (typeof window !== "undefined") {
        window.location.reload();
      }
    });
  }
  static getDerivedStateFromError(error) {
    return {
      error: toError(error)
    };
  }
  componentDidCatch(error, errorInfo) {
    const { role, roomId, appId, onError } = this.props;
    const details = {
      role,
      roomId,
      appId,
      name: error.name,
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack
    };
    emitAirJamDiagnostic({
      code: "AJ_RUNTIME_RENDER_CRASH",
      severity: "error",
      message: `[AirJam] ${role} runtime crashed during render.`,
      details
    });
    emitAirJamDevRuntimeEvent({
      event: AIRJAM_DEV_LOG_EVENTS.browser.runtime,
      level: "error",
      message: `AirJam ${role} runtime crashed during render`,
      role,
      roomId,
      code: "AJ_RUNTIME_RENDER_CRASH",
      data: details
    });
    onError == null ? void 0 : onError(error, errorInfo, {
      role,
      roomId,
      appId
    });
  }
  render() {
    const { error } = this.state;
    const { children, role, roomId, appId, renderFallback } = this.props;
    if (!error) {
      return (0, import_jsx_runtime4.jsx)(import_jsx_runtime4.Fragment, { children });
    }
    const fallbackProps = {
      role,
      roomId,
      appId,
      error,
      reset: this.handleReset,
      reload: this.handleReload,
      isEmbedded: isEmbeddedRuntime()
    };
    if (renderFallback) {
      return renderFallback(fallbackProps);
    }
    return (0, import_jsx_runtime4.jsx)(DefaultFallback, { ...fallbackProps });
  }
};
var resolveControllerPath = (controllerPath) => {
  const normalized = controllerPath ?? CONTROLLER_PATH;
  return normalized.startsWith("/") ? normalized : `/${normalized}`;
};
var toViteEnvLike = (source) => {
  if (!source) {
    return void 0;
  }
  const readString = (key) => {
    const value = source[key];
    return typeof value === "string" ? value : void 0;
  };
  return {
    DEV: source.DEV === true,
    VITE_AIR_JAM_RUNTIME_TOPOLOGY: readString("VITE_AIR_JAM_RUNTIME_TOPOLOGY"),
    VITE_AIR_JAM_SERVER_URL: readString("VITE_AIR_JAM_SERVER_URL"),
    VITE_AIR_JAM_APP_ID: readString("VITE_AIR_JAM_APP_ID"),
    VITE_AIR_JAM_HOST_GRANT_ENDPOINT: readString(
      "VITE_AIR_JAM_HOST_GRANT_ENDPOINT"
    ),
    VITE_AIR_JAM_PUBLIC_HOST: readString("VITE_AIR_JAM_PUBLIC_HOST")
  };
};
var readViteEnv = () => {
  try {
    const candidate = import.meta;
    if (candidate && typeof candidate.env === "object") {
      return candidate.env;
    }
  } catch {
    return null;
  }
  return null;
};
var env = {
  auto: () => ({
    resolveEnv: true
  }),
  vite: (viteEnvInput) => {
    const viteEnv = toViteEnvLike(viteEnvInput) ?? readViteEnv();
    const explicitTopology = (viteEnv == null ? void 0 : viteEnv.VITE_AIR_JAM_RUNTIME_TOPOLOGY) ? JSON.parse(
      viteEnv.VITE_AIR_JAM_RUNTIME_TOPOLOGY
    ) : null;
    const projectTopology = !explicitTopology && (viteEnv == null ? void 0 : viteEnv.VITE_AIR_JAM_PUBLIC_HOST) ? resolveProjectRuntimeTopology({
      runtimeMode: viteEnv.DEV ? viteEnv.VITE_AIR_JAM_PUBLIC_HOST.startsWith("https://") ? "standalone-secure" : "standalone-dev" : "self-hosted-production",
      surfaceRole: "host",
      appOrigin: viteEnv.VITE_AIR_JAM_PUBLIC_HOST,
      backendOrigin: viteEnv.VITE_AIR_JAM_SERVER_URL || viteEnv.VITE_AIR_JAM_PUBLIC_HOST,
      publicHost: viteEnv.VITE_AIR_JAM_PUBLIC_HOST,
      secureTransport: viteEnv.VITE_AIR_JAM_PUBLIC_HOST.startsWith("https://")
    }) : null;
    return {
      ...explicitTopology || projectTopology ? { topology: explicitTopology ?? projectTopology ?? void 0 } : {},
      appId: viteEnv == null ? void 0 : viteEnv.VITE_AIR_JAM_APP_ID,
      hostGrantEndpoint: viteEnv == null ? void 0 : viteEnv.VITE_AIR_JAM_HOST_GRANT_ENDPOINT,
      resolveEnv: explicitTopology || projectTopology ? false : true
    };
  },
  next: () => ({
    resolveEnv: true
  }),
  explicit: (runtime) => ({
    ...runtime,
    resolveEnv: false
  })
};
var createAirJamApp = ({
  runtime = {},
  metadata,
  controllerPath: requestedControllerPath,
  capabilities,
  agent,
  input,
  errorBoundary
} = {}) => {
  const controllerPath = resolveControllerPath(requestedControllerPath);
  const hostSession = input ? {
    ...runtime,
    hostSessionKind: runtime.hostSessionKind ?? "game",
    input
  } : {
    ...runtime,
    hostSessionKind: runtime.hostSessionKind ?? "game"
  };
  const controllerSession = {
    ...runtime
  };
  const Host = ({
    children,
    ...runtimeOptions
  }) => {
    const hostErrorBoundary = errorBoundary == null ? void 0 : errorBoundary.host;
    return (0, import_jsx_runtime5.jsx)(
      AirJamErrorBoundary,
      {
        role: "host",
        roomId: runtimeOptions.roomId,
        appId: hostSession.appId,
        renderFallback: hostErrorBoundary == null ? void 0 : hostErrorBoundary.renderFallback,
        onError: hostErrorBoundary == null ? void 0 : hostErrorBoundary.onError,
        children: (0, import_jsx_runtime5.jsx)(AirJamHostRuntime, { ...hostSession, ...runtimeOptions, children })
      }
    );
  };
  const Controller = ({
    children,
    ...runtimeOptions
  }) => {
    const controllerErrorBoundary = errorBoundary == null ? void 0 : errorBoundary.controller;
    return (0, import_jsx_runtime5.jsx)(
      AirJamErrorBoundary,
      {
        role: "controller",
        roomId: runtimeOptions.roomId,
        appId: controllerSession.appId,
        renderFallback: controllerErrorBoundary == null ? void 0 : controllerErrorBoundary.renderFallback,
        onError: controllerErrorBoundary == null ? void 0 : controllerErrorBoundary.onError,
        children: (0, import_jsx_runtime5.jsx)(AirJamControllerRuntime, { ...controllerSession, ...runtimeOptions, children })
      }
    );
  };
  return {
    Host,
    Controller,
    paths: {
      controller: controllerPath
    },
    session: {
      host: hostSession,
      controller: controllerSession
    },
    runtime,
    metadata,
    controllerPath,
    capabilities,
    agent
  };
};
var AIR_JAM_LOCAL_GAME_PROXY_BASE_WINDOW_KEY = "__AIRJAM_LOCAL_GAME_PROXY_BASE__";
var normalizeBase = (value) => {
  if (!value || value === "/") {
    return "/";
  }
  const withLeadingSlash = value.startsWith("/") ? value : `/${value}`;
  return withLeadingSlash.endsWith("/") ? withLeadingSlash.slice(0, -1) : withLeadingSlash;
};
var resolveAirJamBrowserRouterBasename = () => {
  if (typeof window === "undefined") {
    return "/";
  }
  const rawBase = Reflect.get(window, AIR_JAM_LOCAL_GAME_PROXY_BASE_WINDOW_KEY);
  return typeof rawBase === "string" && rawBase.trim() ? normalizeBase(rawBase.trim()) : "/";
};
var INTERNAL_ACTION_PREFIX = "_";
var UNRESOLVED_ACTOR_ID = "unknown";
var isEventLikePayload = (payload) => {
  if (payload === null || typeof payload !== "object") {
    return false;
  }
  const candidate = payload;
  return typeof candidate.preventDefault === "function" || typeof candidate.stopPropagation === "function" || typeof candidate.persist === "function" || "nativeEvent" in candidate && ("target" in candidate || "currentTarget" in candidate);
};
var isPlainActionPayload = (payload) => {
  if (payload === null || typeof payload !== "object" || Array.isArray(payload)) {
    return false;
  }
  const prototype = Object.getPrototypeOf(payload);
  return prototype === Object.prototype || prototype === null;
};
var isInternalActionName = (actionName) => actionName.startsWith(INTERNAL_ACTION_PREFIX);
var acceptAirJamAction = (result) => ({
  __airJamActionAcceptance: true,
  ...result !== void 0 ? { result } : {}
});
var rejectAirJamAction = (reason, message, details) => ({
  __airJamActionRejection: true,
  reason,
  message,
  ...details ? { details } : {}
});
var isAirJamActionAcceptance = (value) => typeof value === "object" && value !== null && value.__airJamActionAcceptance === true;
var isAirJamActionRejection = (value) => typeof value === "object" && value !== null && value.__airJamActionRejection === true;
var createClientRejectedActionResult = (reason, message, details) => ({
  ok: false,
  status: "rejected",
  source: "client",
  reason,
  message,
  ...details ? { details } : {}
});
var createServerRejectedActionResult = (reason, message, details) => ({
  ok: false,
  status: "rejected",
  source: "server",
  reason,
  message,
  ...details ? { details } : {}
});
var normalizeAirJamActionInvocationResult = (value, source) => {
  if (isAirJamActionRejection(value)) {
    return {
      ok: false,
      status: "rejected",
      source,
      reason: value.reason,
      message: value.message,
      ...value.details ? { details: value.details } : {}
    };
  }
  if (isAirJamActionAcceptance(value)) {
    return {
      ok: true,
      status: "accepted",
      source,
      ...value.result !== void 0 ? { result: value.result } : {}
    };
  }
  return {
    ok: true,
    status: "accepted",
    source,
    ...value !== void 0 ? { result: value } : {}
  };
};
var stripActionsFromState = (data) => {
  const { actions: _ignored, ...stateData } = data;
  return stateData;
};
var toActionContext = (payload, connectedPlayerIds) => ({
  actorId: payload.actor.id || UNRESOLVED_ACTOR_ID,
  role: payload.actor.role,
  connectedPlayerIds
});
function createAirJamStore(initializer, options) {
  const store = create((set, get, api) => initializer(set, get, api));
  const runtimeSnapshotRef = {
    current: {
      socket: null,
      role: null,
      roomId: null,
      resolvedStoreDomain: AIR_JAM_DEFAULT_STORE_DOMAIN,
      connectionStatus: null,
      canBroadcastHostState: false,
      connectedPlayerIds: []
    }
  };
  const runtimeBindings = /* @__PURE__ */ new Map();
  const hostActionListeners = /* @__PURE__ */ new Set();
  const createDispatchedActions = (mode) => {
    const sourceActions = store.getState().actions;
    const actionDispatch = {};
    for (const actionName of Object.keys(sourceActions)) {
      if (isInternalActionName(actionName)) {
        continue;
      }
      const sourceAction = sourceActions[actionName];
      actionDispatch[actionName] = async (payload) => {
        const normalizedPayload = isEventLikePayload(payload) ? void 0 : payload;
        if (normalizedPayload !== payload) {
          emitAirJamDiagnostic({
            code: "AJ_STORE_ACTION_EVENT_PAYLOAD_DROPPED",
            severity: "warn",
            message: `[AirJamStore] Action "${actionName}" received an event-like payload. Dropping payload and continuing.`,
            details: { actionName }
          });
        }
        const runtime = runtimeSnapshotRef.current;
        if (mode.kind === "player" && runtime.role !== "host") {
          emitAirJamDiagnostic({
            code: "AJ_STORE_PLAYER_ACTIONS_HOST_ONLY",
            severity: "warn",
            message: `[AirJamStore] Player impersonation for action "${actionName}" is host-only.`,
            details: {
              actionName,
              role: runtime.role,
              controllerId: mode.controllerId
            }
          });
          return createClientRejectedActionResult(
            "player_actions_host_only",
            `Store action "${actionName}" cannot impersonate a player outside the host runtime.`,
            {
              actionName,
              ...runtime.role ? { role: runtime.role } : {},
              controllerId: mode.controllerId
            }
          );
        }
        if (mode.kind === "player") {
          const normalizedControllerId = mode.controllerId.trim();
          if (normalizedControllerId.length === 0) {
            emitAirJamDiagnostic({
              code: "AJ_STORE_PLAYER_ACTIONS_INVALID_ACTOR_ID",
              severity: "warn",
              message: `[AirJamStore] Player impersonation for action "${actionName}" requires a non-empty controller id.`,
              details: {
                actionName
              }
            });
            return createClientRejectedActionResult(
              "player_actor_id_invalid",
              `Store action "${actionName}" requires a non-empty controller id for player impersonation.`,
              {
                actionName
              }
            );
          }
          if (!runtime.connectedPlayerIds.includes(normalizedControllerId)) {
            emitAirJamDiagnostic({
              code: "AJ_STORE_PLAYER_ACTIONS_PLAYER_NOT_CONNECTED",
              severity: "warn",
              message: `[AirJamStore] Player impersonation for action "${actionName}" requires a currently connected controller.`,
              details: {
                actionName,
                controllerId: normalizedControllerId,
                connectedPlayerIds: runtime.connectedPlayerIds
              }
            });
            return createClientRejectedActionResult(
              "player_not_connected",
              `Store action "${actionName}" cannot impersonate controller "${normalizedControllerId}" because it is not currently connected.`,
              {
                actionName,
                controllerId: normalizedControllerId
              }
            );
          }
        }
        if (runtime.role === "host") {
          try {
            const context = mode.kind === "player" ? {
              actorId: mode.controllerId.trim(),
              role: "controller",
              connectedPlayerIds: runtime.connectedPlayerIds
            } : {
              actorId: "host",
              role: "host",
              connectedPlayerIds: runtime.connectedPlayerIds
            };
            const result = sourceAction(context, normalizedPayload);
            const acknowledgement = normalizeAirJamActionInvocationResult(
              result,
              "host"
            );
            const typedActionName = actionName;
            notifyHostActionListeners({
              actionName: typedActionName,
              payload: normalizedPayload,
              context,
              acknowledgement,
              invocationKind: "local",
              roomId: runtime.roomId,
              storeDomain: runtime.resolvedStoreDomain
            });
            return acknowledgement;
          } catch (error) {
            const acknowledgement = {
              ok: false,
              status: "rejected",
              source: "host",
              reason: "handler_error",
              message: error instanceof Error ? error.message : String(error)
            };
            const typedActionName = actionName;
            notifyHostActionListeners({
              actionName: typedActionName,
              payload: normalizedPayload,
              context: {
                actorId: mode.kind === "player" ? mode.controllerId.trim() : "host",
                role: mode.kind === "player" ? "controller" : "host",
                connectedPlayerIds: runtime.connectedPlayerIds
              },
              acknowledgement,
              invocationKind: "local",
              roomId: runtime.roomId,
              storeDomain: runtime.resolvedStoreDomain
            });
            return acknowledgement;
          }
        }
        if (runtime.role !== "controller" || !runtime.roomId) {
          emitAirJamDiagnostic({
            code: "AJ_STORE_ACTION_SESSION_NOT_READY",
            severity: "warn",
            message: `[AirJamStore] Action "${actionName}" blocked: session role not ready.`,
            details: {
              actionName,
              role: runtime.role,
              roomId: runtime.roomId
            }
          });
          return createClientRejectedActionResult(
            "session_not_ready",
            `Store action "${actionName}" cannot run because the controller session is not ready.`,
            {
              actionName,
              ...runtime.role ? { role: runtime.role } : {},
              ...runtime.roomId ? { roomId: runtime.roomId } : {}
            }
          );
        }
        const activeSocket = runtime.socket;
        if (!activeSocket || !activeSocket.connected) {
          emitAirJamDiagnostic({
            code: "AJ_STORE_ACTION_SOCKET_DISCONNECTED",
            severity: "warn",
            message: `[AirJamStore] Action "${actionName}" blocked: Socket disconnected.`,
            details: { actionName }
          });
          return createClientRejectedActionResult(
            "socket_disconnected",
            `Store action "${actionName}" cannot run because the controller socket is disconnected.`,
            {
              actionName
            }
          );
        }
        if (!isRpcSerializable(normalizedPayload)) {
          emitAirJamDiagnostic({
            code: "AJ_STORE_ACTION_PAYLOAD_NOT_SERIALIZABLE",
            severity: "warn",
            message: `[AirJamStore] Action "${actionName}" blocked: payload must be RPC-serializable.`,
            details: { actionName }
          });
          return createClientRejectedActionResult(
            "payload_not_serializable",
            `Store action "${actionName}" requires an RPC-serializable payload.`,
            {
              actionName
            }
          );
        }
        if (normalizedPayload !== void 0 && !isPlainActionPayload(normalizedPayload)) {
          emitAirJamDiagnostic({
            code: "AJ_STORE_ACTION_PAYLOAD_INVALID_SHAPE",
            severity: "warn",
            message: `[AirJamStore] Action "${actionName}" blocked: payload must be omitted or a plain object.`,
            details: { actionName }
          });
          return createClientRejectedActionResult(
            "payload_invalid_shape",
            `Store action "${actionName}" requires an omitted payload or a plain object payload.`,
            {
              actionName
            }
          );
        }
        return await activeSocket.emitWithAck(
          "controller:action_rpc",
          {
            roomId: runtime.roomId,
            actionName,
            payload: normalizedPayload,
            storeDomain: runtime.resolvedStoreDomain
          }
        );
      };
    }
    return actionDispatch;
  };
  const notifyHostActionListeners = (event) => {
    for (const registration of hostActionListeners) {
      if (registration.actionNames && !registration.actionNames.has(event.actionName)) {
        continue;
      }
      if (!registration.includeRejected && event.acknowledgement.status === "rejected") {
        continue;
      }
      try {
        registration.listener(event);
      } catch (error) {
        console.error(
          `[AirJamStore] Host action listener for "${event.actionName}" threw.`,
          error
        );
      }
    }
  };
  const createRuntimeBinding = ({
    socket,
    role,
    roomId,
    resolvedStoreDomain
  }) => {
    if (role === "host") {
      let syncedStateData = stripActionsFromState(store.getState());
      let syncedStateSignature = JSON.stringify(syncedStateData);
      let syncRevision = 0;
      const emitHostStateSync = (requestId) => {
        const runtime = runtimeSnapshotRef.current;
        if (runtime.role !== "host" || runtime.roomId !== roomId || runtime.resolvedStoreDomain !== resolvedStoreDomain || !runtime.canBroadcastHostState || !runtime.socket) {
          return;
        }
        runtime.socket.emit("host:state_sync", {
          roomId,
          data: syncedStateData,
          storeDomain: resolvedStoreDomain,
          revision: syncRevision,
          ...requestId ? { requestId } : {}
        });
      };
      const flushHostStateSync = (requestId) => {
        emitHostStateSync(requestId);
      };
      const handleControllerJoined = () => {
        flushHostStateSync();
      };
      const unsubscribe = store.subscribe((newState) => {
        const runtime = runtimeSnapshotRef.current;
        if (runtime.role !== "host" || runtime.roomId !== roomId || runtime.resolvedStoreDomain !== resolvedStoreDomain || !runtime.canBroadcastHostState || !runtime.socket) {
          return;
        }
        const stateData = stripActionsFromState(newState);
        const nextSignature = JSON.stringify(stateData);
        if (nextSignature === syncedStateSignature) {
          return;
        }
        syncedStateData = stateData;
        syncedStateSignature = nextSignature;
        syncRevision += 1;
        emitHostStateSync();
      });
      const handleAction = (payload, callback) => {
        if (payload.storeDomain !== resolvedStoreDomain) {
          return;
        }
        const { actionName } = payload;
        if (isInternalActionName(actionName)) {
          return;
        }
        const runtime = runtimeSnapshotRef.current;
        const actionFn = store.getState().actions[actionName];
        if (typeof actionFn !== "function") {
          callback == null ? void 0 : callback(
            createServerRejectedActionResult(
              "action_not_found",
              `Store action "${actionName}" is not registered on the host.`,
              {
                actionName,
                storeDomain: resolvedStoreDomain
              }
            )
          );
          return;
        }
        try {
          const context = toActionContext(payload, runtime.connectedPlayerIds);
          const result = actionFn(context, payload.payload);
          const acknowledgement = normalizeAirJamActionInvocationResult(
            result,
            "host"
          );
          const actionName2 = payload.actionName;
          notifyHostActionListeners({
            actionName: actionName2,
            payload: payload.payload,
            context,
            acknowledgement,
            invocationKind: "rpc",
            roomId,
            storeDomain: resolvedStoreDomain
          });
          callback == null ? void 0 : callback(acknowledgement);
        } catch (error) {
          const acknowledgement = {
            ok: false,
            status: "rejected",
            source: "host",
            reason: "handler_error",
            message: error instanceof Error ? error.message : String(error)
          };
          const actionName2 = payload.actionName;
          notifyHostActionListeners({
            actionName: actionName2,
            payload: payload.payload,
            context: toActionContext(payload, runtime.connectedPlayerIds),
            acknowledgement,
            invocationKind: "rpc",
            roomId,
            storeDomain: resolvedStoreDomain
          });
          callback == null ? void 0 : callback(acknowledgement);
        }
      };
      const handleStateSyncRequest = (payload) => {
        if (payload.roomId !== roomId) {
          return;
        }
        if (payload.storeDomain !== resolvedStoreDomain) {
          return;
        }
        flushHostStateSync(payload.requestId);
      };
      const handleSync2 = (payload) => {
        if (payload.roomId !== roomId) {
          return;
        }
        if (payload.storeDomain !== resolvedStoreDomain) {
          return;
        }
        if (payload.revision < syncRevision) {
          return;
        }
        const nextStateData = stripActionsFromState(payload.data);
        const nextSignature = JSON.stringify(nextStateData);
        const currentSignature = JSON.stringify(
          stripActionsFromState(store.getState())
        );
        syncRevision = payload.revision;
        syncedStateData = nextStateData;
        syncedStateSignature = nextSignature;
        if (nextSignature === currentSignature) {
          return;
        }
        store.setState(nextStateData);
      };
      socket.on("server:controllerJoined", handleControllerJoined);
      socket.on("airjam:state_sync", handleSync2);
      socket.on("airjam:state_sync_request", handleStateSyncRequest);
      socket.on("airjam:action_rpc", handleAction);
      return {
        refCount: 0,
        flushHostStateSync,
        cleanup: () => {
          unsubscribe();
          socket.off("server:controllerJoined", handleControllerJoined);
          socket.off("airjam:state_sync", handleSync2);
          socket.off("airjam:state_sync_request", handleStateSyncRequest);
          socket.off("airjam:action_rpc", handleAction);
        }
      };
    }
    let latestSyncRevision = -1;
    const handleSync = (payload) => {
      if (payload.storeDomain !== resolvedStoreDomain) {
        return;
      }
      if (payload.revision < latestSyncRevision) {
        return;
      }
      latestSyncRevision = payload.revision;
      const stateData = stripActionsFromState(payload.data);
      store.setState(stateData);
    };
    socket.on("airjam:state_sync", handleSync);
    if (runtimeSnapshotRef.current.connectionStatus === "connected") {
      socket.emit("controller:state_sync_request", {
        roomId,
        storeDomain: resolvedStoreDomain
      });
    }
    return {
      refCount: 0,
      cleanup: () => {
        socket.off("airjam:state_sync", handleSync);
      }
    };
  };
  const useSyncedStore = (selector = (state) => state) => {
    const slice = store(selector);
    const explicitDomain = options == null ? void 0 : options.storeDomain;
    let resolvedStoreDomain;
    if (typeof explicitDomain === "string" && explicitDomain.trim().length > 0) {
      const trimmed = explicitDomain.trim();
      resolvedStoreDomain = trimmed.length > 128 ? trimmed.slice(0, 128) : trimmed;
    } else {
      resolvedStoreDomain = resolveImplicitReplicatedStoreDomainFromWindow();
    }
    const { getSocket } = useAirJamContext();
    const role = useAirJamState((state) => state.role);
    const roomId = useAirJamState((state) => state.roomId);
    const registeredRoomId = useAirJamState((state) => state.registeredRoomId);
    const connectionStatus = useAirJamState((state) => state.connectionStatus);
    const players = useAirJamState((state) => state.players);
    const hostArcadeRestore = useAirJamState(
      (state) => state.hostArcadeRestore
    );
    const blockArcadeShellHostBroadcast = resolvedStoreDomain === AIR_JAM_ARCADE_SURFACE_STORE_DOMAIN && hostArcadeRestore.phase !== "idle";
    const canBroadcastHostState = role === "host" && !!roomId && registeredRoomId === roomId && !blockArcadeShellHostBroadcast;
    const connectedPlayerIds = (0, import_react15.useMemo)(
      () => Array.from(new Set(players.map((player) => player.id))).sort(),
      [players]
    );
    const playerRosterKey = (0, import_react15.useMemo)(
      () => players.map((player) => player.id).sort().join(","),
      [players]
    );
    const socket = role === "host" ? getHostRealtimeClient((runtimeRole) => getSocket(runtimeRole)) : getControllerRealtimeClient((runtimeRole) => getSocket(runtimeRole));
    runtimeSnapshotRef.current = {
      socket,
      role,
      roomId,
      resolvedStoreDomain,
      connectionStatus,
      canBroadcastHostState,
      connectedPlayerIds
    };
    const runtimeBindingKey = socket && roomId && role ? [
      role,
      roomId,
      resolvedStoreDomain,
      socket.id ?? "socket",
      role === "controller" ? connectionStatus : "host"
    ].join(":") : null;
    (0, import_react15.useEffect)(() => {
      if (!runtimeBindingKey || !socket || !roomId || !role) {
        return;
      }
      let binding = runtimeBindings.get(runtimeBindingKey);
      if (!binding) {
        binding = createRuntimeBinding({
          socket,
          role,
          roomId,
          resolvedStoreDomain
        });
        runtimeBindings.set(runtimeBindingKey, binding);
      }
      binding.refCount += 1;
      return () => {
        const currentBinding = runtimeBindings.get(runtimeBindingKey);
        if (!currentBinding) {
          return;
        }
        currentBinding.refCount -= 1;
        if (currentBinding.refCount > 0) {
          return;
        }
        currentBinding.cleanup();
        runtimeBindings.delete(runtimeBindingKey);
      };
    }, [
      runtimeBindingKey,
      socket,
      role,
      roomId,
      socket == null ? void 0 : socket.id,
      resolvedStoreDomain
    ]);
    (0, import_react15.useEffect)(() => {
      if (!runtimeBindingKey || role !== "host" || !canBroadcastHostState || !roomId) {
        return;
      }
      const binding = runtimeBindings.get(runtimeBindingKey);
      if (!(binding == null ? void 0 : binding.flushHostStateSync)) {
        return;
      }
      const flushKey = [
        roomId,
        registeredRoomId,
        (socket == null ? void 0 : socket.id) ?? "socket",
        resolvedStoreDomain,
        playerRosterKey,
        canBroadcastHostState ? "broadcast" : "blocked"
      ].join(":");
      if (binding.lastHostFlushKey === flushKey) {
        return;
      }
      binding.lastHostFlushKey = flushKey;
      binding.flushHostStateSync();
    }, [
      role,
      roomId,
      registeredRoomId,
      socket == null ? void 0 : socket.id,
      playerRosterKey,
      resolvedStoreDomain,
      canBroadcastHostState,
      runtimeBindingKey
    ]);
    const dispatchedActions = (0, import_react15.useMemo)(
      () => createDispatchedActions({ kind: "default" }),
      []
    );
    const stateActions = store.getState().actions;
    if (slice === stateActions) {
      return dispatchedActions;
    }
    if (typeof slice === "object" && slice !== null && "actions" in slice && slice.actions === stateActions) {
      return {
        ...slice,
        actions: dispatchedActions
      };
    }
    return slice;
  };
  const syncedStore = useSyncedStore;
  const useActions = () => useSyncedStore((state) => state.actions);
  const asPlayer = (controllerId) => createDispatchedActions({
    kind: "player",
    controllerId
  });
  const subscribeHostActions = (listener, options2) => {
    const actionNames = (options2 == null ? void 0 : options2.actionNames) && options2.actionNames.length > 0 ? new Set(options2.actionNames) : null;
    const registration = {
      actionNames,
      includeRejected: (options2 == null ? void 0 : options2.includeRejected) ?? false,
      listener
    };
    hostActionListeners.add(registration);
    return () => {
      hostActionListeners.delete(registration);
    };
  };
  const useHostActionListener = (listener, options2) => {
    var _a;
    const listenerRef = (0, import_react15.useRef)(listener);
    (0, import_react15.useEffect)(() => {
      listenerRef.current = listener;
    }, [listener]);
    const includeRejected = (options2 == null ? void 0 : options2.includeRejected) ?? false;
    const actionNamesKey = ((_a = options2 == null ? void 0 : options2.actionNames) == null ? void 0 : _a.join("\0")) ?? "";
    (0, import_react15.useEffect)(() => {
      return subscribeHostActions((event) => {
        listenerRef.current(event);
      }, options2);
    }, [actionNamesKey, includeRejected, options2]);
  };
  const useLiveStateRef = () => {
    const latestState = useSyncedStore((state) => state);
    const stateRef = (0, import_react15.useRef)(latestState);
    (0, import_react15.useEffect)(() => {
      stateRef.current = latestState;
    }, [latestState]);
    return stateRef;
  };
  syncedStore.useActions = useActions;
  syncedStore.asPlayer = asPlayer;
  syncedStore.getState = store.getState;
  syncedStore.subscribe = store.subscribe;
  syncedStore.subscribeHostActions = subscribeHostActions;
  syncedStore.useHostActionListener = useHostActionListener;
  syncedStore.useLiveStateRef = useLiveStateRef;
  return syncedStore;
}
export {
  AIR_JAM_RUNTIME_INSPECTION_KEY,
  AirJamControllerRuntime,
  AirJamErrorBoundary,
  AirJamHostRuntime,
  AudioRuntime,
  DEFAULT_PLATFORM_SETTINGS,
  DEFAULT_ROOM_PLATFORM_SETTINGS,
  MusicPlaylist,
  PlatformSettingsBoundary,
  PlatformSettingsRuntime,
  acceptAirJamAction,
  agentAction,
  agentActionInput,
  agentStore,
  createAirJamApp,
  createAirJamStore,
  createControllerRuntimeInspectionContract,
  createHostRuntimeInspectionContract,
  defineAirJamAgentContract,
  defineAirJamAgentStores,
  env,
  getEffectiveAudioVolume,
  isActiveMatchPhase,
  isEndedMatchPhase,
  isStandardMatchPhase,
  mergeRoomPlatformSettingsSnapshot,
  onAirJamDiagnostic,
  publishRuntimeInspectionContract,
  readRuntimeInspectionContract,
  rejectAirJamAction,
  resolveAirJamBrowserRouterBasename,
  setAirJamDiagnosticsEnabled,
  standardMatchPhases,
  toRoomPlatformSettingsSnapshot,
  toShellMatchPhase,
  useAirJamController,
  useAirJamHost,
  useAudio,
  useAudioCategoryVolume,
  useAudioRuntimeControls,
  useAudioRuntimeStatus,
  useConnectionStatus,
  useControllerRuntimeInspectionContract,
  useControllerTick,
  useControllerToasts,
  useGetInput,
  useHostAudioMutePreference,
  useHostRuntimeInspectionContract,
  useHostTick,
  useInheritedPlatformSettings,
  useInputWriter,
  useMusicVolume,
  usePlatformAudioSettings,
  usePlatformSettings,
  usePlayers,
  useRoom,
  useSendSignal
};
/*! Bundled license information:

howler/dist/howler.js:
  (*!
   *  howler.js v2.2.4
   *  howlerjs.com
   *
   *  (c) 2013-2020, James Simpson of GoldFire Studios
   *  goldfirestudios.com
   *
   *  MIT License
   *)
  (*!
   *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
   *  
   *  howler.js v2.2.4
   *  howlerjs.com
   *
   *  (c) 2013-2020, James Simpson of GoldFire Studios
   *  goldfirestudios.com
   *
   *  MIT License
   *)
*/
//# sourceMappingURL=@air-jam_sdk.js.map
