import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/controller/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c74894a2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/AiFactory/src/controller/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$();
import { useAirJamController } from "/node_modules/.vite/deps/@air-jam_sdk.js?v=c74894a2";
import { SurfaceViewport } from "/node_modules/.vite/deps/@air-jam_sdk_ui.js?v=c74894a2";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=c74894a2"; const useCallback = __vite__cjsImport5_react["useCallback"]; const useEffect = __vite__cjsImport5_react["useEffect"]; const useRef = __vite__cjsImport5_react["useRef"]; const useState = __vite__cjsImport5_react["useState"];
import { GAME_CONFIG } from "/src/game/config/gameConfig.ts";
import {
  ROLE_COLORS,
  ROLE_ICONS,
  ROLE_LABELS,
  ROLE_MINI_GAME
} from "/src/game/domain/types.ts";
import { useFactoryStore } from "/src/game/store/factoryStore.ts";
function PowerGame({ progress, status, score, onTap }) {
  _s();
  const isComplete = status === "complete";
  const color = "#facc15";
  const [ripples, setRipples] = useState([]);
  const rippleId = useRef(0);
  const btnRef = useRef(null);
  const lastTapRef = useRef(0);
  const handlePointerDown = useCallback(
    (e) => {
      if (isComplete) return;
      const now = Date.now();
      if (now - lastTapRef.current < 80) return;
      lastTapRef.current = now;
      onTap();
      if (btnRef.current) {
        const rect = btnRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const id = ++rippleId.current;
        setRipples((prev) => [...prev, { id, x, y }]);
        setTimeout(() => setRipples((prev) => prev.filter((r) => r.id !== id)), 600);
      }
    },
    [isComplete, onTap]
  );
  const radius = 90;
  const circ = 2 * Math.PI * radius;
  const dashOffset = circ - progress / 100 * circ;
  if (isComplete) {
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex h-full w-full flex-col items-center justify-center gap-6",
        style: { background: "radial-gradient(ellipse at center, #facc1520 0%, transparent 70%)" },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "power-complete-ring flex items-center justify-center rounded-full",
              style: {
                width: 220,
                height: 220,
                border: "4px solid #facc15",
                boxShadow: "0 0 60px #facc15aa, 0 0 120px #facc1540",
                animation: "powerComplete 1.5s ease-in-out infinite alternate"
              },
              children: /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 80 }, children: "⚡" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 113,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 103,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-3xl font-black uppercase tracking-widest",
              style: { color: "#facc15", textShadow: "0 0 20px #facc15" },
              children: "POWER ONLINE"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 115,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
            "Department score: ",
            score.toLocaleString(),
            " pts"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 121,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 98,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-between py-4", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full items-center justify-between px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Progress" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 132,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-2xl font-black", style: { color }, children: [
          progress,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 133,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Score" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 138,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-sky-300", children: score.toLocaleString() }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 137,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Per Tap" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 144,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-slate-300", children: [
          "+",
          GAME_CONFIG.powerIncrementPerTap,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 145,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 143,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex flex-1 items-center justify-center", children: [
      /* @__PURE__ */ jsxDEV(
        "svg",
        {
          width: 220,
          height: 220,
          viewBox: "0 0 220 220",
          className: "absolute",
          style: { transform: "rotate(-90deg)" },
          children: [
            /* @__PURE__ */ jsxDEV("circle", { cx: 110, cy: 110, r: radius, fill: "none", stroke: "#1e293b", strokeWidth: 10 }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 162,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "circle",
              {
                cx: 110,
                cy: 110,
                r: radius,
                fill: "none",
                stroke: color,
                strokeWidth: 10,
                strokeLinecap: "round",
                strokeDasharray: circ,
                strokeDashoffset: dashOffset,
                style: { transition: "stroke-dashoffset 0.2s ease-out", filter: `drop-shadow(0 0 6px ${color})` }
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 164,
                columnNumber: 11
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 154,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          ref: btnRef,
          type: "button",
          id: "power-tap-btn",
          onPointerDown: handlePointerDown,
          className: "relative overflow-hidden rounded-full select-none",
          style: {
            width: 160,
            height: 160,
            background: `radial-gradient(circle at 40% 35%, #facc1530, #facc1508)`,
            border: `3px solid ${color}80`,
            boxShadow: `0 0 30px ${color}40, inset 0 0 20px ${color}10`,
            WebkitTapHighlightColor: "transparent",
            touchAction: "none"
          },
          children: [
            ripples.map(
              (r) => /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "power-ripple",
                  style: {
                    left: r.x,
                    top: r.y
                  }
                },
                r.id,
                false,
                {
                  fileName: "D:/AiFactory/src/controller/index.tsx",
                  lineNumber: 197,
                  columnNumber: 11
                },
                this
              )
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-1 pointer-events-none", children: [
              /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 52 }, children: "⚡" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 208,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "text-lg font-black uppercase tracking-widest",
                  style: { color },
                  children: "TAP"
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/controller/index.tsx",
                  lineNumber: 209,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 207,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 179,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-1 flex justify-between text-[10px] uppercase tracking-widest text-slate-500", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Power Grid" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 222,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          progress,
          " / 100%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 223,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 221,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-3 overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute inset-y-0 left-0 rounded-full",
          style: {
            width: `${progress}%`,
            background: `linear-gradient(90deg, #854d0e, ${color})`,
            boxShadow: `0 0 8px ${color}80`,
            transition: "width 0.15s ease-out"
          }
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 226,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 225,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 220,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 127,
    columnNumber: 5
  }, this);
}
_s(PowerGame, "DsKJ0WWfAiFat3NHqHXtWDscgT0=");
_c = PowerGame;
function CoolingDevPanel({
  temperature,
  onSet
}) {
  _s2();
  const [localTemp, setLocalTemp] = useState(temperature);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-4 w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-5xl font-black text-sky-300 font-mono", children: [
      localTemp.toFixed(0),
      "°C"
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 254,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
      "Safe zone: ",
      GAME_CONFIG.coolingSafeMin,
      "–",
      GAME_CONFIG.coolingSafeMax,
      "°C"
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 257,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "range",
        min: 50,
        max: 120,
        value: localTemp,
        onChange: (e) => {
          const t = Number(e.target.value);
          setLocalTemp(t);
          onSet(t);
        },
        className: "w-full accent-sky-400",
        style: { touchAction: "none" }
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 261,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 w-full", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "ctrl-button flex-1 rounded-xl bg-sky-500/20 border border-sky-500/40 py-3 text-sky-300 font-bold text-lg hover:bg-sky-500/30 active:scale-95 transition-all",
          onClick: () => {
            const t = Math.max(50, localTemp - 5);
            setLocalTemp(t);
            onSet(t);
          },
          children: "− Cool"
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 276,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "ctrl-button flex-1 rounded-xl bg-orange-500/20 border border-orange-500/40 py-3 text-orange-300 font-bold text-lg hover:bg-orange-500/30 active:scale-95 transition-all",
          onClick: () => {
            const t = Math.min(120, localTemp + 5);
            setLocalTemp(t);
            onSet(t);
          },
          children: "+ Heat"
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 287,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 275,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 253,
    columnNumber: 5
  }, this);
}
_s2(CoolingDevPanel, "YWdAWq/JlPeuW0WsFCk4X/0ZaF8=");
_c2 = CoolingDevPanel;
function correctBucket(token) {
  return GAME_CONFIG.dataTokensNumbers.includes(token) ? "numbers" : "ai_terms";
}
function DataCleaningGame({ progress, status, score, onSort }) {
  _s3();
  const isComplete = status === "complete";
  const color = "#60a5fa";
  const allTokens = [
    ...GAME_CONFIG.dataTokensNumbers,
    ...GAME_CONFIG.dataTokensAiTerms
  ];
  const tokenIdRef = useRef(0);
  const lastSortRef = useRef(0);
  const nextToken = useCallback(() => {
    const value = allTokens[Math.floor(Math.random() * allTokens.length)];
    return { id: ++tokenIdRef.current, value };
  }, []);
  const [activeToken, setActiveToken] = useState(() => nextToken());
  const [feedbackToken, setFeedbackToken] = useState(null);
  const [shakeBucket, setShakeBucket] = useState(null);
  const [dragOver, setDragOver] = useState(null);
  const [tokenKey, setTokenKey] = useState(0);
  const handleDrop = useCallback(
    (bucket) => {
      const now = Date.now();
      if (now - lastSortRef.current < GAME_CONFIG.dataSortThrottleMs) return;
      lastSortRef.current = now;
      const token = activeToken;
      const isCorrect = correctBucket(token.value) === bucket;
      if (isCorrect) {
        setFeedbackToken({ ...token, feedback: "correct" });
        setTimeout(() => {
          setFeedbackToken(null);
          setActiveToken(nextToken());
          setTokenKey((k) => k + 1);
        }, 420);
      } else {
        setShakeBucket(bucket);
        setTimeout(() => setShakeBucket(null), 380);
      }
      onSort(token.value, bucket, isCorrect);
    },
    [activeToken, nextToken, onSort]
  );
  const handleBucketTap = useCallback(
    (bucket) => {
      if (isComplete) return;
      handleDrop(bucket);
    },
    [isComplete, handleDrop]
  );
  const radius = 72;
  const circ = 2 * Math.PI * radius;
  const dashOffset = circ - progress / 100 * circ;
  if (isComplete) {
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex h-full w-full flex-col items-center justify-center gap-6",
        style: { background: "radial-gradient(ellipse at center, #60a5fa20 0%, transparent 70%)" },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center justify-center rounded-full",
              style: {
                width: 180,
                height: 180,
                border: "4px solid #60a5fa",
                boxShadow: "0 0 60px #60a5faaa, 0 0 120px #60a5fa40",
                animation: "dataComplete 1.5s ease-in-out infinite alternate"
              },
              children: /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 64 }, children: "💾" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 417,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 407,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-3xl font-black uppercase tracking-widest",
              style: { color, textShadow: "0 0 20px #60a5fa" },
              children: "DATA CLEAN"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 419,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
            "Department score: ",
            score.toLocaleString(),
            " pts"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 425,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 402,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-between py-4 gap-3", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full items-center justify-between px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Progress" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 436,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-2xl font-black", style: { color }, children: [
          progress,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 437,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 435,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Score" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 442,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-sky-300", children: score.toLocaleString() }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 443,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 441,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Per Sort" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 448,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-slate-300", children: [
          "+",
          GAME_CONFIG.pointsPerDataSort
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 449,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 447,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 434,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center justify-center", style: { width: 170, height: 170, flexShrink: 0 }, children: [
      /* @__PURE__ */ jsxDEV("svg", { width: 170, height: 170, viewBox: "0 0 170 170", className: "absolute", style: { transform: "rotate(-90deg)" }, children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: 85, cy: 85, r: radius, fill: "none", stroke: "#1e293b", strokeWidth: 8 }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 458,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "circle",
          {
            cx: 85,
            cy: 85,
            r: radius,
            fill: "none",
            stroke: color,
            strokeWidth: 8,
            strokeLinecap: "round",
            strokeDasharray: circ,
            strokeDashoffset: dashOffset,
            style: { transition: "stroke-dashoffset 0.25s ease-out", filter: `drop-shadow(0 0 5px ${color})` }
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 459,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 457,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "data-token-enter relative z-10 flex flex-col items-center justify-center rounded-2xl select-none",
          style: {
            width: 120,
            height: 120,
            background: "rgba(15, 32, 53, 0.95)",
            border: `2px solid ${color}60`,
            boxShadow: `0 0 20px ${color}30`
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs uppercase tracking-widest text-slate-500 mb-1", children: "Sort this" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 479,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "font-mono font-black text-3xl",
                style: { color },
                children: activeToken.value
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 480,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-600 mt-1 uppercase tracking-wider", children: "Tap a bucket" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 486,
              columnNumber: 11
            }, this)
          ]
        },
        `token-${tokenKey}`,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 468,
          columnNumber: 9
        },
        this
      ),
      feedbackToken && /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "data-sort-correct absolute inset-0 flex items-center justify-center rounded-full pointer-events-none",
          style: { zIndex: 20 },
          children: /* @__PURE__ */ jsxDEV("div", { className: "text-4xl font-black text-green-400", children: "✓" }, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 497,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 493,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 456,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full gap-3 px-2", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          id: "data-bucket-numbers",
          type: "button",
          onPointerDown: () => handleBucketTap("numbers"),
          onDragOver: (e) => {
            e.preventDefault();
            setDragOver("numbers");
          },
          onDragLeave: () => setDragOver(null),
          onDrop: (e) => {
            e.preventDefault();
            setDragOver(null);
            handleDrop("numbers");
          },
          className: [
            "ctrl-button flex-1 flex flex-col items-center justify-center gap-2 rounded-2xl border-2 py-5 transition-all active:scale-95",
            shakeBucket === "numbers" ? "data-bucket-shake" : "",
            dragOver === "numbers" ? "data-bucket-over" : ""
          ].join(" "),
          style: {
            background: "rgba(96, 165, 250, 0.08)",
            borderColor: dragOver === "numbers" ? "#60a5fa" : "rgba(96, 165, 250, 0.35)"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl", children: "🔢" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 522,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold uppercase tracking-widest", style: { color }, children: "Numbers" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 523,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500", children: "42, 7, 256…" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 524,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 505,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          id: "data-bucket-ai-terms",
          type: "button",
          onPointerDown: () => handleBucketTap("ai_terms"),
          onDragOver: (e) => {
            e.preventDefault();
            setDragOver("ai_terms");
          },
          onDragLeave: () => setDragOver(null),
          onDrop: (e) => {
            e.preventDefault();
            setDragOver(null);
            handleDrop("ai_terms");
          },
          className: [
            "ctrl-button flex-1 flex flex-col items-center justify-center gap-2 rounded-2xl border-2 py-5 transition-all active:scale-95",
            shakeBucket === "ai_terms" ? "data-bucket-shake" : "",
            dragOver === "ai_terms" ? "data-bucket-over" : ""
          ].join(" "),
          style: {
            background: "rgba(96, 165, 250, 0.08)",
            borderColor: dragOver === "ai_terms" ? "#60a5fa" : "rgba(96, 165, 250, 0.35)"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl", children: "🧠" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 545,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold uppercase tracking-widest", style: { color }, children: "AI Terms" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 546,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500", children: "AI, ML, GPU…" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 547,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 528,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 503,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-1 flex justify-between text-[10px] uppercase tracking-widest text-slate-500", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Data Pipeline" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 554,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          progress,
          " / 100%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 555,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 553,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-3 overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute inset-y-0 left-0 rounded-full",
          style: {
            width: `${progress}%`,
            background: `linear-gradient(90deg, #1e3a5f, ${color})`,
            boxShadow: `0 0 8px ${color}80`,
            transition: "width 0.2s ease-out"
          }
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 558,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 557,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 552,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 431,
    columnNumber: 5
  }, this);
}
_s3(DataCleaningGame, "o130TgJYFZo+9WwFCbZY/O/IMHQ=");
_c3 = DataCleaningGame;
function generateSequence(length) {
  const seq = [];
  let last = null;
  for (let i = 0; i < length; i++) {
    const options = last === "ZIP" ? ["ZAP", "ZAP", "ZIP"] : ["ZIP", "ZIP", "ZAP"];
    const next = options[Math.floor(Math.random() * options.length)];
    seq.push(next);
    last = next;
  }
  return seq;
}
function ZipZapGame({ progress, status, score, onZipZap }) {
  _s4();
  const isComplete = status === "complete";
  const color = "#34d399";
  const [sequence, setSequence] = useState(
    () => generateSequence(GAME_CONFIG.securitySequenceSeedLength)
  );
  const [currentStep, setCurrentStep] = useState(0);
  const [totalHits, setTotalHits] = useState(0);
  const [zipAnim, setZipAnim] = useState(null);
  const [zapAnim, setZapAnim] = useState(null);
  const lastPressRef = useRef(0);
  const zipAnimTimer = useRef(null);
  const zapAnimTimer = useRef(null);
  const clearZipAnim = useCallback(() => setZipAnim(null), []);
  const clearZapAnim = useCallback(() => setZapAnim(null), []);
  const handlePress = useCallback(
    (pressed) => {
      if (isComplete) return;
      const now = Date.now();
      if (now - lastPressRef.current < GAME_CONFIG.securityHitThrottleMs) return;
      lastPressRef.current = now;
      const expected = sequence[currentStep];
      const isHit = pressed === expected;
      onZipZap(isHit);
      if (isHit) {
        const nextHits = totalHits + 1;
        setTotalHits(nextHits);
        if (pressed === "ZIP") {
          setZipAnim(null);
          requestAnimationFrame(() => setZipAnim("correct"));
          if (zipAnimTimer.current) clearTimeout(zipAnimTimer.current);
          zipAnimTimer.current = setTimeout(clearZipAnim, 380);
        } else {
          setZapAnim(null);
          requestAnimationFrame(() => setZapAnim("correct"));
          if (zapAnimTimer.current) clearTimeout(zapAnimTimer.current);
          zapAnimTimer.current = setTimeout(clearZapAnim, 380);
        }
        const nextStep = currentStep + 1;
        if (nextStep >= sequence.length) {
          const growAt = GAME_CONFIG.securitySequenceGrowEvery;
          const newLen = GAME_CONFIG.securitySequenceSeedLength + Math.floor(nextHits / growAt);
          setSequence(generateSequence(Math.min(newLen, 10)));
          setCurrentStep(0);
        } else {
          setCurrentStep(nextStep);
        }
      } else {
        if (pressed === "ZIP") {
          setZipAnim(null);
          requestAnimationFrame(() => setZipAnim("wrong"));
          if (zipAnimTimer.current) clearTimeout(zipAnimTimer.current);
          zipAnimTimer.current = setTimeout(clearZipAnim, 450);
        } else {
          setZapAnim(null);
          requestAnimationFrame(() => setZapAnim("wrong"));
          if (zapAnimTimer.current) clearTimeout(zapAnimTimer.current);
          zapAnimTimer.current = setTimeout(clearZapAnim, 450);
        }
      }
    },
    [isComplete, sequence, currentStep, totalHits, onZipZap, clearZipAnim, clearZapAnim]
  );
  const radius = 72;
  const circ = 2 * Math.PI * radius;
  const dashOffset = circ - progress / 100 * circ;
  if (isComplete) {
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex h-full w-full flex-col items-center justify-center gap-6",
        style: { background: "radial-gradient(ellipse at center, #34d39920 0%, transparent 70%)" },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center justify-center rounded-full",
              style: {
                width: 180,
                height: 180,
                border: "4px solid #34d399",
                boxShadow: "0 0 60px #34d399aa, 0 0 120px #34d39940",
                animation: "securityComplete 1.5s ease-in-out infinite alternate"
              },
              children: /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 64 }, children: "🛡" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 700,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 690,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-3xl font-black uppercase tracking-widest",
              style: { color, textShadow: "0 0 20px #34d399" },
              children: "FIREWALL ACTIVE"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 702,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
            "Department score: ",
            score.toLocaleString(),
            " pts"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 708,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 686,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-between py-3 gap-2", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full items-center justify-between px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Progress" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 719,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-2xl font-black", style: { color }, children: [
          progress,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 720,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 718,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Score" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 725,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-sky-300", children: score.toLocaleString() }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 726,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 724,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Hits" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 731,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-slate-300", children: totalHits }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 732,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 730,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 717,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center justify-center", style: { width: 160, height: 160, flexShrink: 0 }, children: [
      /* @__PURE__ */ jsxDEV("svg", { width: 160, height: 160, viewBox: "0 0 160 160", className: "absolute", style: { transform: "rotate(-90deg)" }, children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: 80, cy: 80, r: radius, fill: "none", stroke: "#1e293b", strokeWidth: 8 }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 741,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "circle",
          {
            cx: 80,
            cy: 80,
            r: radius,
            fill: "none",
            stroke: color,
            strokeWidth: 8,
            strokeLinecap: "round",
            strokeDasharray: circ,
            strokeDashoffset: dashOffset,
            style: { transition: "stroke-dashoffset 0.3s ease-out", filter: `drop-shadow(0 0 5px ${color})` }
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 742,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 740,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 flex flex-col items-center", children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 44 }, children: "🛡" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 752,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-widest mt-1", style: { color }, children: "FIREWALL" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 753,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 751,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 739,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-1 text-center text-[10px] uppercase tracking-widest text-slate-500", children: "Attack Sequence — press in order" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 759,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden rounded-xl", style: { background: "rgba(52,211,153,0.06)", border: "1px solid rgba(52,211,153,0.2)" }, children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "threat-scan-line absolute inset-y-0 w-12 pointer-events-none",
            style: { background: "linear-gradient(90deg, transparent, rgba(52,211,153,0.25), transparent)" }
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 765,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-2 px-3 py-3 flex-wrap", children: sequence.map((step, i) => {
          const isActive = i === currentStep;
          const isDone = i < currentStep;
          return /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: isActive ? "zipzap-step-active" : "",
              style: {
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                width: 44,
                height: 28,
                borderRadius: 6,
                fontSize: 11,
                fontWeight: 900,
                fontFamily: "var(--font-mono)",
                letterSpacing: "0.08em",
                background: isDone ? "rgba(52,211,153,0.08)" : isActive ? "rgba(52,211,153,0.25)" : "rgba(15,32,53,0.8)",
                border: isDone ? "1px solid rgba(52,211,153,0.15)" : isActive ? "1.5px solid #34d399" : "1px solid rgba(52,211,153,0.15)",
                color: isDone ? "#34d39955" : isActive ? "#34d399" : "#64748b",
                transition: "all 0.15s ease"
              },
              children: isDone ? "✓" : step
            },
            i,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 774,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 769,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 763,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 758,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full gap-3 px-2", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          id: "security-zip-btn",
          type: "button",
          onPointerDown: () => handlePress("ZIP"),
          className: [
            "ctrl-button flex-1 flex flex-col items-center justify-center gap-1 rounded-2xl border-2 py-6 transition-all active:scale-95 select-none",
            zipAnim === "correct" ? "zipzap-correct" : "",
            zipAnim === "wrong" ? "zipzap-wrong" : ""
          ].join(" "),
          style: {
            background: zipAnim === "correct" ? "rgba(52,211,153,0.22)" : zipAnim === "wrong" ? "rgba(248,113,113,0.18)" : "rgba(52,211,153,0.08)",
            borderColor: zipAnim === "correct" ? "#34d399" : zipAnim === "wrong" ? "#f87171" : "rgba(52,211,153,0.35)",
            WebkitTapHighlightColor: "transparent",
            touchAction: "none"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-3xl font-black", style: { color, fontFamily: "var(--font-mono)" }, children: "ZIP" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 838,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500 uppercase tracking-widest", children: "Block" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 839,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 812,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          id: "security-zap-btn",
          type: "button",
          onPointerDown: () => handlePress("ZAP"),
          className: [
            "ctrl-button flex-1 flex flex-col items-center justify-center gap-1 rounded-2xl border-2 py-6 transition-all active:scale-95 select-none",
            zapAnim === "correct" ? "zipzap-correct" : "",
            zapAnim === "wrong" ? "zipzap-wrong" : ""
          ].join(" "),
          style: {
            background: zapAnim === "correct" ? "rgba(52,211,153,0.22)" : zapAnim === "wrong" ? "rgba(248,113,113,0.18)" : "rgba(52,211,153,0.08)",
            borderColor: zapAnim === "correct" ? "#34d399" : zapAnim === "wrong" ? "#f87171" : "rgba(52,211,153,0.35)",
            WebkitTapHighlightColor: "transparent",
            touchAction: "none"
          },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-3xl font-black", style: { color: "#6ee7b7", fontFamily: "var(--font-mono)" }, children: "ZAP" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 868,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500 uppercase tracking-widest", children: "Zap" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 869,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 842,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 811,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-1 flex justify-between text-[10px] uppercase tracking-widest text-slate-500", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Firewall" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 876,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          progress,
          " / 100%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 877,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 875,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-3 overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute inset-y-0 left-0 rounded-full",
          style: {
            width: `${progress}%`,
            background: `linear-gradient(90deg, #064e3b, ${color})`,
            boxShadow: `0 0 8px ${color}80`,
            transition: "width 0.2s ease-out"
          }
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 880,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 879,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 874,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 714,
    columnNumber: 5
  }, this);
}
_s4(ZipZapGame, "TYijRZUjnnqXJM8qA8dEWwtOzUY=");
_c4 = ZipZapGame;
const AI_PUZZLES = [
  {
    steps: ["DATA", "TRAIN", "PREDICT", "DEPLOY"],
    theme: "AI Pipeline",
    hint: "Collect data → train model → run predictions → ship to prod"
  },
  {
    steps: ["COLLECT", "CLEAN", "MODEL", "SHIP"],
    theme: "ML Workflow",
    hint: "Raw data → cleaned dataset → trained model → deployed"
  },
  {
    steps: ["PROMPT", "ENCODE", "GENERATE", "OUTPUT"],
    theme: "LLM Flow",
    hint: "User prompt → token encoding → text generation → response"
  },
  {
    steps: ["INGEST", "EMBED", "SEARCH", "RETRIEVE"],
    theme: "RAG System",
    hint: "Load docs → create embeddings → vector search → fetch context"
  },
  {
    steps: ["SENSE", "ANALYSE", "DECIDE", "ACT"],
    theme: "AI Agent",
    hint: "Perceive world → analyse state → choose action → execute"
  }
];
function shuffleIndices(n) {
  const arr = Array.from({ length: n }, (_, i) => i);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  const sorted = arr.every((v, i) => v === i);
  if (sorted && n > 1) {
    [arr[0], arr[1]] = [arr[1], arr[0]];
  }
  return arr;
}
function AiCorePuzzleGame({ progress, status, score, onSolve }) {
  _s5();
  const isComplete = status === "complete";
  const color = "#c084fc";
  const [puzzleIdx, setPuzzleIdx] = useState(0);
  const [order, setOrder] = useState(() => shuffleIndices(4));
  const [selected, setSelected] = useState(null);
  const [solvedCount, setSolvedCount] = useState(0);
  const [solving, setSolving] = useState(false);
  const puzzle = AI_PUZZLES[puzzleIdx % AI_PUZZLES.length];
  const handleTap = useCallback(
    (pos) => {
      if (solving || isComplete) return;
      if (selected === null) {
        setSelected(pos);
        return;
      }
      if (selected === pos) {
        setSelected(null);
        return;
      }
      const next = [...order];
      [next[selected], next[pos]] = [next[pos], next[selected]];
      setOrder(next);
      setSelected(null);
      const correct = next.every((v, i) => v === i);
      if (correct) {
        setSolving(true);
        onSolve();
        setTimeout(() => {
          setSolving(false);
          setSolvedCount((c) => c + 1);
          setPuzzleIdx((i) => i + 1);
          setOrder(shuffleIndices(4));
        }, 850);
      }
    },
    [selected, order, solving, isComplete, onSolve]
  );
  const radius = 52;
  const circ = 2 * Math.PI * radius;
  const dashOffset = circ - progress / 100 * circ;
  if (isComplete) {
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex h-full w-full flex-col items-center justify-center gap-6",
        style: { background: "radial-gradient(ellipse at center, #c084fc20 0%, transparent 70%)" },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center justify-center rounded-full",
              style: {
                width: 180,
                height: 180,
                border: "4px solid #c084fc",
                boxShadow: "0 0 60px #c084fcaa, 0 0 120px #c084fc40",
                animation: "modelComplete 1.5s ease-in-out infinite alternate"
              },
              children: /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 64 }, children: "🧠" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1019,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1009,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-3xl font-black uppercase tracking-widest",
              style: { color, textShadow: "0 0 20px #c084fc" },
              children: "MODEL OPTIMISED"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1021,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
            "Department score: ",
            score.toLocaleString(),
            " pts"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1027,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1004,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-between py-3 gap-3", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full items-center justify-between px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Progress" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1039,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-2xl font-black", style: { color }, children: [
          progress,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1040,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1038,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Score" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1045,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-sky-300", children: score.toLocaleString() }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1046,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1044,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Solved" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1051,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-slate-300", children: solvedCount }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1052,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1050,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1037,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center justify-center", style: { width: 130, height: 130, flexShrink: 0 }, children: [
      /* @__PURE__ */ jsxDEV("svg", { width: 130, height: 130, viewBox: "0 0 130 130", className: "absolute", style: { transform: "rotate(-90deg)" }, children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: 65, cy: 65, r: radius, fill: "none", stroke: "#1e293b", strokeWidth: 7 }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1061,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "circle",
          {
            cx: 65,
            cy: 65,
            r: radius,
            fill: "none",
            stroke: color,
            strokeWidth: 7,
            strokeLinecap: "round",
            strokeDasharray: circ,
            strokeDashoffset: dashOffset,
            style: { transition: "stroke-dashoffset 0.4s ease-out", filter: `drop-shadow(0 0 5px ${color})` }
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1062,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1060,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 flex flex-col items-center", children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 36 }, children: "🧠" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1071,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] uppercase tracking-widest mt-0.5", style: { color }, children: "AI CORE" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1072,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1070,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1059,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2 flex flex-col gap-2 flex-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold uppercase tracking-widest", style: { color }, children: puzzle.theme }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1080,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500 mt-0.5", children: "Tap to select • tap another to swap • arrange in order →" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1083,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1079,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2 flex-1 justify-center", children: order.map((stepIndex, pos) => {
        const label = puzzle.steps[stepIndex];
        const isSelected = selected === pos;
        const isCorrect = stepIndex === pos;
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            id: `puzzle-card-${pos}`,
            onPointerDown: () => handleTap(pos),
            className: [
              "ctrl-button w-full flex items-center gap-4 rounded-2xl px-5 py-4 transition-all active:scale-98 select-none",
              solving ? "puzzle-card-solve" : "",
              isSelected && !solving ? "puzzle-card-selected" : ""
            ].join(" "),
            style: {
              background: solving ? "rgba(192,132,252,0.12)" : isSelected ? "rgba(192,132,252,0.18)" : "rgba(15,32,53,0.9)",
              border: isSelected && !solving ? "2px solid #c084fc" : solving ? "2px solid #4ade80" : `1px solid rgba(192,132,252,${isCorrect ? "0.35" : "0.15"})`,
              WebkitTapHighlightColor: "transparent",
              touchAction: "none"
            },
            children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "text-[11px] font-black font-mono w-5 text-center shrink-0",
                  style: { color: isSelected ? color : "#475569" },
                  children: pos + 1
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/controller/index.tsx",
                  lineNumber: 1121,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-slate-700 text-xs shrink-0", children: "→" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1128,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "flex-1 text-center font-black tracking-widest",
                  style: {
                    fontFamily: "var(--font-mono)",
                    fontSize: 18,
                    color: isSelected ? color : solving ? "#4ade80" : "#e2e8f0",
                    transition: "color 0.15s ease"
                  },
                  children: label
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/controller/index.tsx",
                  lineNumber: 1130,
                  columnNumber: 17
                },
                this
              ),
              solving && /* @__PURE__ */ jsxDEV("span", { className: "text-green-400 text-lg shrink-0", children: "✓" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1143,
                columnNumber: 17
              }, this)
            ]
          },
          `${puzzleIdx}-${pos}`,
          true,
          {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1095,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1089,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1077,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2 text-center", children: /* @__PURE__ */ jsxDEV("div", { className: "text-[9px] text-slate-600 leading-relaxed", children: puzzle.hint }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1153,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-1 flex justify-between text-[10px] uppercase tracking-widest text-slate-500", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "AI Core" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1159,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          progress,
          " / 100%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1160,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1158,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-3 overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute inset-y-0 left-0 rounded-full",
          style: {
            width: `${progress}%`,
            background: `linear-gradient(90deg, #4a044e, ${color})`,
            boxShadow: `0 0 8px ${color}80`,
            transition: "width 0.35s ease-out"
          }
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1163,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1162,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1157,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 1034,
    columnNumber: 5
  }, this);
}
_s5(AiCorePuzzleGame, "54J1DR7xw+8I//6gi8EAK194NBg=");
_c5 = AiCorePuzzleGame;
async function requestOrientationPermission() {
  if (typeof DeviceOrientationEvent !== "undefined" && // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof DeviceOrientationEvent.requestPermission === "function") {
    try {
      const result = await DeviceOrientationEvent.requestPermission();
      return result === "granted" ? "granted" : "denied";
    } catch {
      return "denied";
    }
  }
  if (typeof DeviceOrientationEvent !== "undefined" && "ondeviceorientation" in window) {
    return "granted";
  }
  return "unavailable";
}
function CoolingGame({ temperature, progress, status, score, onTick }) {
  _s6();
  const isComplete = status === "complete";
  const color = "#38bdf8";
  const [orientState, setOrientState] = useState("idle");
  const bubblePosRef = useRef({ x: 0, y: 0 });
  const [bubblePos, setBubblePos] = useState({ x: 0, y: 0 });
  const boundsRef = useRef(null);
  const lastTickRef = useRef(0);
  useEffect(() => {
    const id = setInterval(() => {
      const { x, y } = bubblePosRef.current;
      const centeredness2 = Math.min(1, Math.sqrt(x * x + y * y));
      onTick(centeredness2);
    }, GAME_CONFIG.coolingTickThrottleMs);
    return () => clearInterval(id);
  }, [onTick]);
  useEffect(() => {
    if (orientState !== "granted") return;
    const handleOrientation = (e) => {
      const gamma = e.gamma ?? 0;
      const beta = e.beta ?? 0;
      const maxAngle = GAME_CONFIG.coolingMaxTiltAngle;
      const nx = Math.min(1, Math.max(-1, gamma / maxAngle));
      const ny = Math.min(1, Math.max(-1, (beta - 45) / maxAngle));
      bubblePosRef.current = { x: nx, y: ny };
      setBubblePos({ x: nx, y: ny });
    };
    window.addEventListener("deviceorientation", handleOrientation, true);
    return () => window.removeEventListener("deviceorientation", handleOrientation, true);
  }, [orientState]);
  const touchActiveRef = useRef(false);
  const handleTouchStart = useCallback((e) => {
    touchActiveRef.current = true;
    e.preventDefault();
  }, []);
  const handleTouchMove = useCallback((e) => {
    if (!touchActiveRef.current || !boundsRef.current) return;
    e.preventDefault();
    const rect = boundsRef.current.getBoundingClientRect();
    const touch = e.touches[0];
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const r = rect.width / 2;
    const dx = (touch.clientX - cx) / r;
    const dy = (touch.clientY - cy) / r;
    const len = Math.sqrt(dx * dx + dy * dy);
    const scale = len > 1 ? 1 / len : 1;
    const nx = dx * scale;
    const ny = dy * scale;
    bubblePosRef.current = { x: nx, y: ny };
    setBubblePos({ x: nx, y: ny });
  }, []);
  const handleTouchEnd = useCallback(() => {
    touchActiveRef.current = false;
    bubblePosRef.current = { x: 0, y: 0 };
    setBubblePos({ x: 0, y: 0 });
  }, []);
  const handleRequestPermission = useCallback(async () => {
    setOrientState("requesting");
    const result = await requestOrientationPermission();
    setOrientState(result);
  }, []);
  useEffect(() => {
    if (orientState === "idle") {
      requestOrientationPermission().then((result) => {
        if (result !== "denied") {
          setOrientState(result);
        }
      });
    }
  }, []);
  const centeredness = Math.min(1, Math.sqrt(bubblePos.x ** 2 + bubblePos.y ** 2));
  const isCentered = centeredness <= GAME_CONFIG.coolingCenteredThreshold;
  const inSafeZone = temperature >= GAME_CONFIG.coolingSafeMin && temperature <= GAME_CONFIG.coolingSafeMax;
  const BOUNDS_R = 110;
  const BUBBLE_R = 28;
  const maxTravel = BOUNDS_R - BUBBLE_R;
  const bx = bubblePos.x * maxTravel;
  const by = bubblePos.y * maxTravel;
  const tempFraction = Math.min(1, Math.max(0, (temperature - 50) / 70));
  const tempColor = inSafeZone ? "#34d399" : tempFraction > 0.7 ? "#f87171" : tempFraction > 0.45 ? "#fb923c" : "#38bdf8";
  const ringRadius = 50;
  const ringCirc = 2 * Math.PI * ringRadius;
  const ringOffset = ringCirc - progress / 100 * ringCirc;
  if (isComplete) {
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "flex h-full w-full flex-col items-center justify-center gap-6",
        style: { background: "radial-gradient(ellipse at center, #38bdf820 0%, transparent 70%)" },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "flex items-center justify-center rounded-full",
              style: {
                width: 200,
                height: 200,
                border: "4px solid #38bdf8",
                boxShadow: "0 0 60px #38bdf8aa, 0 0 120px #38bdf840",
                animation: "dataComplete 1.5s ease-in-out infinite alternate"
              },
              children: /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 72 }, children: "❄️" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1356,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1346,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-3xl font-black uppercase tracking-widest",
              style: { color, textShadow: "0 0 20px #38bdf8" },
              children: "COOLING STABLE"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1358,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
            "Department score: ",
            score.toLocaleString(),
            " pts"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1364,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1342,
        columnNumber: 7
      },
      this
    );
  }
  const needsPermissionTap = orientState === "idle" || orientState === "requesting";
  const showTouchFallback = orientState === "denied" || orientState === "unavailable";
  const showOrientUI = orientState === "granted";
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-between py-3 gap-2", style: { touchAction: "none" }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-full items-center justify-between px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Progress" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1380,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-2xl font-black", style: { color }, children: [
          progress,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1381,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1379,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Temp" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1384,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-xl font-black", style: { color: tempColor }, children: [
          temperature.toFixed(1),
          "°C"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1385,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1383,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase tracking-widest text-slate-500", children: "Score" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1390,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-bold text-sky-300", children: score.toLocaleString() }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1391,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1389,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1378,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "text-xs font-semibold uppercase tracking-widest px-3 py-1 rounded-full",
        style: {
          background: inSafeZone ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.1)",
          color: inSafeZone ? "#34d399" : "#f87171",
          border: `1px solid ${inSafeZone ? "#34d39940" : "#f8717140"}`,
          transition: "all 0.3s ease"
        },
        children: inSafeZone ? `✓ Safe zone ${GAME_CONFIG.coolingSafeMin}–${GAME_CONFIG.coolingSafeMax}°C` : `Target: ${GAME_CONFIG.coolingSafeMin}–${GAME_CONFIG.coolingSafeMax}°C`
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1396,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center justify-center", style: { flexShrink: 0 }, children: /* @__PURE__ */ jsxDEV(
      "div",
      {
        ref: boundsRef,
        onTouchStart: showTouchFallback ? handleTouchStart : void 0,
        onTouchMove: showTouchFallback ? handleTouchMove : void 0,
        onTouchEnd: showTouchFallback ? handleTouchEnd : void 0,
        style: {
          position: "relative",
          width: BOUNDS_R * 2,
          height: BOUNDS_R * 2,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(56,189,248,0.07) 0%, rgba(15,32,53,0.95) 75%)",
          border: `2px solid ${isCentered ? "#34d399" : "rgba(56,189,248,0.3)"}`,
          boxShadow: isCentered ? "0 0 24px #34d39960" : `0 0 12px rgba(56,189,248,0.15)`,
          transition: "border-color 0.3s ease, box-shadow 0.3s ease",
          overflow: "hidden"
        },
        children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            pointerEvents: "none"
          }, children: /* @__PURE__ */ jsxDEV("div", { style: {
            width: BOUNDS_R * 2 * GAME_CONFIG.coolingCenteredThreshold * 2,
            height: BOUNDS_R * 2 * GAME_CONFIG.coolingCenteredThreshold * 2,
            borderRadius: "50%",
            border: `1.5px dashed ${isCentered ? "#34d399" : "rgba(56,189,248,0.4)"}`,
            transition: "border-color 0.3s ease"
          } }, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1438,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1429,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            position: "absolute",
            top: "50%",
            left: 0,
            right: 0,
            height: 1,
            background: "rgba(56,189,248,0.12)",
            transform: "translateY(-0.5px)",
            pointerEvents: "none"
          } }, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1448,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            position: "absolute",
            left: "50%",
            top: 0,
            bottom: 0,
            width: 1,
            background: "rgba(56,189,248,0.12)",
            transform: "translateX(-0.5px)",
            pointerEvents: "none"
          } }, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1458,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                position: "absolute",
                width: BUBBLE_R * 2,
                height: BUBBLE_R * 2,
                borderRadius: "50%",
                // Centre of bounds + offset
                left: BOUNDS_R - BUBBLE_R + bx,
                top: BOUNDS_R - BUBBLE_R + by,
                background: `radial-gradient(circle at 35% 35%, ${isCentered ? "#34d399" : tempColor}cc, ${isCentered ? "#34d399" : tempColor}44)`,
                border: `2px solid ${isCentered ? "#34d399" : tempColor}`,
                boxShadow: `0 0 18px ${isCentered ? "#34d399" : tempColor}88`,
                transition: orientState === "granted" ? "left 0.08s ease-out, top 0.08s ease-out" : "none",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                pointerEvents: "none"
              },
              children: /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 18 }, children: "❄️" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1489,
                columnNumber: 13
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1470,
              columnNumber: 11
            },
            this
          ),
          needsPermissionTap && /* @__PURE__ */ jsxDEV("div", { style: {
            position: "absolute",
            inset: 0,
            borderRadius: "50%",
            background: "rgba(5,10,20,0.82)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            zIndex: 10
          }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 32 }, children: "🔄" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1506,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-sky-300 font-bold uppercase tracking-wider text-center px-4", children: orientState === "requesting" ? "Requesting…" : "Tap to enable\nGyroscope" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1507,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1494,
            columnNumber: 11
          }, this),
          showTouchFallback && centeredness < 0.05 && /* @__PURE__ */ jsxDEV("div", { style: {
            position: "absolute",
            inset: 0,
            borderRadius: "50%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 4,
            pointerEvents: "none",
            zIndex: 5
          }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 22, opacity: 0.5 }, children: "👆" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1527,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[9px] text-slate-500 uppercase tracking-widest", children: "Drag to control" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1528,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1515,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1411,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1409,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-2 w-full px-4", children: [
      needsPermissionTap && /* @__PURE__ */ jsxDEV(
        "button",
        {
          id: "cooling-enable-gyro-btn",
          type: "button",
          onClick: handleRequestPermission,
          disabled: orientState === "requesting",
          className: "ctrl-button w-full rounded-2xl py-3 text-sm font-bold uppercase tracking-wider active:scale-95 transition-all",
          style: {
            background: "rgba(56,189,248,0.12)",
            border: "2px solid rgba(56,189,248,0.4)",
            color: "#38bdf8",
            WebkitTapHighlightColor: "transparent"
          },
          children: "🎮 Enable Gyroscope"
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1537,
          columnNumber: 9
        },
        this
      ),
      showTouchFallback && /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500 uppercase tracking-widest text-center", children: "Touch fallback active — drag the bubble to centre" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1554,
        columnNumber: 9
      }, this),
      showOrientUI && /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500 uppercase tracking-widest text-center", children: "Tilt your phone to centre the bubble" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1559,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1535,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-center justify-center", style: { width: 120, height: 120, flexShrink: 0 }, children: [
      /* @__PURE__ */ jsxDEV("svg", { width: 120, height: 120, viewBox: "0 0 120 120", className: "absolute", style: { transform: "rotate(-90deg)" }, children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: 60, cy: 60, r: ringRadius, fill: "none", stroke: "#1e293b", strokeWidth: 7 }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1568,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "circle",
          {
            cx: 60,
            cy: 60,
            r: ringRadius,
            fill: "none",
            stroke: color,
            strokeWidth: 7,
            strokeLinecap: "round",
            strokeDasharray: ringCirc,
            strokeDashoffset: ringOffset,
            style: { transition: "stroke-dashoffset 0.5s ease-out", filter: `drop-shadow(0 0 4px ${color})` }
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1569,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1567,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 flex flex-col items-center", children: [
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 28 }, children: "🌡️" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1578,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[9px] uppercase tracking-widest mt-0.5", style: { color }, children: "COOLING" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1579,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1577,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1566,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full px-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-1 flex justify-between text-[10px] uppercase tracking-widest text-slate-500", children: [
        /* @__PURE__ */ jsxDEV("span", { children: "Coolant" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1586,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          progress,
          " / 100%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1587,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1585,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-3 overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute inset-y-0 left-0 rounded-full",
          style: {
            width: `${progress}%`,
            background: `linear-gradient(90deg, #0c4a6e, ${color})`,
            boxShadow: `0 0 8px ${color}80`,
            transition: "width 0.5s ease-out"
          }
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1590,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1589,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1584,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 1375,
    columnNumber: 5
  }, this);
}
_s6(CoolingGame, "AVElimMtQ60/yYX4HmP/0TMbmaU=");
_c6 = CoolingGame;
function RoleDevPanel({ role, progress, status, actions, coolingTemp }) {
  const color = ROLE_COLORS[role];
  const amt = GAME_CONFIG.devIncrementAmount;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-6 w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "w-full factory-panel p-4 flex flex-col gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs uppercase tracking-widest text-slate-400", children: "Progress" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1624,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-mono font-black text-2xl", style: { color }, children: [
          progress,
          "%"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1625,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1623,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-4 w-full overflow-hidden rounded-full bg-slate-800", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "progress-fill absolute inset-y-0 left-0 rounded-full",
          style: { width: `${progress}%`, background: color }
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1628,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1627,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-center text-slate-500 uppercase tracking-widest", children: status }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1633,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1622,
      columnNumber: 7
    }, this),
    role === "power" && /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "ctrl-button w-full rounded-2xl py-8 text-3xl font-black uppercase tracking-wider active:scale-95 transition-all",
        style: { background: `${color}25`, border: `2px solid ${color}60`, color },
        onClick: () => actions.devIncrementPower({ amount: amt }),
        children: [
          "⚡ TAP POWER",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1645,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-normal normal-case", children: [
            "+",
            amt,
            "% per tap"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1646,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1638,
        columnNumber: 7
      },
      this
    ),
    role === "data" && /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "ctrl-button w-full rounded-2xl py-8 text-3xl font-black uppercase tracking-wider active:scale-95 transition-all",
        style: { background: `${color}25`, border: `2px solid ${color}60`, color },
        onClick: () => actions.devIncrementData({ amount: amt }),
        children: [
          "💾 SORT DATA",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1658,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-normal normal-case", children: [
            "+",
            amt,
            "% per sort"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1659,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1651,
        columnNumber: 7
      },
      this
    ),
    role === "security" && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 w-full", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "ctrl-button flex-1 rounded-2xl py-8 text-2xl font-black active:scale-95 transition-all",
          style: { background: `${color}25`, border: `2px solid ${color}60`, color },
          onClick: () => actions.devIncrementSecurity({ amount: amt }),
          children: [
            "ZIP",
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1671,
              columnNumber: 16
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-normal", children: [
              "+",
              amt,
              "%"
            ] }, void 0, true, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1671,
              columnNumber: 22
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1665,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "ctrl-button flex-1 rounded-2xl py-8 text-2xl font-black active:scale-95 transition-all",
          style: { background: `${color}25`, border: `2px solid ${color}60`, color },
          onClick: () => actions.devIncrementSecurity({ amount: amt }),
          children: [
            "ZAP",
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1679,
              columnNumber: 16
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-normal", children: [
              "+",
              amt,
              "%"
            ] }, void 0, true, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1679,
              columnNumber: 22
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1673,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1664,
      columnNumber: 7
    }, this),
    role === "model" && /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        className: "ctrl-button w-full rounded-2xl py-8 text-3xl font-black uppercase tracking-wider active:scale-95 transition-all",
        style: { background: `${color}25`, border: `2px solid ${color}60`, color },
        onClick: () => actions.devIncrementModel({ amount: amt }),
        children: [
          "🧠 OPTIMIZE",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1692,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-normal normal-case", children: [
            "+",
            amt,
            "% per solve"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/controller/index.tsx",
            lineNumber: 1693,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1685,
        columnNumber: 7
      },
      this
    ),
    role === "cooling" && /* @__PURE__ */ jsxDEV(
      CoolingDevPanel,
      {
        temperature: coolingTemp,
        onSet: (t) => actions.devSetCoolingTemp({ temperature: t })
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1698,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-600 text-center", children: "DEV TEST MODE · Real mini-game in next milestone" }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1704,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 1620,
    columnNumber: 5
  }, this);
}
_c7 = RoleDevPanel;
export function ControllerView() {
  _s7();
  const controller = useAirJamController();
  const state = useFactoryStore((s) => s);
  const actions = useFactoryStore.useActions();
  const requestedRef = useRef(false);
  const myId = controller.controllerId;
  const myRole = myId ? state.roleAssignments[myId] : void 0;
  const connected = controller.connectionStatus === "connected";
  const color = myRole ? ROLE_COLORS[myRole] : "#38bdf8";
  useEffect(() => {
    if (connected && !myRole && !requestedRef.current) {
      requestedRef.current = true;
      actions.requestRole();
    }
  }, [connected, myRole, actions]);
  if (!connected) {
    return /* @__PURE__ */ jsxDEV(SurfaceViewport, { orientation: "portrait", className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-center gap-4 p-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-4xl animate-pulse", children: "🏭" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1738,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-sky-400", children: "AI FACTORY" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1739,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-500", children: controller.connectionStatus === "connecting" ? "Connecting to factory…" : "Reconnecting…" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1740,
        columnNumber: 11
      }, this),
      controller.connectionStatus === "disconnected" && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: "ctrl-button mt-2 rounded-lg border border-sky-400/30 px-6 py-2 text-sm text-sky-400 hover:bg-sky-400/10",
          onClick: controller.reconnect,
          children: "Retry Connection"
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1746,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1737,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1736,
      columnNumber: 7
    }, this);
  }
  if (!myRole) {
    return /* @__PURE__ */ jsxDEV(SurfaceViewport, { orientation: "portrait", className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-center gap-4 p-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-4xl animate-spin", children: "⚙️" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1764,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-sky-400", children: "Joining Factory…" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1765,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-500", children: "Waiting for role assignment" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1766,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1763,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1762,
      columnNumber: 7
    }, this);
  }
  if (state.phase === "idle" || state.phase === "lobby") {
    return /* @__PURE__ */ jsxDEV(SurfaceViewport, { orientation: "portrait", className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-center gap-6 p-6", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "factory-panel flex flex-col items-center gap-3 p-8 w-full max-w-xs",
          style: { borderColor: `${color}60`, boxShadow: `0 0 24px ${color}25` },
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-6xl", children: ROLE_ICONS[myRole] }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1781,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs uppercase tracking-widest text-slate-400", children: "Your Role" }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1782,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-black", style: { color }, children: ROLE_LABELS[myRole] }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1783,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400 text-center", children: ROLE_MINI_GAME[myRole] }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1786,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1777,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
          Object.keys(state.roleAssignments).length,
          " / ",
          GAME_CONFIG.maxPlayers,
          " engineers ready"
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1792,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-sky-400 animate-pulse", children: "Waiting for host to start…" }, void 0, false, {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1795,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1791,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] font-mono text-slate-700", children: [
        "ID: ",
        myId?.slice(0, 12)
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1800,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1776,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1775,
      columnNumber: 7
    }, this);
  }
  if (state.phase === "playing") {
    const deptState = state[myRole];
    const myEvent = state.activeEvents.find((e) => e.affectedRole === myRole);
    return /* @__PURE__ */ jsxDEV(SurfaceViewport, { orientation: "portrait", className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col gap-4 p-4", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "factory-surface flex items-center gap-3 px-4 py-3",
          style: {
            borderColor: myEvent ? `rgba(251,146,60,0.7)` : `${color}40`,
            animation: myEvent ? "warningPulse 0.8s ease-in-out infinite" : void 0,
            transition: "border-color 0.3s ease"
          },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: ROLE_ICONS[myRole] }, void 0, false, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1824,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-500 uppercase tracking-widest", children: "Role" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1826,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-black", style: { color }, children: ROLE_LABELS[myRole] }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1827,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1825,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "ml-auto text-right", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-500", children: "Time" }, void 0, false, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1832,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-lg font-black text-white", children: [
                String(Math.floor(state.timeRemaining / 60)).padStart(2, "0"),
                ":",
                String(state.timeRemaining % 60).padStart(2, "0")
              ] }, void 0, true, {
                fileName: "D:/AiFactory/src/controller/index.tsx",
                lineNumber: 1833,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/AiFactory/src/controller/index.tsx",
              lineNumber: 1831,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1816,
          columnNumber: 11
        },
        this
      ),
      myEvent && /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            padding: "8px 12px",
            borderRadius: 8,
            background: "rgba(251,146,60,0.1)",
            border: "1px solid rgba(251,146,60,0.5)",
            fontSize: 11,
            fontWeight: 700,
            color: "#fb923c",
            textAlign: "center",
            letterSpacing: "0.06em",
            textTransform: "uppercase",
            animation: "warningPulse 0.9s ease-in-out infinite"
          },
          children: myEvent.message
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1842,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex items-center", children: myRole === "power" ? /* @__PURE__ */ jsxDEV(
        PowerGame,
        {
          progress: deptState.progress,
          status: deptState.status,
          score: state.power.score,
          onTap: () => actions.tapPower()
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1863,
          columnNumber: 13
        },
        this
      ) : myRole === "data" ? /* @__PURE__ */ jsxDEV(
        DataCleaningGame,
        {
          progress: deptState.progress,
          status: deptState.status,
          score: state.data.score,
          onSort: (token, bucket, correct) => actions.sortData({ token, bucket, correct })
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1870,
          columnNumber: 13
        },
        this
      ) : myRole === "security" ? /* @__PURE__ */ jsxDEV(
        ZipZapGame,
        {
          progress: deptState.progress,
          status: deptState.status,
          score: state.security.score,
          onZipZap: (hit) => actions.zipZap({ hit })
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1879,
          columnNumber: 13
        },
        this
      ) : myRole === "model" ? /* @__PURE__ */ jsxDEV(
        AiCorePuzzleGame,
        {
          progress: deptState.progress,
          status: deptState.status,
          score: state.model.score,
          onSolve: () => actions.solvePuzzle()
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1886,
          columnNumber: 13
        },
        this
      ) : myRole === "cooling" ? /* @__PURE__ */ jsxDEV(
        CoolingGame,
        {
          temperature: state.cooling.temperature,
          progress: deptState.progress,
          status: deptState.status,
          score: state.cooling.score,
          onTick: (centeredness) => actions.coolTick({ centeredness })
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1893,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        RoleDevPanel,
        {
          role: myRole,
          progress: deptState.progress,
          status: deptState.status,
          actions,
          coolingTemp: state.cooling.temperature
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/controller/index.tsx",
          lineNumber: 1901,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1861,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1815,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1814,
      columnNumber: 7
    }, this);
  }
  const success = state.finalResult === "success";
  return /* @__PURE__ */ jsxDEV(SurfaceViewport, { orientation: "portrait", className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full flex-col items-center justify-center gap-6 p-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-6xl", children: success ? "🎉" : "💥" }, void 0, false, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1920,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "text-3xl font-black text-center",
        style: { color: success ? "#4ade80" : "#f87171" },
        children: success ? "AI DEPLOYED!" : "FACTORY FAILED"
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1921,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "factory-panel p-6 w-full max-w-xs text-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: "Your Department" }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1928,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold mt-1", style: { color }, children: [
        ROLE_ICONS[myRole],
        " ",
        ROLE_LABELS[myRole]
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1929,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-3xl font-black mt-2", style: { color }, children: [
        state[myRole].progress,
        "%"
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1932,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1927,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
      "Factory Health:",
      " ",
      /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-white", children: [
        state.factoryHealth,
        "%"
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1938,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1936,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-slate-400", children: [
      "Team Score:",
      " ",
      /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-sky-400", children: state.teamScore.toLocaleString() }, void 0, false, {
        fileName: "D:/AiFactory/src/controller/index.tsx",
        lineNumber: 1942,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/controller/index.tsx",
      lineNumber: 1940,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 1919,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/AiFactory/src/controller/index.tsx",
    lineNumber: 1918,
    columnNumber: 5
  }, this);
}
_s7(ControllerView, "fQYk7sfUvmuPlFIHTpiTNpHlE5c=", false, function() {
  return [useAirJamController, useFactoryStore, useFactoryStore.useActions];
});
_c8 = ControllerView;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
$RefreshReg$(_c, "PowerGame");
$RefreshReg$(_c2, "CoolingDevPanel");
$RefreshReg$(_c3, "DataCleaningGame");
$RefreshReg$(_c4, "ZipZapGame");
$RefreshReg$(_c5, "AiCorePuzzleGame");
$RefreshReg$(_c6, "CoolingGame");
$RefreshReg$(_c7, "RoleDevPanel");
$RefreshReg$(_c8, "ControllerView");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/AiFactory/src/controller/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/AiFactory/src/controller/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkZVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxGVixTQUFTQSwyQkFBMkI7QUFDcEMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGFBQWFDLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUN6RCxTQUFTQyxtQkFBbUI7QUFDNUI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBQ1AsU0FBU0MsdUJBQTBDO0FBV25ELFNBQVNDLFVBQVUsRUFBRUMsVUFBVUMsUUFBUUMsT0FBT0MsTUFBc0IsR0FBRztBQUFBQyxLQUFBO0FBQ3JFLFFBQU1DLGFBQWFKLFdBQVc7QUFDOUIsUUFBTUssUUFBUTtBQUdkLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJaEIsU0FBaUQsRUFBRTtBQUNqRixRQUFNaUIsV0FBV2xCLE9BQU8sQ0FBQztBQUN6QixRQUFNbUIsU0FBU25CLE9BQTBCLElBQUk7QUFJN0MsUUFBTW9CLGFBQWFwQixPQUFPLENBQUM7QUFFM0IsUUFBTXFCLG9CQUFvQnZCO0FBQUFBLElBQ3hCLENBQUN3QixNQUE2QztBQUM1QyxVQUFJUixXQUFZO0FBRWhCLFlBQU1TLE1BQU1DLEtBQUtELElBQUk7QUFDckIsVUFBSUEsTUFBTUgsV0FBV0ssVUFBVSxHQUFJO0FBQ25DTCxpQkFBV0ssVUFBVUY7QUFHckJYLFlBQU07QUFHTixVQUFJTyxPQUFPTSxTQUFTO0FBQ2xCLGNBQU1DLE9BQU9QLE9BQU9NLFFBQVFFLHNCQUFzQjtBQUNsRCxjQUFNQyxJQUFJTixFQUFFTyxVQUFVSCxLQUFLSTtBQUMzQixjQUFNQyxJQUFJVCxFQUFFVSxVQUFVTixLQUFLTztBQUMzQixjQUFNQyxLQUFLLEVBQUVoQixTQUFTTztBQUN0QlIsbUJBQVcsQ0FBQ2tCLFNBQVMsQ0FBQyxHQUFHQSxNQUFNLEVBQUVELElBQUlOLEdBQUdHLEVBQUUsQ0FBQyxDQUFDO0FBRTVDSyxtQkFBVyxNQUFNbkIsV0FBVyxDQUFDa0IsU0FBU0EsS0FBS0UsT0FBTyxDQUFDQyxNQUFNQSxFQUFFSixPQUFPQSxFQUFFLENBQUMsR0FBRyxHQUFHO0FBQUEsTUFDN0U7QUFBQSxJQUNGO0FBQUEsSUFDQSxDQUFDcEIsWUFBWUYsS0FBSztBQUFBLEVBQ3BCO0FBR0EsUUFBTTJCLFNBQVM7QUFDZixRQUFNQyxPQUFPLElBQUlDLEtBQUtDLEtBQUtIO0FBQzNCLFFBQU1JLGFBQWFILE9BQVEvQixXQUFXLE1BQU8rQjtBQUU3QyxNQUFJMUIsWUFBWTtBQUNkLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRThCLFlBQVksb0VBQW9FO0FBQUEsUUFHekY7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BDLFFBQVE7QUFBQSxnQkFDUkMsUUFBUTtBQUFBLGdCQUNSQyxXQUFXO0FBQUEsZ0JBQ1hDLFdBQVc7QUFBQSxjQUNiO0FBQUEsY0FFQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUMsVUFBVSxHQUFHLEdBQUcsaUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQVZqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRW5DLE9BQU8sV0FBV29DLFlBQVksbUJBQW1CO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFBeUI7QUFBQTtBQUFBLFlBQW1CeEMsTUFBTXlDLGVBQWU7QUFBQSxZQUFFO0FBQUEsZUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQTtBQUFBO0FBQUEsTUF2QnhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdCQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpRUFHYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdEQUF1RCx3QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzlFLHVCQUFDLFNBQUksV0FBVSxpQ0FBZ0MsT0FBTyxFQUFFckMsTUFBTSxHQUMzRE47QUFBQUE7QUFBQUEsVUFBUztBQUFBLGFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdEQUF1RCxxQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFLHVCQUFDLFNBQUksV0FBVSw0Q0FDWkUsZ0JBQU15QyxlQUFlLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3REFBdUQsdUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM3RSx1QkFBQyxTQUFJLFdBQVUsOENBQTRDO0FBQUE7QUFBQSxVQUN2RGxELFlBQVltRDtBQUFBQSxVQUFxQjtBQUFBLGFBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG9EQUViO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxVQUNQLFFBQVE7QUFBQSxVQUNSLFNBQVE7QUFBQSxVQUNSLFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRUMsV0FBVyxpQkFBaUI7QUFBQSxVQUdyQztBQUFBLG1DQUFDLFlBQU8sSUFBSSxLQUFLLElBQUksS0FBSyxHQUFHZixRQUFRLE1BQUssUUFBTyxRQUFPLFdBQVUsYUFBYSxNQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBRWxGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSTtBQUFBLGdCQUNKLElBQUk7QUFBQSxnQkFDSixHQUFHQTtBQUFBQSxnQkFDSCxNQUFLO0FBQUEsZ0JBQ0wsUUFBUXhCO0FBQUFBLGdCQUNSLGFBQWE7QUFBQSxnQkFDYixlQUFjO0FBQUEsZ0JBQ2QsaUJBQWlCeUI7QUFBQUEsZ0JBQ2pCLGtCQUFrQkc7QUFBQUEsZ0JBQ2xCLE9BQU8sRUFBRVksWUFBWSxtQ0FBbUNsQixRQUFRLHVCQUF1QnRCLEtBQUssSUFBSTtBQUFBO0FBQUEsY0FWbEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVW9HO0FBQUE7QUFBQTtBQUFBLFFBcEJ0RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzQkE7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxLQUFLSTtBQUFBQSxVQUNMLE1BQUs7QUFBQSxVQUNMLElBQUc7QUFBQSxVQUNILGVBQWVFO0FBQUFBLFVBQ2YsV0FBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFlBQ0x3QixPQUFPO0FBQUEsWUFDUEMsUUFBUTtBQUFBLFlBQ1JGLFlBQVk7QUFBQSxZQUNaRyxRQUFRLGFBQWFoQyxLQUFLO0FBQUEsWUFDMUJpQyxXQUFXLFlBQVlqQyxLQUFLLHNCQUFzQkEsS0FBSztBQUFBLFlBQ3ZEeUMseUJBQXlCO0FBQUEsWUFDekJDLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFHQ3pDO0FBQUFBLG9CQUFRMEM7QUFBQUEsY0FBSSxDQUFDcEIsTUFDWjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTztBQUFBLG9CQUNMUixNQUFNUSxFQUFFVjtBQUFBQSxvQkFDUkssS0FBS0ssRUFBRVA7QUFBQUEsa0JBQ1Q7QUFBQTtBQUFBLGdCQUxLTyxFQUFFSjtBQUFBQSxnQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUk7QUFBQSxZQUVMO0FBQUEsWUFFRCx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxxQ0FBQyxVQUFLLE9BQU8sRUFBRWdCLFVBQVUsR0FBRyxHQUFHLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGNBQ2hDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPLEVBQUVuQyxNQUFNO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQTtBQUFBO0FBQUEsUUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUNBO0FBQUEsU0FoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0ZBQ2I7QUFBQSwrQkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUNoQix1QkFBQyxVQUFNTjtBQUFBQTtBQUFBQSxVQUFTO0FBQUEsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsWUFDTG9DLE9BQU8sR0FBR3BDLFFBQVE7QUFBQSxZQUNsQm1DLFlBQVksbUNBQW1DN0IsS0FBSztBQUFBLFlBQ3BEaUMsV0FBVyxXQUFXakMsS0FBSztBQUFBLFlBQzNCd0MsWUFBWTtBQUFBLFVBQ2Q7QUFBQTtBQUFBLFFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0ksS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQTdHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEdBO0FBRUo7QUFFQTFDLEdBNUxTTCxXQUFTO0FBQUEsS0FBVEE7QUE4TFQsU0FBU21ELGdCQUFnQjtBQUFBLEVBQ3ZCQztBQUFBQSxFQUNBQztBQUlGLEdBQUc7QUFBQUMsTUFBQTtBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJL0QsU0FBUzJELFdBQVc7QUFFdEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsOENBQ1pHO0FBQUFBLGdCQUFVRSxRQUFRLENBQUM7QUFBQSxNQUFFO0FBQUEsU0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQXdCO0FBQUE7QUFBQSxNQUN6Qi9ELFlBQVlnRTtBQUFBQSxNQUFlO0FBQUEsTUFBRWhFLFlBQVlpRTtBQUFBQSxNQUFlO0FBQUEsU0FEdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsT0FBT0o7QUFBQUEsUUFDUCxVQUFVLENBQUN6QyxNQUFNO0FBQ2YsZ0JBQU04QyxJQUFJQyxPQUFPL0MsRUFBRWdELE9BQU9DLEtBQUs7QUFDL0JQLHVCQUFhSSxDQUFDO0FBQ2RQLGdCQUFNTyxDQUFDO0FBQUEsUUFDVDtBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBQ1YsT0FBTyxFQUFFWCxhQUFhLE9BQU87QUFBQTtBQUFBLE1BWC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVdpQztBQUFBLElBR2pDLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixTQUFTLE1BQU07QUFDYixrQkFBTVcsSUFBSTNCLEtBQUsrQixJQUFJLElBQUlULFlBQVksQ0FBQztBQUNwQ0MseUJBQWFJLENBQUM7QUFDZFAsa0JBQU1PLENBQUM7QUFBQSxVQUNUO0FBQUEsVUFBRTtBQUFBO0FBQUEsUUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLFNBQVMsTUFBTTtBQUNiLGtCQUFNQSxJQUFJM0IsS0FBS2dDLElBQUksS0FBS1YsWUFBWSxDQUFDO0FBQ3JDQyx5QkFBYUksQ0FBQztBQUNkUCxrQkFBTU8sQ0FBQztBQUFBLFVBQ1Q7QUFBQSxVQUFFO0FBQUE7QUFBQSxRQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLE9BN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4Q0E7QUFFSjtBQUVBTixJQTVEU0gsaUJBQWU7QUFBQSxNQUFmQTtBQWlFVCxTQUFTZSxjQUFjQyxPQUEyQjtBQUNoRCxTQUFRekUsWUFBWTBFLGtCQUF3Q0MsU0FBU0YsS0FBSyxJQUN0RSxZQUNBO0FBQ047QUFnQkEsU0FBU0csaUJBQWlCLEVBQUVyRSxVQUFVQyxRQUFRQyxPQUFPb0UsT0FBc0IsR0FBRztBQUFBQyxNQUFBO0FBQzVFLFFBQU1sRSxhQUFhSixXQUFXO0FBQzlCLFFBQU1LLFFBQVE7QUFHZCxRQUFNa0UsWUFBWTtBQUFBLElBQ2hCLEdBQUkvRSxZQUFZMEU7QUFBQUEsSUFDaEIsR0FBSTFFLFlBQVlnRjtBQUFBQSxFQUF1QztBQUd6RCxRQUFNQyxhQUFhbkYsT0FBTyxDQUFDO0FBQzNCLFFBQU1vRixjQUFjcEYsT0FBTyxDQUFDO0FBRzVCLFFBQU1xRixZQUFZdkYsWUFBWSxNQUFpQjtBQUM3QyxVQUFNeUUsUUFBUVUsVUFBVXhDLEtBQUs2QyxNQUFNN0MsS0FBSzhDLE9BQU8sSUFBSU4sVUFBVU8sTUFBTSxDQUFDO0FBQ3BFLFdBQU8sRUFBRXRELElBQUksRUFBRWlELFdBQVcxRCxTQUFTOEMsTUFBTTtBQUFBLEVBQzNDLEdBQUcsRUFBRTtBQUdMLFFBQU0sQ0FBQ2tCLGFBQWFDLGNBQWMsSUFBSXpGLFNBQW9CLE1BQU1vRixVQUFVLENBQUM7QUFDM0UsUUFBTSxDQUFDTSxlQUFlQyxnQkFBZ0IsSUFBSTNGLFNBQTJCLElBQUk7QUFHekUsUUFBTSxDQUFDNEYsYUFBYUMsY0FBYyxJQUFJN0YsU0FBNEIsSUFBSTtBQUN0RSxRQUFNLENBQUM4RixVQUFVQyxXQUFXLElBQUkvRixTQUE0QixJQUFJO0FBR2hFLFFBQU0sQ0FBQ2dHLFVBQVVDLFdBQVcsSUFBSWpHLFNBQVMsQ0FBQztBQUUxQyxRQUFNa0csYUFBYXJHO0FBQUFBLElBQ2pCLENBQUNzRyxXQUF1QjtBQUN0QixZQUFNN0UsTUFBTUMsS0FBS0QsSUFBSTtBQUNyQixVQUFJQSxNQUFNNkQsWUFBWTNELFVBQVV2QixZQUFZbUcsbUJBQW9CO0FBQ2hFakIsa0JBQVkzRCxVQUFVRjtBQUV0QixZQUFNb0QsUUFBUWM7QUFDZCxZQUFNYSxZQUFZNUIsY0FBY0MsTUFBTUosS0FBSyxNQUFNNkI7QUFFakQsVUFBSUUsV0FBVztBQUViVix5QkFBaUIsRUFBRSxHQUFHakIsT0FBTzRCLFVBQVUsVUFBVSxDQUFDO0FBQ2xEbkUsbUJBQVcsTUFBTTtBQUNmd0QsMkJBQWlCLElBQUk7QUFDckJGLHlCQUFlTCxVQUFVLENBQUM7QUFDMUJhLHNCQUFZLENBQUNNLE1BQU1BLElBQUksQ0FBQztBQUFBLFFBQzFCLEdBQUcsR0FBRztBQUFBLE1BQ1IsT0FBTztBQUVMVix1QkFBZU0sTUFBTTtBQUNyQmhFLG1CQUFXLE1BQU0wRCxlQUFlLElBQUksR0FBRyxHQUFHO0FBQUEsTUFDNUM7QUFFQWYsYUFBT0osTUFBTUosT0FBTzZCLFFBQVFFLFNBQVM7QUFBQSxJQUN2QztBQUFBLElBQ0EsQ0FBQ2IsYUFBYUosV0FBV04sTUFBTTtBQUFBLEVBQ2pDO0FBR0EsUUFBTTBCLGtCQUFrQjNHO0FBQUFBLElBQ3RCLENBQUNzRyxXQUF1QjtBQUN0QixVQUFJdEYsV0FBWTtBQUNoQnFGLGlCQUFXQyxNQUFNO0FBQUEsSUFDbkI7QUFBQSxJQUNBLENBQUN0RixZQUFZcUYsVUFBVTtBQUFBLEVBQ3pCO0FBR0EsUUFBTTVELFNBQVM7QUFDZixRQUFNQyxPQUFPLElBQUlDLEtBQUtDLEtBQUtIO0FBQzNCLFFBQU1JLGFBQWFILE9BQVEvQixXQUFXLE1BQU8rQjtBQUU3QyxNQUFJMUIsWUFBWTtBQUNkLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRThCLFlBQVksb0VBQW9FO0FBQUEsUUFHekY7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BDLFFBQVE7QUFBQSxnQkFDUkMsUUFBUTtBQUFBLGdCQUNSQyxXQUFXO0FBQUEsZ0JBQ1hDLFdBQVc7QUFBQSxjQUNiO0FBQUEsY0FFQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUMsVUFBVSxHQUFHLEdBQUcsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUE7QUFBQSxZQVZsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRW5DLE9BQU9vQyxZQUFZLG1CQUFtQjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxZQUFtQnhDLE1BQU15QyxlQUFlO0FBQUEsWUFBRTtBQUFBLGVBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUE7QUFBQTtBQUFBLE1BdkJ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF3QkE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUVBR2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3REFBdUQsd0JBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxRQUM5RSx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDLE9BQU8sRUFBRXJDLE1BQU0sR0FDM0ROO0FBQUFBO0FBQUFBLFVBQVM7QUFBQSxhQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3REFBdUQscUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQyxTQUFJLFdBQVUsNENBQ1pFLGdCQUFNeUMsZUFBZSxLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQXVELHdCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUUsdUJBQUMsU0FBSSxXQUFVLDhDQUE0QztBQUFBO0FBQUEsVUFDdkRsRCxZQUFZd0c7QUFBQUEsYUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNkNBQTRDLE9BQU8sRUFBRTdELE9BQU8sS0FBS0MsUUFBUSxLQUFLNkQsWUFBWSxFQUFFLEdBQ3pHO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEtBQUssUUFBUSxLQUFLLFNBQVEsZUFBYyxXQUFVLFlBQVcsT0FBTyxFQUFFckQsV0FBVyxpQkFBaUIsR0FDNUc7QUFBQSwrQkFBQyxZQUFPLElBQUksSUFBSSxJQUFJLElBQUksR0FBR2YsUUFBUSxNQUFLLFFBQU8sUUFBTyxXQUFVLGFBQWEsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFFBQy9FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFJO0FBQUEsWUFBSSxJQUFJO0FBQUEsWUFBSSxHQUFHQTtBQUFBQSxZQUFRLE1BQUs7QUFBQSxZQUNoQyxRQUFReEI7QUFBQUEsWUFBTyxhQUFhO0FBQUEsWUFBRyxlQUFjO0FBQUEsWUFDN0MsaUJBQWlCeUI7QUFBQUEsWUFDakIsa0JBQWtCRztBQUFBQSxZQUNsQixPQUFPLEVBQUVZLFlBQVksb0NBQW9DbEIsUUFBUSx1QkFBdUJ0QixLQUFLLElBQUk7QUFBQTtBQUFBLFVBTG5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtxRztBQUFBLFdBUHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFdBQVU7QUFBQSxVQUNWLE9BQU87QUFBQSxZQUNMOEIsT0FBTztBQUFBLFlBQ1BDLFFBQVE7QUFBQSxZQUNSRixZQUFZO0FBQUEsWUFDWkcsUUFBUSxhQUFhaEMsS0FBSztBQUFBLFlBQzFCaUMsV0FBVyxZQUFZakMsS0FBSztBQUFBLFVBQzlCO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFNBQUksV0FBVSx5REFBd0QseUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFQSxNQUFNO0FBQUEsZ0JBRWQwRSxzQkFBWWxCO0FBQUFBO0FBQUFBLGNBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSw0REFBMEQsNEJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQTtBQUFBO0FBQUEsUUFuQkssU0FBUzBCLFFBQVE7QUFBQSxRQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUJBO0FBQUEsTUFHQ04saUJBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRWlCLFFBQVEsR0FBRztBQUFBLFVBRXBCLGlDQUFDLFNBQUksV0FBVSxzQ0FBcUMsaUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUE7QUFBQSxRQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0Q0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSwwQkFFYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxNQUFLO0FBQUEsVUFDTCxlQUFlLE1BQU1ILGdCQUFnQixTQUFTO0FBQUEsVUFDOUMsWUFBWSxDQUFDbkYsTUFBTTtBQUFFQSxjQUFFdUYsZUFBZTtBQUFHYix3QkFBWSxTQUFTO0FBQUEsVUFBRztBQUFBLFVBQ2pFLGFBQWEsTUFBTUEsWUFBWSxJQUFJO0FBQUEsVUFDbkMsUUFBUSxDQUFDMUUsTUFBTTtBQUFFQSxjQUFFdUYsZUFBZTtBQUFHYix3QkFBWSxJQUFJO0FBQUdHLHVCQUFXLFNBQVM7QUFBQSxVQUFHO0FBQUEsVUFDL0UsV0FBVztBQUFBLFlBQ1Q7QUFBQSxZQUNBTixnQkFBZ0IsWUFBWSxzQkFBc0I7QUFBQSxZQUNsREUsYUFBYSxZQUFZLHFCQUFxQjtBQUFBLFVBQUUsRUFDaERlLEtBQUssR0FBRztBQUFBLFVBQ1YsT0FBTztBQUFBLFlBQ0xsRSxZQUFZO0FBQUEsWUFDWm1FLGFBQWFoQixhQUFhLFlBQVksWUFBWTtBQUFBLFVBQ3BEO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFNBQUksV0FBVSxZQUFXLGtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBLFlBQzVCLHVCQUFDLFNBQUksV0FBVSwrQ0FBOEMsT0FBTyxFQUFFaEYsTUFBTSxHQUFHLHVCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLFlBQ3RGLHVCQUFDLFNBQUksV0FBVSw4QkFBNkIsMkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUE7QUFBQTtBQUFBLFFBbkJ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFvQkE7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxNQUFLO0FBQUEsVUFDTCxlQUFlLE1BQU0wRixnQkFBZ0IsVUFBVTtBQUFBLFVBQy9DLFlBQVksQ0FBQ25GLE1BQU07QUFBRUEsY0FBRXVGLGVBQWU7QUFBR2Isd0JBQVksVUFBVTtBQUFBLFVBQUc7QUFBQSxVQUNsRSxhQUFhLE1BQU1BLFlBQVksSUFBSTtBQUFBLFVBQ25DLFFBQVEsQ0FBQzFFLE1BQU07QUFBRUEsY0FBRXVGLGVBQWU7QUFBR2Isd0JBQVksSUFBSTtBQUFHRyx1QkFBVyxVQUFVO0FBQUEsVUFBRztBQUFBLFVBQ2hGLFdBQVc7QUFBQSxZQUNUO0FBQUEsWUFDQU4sZ0JBQWdCLGFBQWEsc0JBQXNCO0FBQUEsWUFDbkRFLGFBQWEsYUFBYSxxQkFBcUI7QUFBQSxVQUFFLEVBQ2pEZSxLQUFLLEdBQUc7QUFBQSxVQUNWLE9BQU87QUFBQSxZQUNMbEUsWUFBWTtBQUFBLFlBQ1ptRSxhQUFhaEIsYUFBYSxhQUFhLFlBQVk7QUFBQSxVQUNyRDtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsWUFBVyxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEI7QUFBQSxZQUM1Qix1QkFBQyxTQUFJLFdBQVUsK0NBQThDLE9BQU8sRUFBRWhGLE1BQU0sR0FBRyx3QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUN2Rix1QkFBQyxTQUFJLFdBQVUsOEJBQTZCLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RDtBQUFBO0FBQUE7QUFBQSxRQW5CMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bb0JBO0FBQUEsU0E3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThDQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0ZBQ2I7QUFBQSwrQkFBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUNuQix1QkFBQyxVQUFNTjtBQUFBQTtBQUFBQSxVQUFTO0FBQUEsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsWUFDTG9DLE9BQU8sR0FBR3BDLFFBQVE7QUFBQSxZQUNsQm1DLFlBQVksbUNBQW1DN0IsS0FBSztBQUFBLFlBQ3BEaUMsV0FBVyxXQUFXakMsS0FBSztBQUFBLFlBQzNCd0MsWUFBWTtBQUFBLFVBQ2Q7QUFBQTtBQUFBLFFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0ksS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQXpJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMElBO0FBRUo7QUFFQXlCLElBclBTRixrQkFBZ0I7QUFBQSxNQUFoQkE7QUF5UFQsU0FBU2tDLGlCQUFpQnhCLFFBQThCO0FBQ3RELFFBQU15QixNQUFvQjtBQUUxQixNQUFJQyxPQUEwQjtBQUM5QixXQUFTQyxJQUFJLEdBQUdBLElBQUkzQixRQUFRMkIsS0FBSztBQUUvQixVQUFNQyxVQUF3QkYsU0FBUyxRQUFRLENBQUMsT0FBTyxPQUFPLEtBQUssSUFBSSxDQUFDLE9BQU8sT0FBTyxLQUFLO0FBQzNGLFVBQU1HLE9BQU9ELFFBQVEzRSxLQUFLNkMsTUFBTTdDLEtBQUs4QyxPQUFPLElBQUk2QixRQUFRNUIsTUFBTSxDQUFDO0FBQy9EeUIsUUFBSUssS0FBS0QsSUFBSTtBQUNiSCxXQUFPRztBQUFBQSxFQUNUO0FBQ0EsU0FBT0o7QUFDVDtBQVNBLFNBQVNNLFdBQVcsRUFBRTlHLFVBQVVDLFFBQVFDLE9BQU82RyxTQUEwQixHQUFHO0FBQUFDLE1BQUE7QUFDMUUsUUFBTTNHLGFBQWFKLFdBQVc7QUFDOUIsUUFBTUssUUFBUTtBQUdkLFFBQU0sQ0FBQzJHLFVBQVVDLFdBQVcsSUFBSTFIO0FBQUFBLElBQXVCLE1BQ3JEK0csaUJBQWlCOUcsWUFBWTBILDBCQUEwQjtBQUFBLEVBQ3pEO0FBQ0EsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUk3SCxTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDOEgsV0FBV0MsWUFBWSxJQUFJL0gsU0FBUyxDQUFDO0FBRzVDLFFBQU0sQ0FBQ2dJLFNBQVNDLFVBQVUsSUFBSWpJLFNBQXFDLElBQUk7QUFDdkUsUUFBTSxDQUFDa0ksU0FBU0MsVUFBVSxJQUFJbkksU0FBcUMsSUFBSTtBQUV2RSxRQUFNb0ksZUFBZXJJLE9BQU8sQ0FBQztBQUM3QixRQUFNc0ksZUFBZXRJLE9BQTZDLElBQUk7QUFDdEUsUUFBTXVJLGVBQWV2SSxPQUE2QyxJQUFJO0FBRXRFLFFBQU13SSxlQUFlMUksWUFBWSxNQUFNb0ksV0FBVyxJQUFJLEdBQUcsRUFBRTtBQUMzRCxRQUFNTyxlQUFlM0ksWUFBWSxNQUFNc0ksV0FBVyxJQUFJLEdBQUcsRUFBRTtBQUUzRCxRQUFNTSxjQUFjNUk7QUFBQUEsSUFDbEIsQ0FBQzZJLFlBQXdCO0FBQ3ZCLFVBQUk3SCxXQUFZO0FBRWhCLFlBQU1TLE1BQU1DLEtBQUtELElBQUk7QUFDckIsVUFBSUEsTUFBTThHLGFBQWE1RyxVQUFVdkIsWUFBWTBJLHNCQUF1QjtBQUNwRVAsbUJBQWE1RyxVQUFVRjtBQUV2QixZQUFNc0gsV0FBV25CLFNBQVNHLFdBQVc7QUFDckMsWUFBTWlCLFFBQVFILFlBQVlFO0FBRTFCckIsZUFBU3NCLEtBQUs7QUFFZCxVQUFJQSxPQUFPO0FBQ1QsY0FBTUMsV0FBV2hCLFlBQVk7QUFDN0JDLHFCQUFhZSxRQUFRO0FBR3JCLFlBQUlKLFlBQVksT0FBTztBQUNyQlQscUJBQVcsSUFBSTtBQUNmYyxnQ0FBc0IsTUFBTWQsV0FBVyxTQUFTLENBQUM7QUFDakQsY0FBSUksYUFBYTdHLFFBQVN3SCxjQUFhWCxhQUFhN0csT0FBTztBQUMzRDZHLHVCQUFhN0csVUFBVVcsV0FBV29HLGNBQWMsR0FBRztBQUFBLFFBQ3JELE9BQU87QUFDTEoscUJBQVcsSUFBSTtBQUNmWSxnQ0FBc0IsTUFBTVosV0FBVyxTQUFTLENBQUM7QUFDakQsY0FBSUcsYUFBYTlHLFFBQVN3SCxjQUFhVixhQUFhOUcsT0FBTztBQUMzRDhHLHVCQUFhOUcsVUFBVVcsV0FBV3FHLGNBQWMsR0FBRztBQUFBLFFBQ3JEO0FBRUEsY0FBTVMsV0FBV3JCLGNBQWM7QUFDL0IsWUFBSXFCLFlBQVl4QixTQUFTbEMsUUFBUTtBQUUvQixnQkFBTTJELFNBQVNqSixZQUFZa0o7QUFDM0IsZ0JBQU1DLFNBQVNuSixZQUFZMEgsNkJBQTZCbkYsS0FBSzZDLE1BQU15RCxXQUFXSSxNQUFNO0FBQ3BGeEIsc0JBQVlYLGlCQUFpQnZFLEtBQUtnQyxJQUFJNEUsUUFBUSxFQUFFLENBQUMsQ0FBQztBQUNsRHZCLHlCQUFlLENBQUM7QUFBQSxRQUNsQixPQUFPO0FBQ0xBLHlCQUFlb0IsUUFBUTtBQUFBLFFBQ3pCO0FBQUEsTUFDRixPQUFPO0FBRUwsWUFBSVAsWUFBWSxPQUFPO0FBQ3JCVCxxQkFBVyxJQUFJO0FBQ2ZjLGdDQUFzQixNQUFNZCxXQUFXLE9BQU8sQ0FBQztBQUMvQyxjQUFJSSxhQUFhN0csUUFBU3dILGNBQWFYLGFBQWE3RyxPQUFPO0FBQzNENkcsdUJBQWE3RyxVQUFVVyxXQUFXb0csY0FBYyxHQUFHO0FBQUEsUUFDckQsT0FBTztBQUNMSixxQkFBVyxJQUFJO0FBQ2ZZLGdDQUFzQixNQUFNWixXQUFXLE9BQU8sQ0FBQztBQUMvQyxjQUFJRyxhQUFhOUcsUUFBU3dILGNBQWFWLGFBQWE5RyxPQUFPO0FBQzNEOEcsdUJBQWE5RyxVQUFVVyxXQUFXcUcsY0FBYyxHQUFHO0FBQUEsUUFDckQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsQ0FBQzNILFlBQVk0RyxVQUFVRyxhQUFhRSxXQUFXUCxVQUFVZ0IsY0FBY0MsWUFBWTtBQUFBLEVBQ3JGO0FBR0EsUUFBTWxHLFNBQVM7QUFDZixRQUFNQyxPQUFPLElBQUlDLEtBQUtDLEtBQUtIO0FBQzNCLFFBQU1JLGFBQWFILE9BQVEvQixXQUFXLE1BQU8rQjtBQUc3QyxNQUFJMUIsWUFBWTtBQUNkLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRThCLFlBQVksb0VBQW9FO0FBQUEsUUFFekY7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BDLFFBQVE7QUFBQSxnQkFDUkMsUUFBUTtBQUFBLGdCQUNSQyxXQUFXO0FBQUEsZ0JBQ1hDLFdBQVc7QUFBQSxjQUNiO0FBQUEsY0FFQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUMsVUFBVSxHQUFHLEdBQUcsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUE7QUFBQSxZQVZsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRW5DLE9BQU9vQyxZQUFZLG1CQUFtQjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxZQUFtQnhDLE1BQU15QyxlQUFlO0FBQUEsWUFBRTtBQUFBLGVBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUE7QUFBQTtBQUFBLE1BdEJ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1QkE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUVBR2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3REFBdUQsd0JBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEU7QUFBQSxRQUM5RSx1QkFBQyxTQUFJLFdBQVUsaUNBQWdDLE9BQU8sRUFBRXJDLE1BQU0sR0FDM0ROO0FBQUFBO0FBQUFBLFVBQVM7QUFBQSxhQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3REFBdUQscUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxRQUMzRSx1QkFBQyxTQUFJLFdBQVUsNENBQ1pFLGdCQUFNeUMsZUFBZSxLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQXVELG9CQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUUsdUJBQUMsU0FBSSxXQUFVLDhDQUNaMkUsdUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNkNBQTRDLE9BQU8sRUFBRWxGLE9BQU8sS0FBS0MsUUFBUSxLQUFLNkQsWUFBWSxFQUFFLEdBQ3pHO0FBQUEsNkJBQUMsU0FBSSxPQUFPLEtBQUssUUFBUSxLQUFLLFNBQVEsZUFBYyxXQUFVLFlBQVcsT0FBTyxFQUFFckQsV0FBVyxpQkFBaUIsR0FDNUc7QUFBQSwrQkFBQyxZQUFPLElBQUksSUFBSSxJQUFJLElBQUksR0FBR2YsUUFBUSxNQUFLLFFBQU8sUUFBTyxXQUFVLGFBQWEsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRTtBQUFBLFFBQy9FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFJO0FBQUEsWUFBSSxJQUFJO0FBQUEsWUFBSSxHQUFHQTtBQUFBQSxZQUFRLE1BQUs7QUFBQSxZQUNoQyxRQUFReEI7QUFBQUEsWUFBTyxhQUFhO0FBQUEsWUFBRyxlQUFjO0FBQUEsWUFDN0MsaUJBQWlCeUI7QUFBQUEsWUFDakIsa0JBQWtCRztBQUFBQSxZQUNsQixPQUFPLEVBQUVZLFlBQVksbUNBQW1DbEIsUUFBUSx1QkFBdUJ0QixLQUFLLElBQUk7QUFBQTtBQUFBLFVBTGxHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtvRztBQUFBLFdBUHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVtQyxVQUFVLEdBQUcsR0FBRyxrQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFVBQUssV0FBVSw4Q0FBNkMsT0FBTyxFQUFFbkMsTUFBTSxHQUFHLHdCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsV0FGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx5RUFBdUUsZ0RBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUFzQyxPQUFPLEVBQUU2QixZQUFZLHlCQUF5QkcsUUFBUSxpQ0FBaUMsR0FFMUk7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTyxFQUFFSCxZQUFZLDBFQUEwRTtBQUFBO0FBQUEsVUFGakc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRW1HO0FBQUEsUUFFbkcsdUJBQUMsU0FBSSxXQUFVLDhEQUNaOEUsbUJBQVNoRSxJQUFJLENBQUM0RixNQUFNbkMsTUFBTTtBQUN6QixnQkFBTW9DLFdBQVdwQyxNQUFNVTtBQUN2QixnQkFBTTJCLFNBQVNyQyxJQUFJVTtBQUNuQixpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVzBCLFdBQVcsdUJBQXVCO0FBQUEsY0FDN0MsT0FBTztBQUFBLGdCQUNMRSxTQUFTO0FBQUEsZ0JBQ1RDLFlBQVk7QUFBQSxnQkFDWkMsZ0JBQWdCO0FBQUEsZ0JBQ2hCOUcsT0FBTztBQUFBLGdCQUNQQyxRQUFRO0FBQUEsZ0JBQ1I4RyxjQUFjO0FBQUEsZ0JBQ2QxRyxVQUFVO0FBQUEsZ0JBQ1YyRyxZQUFZO0FBQUEsZ0JBQ1pDLFlBQVk7QUFBQSxnQkFDWkMsZUFBZTtBQUFBLGdCQUNmbkgsWUFBWTRHLFNBQ1IsMEJBQ0FELFdBQ0UsMEJBQ0E7QUFBQSxnQkFDTnhHLFFBQVF5RyxTQUNKLG9DQUNBRCxXQUNFLHdCQUNBO0FBQUEsZ0JBQ054SSxPQUFPeUksU0FBUyxjQUFjRCxXQUFXLFlBQVk7QUFBQSxnQkFDckRoRyxZQUFZO0FBQUEsY0FDZDtBQUFBLGNBRUNpRyxtQkFBUyxNQUFNRjtBQUFBQTtBQUFBQSxZQTNCWG5DO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTZCQTtBQUFBLFFBRUosQ0FBQyxLQXBDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUNBO0FBQUEsV0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRDQTtBQUFBLFNBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxNQUFLO0FBQUEsVUFDTCxlQUFlLE1BQU11QixZQUFZLEtBQUs7QUFBQSxVQUN0QyxXQUFXO0FBQUEsWUFDVDtBQUFBLFlBQ0FULFlBQVksWUFBWSxtQkFBbUI7QUFBQSxZQUMzQ0EsWUFBWSxVQUFVLGlCQUFpQjtBQUFBLFVBQUUsRUFDekNuQixLQUFLLEdBQUc7QUFBQSxVQUNWLE9BQU87QUFBQSxZQUNMbEUsWUFDRXFGLFlBQVksWUFDUiwwQkFDQUEsWUFBWSxVQUNWLDJCQUNBO0FBQUEsWUFDUmxCLGFBQ0VrQixZQUFZLFlBQ1IsWUFDQUEsWUFBWSxVQUNWLFlBQ0E7QUFBQSxZQUNSekUseUJBQXlCO0FBQUEsWUFDekJDLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFFQTtBQUFBLG1DQUFDLFNBQUksV0FBVSx1QkFBc0IsT0FBTyxFQUFFMUMsT0FBTytJLFlBQVksbUJBQW1CLEdBQUcsbUJBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsWUFDMUYsdUJBQUMsU0FBSSxXQUFVLHdEQUF1RCxxQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQTtBQUFBO0FBQUEsUUEzQjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTRCQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILE1BQUs7QUFBQSxVQUNMLGVBQWUsTUFBTXBCLFlBQVksS0FBSztBQUFBLFVBQ3RDLFdBQVc7QUFBQSxZQUNUO0FBQUEsWUFDQVAsWUFBWSxZQUFZLG1CQUFtQjtBQUFBLFlBQzNDQSxZQUFZLFVBQVUsaUJBQWlCO0FBQUEsVUFBRSxFQUN6Q3JCLEtBQUssR0FBRztBQUFBLFVBQ1YsT0FBTztBQUFBLFlBQ0xsRSxZQUNFdUYsWUFBWSxZQUNSLDBCQUNBQSxZQUFZLFVBQ1YsMkJBQ0E7QUFBQSxZQUNScEIsYUFDRW9CLFlBQVksWUFDUixZQUNBQSxZQUFZLFVBQ1YsWUFDQTtBQUFBLFlBQ1IzRSx5QkFBeUI7QUFBQSxZQUN6QkMsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUVBO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHVCQUFzQixPQUFPLEVBQUUxQyxPQUFPLFdBQVcrSSxZQUFZLG1CQUFtQixHQUFHLG1CQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRztBQUFBLFlBQ3JHLHVCQUFDLFNBQUksV0FBVSx3REFBdUQsbUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUE7QUFBQTtBQUFBLFFBM0IzRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUE0QkE7QUFBQSxTQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNERBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxrRkFDYjtBQUFBLCtCQUFDLFVBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjO0FBQUEsUUFDZCx1QkFBQyxVQUFNcko7QUFBQUE7QUFBQUEsVUFBUztBQUFBLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTztBQUFBLFlBQ0xvQyxPQUFPLEdBQUdwQyxRQUFRO0FBQUEsWUFDbEJtQyxZQUFZLG1DQUFtQzdCLEtBQUs7QUFBQSxZQUNwRGlDLFdBQVcsV0FBV2pDLEtBQUs7QUFBQSxZQUMzQndDLFlBQVk7QUFBQSxVQUNkO0FBQUE7QUFBQSxRQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9JLEtBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsT0FoTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlMQTtBQUVKO0FBSUFrRSxJQTNTU0YsWUFBVTtBQUFBLE1BQVZBO0FBNFNULE1BQU15QyxhQUEwRTtBQUFBLEVBQzlFO0FBQUEsSUFDRUMsT0FBTyxDQUFDLFFBQVEsU0FBUyxXQUFXLFFBQVE7QUFBQSxJQUM1Q0MsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBLElBQ0VGLE9BQU8sQ0FBQyxXQUFXLFNBQVMsU0FBUyxNQUFNO0FBQUEsSUFDM0NDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsRUFDUjtBQUFBLEVBQ0E7QUFBQSxJQUNFRixPQUFPLENBQUMsVUFBVSxVQUFVLFlBQVksUUFBUTtBQUFBLElBQ2hEQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLEVBQ1I7QUFBQSxFQUNBO0FBQUEsSUFDRUYsT0FBTyxDQUFDLFVBQVUsU0FBUyxVQUFVLFVBQVU7QUFBQSxJQUMvQ0MsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBLElBQ0VGLE9BQU8sQ0FBQyxTQUFTLFdBQVcsVUFBVSxLQUFLO0FBQUEsSUFDM0NDLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsRUFDUjtBQUFDO0FBSUgsU0FBU0MsZUFBZUMsR0FBcUI7QUFDM0MsUUFBTUMsTUFBTUMsTUFBTUMsS0FBSyxFQUFFaEYsUUFBUTZFLEVBQUUsR0FBRyxDQUFDSSxHQUFHdEQsTUFBTUEsQ0FBQztBQUNqRCxXQUFTQSxJQUFJbUQsSUFBSTlFLFNBQVMsR0FBRzJCLElBQUksR0FBR0EsS0FBSztBQUN2QyxVQUFNdUQsSUFBSWpJLEtBQUs2QyxNQUFNN0MsS0FBSzhDLE9BQU8sS0FBSzRCLElBQUksRUFBRTtBQUM1QyxLQUFDbUQsSUFBSW5ELENBQUMsR0FBR21ELElBQUlJLENBQUMsQ0FBQyxJQUFJLENBQUNKLElBQUlJLENBQUMsR0FBR0osSUFBSW5ELENBQUMsQ0FBQztBQUFBLEVBQ3BDO0FBRUEsUUFBTXdELFNBQVNMLElBQUlNLE1BQU0sQ0FBQ0MsR0FBRzFELE1BQU0wRCxNQUFNMUQsQ0FBQztBQUMxQyxNQUFJd0QsVUFBVU4sSUFBSSxHQUFHO0FBQ25CLEtBQUNDLElBQUksQ0FBQyxHQUFHQSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUNBLElBQUksQ0FBQyxHQUFHQSxJQUFJLENBQUMsQ0FBQztBQUFBLEVBQ3BDO0FBQ0EsU0FBT0E7QUFDVDtBQVNBLFNBQVNRLGlCQUFpQixFQUFFckssVUFBVUMsUUFBUUMsT0FBT29LLFFBQStCLEdBQUc7QUFBQUMsTUFBQTtBQUNyRixRQUFNbEssYUFBYUosV0FBVztBQUM5QixRQUFNSyxRQUFRO0FBRWQsUUFBTSxDQUFDa0ssV0FBV0MsWUFBWSxJQUFJakwsU0FBUyxDQUFDO0FBQzVDLFFBQU0sQ0FBQ2tMLE9BQU9DLFFBQVEsSUFBSW5MLFNBQW1CLE1BQU1tSyxlQUFlLENBQUMsQ0FBQztBQUNwRSxRQUFNLENBQUNpQixVQUFVQyxXQUFXLElBQUlyTCxTQUF3QixJQUFJO0FBQzVELFFBQU0sQ0FBQ3NMLGFBQWFDLGNBQWMsSUFBSXZMLFNBQVMsQ0FBQztBQUVoRCxRQUFNLENBQUN3TCxTQUFTQyxVQUFVLElBQUl6TCxTQUFTLEtBQUs7QUFFNUMsUUFBTTBMLFNBQVMzQixXQUFXaUIsWUFBWWpCLFdBQVd4RSxNQUFNO0FBRXZELFFBQU1vRyxZQUFZOUw7QUFBQUEsSUFDaEIsQ0FBQytMLFFBQWdCO0FBQ2YsVUFBSUosV0FBVzNLLFdBQVk7QUFFM0IsVUFBSXVLLGFBQWEsTUFBTTtBQUNyQkMsb0JBQVlPLEdBQUc7QUFDZjtBQUFBLE1BQ0Y7QUFDQSxVQUFJUixhQUFhUSxLQUFLO0FBQ3BCUCxvQkFBWSxJQUFJO0FBQ2hCO0FBQUEsTUFDRjtBQUdBLFlBQU1qRSxPQUFPLENBQUMsR0FBRzhELEtBQUs7QUFDdEIsT0FBQzlELEtBQUtnRSxRQUFRLEdBQUdoRSxLQUFLd0UsR0FBRyxDQUFDLElBQUksQ0FBQ3hFLEtBQUt3RSxHQUFHLEdBQUd4RSxLQUFLZ0UsUUFBUSxDQUFDO0FBQ3hERCxlQUFTL0QsSUFBSTtBQUNiaUUsa0JBQVksSUFBSTtBQUdoQixZQUFNUSxVQUFVekUsS0FBS3VELE1BQU0sQ0FBQ0MsR0FBRzFELE1BQU0wRCxNQUFNMUQsQ0FBQztBQUM1QyxVQUFJMkUsU0FBUztBQUNYSixtQkFBVyxJQUFJO0FBQ2ZYLGdCQUFRO0FBQ1IzSSxtQkFBVyxNQUFNO0FBQ2ZzSixxQkFBVyxLQUFLO0FBQ2hCRix5QkFBZSxDQUFDTyxNQUFNQSxJQUFJLENBQUM7QUFDM0JiLHVCQUFhLENBQUMvRCxNQUFNQSxJQUFJLENBQUM7QUFDekJpRSxtQkFBU2hCLGVBQWUsQ0FBQyxDQUFDO0FBQUEsUUFDNUIsR0FBRyxHQUFHO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQSxJQUNBLENBQUNpQixVQUFVRixPQUFPTSxTQUFTM0ssWUFBWWlLLE9BQU87QUFBQSxFQUNoRDtBQUdBLFFBQU14SSxTQUFTO0FBQ2YsUUFBTUMsT0FBTyxJQUFJQyxLQUFLQyxLQUFLSDtBQUMzQixRQUFNSSxhQUFhSCxPQUFRL0IsV0FBVyxNQUFPK0I7QUFHN0MsTUFBSTFCLFlBQVk7QUFDZCxXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixPQUFPLEVBQUU4QixZQUFZLG9FQUFvRTtBQUFBLFFBR3pGO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU87QUFBQSxnQkFDTEMsT0FBTztBQUFBLGdCQUNQQyxRQUFRO0FBQUEsZ0JBQ1JDLFFBQVE7QUFBQSxnQkFDUkMsV0FBVztBQUFBLGdCQUNYQyxXQUFXO0FBQUEsY0FDYjtBQUFBLGNBRUEsaUNBQUMsU0FBSSxPQUFPLEVBQUVDLFVBQVUsR0FBRyxHQUFHLGtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBO0FBQUEsWUFWbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPLEVBQUVuQyxPQUFPb0MsWUFBWSxtQkFBbUI7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsWUFBbUJ4QyxNQUFNeUMsZUFBZTtBQUFBLFlBQUU7QUFBQSxlQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBO0FBQUE7QUFBQSxNQXZCeEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBd0JBO0FBQUEsRUFFSjtBQUdBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVFQUdiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQXVELHdCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUUsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxPQUFPLEVBQUVyQyxNQUFNLEdBQzNETjtBQUFBQTtBQUFBQSxVQUFTO0FBQUEsYUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQXVELHFCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFDM0UsdUJBQUMsU0FBSSxXQUFVLDRDQUNaRSxnQkFBTXlDLGVBQWUsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdEQUF1RCxzQkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQzVFLHVCQUFDLFNBQUksV0FBVSw4Q0FDWm1JLHlCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDZDQUE0QyxPQUFPLEVBQUUxSSxPQUFPLEtBQUtDLFFBQVEsS0FBSzZELFlBQVksRUFBRSxHQUN6RztBQUFBLDZCQUFDLFNBQUksT0FBTyxLQUFLLFFBQVEsS0FBSyxTQUFRLGVBQWMsV0FBVSxZQUFXLE9BQU8sRUFBRXJELFdBQVcsaUJBQWlCLEdBQzVHO0FBQUEsK0JBQUMsWUFBTyxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUdmLFFBQVEsTUFBSyxRQUFPLFFBQU8sV0FBVSxhQUFhLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUMvRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSTtBQUFBLFlBQUksSUFBSTtBQUFBLFlBQUksR0FBR0E7QUFBQUEsWUFBUSxNQUFLO0FBQUEsWUFDaEMsUUFBUXhCO0FBQUFBLFlBQU8sYUFBYTtBQUFBLFlBQUcsZUFBYztBQUFBLFlBQzdDLGlCQUFpQnlCO0FBQUFBLFlBQ2pCLGtCQUFrQkc7QUFBQUEsWUFDbEIsT0FBTyxFQUFFWSxZQUFZLG1DQUFtQ2xCLFFBQVEsdUJBQXVCdEIsS0FBSyxJQUFJO0FBQUE7QUFBQSxVQUxsRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLb0c7QUFBQSxXQVB0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLCtCQUFDLFVBQUssT0FBTyxFQUFFbUMsVUFBVSxHQUFHLEdBQUcsa0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUNqQyx1QkFBQyxVQUFLLFdBQVUsK0NBQThDLE9BQU8sRUFBRW5DLE1BQU0sR0FBRyx1QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFdBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsMENBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwrQ0FBOEMsT0FBTyxFQUFFQSxNQUFNLEdBQ3pFNEssaUJBQU96QixTQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUFtQyx3RUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw2Q0FDWmlCLGdCQUFNekgsSUFBSSxDQUFDc0ksV0FBV0gsUUFBUTtBQUM3QixjQUFNSSxRQUFRTixPQUFPMUIsTUFBTStCLFNBQVM7QUFDcEMsY0FBTUUsYUFBYWIsYUFBYVE7QUFDaEMsY0FBTXZGLFlBQVkwRixjQUFjSDtBQUNoQyxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxNQUFLO0FBQUEsWUFDTCxJQUFJLGVBQWVBLEdBQUc7QUFBQSxZQUN0QixlQUFlLE1BQU1ELFVBQVVDLEdBQUc7QUFBQSxZQUNsQyxXQUFXO0FBQUEsY0FDVDtBQUFBLGNBQ0FKLFVBQVUsc0JBQXNCO0FBQUEsY0FDaENTLGNBQWMsQ0FBQ1QsVUFBVSx5QkFBeUI7QUFBQSxZQUFFLEVBQ3BEM0UsS0FBSyxHQUFHO0FBQUEsWUFDVixPQUFPO0FBQUEsY0FDTGxFLFlBQVk2SSxVQUNSLDJCQUNBUyxhQUNFLDJCQUNBO0FBQUEsY0FDTm5KLFFBQVFtSixjQUFjLENBQUNULFVBQ25CLHNCQUNBQSxVQUNFLHNCQUNBLDhCQUE4Qm5GLFlBQVksU0FBUyxNQUFNO0FBQUEsY0FDL0Q5Qyx5QkFBeUI7QUFBQSxjQUN6QkMsYUFBYTtBQUFBLFlBQ2Y7QUFBQSxZQUdBO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU8sRUFBRTFDLE9BQU9tTCxhQUFhbkwsUUFBUSxVQUFVO0FBQUEsa0JBRTlDOEssZ0JBQU07QUFBQTtBQUFBLGdCQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQSx1QkFBQyxVQUFLLFdBQVUsbUNBQWtDLGlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBRW5EO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPO0FBQUEsb0JBQ0wvQixZQUFZO0FBQUEsb0JBQ1o1RyxVQUFVO0FBQUEsb0JBQ1ZuQyxPQUFPbUwsYUFBYW5MLFFBQVEwSyxVQUFVLFlBQVk7QUFBQSxvQkFDbERsSSxZQUFZO0FBQUEsa0JBQ2Q7QUFBQSxrQkFFQzBJO0FBQUFBO0FBQUFBLGdCQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsY0FFQ1IsV0FDQyx1QkFBQyxVQUFLLFdBQVUsbUNBQWtDLGlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBO0FBQUE7QUFBQSxVQS9DaEQsR0FBR1IsU0FBUyxJQUFJWSxHQUFHO0FBQUEsVUFEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtEQTtBQUFBLE1BRUosQ0FBQyxLQTFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkRBO0FBQUEsU0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdFQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLFNBQUksV0FBVSw2Q0FBNkNGLGlCQUFPeEIsUUFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RSxLQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtGQUNiO0FBQUEsK0JBQUMsVUFBSyx1QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUNiLHVCQUFDLFVBQU0xSjtBQUFBQTtBQUFBQSxVQUFTO0FBQUEsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsWUFDTG9DLE9BQU8sR0FBR3BDLFFBQVE7QUFBQSxZQUNsQm1DLFlBQVksbUNBQW1DN0IsS0FBSztBQUFBLFlBQ3BEaUMsV0FBVyxXQUFXakMsS0FBSztBQUFBLFlBQzNCd0MsWUFBWTtBQUFBLFVBQ2Q7QUFBQTtBQUFBLFFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0ksS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQTNJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNElBO0FBRUo7QUFJQXlILElBeE9TRixrQkFBZ0I7QUFBQSxNQUFoQkE7QUE0T1QsZUFBZXFCLCtCQUE4RTtBQUUzRixNQUNFLE9BQU9DLDJCQUEyQjtBQUFBLEVBRWxDLE9BQVFBLHVCQUErQkMsc0JBQXNCLFlBQzdEO0FBQ0EsUUFBSTtBQUVGLFlBQU1DLFNBQVMsTUFBT0YsdUJBQStCQyxrQkFBa0I7QUFDdkUsYUFBT0MsV0FBVyxZQUFZLFlBQVk7QUFBQSxJQUM1QyxRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsTUFBSSxPQUFPRiwyQkFBMkIsZUFBZSx5QkFBeUJHLFFBQVE7QUFDcEYsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFZQSxTQUFTQyxZQUFZLEVBQUU1SSxhQUFhbkQsVUFBVUMsUUFBUUMsT0FBTzhMLE9BQXlCLEdBQUc7QUFBQUMsTUFBQTtBQUN2RixRQUFNNUwsYUFBYUosV0FBVztBQUM5QixRQUFNSyxRQUFRO0FBR2QsUUFBTSxDQUFDNEwsYUFBYUMsY0FBYyxJQUFJM00sU0FBMkIsTUFBTTtBQUl2RSxRQUFNNE0sZUFBZTdNLE9BQU8sRUFBRTRCLEdBQUcsR0FBR0csR0FBRyxFQUFFLENBQUM7QUFDMUMsUUFBTSxDQUFDK0ssV0FBV0MsWUFBWSxJQUFJOU0sU0FBUyxFQUFFMkIsR0FBRyxHQUFHRyxHQUFHLEVBQUUsQ0FBQztBQUd6RCxRQUFNaUwsWUFBWWhOLE9BQXVCLElBQUk7QUFHN0MsUUFBTWlOLGNBQWNqTixPQUFPLENBQUM7QUFDNUJELFlBQVUsTUFBTTtBQUNkLFVBQU1tQyxLQUFLZ0wsWUFBWSxNQUFNO0FBQzNCLFlBQU0sRUFBRXRMLEdBQUdHLEVBQUUsSUFBSThLLGFBQWFwTDtBQUU5QixZQUFNMEwsZ0JBQWUxSyxLQUFLZ0MsSUFBSSxHQUFHaEMsS0FBSzJLLEtBQUt4TCxJQUFJQSxJQUFJRyxJQUFJQSxDQUFDLENBQUM7QUFDekQwSyxhQUFPVSxhQUFZO0FBQUEsSUFDckIsR0FBR2pOLFlBQVltTixxQkFBcUI7QUFDcEMsV0FBTyxNQUFNQyxjQUFjcEwsRUFBRTtBQUFBLEVBQy9CLEdBQUcsQ0FBQ3VLLE1BQU0sQ0FBQztBQUdYMU0sWUFBVSxNQUFNO0FBQ2QsUUFBSTRNLGdCQUFnQixVQUFXO0FBRS9CLFVBQU1ZLG9CQUFvQkEsQ0FBQ2pNLE1BQThCO0FBQ3ZELFlBQU1rTSxRQUFRbE0sRUFBRWtNLFNBQVM7QUFDekIsWUFBTUMsT0FBT25NLEVBQUVtTSxRQUFRO0FBRXZCLFlBQU1DLFdBQVd4TixZQUFZeU47QUFDN0IsWUFBTUMsS0FBS25MLEtBQUtnQyxJQUFJLEdBQUdoQyxLQUFLK0IsSUFBSSxJQUFJZ0osUUFBUUUsUUFBUSxDQUFDO0FBQ3JELFlBQU1HLEtBQUtwTCxLQUFLZ0MsSUFBSSxHQUFHaEMsS0FBSytCLElBQUksS0FBS2lKLE9BQU8sTUFBTUMsUUFBUSxDQUFDO0FBRTNEYixtQkFBYXBMLFVBQVUsRUFBRUcsR0FBR2dNLElBQUk3TCxHQUFHOEwsR0FBRztBQUN0Q2QsbUJBQWEsRUFBRW5MLEdBQUdnTSxJQUFJN0wsR0FBRzhMLEdBQUcsQ0FBQztBQUFBLElBQy9CO0FBRUF0QixXQUFPdUIsaUJBQWlCLHFCQUFxQlAsbUJBQW1CLElBQUk7QUFDcEUsV0FBTyxNQUFNaEIsT0FBT3dCLG9CQUFvQixxQkFBcUJSLG1CQUFtQixJQUFJO0FBQUEsRUFDdEYsR0FBRyxDQUFDWixXQUFXLENBQUM7QUFHaEIsUUFBTXFCLGlCQUFpQmhPLE9BQU8sS0FBSztBQUVuQyxRQUFNaU8sbUJBQW1Cbk8sWUFBWSxDQUFDd0IsTUFBd0I7QUFDNUQwTSxtQkFBZXZNLFVBQVU7QUFDekJILE1BQUV1RixlQUFlO0FBQUEsRUFDbkIsR0FBRyxFQUFFO0FBRUwsUUFBTXFILGtCQUFrQnBPLFlBQVksQ0FBQ3dCLE1BQXdCO0FBQzNELFFBQUksQ0FBQzBNLGVBQWV2TSxXQUFXLENBQUN1TCxVQUFVdkwsUUFBUztBQUNuREgsTUFBRXVGLGVBQWU7QUFDakIsVUFBTW5GLE9BQU9zTCxVQUFVdkwsUUFBUUUsc0JBQXNCO0FBQ3JELFVBQU13TSxRQUFRN00sRUFBRThNLFFBQVEsQ0FBQztBQUN6QixVQUFNQyxLQUFLM00sS0FBS0ksT0FBT0osS0FBS21CLFFBQVE7QUFDcEMsVUFBTXlMLEtBQUs1TSxLQUFLTyxNQUFNUCxLQUFLb0IsU0FBUztBQUNwQyxVQUFNUixJQUFJWixLQUFLbUIsUUFBUTtBQUN2QixVQUFNMEwsTUFBTUosTUFBTXRNLFVBQVV3TSxNQUFNL0w7QUFDbEMsVUFBTWtNLE1BQU1MLE1BQU1uTSxVQUFVc00sTUFBTWhNO0FBRWxDLFVBQU1tTSxNQUFNaE0sS0FBSzJLLEtBQUttQixLQUFLQSxLQUFLQyxLQUFLQSxFQUFFO0FBQ3ZDLFVBQU1FLFFBQVFELE1BQU0sSUFBSSxJQUFJQSxNQUFNO0FBQ2xDLFVBQU1iLEtBQUtXLEtBQUtHO0FBQ2hCLFVBQU1iLEtBQUtXLEtBQUtFO0FBQ2hCN0IsaUJBQWFwTCxVQUFVLEVBQUVHLEdBQUdnTSxJQUFJN0wsR0FBRzhMLEdBQUc7QUFDdENkLGlCQUFhLEVBQUVuTCxHQUFHZ00sSUFBSTdMLEdBQUc4TCxHQUFHLENBQUM7QUFBQSxFQUMvQixHQUFHLEVBQUU7QUFFTCxRQUFNYyxpQkFBaUI3TyxZQUFZLE1BQU07QUFDdkNrTyxtQkFBZXZNLFVBQVU7QUFFekJvTCxpQkFBYXBMLFVBQVUsRUFBRUcsR0FBRyxHQUFHRyxHQUFHLEVBQUU7QUFDcENnTCxpQkFBYSxFQUFFbkwsR0FBRyxHQUFHRyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQzdCLEdBQUcsRUFBRTtBQUdMLFFBQU02TSwwQkFBMEI5TyxZQUFZLFlBQVk7QUFDdEQ4TSxtQkFBZSxZQUFZO0FBQzNCLFVBQU1OLFNBQVMsTUFBTUgsNkJBQTZCO0FBQ2xEUyxtQkFBZU4sTUFBTTtBQUFBLEVBQ3ZCLEdBQUcsRUFBRTtBQUdMdk0sWUFBVSxNQUFNO0FBQ2QsUUFBSTRNLGdCQUFnQixRQUFRO0FBQzFCUixtQ0FBNkIsRUFBRTBDLEtBQUssQ0FBQ3ZDLFdBQVc7QUFHOUMsWUFBSUEsV0FBVyxVQUFVO0FBQ3ZCTSx5QkFBZU4sTUFBTTtBQUFBLFFBQ3ZCO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBRUYsR0FBRyxFQUFFO0FBR0wsUUFBTWEsZUFBZTFLLEtBQUtnQyxJQUFJLEdBQUdoQyxLQUFLMkssS0FBS04sVUFBVWxMLEtBQUssSUFBSWtMLFVBQVUvSyxLQUFLLENBQUMsQ0FBQztBQUMvRSxRQUFNK00sYUFBYTNCLGdCQUFnQmpOLFlBQVk2TztBQUMvQyxRQUFNQyxhQUFhcEwsZUFBZTFELFlBQVlnRSxrQkFBa0JOLGVBQWUxRCxZQUFZaUU7QUFHM0YsUUFBTThLLFdBQVc7QUFDakIsUUFBTUMsV0FBVztBQUNqQixRQUFNQyxZQUFZRixXQUFXQztBQUM3QixRQUFNRSxLQUFLdEMsVUFBVWxMLElBQUl1TjtBQUN6QixRQUFNRSxLQUFLdkMsVUFBVS9LLElBQUlvTjtBQUd6QixRQUFNRyxlQUFlN00sS0FBS2dDLElBQUksR0FBR2hDLEtBQUsrQixJQUFJLElBQUlaLGNBQWMsTUFBTSxFQUFFLENBQUM7QUFDckUsUUFBTTJMLFlBQVlQLGFBQWEsWUFBWU0sZUFBZSxNQUFNLFlBQVlBLGVBQWUsT0FBTyxZQUFZO0FBRzlHLFFBQU1FLGFBQWE7QUFDbkIsUUFBTUMsV0FBVyxJQUFJaE4sS0FBS0MsS0FBSzhNO0FBQy9CLFFBQU1FLGFBQWFELFdBQVloUCxXQUFXLE1BQU9nUDtBQUdqRCxNQUFJM08sWUFBWTtBQUNkLFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRThCLFlBQVksb0VBQW9FO0FBQUEsUUFFekY7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTztBQUFBLGdCQUNMQyxPQUFPO0FBQUEsZ0JBQ1BDLFFBQVE7QUFBQSxnQkFDUkMsUUFBUTtBQUFBLGdCQUNSQyxXQUFXO0FBQUEsZ0JBQ1hDLFdBQVc7QUFBQSxjQUNiO0FBQUEsY0FFQSxpQ0FBQyxTQUFJLE9BQU8sRUFBRUMsVUFBVSxHQUFHLEdBQUcsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUE7QUFBQSxZQVZsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRW5DLE9BQU9vQyxZQUFZLG1CQUFtQjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxZQUFtQnhDLE1BQU15QyxlQUFlO0FBQUEsWUFBRTtBQUFBLGVBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUE7QUFBQTtBQUFBLE1BdEJ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1QkE7QUFBQSxFQUVKO0FBR0EsUUFBTXVNLHFCQUFxQmhELGdCQUFnQixVQUFVQSxnQkFBZ0I7QUFDckUsUUFBTWlELG9CQUFvQmpELGdCQUFnQixZQUFZQSxnQkFBZ0I7QUFDdEUsUUFBTWtELGVBQWVsRCxnQkFBZ0I7QUFFckMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUVBQXNFLE9BQU8sRUFBRWxKLGFBQWEsT0FBTyxHQUdoSDtBQUFBLDJCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdEQUF1RCx3QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzlFLHVCQUFDLFNBQUksV0FBVSxpQ0FBZ0MsT0FBTyxFQUFFMUMsTUFBTSxHQUFJTjtBQUFBQTtBQUFBQSxVQUFTO0FBQUEsYUFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFdBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQXVELG9CQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUUsdUJBQUMsU0FBSSxXQUFVLGdDQUErQixPQUFPLEVBQUVNLE9BQU93TyxVQUFVLEdBQ3JFM0w7QUFBQUEsc0JBQVlLLFFBQVEsQ0FBQztBQUFBLFVBQUU7QUFBQSxhQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQXVELHFCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFDM0UsdUJBQUMsU0FBSSxXQUFVLDRDQUE0Q3RELGdCQUFNeUMsZUFBZSxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsV0FGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsVUFDTFIsWUFBWW9NLGFBQWEsMEJBQTBCO0FBQUEsVUFDbkRqTyxPQUFPaU8sYUFBYSxZQUFZO0FBQUEsVUFDaENqTSxRQUFRLGFBQWFpTSxhQUFhLGNBQWMsV0FBVztBQUFBLFVBQzNEekwsWUFBWTtBQUFBLFFBQ2Q7QUFBQSxRQUVDeUwsdUJBQWEsZUFBZTlPLFlBQVlnRSxjQUFjLElBQUloRSxZQUFZaUUsY0FBYyxPQUFPLFdBQVdqRSxZQUFZZ0UsY0FBYyxJQUFJaEUsWUFBWWlFLGNBQWM7QUFBQTtBQUFBLE1BVGpLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNkNBQTRDLE9BQU8sRUFBRXdDLFlBQVksRUFBRSxHQUVoRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsS0FBS3FHO0FBQUFBLFFBQ0wsY0FBYzRDLG9CQUFvQjNCLG1CQUFtQjZCO0FBQUFBLFFBQ3JELGFBQWFGLG9CQUFvQjFCLGtCQUFrQjRCO0FBQUFBLFFBQ25ELFlBQVlGLG9CQUFvQmpCLGlCQUFpQm1CO0FBQUFBLFFBQ2pELE9BQU87QUFBQSxVQUNMQyxVQUFVO0FBQUEsVUFDVmxOLE9BQU9vTSxXQUFXO0FBQUEsVUFDbEJuTSxRQUFRbU0sV0FBVztBQUFBLFVBQ25CckYsY0FBYztBQUFBLFVBQ2RoSCxZQUFZO0FBQUEsVUFDWkcsUUFBUSxhQUFhK0wsYUFBYSxZQUFZLHNCQUFzQjtBQUFBLFVBQ3BFOUwsV0FBVzhMLGFBQWEsdUJBQXVCO0FBQUEsVUFDL0N2TCxZQUFZO0FBQUEsVUFDWnlNLFVBQVU7QUFBQSxRQUNaO0FBQUEsUUFHQTtBQUFBLGlDQUFDLFNBQUksT0FBTztBQUFBLFlBQ1ZELFVBQVU7QUFBQSxZQUNWRSxPQUFPO0FBQUEsWUFDUHhHLFNBQVM7QUFBQSxZQUNUQyxZQUFZO0FBQUEsWUFDWkMsZ0JBQWdCO0FBQUEsWUFDaEJ1RyxlQUFlO0FBQUEsVUFDakIsR0FFRSxpQ0FBQyxTQUFJLE9BQU87QUFBQSxZQUNWck4sT0FBT29NLFdBQVcsSUFBSS9PLFlBQVk2TywyQkFBMkI7QUFBQSxZQUM3RGpNLFFBQVFtTSxXQUFXLElBQUkvTyxZQUFZNk8sMkJBQTJCO0FBQUEsWUFDOURuRixjQUFjO0FBQUEsWUFDZDdHLFFBQVEsZ0JBQWdCK0wsYUFBYSxZQUFZLHNCQUFzQjtBQUFBLFlBQ3ZFdkwsWUFBWTtBQUFBLFVBQ2QsS0FOQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1FLEtBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQ1Z3TSxVQUFVO0FBQUEsWUFDVjlOLEtBQUs7QUFBQSxZQUNMSCxNQUFNO0FBQUEsWUFDTnFPLE9BQU87QUFBQSxZQUNQck4sUUFBUTtBQUFBLFlBQ1JGLFlBQVk7QUFBQSxZQUNaVSxXQUFXO0FBQUEsWUFDWDRNLGVBQWU7QUFBQSxVQUNqQixLQVRBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0U7QUFBQSxVQUNGLHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQ1ZILFVBQVU7QUFBQSxZQUNWak8sTUFBTTtBQUFBLFlBQ05HLEtBQUs7QUFBQSxZQUNMbU8sUUFBUTtBQUFBLFlBQ1J2TixPQUFPO0FBQUEsWUFDUEQsWUFBWTtBQUFBLFlBQ1pVLFdBQVc7QUFBQSxZQUNYNE0sZUFBZTtBQUFBLFVBQ2pCLEtBVEE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTRTtBQUFBLFVBR0Y7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU87QUFBQSxnQkFDTEgsVUFBVTtBQUFBLGdCQUNWbE4sT0FBT3FNLFdBQVc7QUFBQSxnQkFDbEJwTSxRQUFRb00sV0FBVztBQUFBLGdCQUNuQnRGLGNBQWM7QUFBQTtBQUFBLGdCQUVkOUgsTUFBTW1OLFdBQVdDLFdBQVdFO0FBQUFBLGdCQUM1Qm5OLEtBQUtnTixXQUFXQyxXQUFXRztBQUFBQSxnQkFDM0J6TSxZQUFZLHNDQUFzQ2tNLGFBQWEsWUFBWVMsU0FBUyxPQUFPVCxhQUFhLFlBQVlTLFNBQVM7QUFBQSxnQkFDN0h4TSxRQUFRLGFBQWErTCxhQUFhLFlBQVlTLFNBQVM7QUFBQSxnQkFDdkR2TSxXQUFXLFlBQVk4TCxhQUFhLFlBQVlTLFNBQVM7QUFBQSxnQkFDekRoTSxZQUFZb0osZ0JBQWdCLFlBQVksNENBQTRDO0FBQUEsZ0JBQ3BGbEQsU0FBUztBQUFBLGdCQUNUQyxZQUFZO0FBQUEsZ0JBQ1pDLGdCQUFnQjtBQUFBLGdCQUNoQnVHLGVBQWU7QUFBQSxjQUNqQjtBQUFBLGNBRUEsaUNBQUMsVUFBSyxPQUFPLEVBQUVoTixVQUFVLEdBQUcsR0FBRyxrQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQTtBQUFBLFlBbkJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkE7QUFBQSxVQUdDeU0sc0JBQ0MsdUJBQUMsU0FBSSxPQUFPO0FBQUEsWUFDVkksVUFBVTtBQUFBLFlBQ1ZFLE9BQU87QUFBQSxZQUNQckcsY0FBYztBQUFBLFlBQ2RoSCxZQUFZO0FBQUEsWUFDWjZHLFNBQVM7QUFBQSxZQUNUNEcsZUFBZTtBQUFBLFlBQ2YzRyxZQUFZO0FBQUEsWUFDWkMsZ0JBQWdCO0FBQUEsWUFDaEIyRyxLQUFLO0FBQUEsWUFDTDFKLFFBQVE7QUFBQSxVQUNWLEdBQ0U7QUFBQSxtQ0FBQyxTQUFJLE9BQU8sRUFBRTFELFVBQVUsR0FBRyxHQUFHLGtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQ2hDLHVCQUFDLFNBQUksV0FBVSw0RUFDWnlKLDBCQUFnQixlQUFlLGdCQUFnQiw4QkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUlEaUQscUJBQXFCekMsZUFBZSxRQUNuQyx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUNWNEMsVUFBVTtBQUFBLFlBQ1ZFLE9BQU87QUFBQSxZQUNQckcsY0FBYztBQUFBLFlBQ2RILFNBQVM7QUFBQSxZQUNUNEcsZUFBZTtBQUFBLFlBQ2YzRyxZQUFZO0FBQUEsWUFDWkMsZ0JBQWdCO0FBQUEsWUFDaEIyRyxLQUFLO0FBQUEsWUFDTEosZUFBZTtBQUFBLFlBQ2Z0SixRQUFRO0FBQUEsVUFDVixHQUNFO0FBQUEsbUNBQUMsU0FBSSxPQUFPLEVBQUUxRCxVQUFVLElBQUlxTixTQUFTLElBQUksR0FBRyxrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUM5Qyx1QkFBQyxTQUFJLFdBQVUsdURBQXNELCtCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBLGVBYnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQTtBQUFBO0FBQUEsTUF0SEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBd0hBLEtBMUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EySEE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDWlo7QUFBQUEsNEJBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUc7QUFBQSxVQUNILE1BQUs7QUFBQSxVQUNMLFNBQVNmO0FBQUFBLFVBQ1QsVUFBVWpDLGdCQUFnQjtBQUFBLFVBQzFCLFdBQVU7QUFBQSxVQUNWLE9BQU87QUFBQSxZQUNML0osWUFBWTtBQUFBLFlBQ1pHLFFBQVE7QUFBQSxZQUNSaEMsT0FBTztBQUFBLFlBQ1B5Qyx5QkFBeUI7QUFBQSxVQUMzQjtBQUFBLFVBQUU7QUFBQTtBQUFBLFFBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0E7QUFBQSxNQUVEb00scUJBQ0MsdUJBQUMsU0FBSSxXQUFVLG9FQUFrRSxpRUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFREMsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLG9FQUFrRSxvREFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDZDQUE0QyxPQUFPLEVBQUVoTixPQUFPLEtBQUtDLFFBQVEsS0FBSzZELFlBQVksRUFBRSxHQUN6RztBQUFBLDZCQUFDLFNBQUksT0FBTyxLQUFLLFFBQVEsS0FBSyxTQUFRLGVBQWMsV0FBVSxZQUFXLE9BQU8sRUFBRXJELFdBQVcsaUJBQWlCLEdBQzVHO0FBQUEsK0JBQUMsWUFBTyxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUdrTSxZQUFZLE1BQUssUUFBTyxRQUFPLFdBQVUsYUFBYSxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFDbkY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUFJLElBQUk7QUFBQSxZQUFJLEdBQUdBO0FBQUFBLFlBQVksTUFBSztBQUFBLFlBQ3BDLFFBQVF6TztBQUFBQSxZQUFPLGFBQWE7QUFBQSxZQUFHLGVBQWM7QUFBQSxZQUM3QyxpQkFBaUIwTztBQUFBQSxZQUNqQixrQkFBa0JDO0FBQUFBLFlBQ2xCLE9BQU8sRUFBRW5NLFlBQVksbUNBQW1DbEIsUUFBUSx1QkFBdUJ0QixLQUFLLElBQUk7QUFBQTtBQUFBLFVBTGxHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtvRztBQUFBLFdBUHRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsK0JBQUMsVUFBSyxPQUFPLEVBQUVtQyxVQUFVLEdBQUcsR0FBRyxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQztBQUFBLFFBQ2xDLHVCQUFDLFVBQUssV0FBVSwrQ0FBOEMsT0FBTyxFQUFFbkMsTUFBTSxHQUFHLHVCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsV0FGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtGQUNiO0FBQUEsK0JBQUMsVUFBSyx1QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxRQUNiLHVCQUFDLFVBQU1OO0FBQUFBO0FBQUFBLFVBQVM7QUFBQSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsV0FGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE9BQU87QUFBQSxZQUNMb0MsT0FBTyxHQUFHcEMsUUFBUTtBQUFBLFlBQ2xCbUMsWUFBWSxtQ0FBbUM3QixLQUFLO0FBQUEsWUFDcERpQyxXQUFXLFdBQVdqQyxLQUFLO0FBQUEsWUFDM0J3QyxZQUFZO0FBQUEsVUFDZDtBQUFBO0FBQUEsUUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPSSxLQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9Bak9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrT0E7QUFFSjtBQUVBbUosSUFyWVNGLGFBQVc7QUFBQSxNQUFYQTtBQStZVCxTQUFTZ0UsYUFBYSxFQUFFQyxNQUFNaFEsVUFBVUMsUUFBUWdRLFNBQVNDLFlBQStCLEdBQUc7QUFDekYsUUFBTTVQLFFBQVFaLFlBQVlzUSxJQUFJO0FBQzlCLFFBQU1HLE1BQU0xUSxZQUFZMlE7QUFFeEIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkNBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsb0RBQW1ELHdCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFDM0UsdUJBQUMsVUFBSyxXQUFVLGlDQUFnQyxPQUFPLEVBQUU5UCxNQUFNLEdBQUlOO0FBQUFBO0FBQUFBLFVBQVM7QUFBQSxhQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZFO0FBQUEsV0FGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE9BQU8sRUFBRW9DLE9BQU8sR0FBR3BDLFFBQVEsS0FBS21DLFlBQVk3QixNQUFNO0FBQUE7QUFBQSxRQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFc0QsS0FIeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQWdFTCxvQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRjtBQUFBLFNBWHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBR0MrUCxTQUFTLFdBQ1I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRTdOLFlBQVksR0FBRzdCLEtBQUssTUFBTWdDLFFBQVEsYUFBYWhDLEtBQUssTUFBTUEsTUFBTTtBQUFBLFFBQ3pFLFNBQVMsTUFBTTJQLFFBQVFJLGtCQUFrQixFQUFFQyxRQUFRSCxJQUFJLENBQUM7QUFBQSxRQUFFO0FBQUE7QUFBQSxVQUcxRCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUc7QUFBQSxVQUNILHVCQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLFlBQUVBO0FBQUFBLFlBQUk7QUFBQSxlQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRTtBQUFBO0FBQUE7QUFBQSxNQVJuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTQTtBQUFBLElBR0RILFNBQVMsVUFDUjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsT0FBTyxFQUFFN04sWUFBWSxHQUFHN0IsS0FBSyxNQUFNZ0MsUUFBUSxhQUFhaEMsS0FBSyxNQUFNQSxNQUFNO0FBQUEsUUFDekUsU0FBUyxNQUFNMlAsUUFBUU0saUJBQWlCLEVBQUVELFFBQVFILElBQUksQ0FBQztBQUFBLFFBQUU7QUFBQTtBQUFBLFVBR3pELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQ0gsdUJBQUMsVUFBSyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsWUFBRUE7QUFBQUEsWUFBSTtBQUFBLGVBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtFO0FBQUE7QUFBQTtBQUFBLE1BUnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBO0FBQUEsSUFHREgsU0FBUyxjQUNSLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxXQUFVO0FBQUEsVUFDVixPQUFPLEVBQUU3TixZQUFZLEdBQUc3QixLQUFLLE1BQU1nQyxRQUFRLGFBQWFoQyxLQUFLLE1BQU1BLE1BQU07QUFBQSxVQUN6RSxTQUFTLE1BQU0yUCxRQUFRTyxxQkFBcUIsRUFBRUYsUUFBUUgsSUFBSSxDQUFDO0FBQUEsVUFBRTtBQUFBO0FBQUEsWUFFMUQsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFHO0FBQUEsWUFBRyx1QkFBQyxVQUFLLFdBQVUsdUJBQXNCO0FBQUE7QUFBQSxjQUFFQTtBQUFBQSxjQUFJO0FBQUEsaUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUE7QUFBQTtBQUFBLFFBTnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsT0FBTyxFQUFFaE8sWUFBWSxHQUFHN0IsS0FBSyxNQUFNZ0MsUUFBUSxhQUFhaEMsS0FBSyxNQUFNQSxNQUFNO0FBQUEsVUFDekUsU0FBUyxNQUFNMlAsUUFBUU8scUJBQXFCLEVBQUVGLFFBQVFILElBQUksQ0FBQztBQUFBLFVBQUU7QUFBQTtBQUFBLFlBRTFELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBRztBQUFBLFlBQUcsdUJBQUMsVUFBSyxXQUFVLHVCQUFzQjtBQUFBO0FBQUEsY0FBRUE7QUFBQUEsY0FBSTtBQUFBLGlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBO0FBQUE7QUFBQSxRQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUdESCxTQUFTLFdBQ1I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRTdOLFlBQVksR0FBRzdCLEtBQUssTUFBTWdDLFFBQVEsYUFBYWhDLEtBQUssTUFBTUEsTUFBTTtBQUFBLFFBQ3pFLFNBQVMsTUFBTTJQLFFBQVFRLGtCQUFrQixFQUFFSCxRQUFRSCxJQUFJLENBQUM7QUFBQSxRQUFFO0FBQUE7QUFBQSxVQUcxRCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUc7QUFBQSxVQUNILHVCQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLFlBQUVBO0FBQUFBLFlBQUk7QUFBQSxlQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBO0FBQUE7QUFBQSxNQVJyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFTQTtBQUFBLElBR0RILFNBQVMsYUFDUjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsYUFBYUU7QUFBQUEsUUFDYixPQUFPLENBQUN2TSxNQUFNc00sUUFBUVMsa0JBQWtCLEVBQUV2TixhQUFhUSxFQUFFLENBQUM7QUFBQTtBQUFBLE1BRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU4RDtBQUFBLElBSWhFLHVCQUFDLFNBQUksV0FBVSxzQ0FBb0MsZ0VBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1RkE7QUFFSjtBQUVBZ04sTUFoR1NaO0FBa0dGLGdCQUFTYSxpQkFBaUI7QUFBQUMsTUFBQTtBQUMvQixRQUFNQyxhQUFhM1Isb0JBQW9CO0FBRXZDLFFBQU00UixRQUFRalIsZ0JBQWdCLENBQUNrUixNQUFvQkEsQ0FBQztBQUNwRCxRQUFNZixVQUFVblEsZ0JBQWdCbVIsV0FBVztBQUMzQyxRQUFNQyxlQUFlM1IsT0FBTyxLQUFLO0FBRWpDLFFBQU00UixPQUFPTCxXQUFXTTtBQUN4QixRQUFNQyxTQUFTRixPQUFRSixNQUFNTyxnQkFBZ0JILElBQUksSUFBK0I5QjtBQUNoRixRQUFNa0MsWUFBWVQsV0FBV1UscUJBQXFCO0FBQ2xELFFBQU1sUixRQUFRK1EsU0FBUzNSLFlBQVkyUixNQUFNLElBQUk7QUFHN0MvUixZQUFVLE1BQU07QUFDZCxRQUFJaVMsYUFBYSxDQUFDRixVQUFVLENBQUNILGFBQWFsUSxTQUFTO0FBQ2pEa1EsbUJBQWFsUSxVQUFVO0FBQ3ZCaVAsY0FBUXdCLFlBQVk7QUFBQSxJQUN0QjtBQUFBLEVBQ0YsR0FBRyxDQUFDRixXQUFXRixRQUFRcEIsT0FBTyxDQUFDO0FBRy9CLE1BQUksQ0FBQ3NCLFdBQVc7QUFDZCxXQUNFLHVCQUFDLG1CQUFnQixhQUFZLFlBQVcsV0FBVSxnQkFDaEQsaUNBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBCQUF5QixrQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLE1BQzFDLHVCQUFDLFNBQUksV0FBVSxrQ0FBaUMsMEJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUMxRCx1QkFBQyxTQUFJLFdBQVUsMEJBQ1pULHFCQUFXVSxxQkFBcUIsZUFDN0IsMkJBQ0EsbUJBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQ1YsV0FBV1UscUJBQXFCLGtCQUMvQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsU0FBU1YsV0FBV1k7QUFBQUEsVUFBVTtBQUFBO0FBQUEsUUFIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLEVBRUo7QUFHQSxNQUFJLENBQUNMLFFBQVE7QUFDWCxXQUNFLHVCQUFDLG1CQUFnQixhQUFZLFlBQVcsV0FBVSxnQkFDaEQsaUNBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHlCQUF3QixrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLE1BQ3pDLHVCQUFDLFNBQUksV0FBVSxrQ0FBaUMsZ0NBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCLDJDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsU0FIckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsRUFFSjtBQUdBLE1BQUlOLE1BQU1ZLFVBQVUsVUFBVVosTUFBTVksVUFBVSxTQUFTO0FBQ3JELFdBQ0UsdUJBQUMsbUJBQWdCLGFBQVksWUFBVyxXQUFVLGdCQUNoRCxpQ0FBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTyxFQUFFckwsYUFBYSxHQUFHaEcsS0FBSyxNQUFNaUMsV0FBVyxZQUFZakMsS0FBSyxLQUFLO0FBQUEsVUFFckU7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsWUFBWVgscUJBQVcwUixNQUFNLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDO0FBQUEsWUFDOUMsdUJBQUMsU0FBSSxXQUFVLG9EQUFtRCx5QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUMzRSx1QkFBQyxTQUFJLFdBQVUsdUJBQXNCLE9BQU8sRUFBRS9RLE1BQU0sR0FDakRWLHNCQUFZeVIsTUFBTSxLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ1p4Uix5QkFBZXdSLE1BQU0sS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUE7QUFBQSxRQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQkFDWk87QUFBQUEsaUJBQU9DLEtBQUtkLE1BQU1PLGVBQWUsRUFBRXZNO0FBQUFBLFVBQU87QUFBQSxVQUFJdEYsWUFBWXFTO0FBQUFBLFVBQVc7QUFBQSxhQUR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FBeUMsMENBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsd0NBQXNDO0FBQUE7QUFBQSxRQUM5Q1gsTUFBTVksTUFBTSxHQUFHLEVBQUU7QUFBQSxXQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxFQUVKO0FBR0EsTUFBSWhCLE1BQU1ZLFVBQVUsV0FBVztBQUM3QixVQUFNSyxZQUFZakIsTUFBTU0sTUFBTTtBQUM5QixVQUFNWSxVQUFVbEIsTUFBTW1CLGFBQWFDLEtBQUssQ0FBQ3RSLE1BQU1BLEVBQUV1UixpQkFBaUJmLE1BQU07QUFFeEUsV0FDRSx1QkFBQyxtQkFBZ0IsYUFBWSxZQUFXLFdBQVUsZ0JBQ2hELGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixPQUFPO0FBQUEsWUFDTC9LLGFBQWEyTCxVQUFVLHlCQUF5QixHQUFHM1IsS0FBSztBQUFBLFlBQ3hEa0MsV0FBV3lQLFVBQVUsMkNBQTJDNUM7QUFBQUEsWUFDaEV2TSxZQUFZO0FBQUEsVUFDZDtBQUFBLFVBRUE7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsWUFBWW5ELHFCQUFXMFIsTUFBTSxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLFlBQy9DLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsb0RBQW1ELG9CQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTyxFQUFFL1EsTUFBTSxHQUNoRFYsc0JBQVl5UixNQUFNLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMEJBQXlCLG9CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGNBQzVDLHVCQUFDLFNBQUksV0FBVSwyQ0FDWmdCO0FBQUFBLHVCQUFPclEsS0FBSzZDLE1BQU1rTSxNQUFNdUIsZ0JBQWdCLEVBQUUsQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUFBLGdCQUFFO0FBQUEsZ0JBQzlERixPQUFPdEIsTUFBTXVCLGdCQUFnQixFQUFFLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQUEsbUJBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUE7QUFBQTtBQUFBLFFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXNCQTtBQUFBLE1BR0NOLFdBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxZQUNMTyxTQUFTO0FBQUEsWUFDVHJKLGNBQWM7QUFBQSxZQUNkaEgsWUFBWTtBQUFBLFlBQ1pHLFFBQVE7QUFBQSxZQUNSRyxVQUFVO0FBQUEsWUFDVjJHLFlBQVk7QUFBQSxZQUNaOUksT0FBTztBQUFBLFlBQ1BtUyxXQUFXO0FBQUEsWUFDWG5KLGVBQWU7QUFBQSxZQUNmb0osZUFBZTtBQUFBLFlBQ2ZsUSxXQUFXO0FBQUEsVUFDYjtBQUFBLFVBRUN5UCxrQkFBUVU7QUFBQUE7QUFBQUEsUUFmWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnQkE7QUFBQSxNQUdGLHVCQUFDLFNBQUksV0FBVSw0QkFDWnRCLHFCQUFXLFVBQ1Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFVBQVVXLFVBQVVoUztBQUFBQSxVQUNwQixRQUFRZ1MsVUFBVS9SO0FBQUFBLFVBQ2xCLE9BQVE4USxNQUFNNkIsTUFBNEIxUztBQUFBQSxVQUMxQyxPQUFPLE1BQU0rUCxRQUFRNEMsU0FBUztBQUFBO0FBQUEsUUFKaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWtDLElBRWhDeEIsV0FBVyxTQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFVVyxVQUFVaFM7QUFBQUEsVUFDcEIsUUFBUWdTLFVBQVUvUjtBQUFBQSxVQUNsQixPQUFROFEsTUFBTStCLEtBQTJCNVM7QUFBQUEsVUFDekMsUUFBUSxDQUFDZ0UsT0FBT3lCLFFBQVEwRixZQUN0QjRFLFFBQVE4QyxTQUFTLEVBQUU3TyxPQUFPeUIsUUFBUTBGLFFBQVEsQ0FBQztBQUFBO0FBQUEsUUFML0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUcsSUFFRGdHLFdBQVcsYUFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsVUFBVVcsVUFBVWhTO0FBQUFBLFVBQ3BCLFFBQVFnUyxVQUFVL1I7QUFBQUEsVUFDbEIsT0FBUThRLE1BQU1pQyxTQUErQjlTO0FBQUFBLFVBQzdDLFVBQVUsQ0FBQytTLFFBQVFoRCxRQUFRaUQsT0FBTyxFQUFFRCxJQUFJLENBQUM7QUFBQTtBQUFBLFFBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUk2QyxJQUUzQzVCLFdBQVcsVUFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsVUFBVVcsVUFBVWhTO0FBQUFBLFVBQ3BCLFFBQVFnUyxVQUFVL1I7QUFBQUEsVUFDbEIsT0FBUThRLE1BQU1vQyxNQUE0QmpUO0FBQUFBLFVBQzFDLFNBQVMsTUFBTStQLFFBQVFtRCxZQUFZO0FBQUE7QUFBQSxRQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJdUMsSUFFckMvQixXQUFXLFlBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLGFBQWFOLE1BQU1zQyxRQUFRbFE7QUFBQUEsVUFDM0IsVUFBVTZPLFVBQVVoUztBQUFBQSxVQUNwQixRQUFRZ1MsVUFBVS9SO0FBQUFBLFVBQ2xCLE9BQVE4USxNQUFNc0MsUUFBOEJuVDtBQUFBQSxVQUM1QyxRQUFRLENBQUN3TSxpQkFBaUJ1RCxRQUFRcUQsU0FBUyxFQUFFNUcsYUFBYSxDQUFDO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLK0QsSUFHL0Q7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU0yRTtBQUFBQSxVQUNOLFVBQVVXLFVBQVVoUztBQUFBQSxVQUNwQixRQUFRZ1MsVUFBVS9SO0FBQUFBLFVBQ2xCO0FBQUEsVUFDQSxhQUFhOFEsTUFBTXNDLFFBQVFsUTtBQUFBQTtBQUFBQSxRQUw3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLeUMsS0E3QzdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnREE7QUFBQSxTQTlGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0ZBLEtBaEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpR0E7QUFBQSxFQUVKO0FBR0EsUUFBTW9RLFVBQVV4QyxNQUFNeUMsZ0JBQWdCO0FBQ3RDLFNBQ0UsdUJBQUMsbUJBQWdCLGFBQVksWUFBVyxXQUFVLGdCQUNoRCxpQ0FBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsWUFBWUQsb0JBQVUsT0FBTyxRQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFDakQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVU7QUFBQSxRQUNWLE9BQU8sRUFBRWpULE9BQU9pVCxVQUFVLFlBQVksVUFBVTtBQUFBLFFBRS9DQSxvQkFBVSxpQkFBaUI7QUFBQTtBQUFBLE1BSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMEJBQXlCLCtCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQsdUJBQUMsU0FBSSxXQUFVLDBCQUF5QixPQUFPLEVBQUVqVCxNQUFNLEdBQ3BEWDtBQUFBQSxtQkFBVzBSLE1BQU07QUFBQSxRQUFFO0FBQUEsUUFBRXpSLFlBQVl5UixNQUFNO0FBQUEsV0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNEJBQTJCLE9BQU8sRUFBRS9RLE1BQU0sR0FDckR5UTtBQUFBQSxjQUFNTSxNQUFNLEVBQTJCclI7QUFBQUEsUUFBUztBQUFBLFdBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQXdCO0FBQUE7QUFBQSxNQUNyQjtBQUFBLE1BQ2hCLHVCQUFDLFVBQUssV0FBVSx3QkFBd0IrUTtBQUFBQSxjQUFNMEM7QUFBQUEsUUFBYztBQUFBLFdBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxTQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFBd0I7QUFBQTtBQUFBLE1BQ3pCO0FBQUEsTUFDWix1QkFBQyxVQUFLLFdBQVUsMEJBQTBCMUMsZ0JBQU0yQyxVQUFVL1EsZUFBZSxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJFO0FBQUEsU0FGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJBO0FBRUo7QUFBQ2tPLElBMU9lRCxnQkFBYztBQUFBLFVBQ1R6UixxQkFFTFcsaUJBQ0VBLGdCQUFnQm1SLFVBQVU7QUFBQTtBQUFBLE1BSjVCTDtBQUFjLElBQUErQyxJQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBckQsS0FBQXNEO0FBQUEsYUFBQU4sSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQXJELEtBQUE7QUFBQSxhQUFBc0QsS0FBQSIsIm5hbWVzIjpbInVzZUFpckphbUNvbnRyb2xsZXIiLCJTdXJmYWNlVmlld3BvcnQiLCJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiR0FNRV9DT05GSUciLCJST0xFX0NPTE9SUyIsIlJPTEVfSUNPTlMiLCJST0xFX0xBQkVMUyIsIlJPTEVfTUlOSV9HQU1FIiwidXNlRmFjdG9yeVN0b3JlIiwiUG93ZXJHYW1lIiwicHJvZ3Jlc3MiLCJzdGF0dXMiLCJzY29yZSIsIm9uVGFwIiwiX3MiLCJpc0NvbXBsZXRlIiwiY29sb3IiLCJyaXBwbGVzIiwic2V0UmlwcGxlcyIsInJpcHBsZUlkIiwiYnRuUmVmIiwibGFzdFRhcFJlZiIsImhhbmRsZVBvaW50ZXJEb3duIiwiZSIsIm5vdyIsIkRhdGUiLCJjdXJyZW50IiwicmVjdCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsIngiLCJjbGllbnRYIiwibGVmdCIsInkiLCJjbGllbnRZIiwidG9wIiwiaWQiLCJwcmV2Iiwic2V0VGltZW91dCIsImZpbHRlciIsInIiLCJyYWRpdXMiLCJjaXJjIiwiTWF0aCIsIlBJIiwiZGFzaE9mZnNldCIsImJhY2tncm91bmQiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlciIsImJveFNoYWRvdyIsImFuaW1hdGlvbiIsImZvbnRTaXplIiwidGV4dFNoYWRvdyIsInRvTG9jYWxlU3RyaW5nIiwicG93ZXJJbmNyZW1lbnRQZXJUYXAiLCJ0cmFuc2Zvcm0iLCJ0cmFuc2l0aW9uIiwiV2Via2l0VGFwSGlnaGxpZ2h0Q29sb3IiLCJ0b3VjaEFjdGlvbiIsIm1hcCIsIkNvb2xpbmdEZXZQYW5lbCIsInRlbXBlcmF0dXJlIiwib25TZXQiLCJfczIiLCJsb2NhbFRlbXAiLCJzZXRMb2NhbFRlbXAiLCJ0b0ZpeGVkIiwiY29vbGluZ1NhZmVNaW4iLCJjb29saW5nU2FmZU1heCIsInQiLCJOdW1iZXIiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1heCIsIm1pbiIsImNvcnJlY3RCdWNrZXQiLCJ0b2tlbiIsImRhdGFUb2tlbnNOdW1iZXJzIiwiaW5jbHVkZXMiLCJEYXRhQ2xlYW5pbmdHYW1lIiwib25Tb3J0IiwiX3MzIiwiYWxsVG9rZW5zIiwiZGF0YVRva2Vuc0FpVGVybXMiLCJ0b2tlbklkUmVmIiwibGFzdFNvcnRSZWYiLCJuZXh0VG9rZW4iLCJmbG9vciIsInJhbmRvbSIsImxlbmd0aCIsImFjdGl2ZVRva2VuIiwic2V0QWN0aXZlVG9rZW4iLCJmZWVkYmFja1Rva2VuIiwic2V0RmVlZGJhY2tUb2tlbiIsInNoYWtlQnVja2V0Iiwic2V0U2hha2VCdWNrZXQiLCJkcmFnT3ZlciIsInNldERyYWdPdmVyIiwidG9rZW5LZXkiLCJzZXRUb2tlbktleSIsImhhbmRsZURyb3AiLCJidWNrZXQiLCJkYXRhU29ydFRocm90dGxlTXMiLCJpc0NvcnJlY3QiLCJmZWVkYmFjayIsImsiLCJoYW5kbGVCdWNrZXRUYXAiLCJwb2ludHNQZXJEYXRhU29ydCIsImZsZXhTaHJpbmsiLCJ6SW5kZXgiLCJwcmV2ZW50RGVmYXVsdCIsImpvaW4iLCJib3JkZXJDb2xvciIsImdlbmVyYXRlU2VxdWVuY2UiLCJzZXEiLCJsYXN0IiwiaSIsIm9wdGlvbnMiLCJuZXh0IiwicHVzaCIsIlppcFphcEdhbWUiLCJvblppcFphcCIsIl9zNCIsInNlcXVlbmNlIiwic2V0U2VxdWVuY2UiLCJzZWN1cml0eVNlcXVlbmNlU2VlZExlbmd0aCIsImN1cnJlbnRTdGVwIiwic2V0Q3VycmVudFN0ZXAiLCJ0b3RhbEhpdHMiLCJzZXRUb3RhbEhpdHMiLCJ6aXBBbmltIiwic2V0WmlwQW5pbSIsInphcEFuaW0iLCJzZXRaYXBBbmltIiwibGFzdFByZXNzUmVmIiwiemlwQW5pbVRpbWVyIiwiemFwQW5pbVRpbWVyIiwiY2xlYXJaaXBBbmltIiwiY2xlYXJaYXBBbmltIiwiaGFuZGxlUHJlc3MiLCJwcmVzc2VkIiwic2VjdXJpdHlIaXRUaHJvdHRsZU1zIiwiZXhwZWN0ZWQiLCJpc0hpdCIsIm5leHRIaXRzIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwiY2xlYXJUaW1lb3V0IiwibmV4dFN0ZXAiLCJncm93QXQiLCJzZWN1cml0eVNlcXVlbmNlR3Jvd0V2ZXJ5IiwibmV3TGVuIiwic3RlcCIsImlzQWN0aXZlIiwiaXNEb25lIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImJvcmRlclJhZGl1cyIsImZvbnRXZWlnaHQiLCJmb250RmFtaWx5IiwibGV0dGVyU3BhY2luZyIsIkFJX1BVWlpMRVMiLCJzdGVwcyIsInRoZW1lIiwiaGludCIsInNodWZmbGVJbmRpY2VzIiwibiIsImFyciIsIkFycmF5IiwiZnJvbSIsIl8iLCJqIiwic29ydGVkIiwiZXZlcnkiLCJ2IiwiQWlDb3JlUHV6emxlR2FtZSIsIm9uU29sdmUiLCJfczUiLCJwdXp6bGVJZHgiLCJzZXRQdXp6bGVJZHgiLCJvcmRlciIsInNldE9yZGVyIiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsInNvbHZlZENvdW50Iiwic2V0U29sdmVkQ291bnQiLCJzb2x2aW5nIiwic2V0U29sdmluZyIsInB1enpsZSIsImhhbmRsZVRhcCIsInBvcyIsImNvcnJlY3QiLCJjIiwic3RlcEluZGV4IiwibGFiZWwiLCJpc1NlbGVjdGVkIiwicmVxdWVzdE9yaWVudGF0aW9uUGVybWlzc2lvbiIsIkRldmljZU9yaWVudGF0aW9uRXZlbnQiLCJyZXF1ZXN0UGVybWlzc2lvbiIsInJlc3VsdCIsIndpbmRvdyIsIkNvb2xpbmdHYW1lIiwib25UaWNrIiwiX3M2Iiwib3JpZW50U3RhdGUiLCJzZXRPcmllbnRTdGF0ZSIsImJ1YmJsZVBvc1JlZiIsImJ1YmJsZVBvcyIsInNldEJ1YmJsZVBvcyIsImJvdW5kc1JlZiIsImxhc3RUaWNrUmVmIiwic2V0SW50ZXJ2YWwiLCJjZW50ZXJlZG5lc3MiLCJzcXJ0IiwiY29vbGluZ1RpY2tUaHJvdHRsZU1zIiwiY2xlYXJJbnRlcnZhbCIsImhhbmRsZU9yaWVudGF0aW9uIiwiZ2FtbWEiLCJiZXRhIiwibWF4QW5nbGUiLCJjb29saW5nTWF4VGlsdEFuZ2xlIiwibngiLCJueSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidG91Y2hBY3RpdmVSZWYiLCJoYW5kbGVUb3VjaFN0YXJ0IiwiaGFuZGxlVG91Y2hNb3ZlIiwidG91Y2giLCJ0b3VjaGVzIiwiY3giLCJjeSIsImR4IiwiZHkiLCJsZW4iLCJzY2FsZSIsImhhbmRsZVRvdWNoRW5kIiwiaGFuZGxlUmVxdWVzdFBlcm1pc3Npb24iLCJ0aGVuIiwiaXNDZW50ZXJlZCIsImNvb2xpbmdDZW50ZXJlZFRocmVzaG9sZCIsImluU2FmZVpvbmUiLCJCT1VORFNfUiIsIkJVQkJMRV9SIiwibWF4VHJhdmVsIiwiYngiLCJieSIsInRlbXBGcmFjdGlvbiIsInRlbXBDb2xvciIsInJpbmdSYWRpdXMiLCJyaW5nQ2lyYyIsInJpbmdPZmZzZXQiLCJuZWVkc1Blcm1pc3Npb25UYXAiLCJzaG93VG91Y2hGYWxsYmFjayIsInNob3dPcmllbnRVSSIsInVuZGVmaW5lZCIsInBvc2l0aW9uIiwib3ZlcmZsb3ciLCJpbnNldCIsInBvaW50ZXJFdmVudHMiLCJyaWdodCIsImJvdHRvbSIsImZsZXhEaXJlY3Rpb24iLCJnYXAiLCJvcGFjaXR5IiwiUm9sZURldlBhbmVsIiwicm9sZSIsImFjdGlvbnMiLCJjb29saW5nVGVtcCIsImFtdCIsImRldkluY3JlbWVudEFtb3VudCIsImRldkluY3JlbWVudFBvd2VyIiwiYW1vdW50IiwiZGV2SW5jcmVtZW50RGF0YSIsImRldkluY3JlbWVudFNlY3VyaXR5IiwiZGV2SW5jcmVtZW50TW9kZWwiLCJkZXZTZXRDb29saW5nVGVtcCIsIl9jNyIsIkNvbnRyb2xsZXJWaWV3IiwiX3M3IiwiY29udHJvbGxlciIsInN0YXRlIiwicyIsInVzZUFjdGlvbnMiLCJyZXF1ZXN0ZWRSZWYiLCJteUlkIiwiY29udHJvbGxlcklkIiwibXlSb2xlIiwicm9sZUFzc2lnbm1lbnRzIiwiY29ubmVjdGVkIiwiY29ubmVjdGlvblN0YXR1cyIsInJlcXVlc3RSb2xlIiwicmVjb25uZWN0IiwicGhhc2UiLCJPYmplY3QiLCJrZXlzIiwibWF4UGxheWVycyIsInNsaWNlIiwiZGVwdFN0YXRlIiwibXlFdmVudCIsImFjdGl2ZUV2ZW50cyIsImZpbmQiLCJhZmZlY3RlZFJvbGUiLCJTdHJpbmciLCJ0aW1lUmVtYWluaW5nIiwicGFkU3RhcnQiLCJwYWRkaW5nIiwidGV4dEFsaWduIiwidGV4dFRyYW5zZm9ybSIsIm1lc3NhZ2UiLCJwb3dlciIsInRhcFBvd2VyIiwiZGF0YSIsInNvcnREYXRhIiwic2VjdXJpdHkiLCJoaXQiLCJ6aXBaYXAiLCJtb2RlbCIsInNvbHZlUHV6emxlIiwiY29vbGluZyIsImNvb2xUaWNrIiwic3VjY2VzcyIsImZpbmFsUmVzdWx0IiwiZmFjdG9yeUhlYWx0aCIsInRlYW1TY29yZSIsIl9jIiwiX2MyIiwiX2MzIiwiX2M0IiwiX2M1IiwiX2M2IiwiX2M4Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENvbnRyb2xsZXIgc3VyZmFjZSDigJQgQUkgRmFjdG9yeS5cbiAqXG4gKiBQaGFzZXM6XG4gKiAgY29ubmVjdGluZyDihpIgc2tlbGV0b24gd2FpdGluZyBzY3JlZW5cbiAqICBpZGxlICAgICAgIOKGkiBqb2luIGxvYmJ5IChhdXRvLXJlcXVlc3Qgcm9sZSBvbiBtb3VudClcbiAqICBsb2JieSAgICAgIOKGkiBzaG93IGFzc2lnbmVkIHJvbGUsIHdhaXQgZm9yIGhvc3QgdG8gc3RhcnRcbiAqICBwbGF5aW5nICAgIOKGkiBQb3dlcjogdGFwOyBEYXRhOiBzb3J0OyBTZWN1cml0eTogWmlwLVphcDsgTW9kZWw6IHB1enpsZTtcbiAqICAgICAgICAgICAgICAgQ29vbGluZzogZ3lyb3Njb3BlIHNwaXJpdC1sZXZlbCAod2l0aCB0b3VjaCBmYWxsYmFjaylcbiAqICBlbmRlZCAgICAgIOKGkiBmaW5hbCByZXN1bHRcbiAqL1xuaW1wb3J0IHsgdXNlQWlySmFtQ29udHJvbGxlciB9IGZyb20gXCJAYWlyLWphbS9zZGtcIjtcbmltcG9ydCB7IFN1cmZhY2VWaWV3cG9ydCB9IGZyb20gXCJAYWlyLWphbS9zZGsvdWlcIjtcbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEdBTUVfQ09ORklHIH0gZnJvbSBcIi4uL2dhbWUvY29uZmlnL2dhbWVDb25maWdcIjtcbmltcG9ydCB7XG4gIFJPTEVfQ09MT1JTLFxuICBST0xFX0lDT05TLFxuICBST0xFX0xBQkVMUyxcbiAgUk9MRV9NSU5JX0dBTUUsXG4gIHR5cGUgUGxheWVyUm9sZSxcbn0gZnJvbSBcIi4uL2dhbWUvZG9tYWluL3R5cGVzXCI7XG5pbXBvcnQgeyB1c2VGYWN0b3J5U3RvcmUsIHR5cGUgRmFjdG9yeVN0YXRlIH0gZnJvbSBcIi4uL2dhbWUvc3RvcmUvZmFjdG9yeVN0b3JlXCI7XG5cbi8vIOKUgOKUgCBQb3dlciBtaW5pLWdhbWUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmludGVyZmFjZSBQb3dlckdhbWVQcm9wcyB7XG4gIHByb2dyZXNzOiBudW1iZXI7XG4gIHN0YXR1czogc3RyaW5nO1xuICBzY29yZTogbnVtYmVyO1xuICBvblRhcDogKCkgPT4gdm9pZDtcbn1cblxuZnVuY3Rpb24gUG93ZXJHYW1lKHsgcHJvZ3Jlc3MsIHN0YXR1cywgc2NvcmUsIG9uVGFwIH06IFBvd2VyR2FtZVByb3BzKSB7XG4gIGNvbnN0IGlzQ29tcGxldGUgPSBzdGF0dXMgPT09IFwiY29tcGxldGVcIjtcbiAgY29uc3QgY29sb3IgPSBcIiNmYWNjMTVcIjtcblxuICAvLyBSaXBwbGUgc3RhdGU6IGVhY2ggdGFwIHNwYXducyBhIHNob3J0LWxpdmVkIHJpcHBsZSBlbGVtZW50LlxuICBjb25zdCBbcmlwcGxlcywgc2V0UmlwcGxlc10gPSB1c2VTdGF0ZTx7IGlkOiBudW1iZXI7IHg6IG51bWJlcjsgeTogbnVtYmVyIH1bXT4oW10pO1xuICBjb25zdCByaXBwbGVJZCA9IHVzZVJlZigwKTtcbiAgY29uc3QgYnRuUmVmID0gdXNlUmVmPEhUTUxCdXR0b25FbGVtZW50PihudWxsKTtcblxuICAvLyBUaHJvdHRsZSBndWFyZDogcHJldmVudCBkaXNwYXRjaGluZyBmYXN0ZXIgdGhhbiA4MCBtcyAoMTIgdGFwcy9zIG1heCkuXG4gIC8vIEdpdmVzIHRoZSBuZXR3b3JrIGEgY2hhbmNlIHRvIGJyZWF0aGUgd2hpbGUgc3RpbGwgZmVlbGluZyBpbnN0YW50LlxuICBjb25zdCBsYXN0VGFwUmVmID0gdXNlUmVmKDApO1xuXG4gIGNvbnN0IGhhbmRsZVBvaW50ZXJEb3duID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IFJlYWN0LlBvaW50ZXJFdmVudDxIVE1MQnV0dG9uRWxlbWVudD4pID0+IHtcbiAgICAgIGlmIChpc0NvbXBsZXRlKSByZXR1cm47XG5cbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICBpZiAobm93IC0gbGFzdFRhcFJlZi5jdXJyZW50IDwgODApIHJldHVybjtcbiAgICAgIGxhc3RUYXBSZWYuY3VycmVudCA9IG5vdztcblxuICAgICAgLy8gRmlyZSB0aGUgbmV0d29ya2VkIGFjdGlvbi5cbiAgICAgIG9uVGFwKCk7XG5cbiAgICAgIC8vIFNwYXduIGEgcmlwcGxlIGF0IHRoZSB0YXAgcG9zaXRpb24gcmVsYXRpdmUgdG8gdGhlIGJ1dHRvbi5cbiAgICAgIGlmIChidG5SZWYuY3VycmVudCkge1xuICAgICAgICBjb25zdCByZWN0ID0gYnRuUmVmLmN1cnJlbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGNvbnN0IHggPSBlLmNsaWVudFggLSByZWN0LmxlZnQ7XG4gICAgICAgIGNvbnN0IHkgPSBlLmNsaWVudFkgLSByZWN0LnRvcDtcbiAgICAgICAgY29uc3QgaWQgPSArK3JpcHBsZUlkLmN1cnJlbnQ7XG4gICAgICAgIHNldFJpcHBsZXMoKHByZXYpID0+IFsuLi5wcmV2LCB7IGlkLCB4LCB5IH1dKTtcbiAgICAgICAgLy8gUmVtb3ZlIHJpcHBsZSBhZnRlciBhbmltYXRpb24gY29tcGxldGVzLlxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFJpcHBsZXMoKHByZXYpID0+IHByZXYuZmlsdGVyKChyKSA9PiByLmlkICE9PSBpZCkpLCA2MDApO1xuICAgICAgfVxuICAgIH0sXG4gICAgW2lzQ29tcGxldGUsIG9uVGFwXSxcbiAgKTtcblxuICAvLyBDaXJjdW1mZXJlbmNlIG9mIHRoZSBTVkcgcHJvZ3Jlc3MgcmluZy5cbiAgY29uc3QgcmFkaXVzID0gOTA7XG4gIGNvbnN0IGNpcmMgPSAyICogTWF0aC5QSSAqIHJhZGl1cztcbiAgY29uc3QgZGFzaE9mZnNldCA9IGNpcmMgLSAocHJvZ3Jlc3MgLyAxMDApICogY2lyYztcblxuICBpZiAoaXNDb21wbGV0ZSkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTZcIlxuICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcInJhZGlhbC1ncmFkaWVudChlbGxpcHNlIGF0IGNlbnRlciwgI2ZhY2MxNTIwIDAlLCB0cmFuc3BhcmVudCA3MCUpXCIgfX1cbiAgICAgID5cbiAgICAgICAgey8qIENvbXBsZXRpb24gZ2xvdyByaW5nICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwicG93ZXItY29tcGxldGUtcmluZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICB3aWR0aDogMjIwLFxuICAgICAgICAgICAgaGVpZ2h0OiAyMjAsXG4gICAgICAgICAgICBib3JkZXI6IFwiNHB4IHNvbGlkICNmYWNjMTVcIixcbiAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDAgNjBweCAjZmFjYzE1YWEsIDAgMCAxMjBweCAjZmFjYzE1NDBcIixcbiAgICAgICAgICAgIGFuaW1hdGlvbjogXCJwb3dlckNvbXBsZXRlIDEuNXMgZWFzZS1pbi1vdXQgaW5maW5pdGUgYWx0ZXJuYXRlXCIsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDgwIH19PuKaoTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiXG4gICAgICAgICAgc3R5bGU9e3sgY29sb3I6IFwiI2ZhY2MxNVwiLCB0ZXh0U2hhZG93OiBcIjAgMCAyMHB4ICNmYWNjMTVcIiB9fVxuICAgICAgICA+XG4gICAgICAgICAgUE9XRVIgT05MSU5FXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5EZXBhcnRtZW50IHNjb3JlOiB7c2NvcmUudG9Mb2NhbGVTdHJpbmcoKX0gcHRzPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTRcIj5cblxuICAgICAgey8qIEhlYWRlciBzdGF0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5Qcm9ncmVzczwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtMnhsIGZvbnQtYmxhY2tcIiBzdHlsZT17eyBjb2xvciB9fT5cbiAgICAgICAgICAgIHtwcm9ncmVzc30lXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwXCI+U2NvcmU8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNreS0zMDBcIj5cbiAgICAgICAgICAgIHtzY29yZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlBlciBUYXA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgK3tHQU1FX0NPTkZJRy5wb3dlckluY3JlbWVudFBlclRhcH0lXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTVkcgcHJvZ3Jlc3MgcmluZyArIFRBUCBidXR0b24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICB7LyogUmluZyAqL31cbiAgICAgICAgPHN2Z1xuICAgICAgICAgIHdpZHRoPXsyMjB9XG4gICAgICAgICAgaGVpZ2h0PXsyMjB9XG4gICAgICAgICAgdmlld0JveD1cIjAgMCAyMjAgMjIwXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZVwiXG4gICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBcInJvdGF0ZSgtOTBkZWcpXCIgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHsvKiBUcmFjayAqL31cbiAgICAgICAgICA8Y2lyY2xlIGN4PXsxMTB9IGN5PXsxMTB9IHI9e3JhZGl1c30gZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjMWUyOTNiXCIgc3Ryb2tlV2lkdGg9ezEwfSAvPlxuICAgICAgICAgIHsvKiBGaWxsICovfVxuICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgIGN4PXsxMTB9XG4gICAgICAgICAgICBjeT17MTEwfVxuICAgICAgICAgICAgcj17cmFkaXVzfVxuICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgc3Ryb2tlPXtjb2xvcn1cbiAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsxMH1cbiAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICBzdHJva2VEYXNoYXJyYXk9e2NpcmN9XG4gICAgICAgICAgICBzdHJva2VEYXNob2Zmc2V0PXtkYXNoT2Zmc2V0fVxuICAgICAgICAgICAgc3R5bGU9e3sgdHJhbnNpdGlvbjogXCJzdHJva2UtZGFzaG9mZnNldCAwLjJzIGVhc2Utb3V0XCIsIGZpbHRlcjogYGRyb3Atc2hhZG93KDAgMCA2cHggJHtjb2xvcn0pYCB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvc3ZnPlxuXG4gICAgICAgIHsvKiBUQVAgYnV0dG9uICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgcmVmPXtidG5SZWZ9XG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgaWQ9XCJwb3dlci10YXAtYnRuXCJcbiAgICAgICAgICBvblBvaW50ZXJEb3duPXtoYW5kbGVQb2ludGVyRG93bn1cbiAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIHNlbGVjdC1ub25lXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgd2lkdGg6IDE2MCxcbiAgICAgICAgICAgIGhlaWdodDogMTYwLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogYHJhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgNDAlIDM1JSwgI2ZhY2MxNTMwLCAjZmFjYzE1MDgpYCxcbiAgICAgICAgICAgIGJvcmRlcjogYDNweCBzb2xpZCAke2NvbG9yfTgwYCxcbiAgICAgICAgICAgIGJveFNoYWRvdzogYDAgMCAzMHB4ICR7Y29sb3J9NDAsIGluc2V0IDAgMCAyMHB4ICR7Y29sb3J9MTBgLFxuICAgICAgICAgICAgV2Via2l0VGFwSGlnaGxpZ2h0Q29sb3I6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgICAgICAgIHRvdWNoQWN0aW9uOiBcIm5vbmVcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgey8qIFJpcHBsZXMgKi99XG4gICAgICAgICAge3JpcHBsZXMubWFwKChyKSA9PiAoXG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICBrZXk9e3IuaWR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBvd2VyLXJpcHBsZVwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgbGVmdDogci54LFxuICAgICAgICAgICAgICAgIHRvcDogci55LFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTEgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IDUyIH19PuKaoTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3IgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgVEFQXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9ncmVzcyBiYXIgYXQgYm90dG9tICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgIDxzcGFuPlBvd2VyIEdyaWQ8L3NwYW4+XG4gICAgICAgICAgPHNwYW4+e3Byb2dyZXNzfSAvIDEwMCU8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMyBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIHdpZHRoOiBgJHtwcm9ncmVzc30lYCxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogYGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzg1NGQwZSwgJHtjb2xvcn0pYCxcbiAgICAgICAgICAgICAgYm94U2hhZG93OiBgMCAwIDhweCAke2NvbG9yfTgwYCxcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJ3aWR0aCAwLjE1cyBlYXNlLW91dFwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyDilIDilIAgQ29vbGluZyB0ZW1wZXJhdHVyZSBkZXYgcGFuZWwg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIENvb2xpbmdEZXZQYW5lbCh7XG4gIHRlbXBlcmF0dXJlLFxuICBvblNldCxcbn06IHtcbiAgdGVtcGVyYXR1cmU6IG51bWJlcjtcbiAgb25TZXQ6ICh0OiBudW1iZXIpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IFtsb2NhbFRlbXAsIHNldExvY2FsVGVtcF0gPSB1c2VTdGF0ZSh0ZW1wZXJhdHVyZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC00IHctZnVsbFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTV4bCBmb250LWJsYWNrIHRleHQtc2t5LTMwMCBmb250LW1vbm9cIj5cbiAgICAgICAge2xvY2FsVGVtcC50b0ZpeGVkKDApfcKwQ1xuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgU2FmZSB6b25lOiB7R0FNRV9DT05GSUcuY29vbGluZ1NhZmVNaW594oCTe0dBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWF4fcKwQ1xuICAgICAgPC9kaXY+XG5cbiAgICAgIDxpbnB1dFxuICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICBtaW49ezUwfVxuICAgICAgICBtYXg9ezEyMH1cbiAgICAgICAgdmFsdWU9e2xvY2FsVGVtcH1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgY29uc3QgdCA9IE51bWJlcihlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgc2V0TG9jYWxUZW1wKHQpO1xuICAgICAgICAgIG9uU2V0KHQpO1xuICAgICAgICB9fVxuICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LXNreS00MDBcIlxuICAgICAgICBzdHlsZT17eyB0b3VjaEFjdGlvbjogXCJub25lXCIgfX1cbiAgICAgIC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyB3LWZ1bGxcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uIGZsZXgtMSByb3VuZGVkLXhsIGJnLXNreS01MDAvMjAgYm9yZGVyIGJvcmRlci1za3ktNTAwLzQwIHB5LTMgdGV4dC1za3ktMzAwIGZvbnQtYm9sZCB0ZXh0LWxnIGhvdmVyOmJnLXNreS01MDAvMzAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0ID0gTWF0aC5tYXgoNTAsIGxvY2FsVGVtcCAtIDUpO1xuICAgICAgICAgICAgc2V0TG9jYWxUZW1wKHQpO1xuICAgICAgICAgICAgb25TZXQodCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIOKIkiBDb29sXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY3RybC1idXR0b24gZmxleC0xIHJvdW5kZWQteGwgYmctb3JhbmdlLTUwMC8yMCBib3JkZXIgYm9yZGVyLW9yYW5nZS01MDAvNDAgcHktMyB0ZXh0LW9yYW5nZS0zMDAgZm9udC1ib2xkIHRleHQtbGcgaG92ZXI6Ymctb3JhbmdlLTUwMC8zMCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHQgPSBNYXRoLm1pbigxMjAsIGxvY2FsVGVtcCArIDUpO1xuICAgICAgICAgICAgc2V0TG9jYWxUZW1wKHQpO1xuICAgICAgICAgICAgb25TZXQodCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgICsgSGVhdFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyDilIDilIAgRGF0YSBDbGVhbmluZyBtaW5pLWdhbWUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbnR5cGUgRGF0YUJ1Y2tldCA9IFwibnVtYmVyc1wiIHwgXCJhaV90ZXJtc1wiO1xuXG4vKiogRGV0ZXJtaW5lIHdoaWNoIGJ1Y2tldCBhIHRva2VuIGJlbG9uZ3MgdG8uICovXG5mdW5jdGlvbiBjb3JyZWN0QnVja2V0KHRva2VuOiBzdHJpbmcpOiBEYXRhQnVja2V0IHtcbiAgcmV0dXJuIChHQU1FX0NPTkZJRy5kYXRhVG9rZW5zTnVtYmVycyBhcyByZWFkb25seSBzdHJpbmdbXSkuaW5jbHVkZXModG9rZW4pXG4gICAgPyBcIm51bWJlcnNcIlxuICAgIDogXCJhaV90ZXJtc1wiO1xufVxuXG5pbnRlcmZhY2UgRGF0YUdhbWVQcm9wcyB7XG4gIHByb2dyZXNzOiBudW1iZXI7XG4gIHN0YXR1czogc3RyaW5nO1xuICBzY29yZTogbnVtYmVyO1xuICBvblNvcnQ6ICh0b2tlbjogc3RyaW5nLCBidWNrZXQ6IERhdGFCdWNrZXQsIGNvcnJlY3Q6IGJvb2xlYW4pID0+IHZvaWQ7XG59XG5cbmludGVyZmFjZSBEYXRhVG9rZW4ge1xuICBpZDogbnVtYmVyO1xuICB2YWx1ZTogc3RyaW5nO1xuICAvKiogVHJhbnNpZW50IGZlZWRiYWNrOiB1bmRlZmluZWQgfCAnY29ycmVjdCcgfCAnd3JvbmcnICovXG4gIGZlZWRiYWNrPzogXCJjb3JyZWN0XCIgfCBcIndyb25nXCI7XG59XG5cbmZ1bmN0aW9uIERhdGFDbGVhbmluZ0dhbWUoeyBwcm9ncmVzcywgc3RhdHVzLCBzY29yZSwgb25Tb3J0IH06IERhdGFHYW1lUHJvcHMpIHtcbiAgY29uc3QgaXNDb21wbGV0ZSA9IHN0YXR1cyA9PT0gXCJjb21wbGV0ZVwiO1xuICBjb25zdCBjb2xvciA9IFwiIzYwYTVmYVwiO1xuXG4gIC8vIEJ1aWxkIGEgc2h1ZmZsZWQgdG9rZW4gcG9vbCBmcm9tIGJvdGggY2F0ZWdvcmllcy5cbiAgY29uc3QgYWxsVG9rZW5zID0gW1xuICAgIC4uLihHQU1FX0NPTkZJRy5kYXRhVG9rZW5zTnVtYmVycyBhcyByZWFkb25seSBzdHJpbmdbXSksXG4gICAgLi4uKEdBTUVfQ09ORklHLmRhdGFUb2tlbnNBaVRlcm1zIGFzIHJlYWRvbmx5IHN0cmluZ1tdKSxcbiAgXTtcblxuICBjb25zdCB0b2tlbklkUmVmID0gdXNlUmVmKDApO1xuICBjb25zdCBsYXN0U29ydFJlZiA9IHVzZVJlZigwKTtcblxuICAvKiogUGljayB0aGUgbmV4dCB0b2tlbiBhdCByYW5kb20sIGVuc3VyaW5nIHdlIGtlZXAgcm90YXRpbmcgdGhlIHBvb2wuICovXG4gIGNvbnN0IG5leHRUb2tlbiA9IHVzZUNhbGxiYWNrKCgpOiBEYXRhVG9rZW4gPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gYWxsVG9rZW5zW01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGFsbFRva2Vucy5sZW5ndGgpXTtcbiAgICByZXR1cm4geyBpZDogKyt0b2tlbklkUmVmLmN1cnJlbnQsIHZhbHVlIH07XG4gIH0sIFtdKTtcblxuICAvLyBRdWV1ZSBvZiB0b2tlbnMgdmlzaWJsZSBvbiBzY3JlZW4gKHdlIHNob3cgMSBhY3RpdmUgYXQgYSB0aW1lLCBxdWV1ZSA9IHVwY29taW5nKS5cbiAgY29uc3QgW2FjdGl2ZVRva2VuLCBzZXRBY3RpdmVUb2tlbl0gPSB1c2VTdGF0ZTxEYXRhVG9rZW4+KCgpID0+IG5leHRUb2tlbigpKTtcbiAgY29uc3QgW2ZlZWRiYWNrVG9rZW4sIHNldEZlZWRiYWNrVG9rZW5dID0gdXNlU3RhdGU8RGF0YVRva2VuIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQnVja2V0IHNoYWtlIGZlZWRiYWNrOiBudWxsIHwgJ251bWJlcnMnIHwgJ2FpX3Rlcm1zJ1xuICBjb25zdCBbc2hha2VCdWNrZXQsIHNldFNoYWtlQnVja2V0XSA9IHVzZVN0YXRlPERhdGFCdWNrZXQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2RyYWdPdmVyLCBzZXREcmFnT3Zlcl0gPSB1c2VTdGF0ZTxEYXRhQnVja2V0IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQW5pbWF0ZSBpbiBuZXcgdG9rZW4gb24gbW91bnQvY2hhbmdlLlxuICBjb25zdCBbdG9rZW5LZXksIHNldFRva2VuS2V5XSA9IHVzZVN0YXRlKDApO1xuXG4gIGNvbnN0IGhhbmRsZURyb3AgPSB1c2VDYWxsYmFjayhcbiAgICAoYnVja2V0OiBEYXRhQnVja2V0KSA9PiB7XG4gICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgaWYgKG5vdyAtIGxhc3RTb3J0UmVmLmN1cnJlbnQgPCBHQU1FX0NPTkZJRy5kYXRhU29ydFRocm90dGxlTXMpIHJldHVybjtcbiAgICAgIGxhc3RTb3J0UmVmLmN1cnJlbnQgPSBub3c7XG5cbiAgICAgIGNvbnN0IHRva2VuID0gYWN0aXZlVG9rZW47XG4gICAgICBjb25zdCBpc0NvcnJlY3QgPSBjb3JyZWN0QnVja2V0KHRva2VuLnZhbHVlKSA9PT0gYnVja2V0O1xuXG4gICAgICBpZiAoaXNDb3JyZWN0KSB7XG4gICAgICAgIC8vIFNob3cgY29ycmVjdCBmZWVkYmFjayBicmllZmx5LCB0aGVuIGFkdmFuY2UgdG8gbmV4dCB0b2tlbi5cbiAgICAgICAgc2V0RmVlZGJhY2tUb2tlbih7IC4uLnRva2VuLCBmZWVkYmFjazogXCJjb3JyZWN0XCIgfSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHNldEZlZWRiYWNrVG9rZW4obnVsbCk7XG4gICAgICAgICAgc2V0QWN0aXZlVG9rZW4obmV4dFRva2VuKCkpO1xuICAgICAgICAgIHNldFRva2VuS2V5KChrKSA9PiBrICsgMSk7XG4gICAgICAgIH0sIDQyMCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBTaGFrZSB0aGUgd3JvbmcgYnVja2V0LCBrZWVwIHRoZSBzYW1lIHRva2VuLlxuICAgICAgICBzZXRTaGFrZUJ1Y2tldChidWNrZXQpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFNoYWtlQnVja2V0KG51bGwpLCAzODApO1xuICAgICAgfVxuXG4gICAgICBvblNvcnQodG9rZW4udmFsdWUsIGJ1Y2tldCwgaXNDb3JyZWN0KTtcbiAgICB9LFxuICAgIFthY3RpdmVUb2tlbiwgbmV4dFRva2VuLCBvblNvcnRdLFxuICApO1xuXG4gIC8vIFRvdWNoLXRhcCBpbnRlcmFjdGlvbiBmb3IgbW9iaWxlOiB0YXAgYSBidWNrZXQgdG8gc29ydCB0aGUgYWN0aXZlIHRva2VuLlxuICBjb25zdCBoYW5kbGVCdWNrZXRUYXAgPSB1c2VDYWxsYmFjayhcbiAgICAoYnVja2V0OiBEYXRhQnVja2V0KSA9PiB7XG4gICAgICBpZiAoaXNDb21wbGV0ZSkgcmV0dXJuO1xuICAgICAgaGFuZGxlRHJvcChidWNrZXQpO1xuICAgIH0sXG4gICAgW2lzQ29tcGxldGUsIGhhbmRsZURyb3BdLFxuICApO1xuXG4gIC8vIFNWRyBwcm9ncmVzcyByaW5nLlxuICBjb25zdCByYWRpdXMgPSA3MjtcbiAgY29uc3QgY2lyYyA9IDIgKiBNYXRoLlBJICogcmFkaXVzO1xuICBjb25zdCBkYXNoT2Zmc2V0ID0gY2lyYyAtIChwcm9ncmVzcyAvIDEwMCkgKiBjaXJjO1xuXG4gIGlmIChpc0NvbXBsZXRlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgdy1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNlwiXG4gICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgY2VudGVyLCAjNjBhNWZhMjAgMCUsIHRyYW5zcGFyZW50IDcwJSlcIiB9fVxuICAgICAgPlxuICAgICAgICB7LyogQ29tcGxldGlvbiBnbG93IHJpbmcgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICB3aWR0aDogMTgwLFxuICAgICAgICAgICAgaGVpZ2h0OiAxODAsXG4gICAgICAgICAgICBib3JkZXI6IFwiNHB4IHNvbGlkICM2MGE1ZmFcIixcbiAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDAgNjBweCAjNjBhNWZhYWEsIDAgMCAxMjBweCAjNjBhNWZhNDBcIixcbiAgICAgICAgICAgIGFuaW1hdGlvbjogXCJkYXRhQ29tcGxldGUgMS41cyBlYXNlLWluLW91dCBpbmZpbml0ZSBhbHRlcm5hdGVcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogNjQgfX0+8J+SvjwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiXG4gICAgICAgICAgc3R5bGU9e3sgY29sb3IsIHRleHRTaGFkb3c6IFwiMCAwIDIwcHggIzYwYTVmYVwiIH19XG4gICAgICAgID5cbiAgICAgICAgICBEQVRBIENMRUFOXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5EZXBhcnRtZW50IHNjb3JlOiB7c2NvcmUudG9Mb2NhbGVTdHJpbmcoKX0gcHRzPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTQgZ2FwLTNcIj5cblxuICAgICAgey8qIEhlYWRlciBzdGF0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5Qcm9ncmVzczwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtMnhsIGZvbnQtYmxhY2tcIiBzdHlsZT17eyBjb2xvciB9fT5cbiAgICAgICAgICAgIHtwcm9ncmVzc30lXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwXCI+U2NvcmU8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNreS0zMDBcIj5cbiAgICAgICAgICAgIHtzY29yZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlBlciBTb3J0PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICt7R0FNRV9DT05GSUcucG9pbnRzUGVyRGF0YVNvcnR9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTVkcgcHJvZ3Jlc3MgcmluZyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIiBzdHlsZT17eyB3aWR0aDogMTcwLCBoZWlnaHQ6IDE3MCwgZmxleFNocmluazogMCB9fT5cbiAgICAgICAgPHN2ZyB3aWR0aD17MTcwfSBoZWlnaHQ9ezE3MH0gdmlld0JveD1cIjAgMCAxNzAgMTcwXCIgY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyB0cmFuc2Zvcm06IFwicm90YXRlKC05MGRlZylcIiB9fT5cbiAgICAgICAgICA8Y2lyY2xlIGN4PXs4NX0gY3k9ezg1fSByPXtyYWRpdXN9IGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzFlMjkzYlwiIHN0cm9rZVdpZHRoPXs4fSAvPlxuICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgIGN4PXs4NX0gY3k9ezg1fSByPXtyYWRpdXN9IGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHN0cm9rZT17Y29sb3J9IHN0cm9rZVdpZHRoPXs4fSBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtjaXJjfVxuICAgICAgICAgICAgc3Ryb2tlRGFzaG9mZnNldD17ZGFzaE9mZnNldH1cbiAgICAgICAgICAgIHN0eWxlPXt7IHRyYW5zaXRpb246IFwic3Ryb2tlLWRhc2hvZmZzZXQgMC4yNXMgZWFzZS1vdXRcIiwgZmlsdGVyOiBgZHJvcC1zaGFkb3coMCAwIDVweCAke2NvbG9yfSlgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9zdmc+XG4gICAgICAgIHsvKiBBY3RpdmUgdG9rZW4gY2FyZCAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGtleT17YHRva2VuLSR7dG9rZW5LZXl9YH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJkYXRhLXRva2VuLWVudGVyIHJlbGF0aXZlIHotMTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC0yeGwgc2VsZWN0LW5vbmVcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICB3aWR0aDogMTIwLFxuICAgICAgICAgICAgaGVpZ2h0OiAxMjAsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInJnYmEoMTUsIDMyLCA1MywgMC45NSlcIixcbiAgICAgICAgICAgIGJvcmRlcjogYDJweCBzb2xpZCAke2NvbG9yfTYwYCxcbiAgICAgICAgICAgIGJveFNoYWRvdzogYDAgMCAyMHB4ICR7Y29sb3J9MzBgLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMCBtYi0xXCI+U29ydCB0aGlzPC9kaXY+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYmxhY2sgdGV4dC0zeGxcIlxuICAgICAgICAgICAgc3R5bGU9e3sgY29sb3IgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7YWN0aXZlVG9rZW4udmFsdWV9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTYwMCBtdC0xIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgVGFwIGEgYnVja2V0XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDb3JyZWN0IGZlZWRiYWNrIG92ZXJsYXkgKi99XG4gICAgICAgIHtmZWVkYmFja1Rva2VuICYmIChcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJkYXRhLXNvcnQtY29ycmVjdCBhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IHpJbmRleDogMjAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYmxhY2sgdGV4dC1ncmVlbi00MDBcIj7inJM8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQnVja2V0IHRhcCB0YXJnZXRzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBnYXAtMyBweC0yXCI+XG4gICAgICAgIHsvKiBOdW1iZXJzIGJ1Y2tldCAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGlkPVwiZGF0YS1idWNrZXQtbnVtYmVyc1wiXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25Qb2ludGVyRG93bj17KCkgPT4gaGFuZGxlQnVja2V0VGFwKFwibnVtYmVyc1wiKX1cbiAgICAgICAgICBvbkRyYWdPdmVyPXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IHNldERyYWdPdmVyKFwibnVtYmVyc1wiKTsgfX1cbiAgICAgICAgICBvbkRyYWdMZWF2ZT17KCkgPT4gc2V0RHJhZ092ZXIobnVsbCl9XG4gICAgICAgICAgb25Ecm9wPXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IHNldERyYWdPdmVyKG51bGwpOyBoYW5kbGVEcm9wKFwibnVtYmVyc1wiKTsgfX1cbiAgICAgICAgICBjbGFzc05hbWU9e1tcbiAgICAgICAgICAgIFwiY3RybC1idXR0b24gZmxleC0xIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtMnhsIGJvcmRlci0yIHB5LTUgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1XCIsXG4gICAgICAgICAgICBzaGFrZUJ1Y2tldCA9PT0gXCJudW1iZXJzXCIgPyBcImRhdGEtYnVja2V0LXNoYWtlXCIgOiBcIlwiLFxuICAgICAgICAgICAgZHJhZ092ZXIgPT09IFwibnVtYmVyc1wiID8gXCJkYXRhLWJ1Y2tldC1vdmVyXCIgOiBcIlwiLFxuICAgICAgICAgIF0uam9pbihcIiBcIil9XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSg5NiwgMTY1LCAyNTAsIDAuMDgpXCIsXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogZHJhZ092ZXIgPT09IFwibnVtYmVyc1wiID8gXCIjNjBhNWZhXCIgOiBcInJnYmEoOTYsIDE2NSwgMjUwLCAwLjM1KVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsXCI+8J+UojwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiIHN0eWxlPXt7IGNvbG9yIH19Pk51bWJlcnM8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+NDIsIDcsIDI1NuKApjwvZGl2PlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogQUkgVGVybXMgYnVja2V0ICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgaWQ9XCJkYXRhLWJ1Y2tldC1haS10ZXJtc1wiXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25Qb2ludGVyRG93bj17KCkgPT4gaGFuZGxlQnVja2V0VGFwKFwiYWlfdGVybXNcIil9XG4gICAgICAgICAgb25EcmFnT3Zlcj17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBzZXREcmFnT3ZlcihcImFpX3Rlcm1zXCIpOyB9fVxuICAgICAgICAgIG9uRHJhZ0xlYXZlPXsoKSA9PiBzZXREcmFnT3ZlcihudWxsKX1cbiAgICAgICAgICBvbkRyb3A9eyhlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0RHJhZ092ZXIobnVsbCk7IGhhbmRsZURyb3AoXCJhaV90ZXJtc1wiKTsgfX1cbiAgICAgICAgICBjbGFzc05hbWU9e1tcbiAgICAgICAgICAgIFwiY3RybC1idXR0b24gZmxleC0xIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtMnhsIGJvcmRlci0yIHB5LTUgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1XCIsXG4gICAgICAgICAgICBzaGFrZUJ1Y2tldCA9PT0gXCJhaV90ZXJtc1wiID8gXCJkYXRhLWJ1Y2tldC1zaGFrZVwiIDogXCJcIixcbiAgICAgICAgICAgIGRyYWdPdmVyID09PSBcImFpX3Rlcm1zXCIgPyBcImRhdGEtYnVja2V0LW92ZXJcIiA6IFwiXCIsXG4gICAgICAgICAgXS5qb2luKFwiIFwiKX1cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDk2LCAxNjUsIDI1MCwgMC4wOClcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOiBkcmFnT3ZlciA9PT0gXCJhaV90ZXJtc1wiID8gXCIjNjBhNWZhXCIgOiBcInJnYmEoOTYsIDE2NSwgMjUwLCAwLjM1KVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsXCI+8J+noDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiIHN0eWxlPXt7IGNvbG9yIH19PkFJIFRlcm1zPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMFwiPkFJLCBNTCwgR1BV4oCmPC9kaXY+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9ncmVzcyBiYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBweC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMSBmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgPHNwYW4+RGF0YSBQaXBlbGluZTwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57cHJvZ3Jlc3N9IC8gMTAwJTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC0zIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgd2lkdGg6IGAke3Byb2dyZXNzfSVgLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjMWUzYTVmLCAke2NvbG9yfSlgLFxuICAgICAgICAgICAgICBib3hTaGFkb3c6IGAwIDAgOHB4ICR7Y29sb3J9ODBgLFxuICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcIndpZHRoIDAuMnMgZWFzZS1vdXRcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLy8g4pSA4pSAIFppcC1aYXAgRmlyZXdhbGwgbWluaS1nYW1lIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG50eXBlIFppcFphcFN0ZXAgPSBcIlpJUFwiIHwgXCJaQVBcIjtcblxuZnVuY3Rpb24gZ2VuZXJhdGVTZXF1ZW5jZShsZW5ndGg6IG51bWJlcik6IFppcFphcFN0ZXBbXSB7XG4gIGNvbnN0IHNlcTogWmlwWmFwU3RlcFtdID0gW107XG4gIC8vIEd1YXJhbnRlZSBpdCBhbHdheXMgYWx0ZXJuYXRlcyBhdCBsZWFzdCBvbmNlIHRoZW4gZ29lcyByYW5kb20uXG4gIGxldCBsYXN0OiBaaXBaYXBTdGVwIHwgbnVsbCA9IG51bGw7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAvLyBCaWFzIHRvd2FyZCBhbHRlcm5hdGluZyB0byBrZWVwIGl0IHJlYWRhYmxlIGF0IGFueSBsZW5ndGguXG4gICAgY29uc3Qgb3B0aW9uczogWmlwWmFwU3RlcFtdID0gbGFzdCA9PT0gXCJaSVBcIiA/IFtcIlpBUFwiLCBcIlpBUFwiLCBcIlpJUFwiXSA6IFtcIlpJUFwiLCBcIlpJUFwiLCBcIlpBUFwiXTtcbiAgICBjb25zdCBuZXh0ID0gb3B0aW9uc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBvcHRpb25zLmxlbmd0aCldO1xuICAgIHNlcS5wdXNoKG5leHQpO1xuICAgIGxhc3QgPSBuZXh0O1xuICB9XG4gIHJldHVybiBzZXE7XG59XG5cbmludGVyZmFjZSBaaXBaYXBHYW1lUHJvcHMge1xuICBwcm9ncmVzczogbnVtYmVyO1xuICBzdGF0dXM6IHN0cmluZztcbiAgc2NvcmU6IG51bWJlcjtcbiAgb25aaXBaYXA6IChoaXQ6IGJvb2xlYW4pID0+IHZvaWQ7XG59XG5cbmZ1bmN0aW9uIFppcFphcEdhbWUoeyBwcm9ncmVzcywgc3RhdHVzLCBzY29yZSwgb25aaXBaYXAgfTogWmlwWmFwR2FtZVByb3BzKSB7XG4gIGNvbnN0IGlzQ29tcGxldGUgPSBzdGF0dXMgPT09IFwiY29tcGxldGVcIjtcbiAgY29uc3QgY29sb3IgPSBcIiMzNGQzOTlcIjsgLy8gZW1lcmFsZCDigJQgc2VjdXJpdHkgcm9sZSBjb2xvclxuXG4gIC8vIExvY2FsIHNlcXVlbmNlIHN0YXRlLlxuICBjb25zdCBbc2VxdWVuY2UsIHNldFNlcXVlbmNlXSA9IHVzZVN0YXRlPFppcFphcFN0ZXBbXT4oKCkgPT5cbiAgICBnZW5lcmF0ZVNlcXVlbmNlKEdBTUVfQ09ORklHLnNlY3VyaXR5U2VxdWVuY2VTZWVkTGVuZ3RoKSxcbiAgKTtcbiAgY29uc3QgW2N1cnJlbnRTdGVwLCBzZXRDdXJyZW50U3RlcF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3RvdGFsSGl0cywgc2V0VG90YWxIaXRzXSA9IHVzZVN0YXRlKDApO1xuXG4gIC8vIFBlci1idXR0b24gYW5pbWF0aW9uIGNsYXNzOiBudWxsIHwgJ2NvcnJlY3QnIHwgJ3dyb25nJ1xuICBjb25zdCBbemlwQW5pbSwgc2V0WmlwQW5pbV0gPSB1c2VTdGF0ZTxcImNvcnJlY3RcIiB8IFwid3JvbmdcIiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbemFwQW5pbSwgc2V0WmFwQW5pbV0gPSB1c2VTdGF0ZTxcImNvcnJlY3RcIiB8IFwid3JvbmdcIiB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGxhc3RQcmVzc1JlZiA9IHVzZVJlZigwKTtcbiAgY29uc3QgemlwQW5pbVRpbWVyID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHphcEFuaW1UaW1lciA9IHVzZVJlZjxSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGNsZWFyWmlwQW5pbSA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFppcEFuaW0obnVsbCksIFtdKTtcbiAgY29uc3QgY2xlYXJaYXBBbmltID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0WmFwQW5pbShudWxsKSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZVByZXNzID0gdXNlQ2FsbGJhY2soXG4gICAgKHByZXNzZWQ6IFppcFphcFN0ZXApID0+IHtcbiAgICAgIGlmIChpc0NvbXBsZXRlKSByZXR1cm47XG5cbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICBpZiAobm93IC0gbGFzdFByZXNzUmVmLmN1cnJlbnQgPCBHQU1FX0NPTkZJRy5zZWN1cml0eUhpdFRocm90dGxlTXMpIHJldHVybjtcbiAgICAgIGxhc3RQcmVzc1JlZi5jdXJyZW50ID0gbm93O1xuXG4gICAgICBjb25zdCBleHBlY3RlZCA9IHNlcXVlbmNlW2N1cnJlbnRTdGVwXTtcbiAgICAgIGNvbnN0IGlzSGl0ID0gcHJlc3NlZCA9PT0gZXhwZWN0ZWQ7XG5cbiAgICAgIG9uWmlwWmFwKGlzSGl0KTtcblxuICAgICAgaWYgKGlzSGl0KSB7XG4gICAgICAgIGNvbnN0IG5leHRIaXRzID0gdG90YWxIaXRzICsgMTtcbiAgICAgICAgc2V0VG90YWxIaXRzKG5leHRIaXRzKTtcblxuICAgICAgICAvLyBDbGVhciBvbGQgYW5pbWF0aW9uIHRoZW4gcmUtdHJpZ2dlciAoZm9yY2VzIHJlLXJlbmRlciBzbyBhbmltYXRpb24gcmVwbGF5cykuXG4gICAgICAgIGlmIChwcmVzc2VkID09PSBcIlpJUFwiKSB7XG4gICAgICAgICAgc2V0WmlwQW5pbShudWxsKTtcbiAgICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gc2V0WmlwQW5pbShcImNvcnJlY3RcIikpO1xuICAgICAgICAgIGlmICh6aXBBbmltVGltZXIuY3VycmVudCkgY2xlYXJUaW1lb3V0KHppcEFuaW1UaW1lci5jdXJyZW50KTtcbiAgICAgICAgICB6aXBBbmltVGltZXIuY3VycmVudCA9IHNldFRpbWVvdXQoY2xlYXJaaXBBbmltLCAzODApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldFphcEFuaW0obnVsbCk7XG4gICAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHNldFphcEFuaW0oXCJjb3JyZWN0XCIpKTtcbiAgICAgICAgICBpZiAoemFwQW5pbVRpbWVyLmN1cnJlbnQpIGNsZWFyVGltZW91dCh6YXBBbmltVGltZXIuY3VycmVudCk7XG4gICAgICAgICAgemFwQW5pbVRpbWVyLmN1cnJlbnQgPSBzZXRUaW1lb3V0KGNsZWFyWmFwQW5pbSwgMzgwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5leHRTdGVwID0gY3VycmVudFN0ZXAgKyAxO1xuICAgICAgICBpZiAobmV4dFN0ZXAgPj0gc2VxdWVuY2UubGVuZ3RoKSB7XG4gICAgICAgICAgLy8gU2VxdWVuY2UgY29tcGxldGUg4oCUIGdlbmVyYXRlIGEgbmV3IChwb3NzaWJseSBsb25nZXIpIG9uZS5cbiAgICAgICAgICBjb25zdCBncm93QXQgPSBHQU1FX0NPTkZJRy5zZWN1cml0eVNlcXVlbmNlR3Jvd0V2ZXJ5O1xuICAgICAgICAgIGNvbnN0IG5ld0xlbiA9IEdBTUVfQ09ORklHLnNlY3VyaXR5U2VxdWVuY2VTZWVkTGVuZ3RoICsgTWF0aC5mbG9vcihuZXh0SGl0cyAvIGdyb3dBdCk7XG4gICAgICAgICAgc2V0U2VxdWVuY2UoZ2VuZXJhdGVTZXF1ZW5jZShNYXRoLm1pbihuZXdMZW4sIDEwKSkpO1xuICAgICAgICAgIHNldEN1cnJlbnRTdGVwKDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldEN1cnJlbnRTdGVwKG5leHRTdGVwKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gV3JvbmcgcHJlc3MuXG4gICAgICAgIGlmIChwcmVzc2VkID09PSBcIlpJUFwiKSB7XG4gICAgICAgICAgc2V0WmlwQW5pbShudWxsKTtcbiAgICAgICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gc2V0WmlwQW5pbShcIndyb25nXCIpKTtcbiAgICAgICAgICBpZiAoemlwQW5pbVRpbWVyLmN1cnJlbnQpIGNsZWFyVGltZW91dCh6aXBBbmltVGltZXIuY3VycmVudCk7XG4gICAgICAgICAgemlwQW5pbVRpbWVyLmN1cnJlbnQgPSBzZXRUaW1lb3V0KGNsZWFyWmlwQW5pbSwgNDUwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRaYXBBbmltKG51bGwpO1xuICAgICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiBzZXRaYXBBbmltKFwid3JvbmdcIikpO1xuICAgICAgICAgIGlmICh6YXBBbmltVGltZXIuY3VycmVudCkgY2xlYXJUaW1lb3V0KHphcEFuaW1UaW1lci5jdXJyZW50KTtcbiAgICAgICAgICB6YXBBbmltVGltZXIuY3VycmVudCA9IHNldFRpbWVvdXQoY2xlYXJaYXBBbmltLCA0NTApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBbaXNDb21wbGV0ZSwgc2VxdWVuY2UsIGN1cnJlbnRTdGVwLCB0b3RhbEhpdHMsIG9uWmlwWmFwLCBjbGVhclppcEFuaW0sIGNsZWFyWmFwQW5pbV0sXG4gICk7XG5cbiAgLy8gU1ZHIHByb2dyZXNzIHJpbmcuXG4gIGNvbnN0IHJhZGl1cyA9IDcyO1xuICBjb25zdCBjaXJjID0gMiAqIE1hdGguUEkgKiByYWRpdXM7XG4gIGNvbnN0IGRhc2hPZmZzZXQgPSBjaXJjIC0gKHByb2dyZXNzIC8gMTAwKSAqIGNpcmM7XG5cbiAgLy8gQ29tcGxldGlvbiBzY3JlZW4uXG4gIGlmIChpc0NvbXBsZXRlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgdy1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNlwiXG4gICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgY2VudGVyLCAjMzRkMzk5MjAgMCUsIHRyYW5zcGFyZW50IDcwJSlcIiB9fVxuICAgICAgPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgd2lkdGg6IDE4MCxcbiAgICAgICAgICAgIGhlaWdodDogMTgwLFxuICAgICAgICAgICAgYm9yZGVyOiBcIjRweCBzb2xpZCAjMzRkMzk5XCIsXG4gICAgICAgICAgICBib3hTaGFkb3c6IFwiMCAwIDYwcHggIzM0ZDM5OWFhLCAwIDAgMTIwcHggIzM0ZDM5OTQwXCIsXG4gICAgICAgICAgICBhbmltYXRpb246IFwic2VjdXJpdHlDb21wbGV0ZSAxLjVzIGVhc2UtaW4tb3V0IGluZmluaXRlIGFsdGVybmF0ZVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiA2NCB9fT7wn5uhPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCJcbiAgICAgICAgICBzdHlsZT17eyBjb2xvciwgdGV4dFNoYWRvdzogXCIwIDAgMjBweCAjMzRkMzk5XCIgfX1cbiAgICAgICAgPlxuICAgICAgICAgIEZJUkVXQUxMIEFDVElWRVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+RGVwYXJ0bWVudCBzY29yZToge3Njb3JlLnRvTG9jYWxlU3RyaW5nKCl9IHB0czwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtZnVsbCB3LWZ1bGwgZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweS0zIGdhcC0yXCI+XG5cbiAgICAgIHsvKiBIZWFkZXIgc3RhdHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwXCI+UHJvZ3Jlc3M8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LTJ4bCBmb250LWJsYWNrXCIgc3R5bGU9e3sgY29sb3IgfX0+XG4gICAgICAgICAgICB7cHJvZ3Jlc3N9JVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlNjb3JlPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1sZyBmb250LWJvbGQgdGV4dC1za3ktMzAwXCI+XG4gICAgICAgICAgICB7c2NvcmUudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5IaXRzPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgIHt0b3RhbEhpdHN9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9ncmVzcyByaW5nICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiIHN0eWxlPXt7IHdpZHRoOiAxNjAsIGhlaWdodDogMTYwLCBmbGV4U2hyaW5rOiAwIH19PlxuICAgICAgICA8c3ZnIHdpZHRoPXsxNjB9IGhlaWdodD17MTYwfSB2aWV3Qm94PVwiMCAwIDE2MCAxNjBcIiBjbGFzc05hbWU9XCJhYnNvbHV0ZVwiIHN0eWxlPXt7IHRyYW5zZm9ybTogXCJyb3RhdGUoLTkwZGVnKVwiIH19PlxuICAgICAgICAgIDxjaXJjbGUgY3g9ezgwfSBjeT17ODB9IHI9e3JhZGl1c30gZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjMWUyOTNiXCIgc3Ryb2tlV2lkdGg9ezh9IC8+XG4gICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgY3g9ezgwfSBjeT17ODB9IHI9e3JhZGl1c30gZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgc3Ryb2tlPXtjb2xvcn0gc3Ryb2tlV2lkdGg9ezh9IHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICBzdHJva2VEYXNoYXJyYXk9e2NpcmN9XG4gICAgICAgICAgICBzdHJva2VEYXNob2Zmc2V0PXtkYXNoT2Zmc2V0fVxuICAgICAgICAgICAgc3R5bGU9e3sgdHJhbnNpdGlvbjogXCJzdHJva2UtZGFzaG9mZnNldCAwLjNzIGVhc2Utb3V0XCIsIGZpbHRlcjogYGRyb3Atc2hhZG93KDAgMCA1cHggJHtjb2xvcn0pYCB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvc3ZnPlxuICAgICAgICB7LyogU2hpZWxkIGljb24gY2VudGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogNDQgfX0+8J+boTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IG10LTFcIiBzdHlsZT17eyBjb2xvciB9fT5GSVJFV0FMTDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNlcXVlbmNlIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xIHRleHQtY2VudGVyIHRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICBBdHRhY2sgU2VxdWVuY2Ug4oCUIHByZXNzIGluIG9yZGVyXG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7LyogVGhyZWF0IHNjYW4gYW5pbWF0aW9uIGNvbnRhaW5lciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bFwiIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwicmdiYSg1MiwyMTEsMTUzLDAuMDYpXCIsIGJvcmRlcjogXCIxcHggc29saWQgcmdiYSg1MiwyMTEsMTUzLDAuMilcIiB9fT5cbiAgICAgICAgICB7LyogU2Nhbi1saW5lIHRocmVhdCBlZmZlY3QgKi99XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGhyZWF0LXNjYW4tbGluZSBhYnNvbHV0ZSBpbnNldC15LTAgdy0xMiBwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwibGluZWFyLWdyYWRpZW50KDkwZGVnLCB0cmFuc3BhcmVudCwgcmdiYSg1MiwyMTEsMTUzLDAuMjUpLCB0cmFuc3BhcmVudClcIiB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC0zIHB5LTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICB7c2VxdWVuY2UubWFwKChzdGVwLCBpKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gaSA9PT0gY3VycmVudFN0ZXA7XG4gICAgICAgICAgICAgIGNvbnN0IGlzRG9uZSA9IGkgPCBjdXJyZW50U3RlcDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpc0FjdGl2ZSA/IFwiemlwemFwLXN0ZXAtYWN0aXZlXCIgOiBcIlwifVxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogXCJpbmxpbmUtZmxleFwiLFxuICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDQ0LFxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDI4LFxuICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxMSxcbiAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtbW9ubylcIixcbiAgICAgICAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjA4ZW1cIixcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogaXNEb25lXG4gICAgICAgICAgICAgICAgICAgICAgPyBcInJnYmEoNTIsMjExLDE1MywwLjA4KVwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcInJnYmEoNTIsMjExLDE1MywwLjI1KVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwicmdiYSgxNSwzMiw1MywwLjgpXCIsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogaXNEb25lXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIjFweCBzb2xpZCByZ2JhKDUyLDIxMSwxNTMsMC4xNSlcIlxuICAgICAgICAgICAgICAgICAgICAgIDogaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCIxLjVweCBzb2xpZCAjMzRkMzk5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCIxcHggc29saWQgcmdiYSg1MiwyMTEsMTUzLDAuMTUpXCIsXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBpc0RvbmUgPyBcIiMzNGQzOTk1NVwiIDogaXNBY3RpdmUgPyBcIiMzNGQzOTlcIiA6IFwiIzY0NzQ4YlwiLFxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcImFsbCAwLjE1cyBlYXNlXCIsXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc0RvbmUgPyBcIuKck1wiIDogc3RlcH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFpJUCAvIFpBUCBidXR0b25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBnYXAtMyBweC0yXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBpZD1cInNlY3VyaXR5LXppcC1idG5cIlxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uUG9pbnRlckRvd249eygpID0+IGhhbmRsZVByZXNzKFwiWklQXCIpfVxuICAgICAgICAgIGNsYXNzTmFtZT17W1xuICAgICAgICAgICAgXCJjdHJsLWJ1dHRvbiBmbGV4LTEgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgcm91bmRlZC0yeGwgYm9yZGVyLTIgcHktNiB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTUgc2VsZWN0LW5vbmVcIixcbiAgICAgICAgICAgIHppcEFuaW0gPT09IFwiY29ycmVjdFwiID8gXCJ6aXB6YXAtY29ycmVjdFwiIDogXCJcIixcbiAgICAgICAgICAgIHppcEFuaW0gPT09IFwid3JvbmdcIiA/IFwiemlwemFwLXdyb25nXCIgOiBcIlwiLFxuICAgICAgICAgIF0uam9pbihcIiBcIil9XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAgIHppcEFuaW0gPT09IFwiY29ycmVjdFwiXG4gICAgICAgICAgICAgICAgPyBcInJnYmEoNTIsMjExLDE1MywwLjIyKVwiXG4gICAgICAgICAgICAgICAgOiB6aXBBbmltID09PSBcIndyb25nXCJcbiAgICAgICAgICAgICAgICAgID8gXCJyZ2JhKDI0OCwxMTMsMTEzLDAuMTgpXCJcbiAgICAgICAgICAgICAgICAgIDogXCJyZ2JhKDUyLDIxMSwxNTMsMC4wOClcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOlxuICAgICAgICAgICAgICB6aXBBbmltID09PSBcImNvcnJlY3RcIlxuICAgICAgICAgICAgICAgID8gXCIjMzRkMzk5XCJcbiAgICAgICAgICAgICAgICA6IHppcEFuaW0gPT09IFwid3JvbmdcIlxuICAgICAgICAgICAgICAgICAgPyBcIiNmODcxNzFcIlxuICAgICAgICAgICAgICAgICAgOiBcInJnYmEoNTIsMjExLDE1MywwLjM1KVwiLFxuICAgICAgICAgICAgV2Via2l0VGFwSGlnaGxpZ2h0Q29sb3I6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgICAgICAgIHRvdWNoQWN0aW9uOiBcIm5vbmVcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrXCIgc3R5bGU9e3sgY29sb3IsIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1tb25vKVwiIH19PlpJUDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPkJsb2NrPC9kaXY+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBpZD1cInNlY3VyaXR5LXphcC1idG5cIlxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uUG9pbnRlckRvd249eygpID0+IGhhbmRsZVByZXNzKFwiWkFQXCIpfVxuICAgICAgICAgIGNsYXNzTmFtZT17W1xuICAgICAgICAgICAgXCJjdHJsLWJ1dHRvbiBmbGV4LTEgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgcm91bmRlZC0yeGwgYm9yZGVyLTIgcHktNiB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTUgc2VsZWN0LW5vbmVcIixcbiAgICAgICAgICAgIHphcEFuaW0gPT09IFwiY29ycmVjdFwiID8gXCJ6aXB6YXAtY29ycmVjdFwiIDogXCJcIixcbiAgICAgICAgICAgIHphcEFuaW0gPT09IFwid3JvbmdcIiA/IFwiemlwemFwLXdyb25nXCIgOiBcIlwiLFxuICAgICAgICAgIF0uam9pbihcIiBcIil9XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAgIHphcEFuaW0gPT09IFwiY29ycmVjdFwiXG4gICAgICAgICAgICAgICAgPyBcInJnYmEoNTIsMjExLDE1MywwLjIyKVwiXG4gICAgICAgICAgICAgICAgOiB6YXBBbmltID09PSBcIndyb25nXCJcbiAgICAgICAgICAgICAgICAgID8gXCJyZ2JhKDI0OCwxMTMsMTEzLDAuMTgpXCJcbiAgICAgICAgICAgICAgICAgIDogXCJyZ2JhKDUyLDIxMSwxNTMsMC4wOClcIixcbiAgICAgICAgICAgIGJvcmRlckNvbG9yOlxuICAgICAgICAgICAgICB6YXBBbmltID09PSBcImNvcnJlY3RcIlxuICAgICAgICAgICAgICAgID8gXCIjMzRkMzk5XCJcbiAgICAgICAgICAgICAgICA6IHphcEFuaW0gPT09IFwid3JvbmdcIlxuICAgICAgICAgICAgICAgICAgPyBcIiNmODcxNzFcIlxuICAgICAgICAgICAgICAgICAgOiBcInJnYmEoNTIsMjExLDE1MywwLjM1KVwiLFxuICAgICAgICAgICAgV2Via2l0VGFwSGlnaGxpZ2h0Q29sb3I6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgICAgICAgIHRvdWNoQWN0aW9uOiBcIm5vbmVcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrXCIgc3R5bGU9e3sgY29sb3I6IFwiIzZlZTdiN1wiLCBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtbW9ubylcIiB9fT5aQVA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj5aYXA8L2Rpdj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFByb2dyZXNzIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xIGZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICA8c3Bhbj5GaXJld2FsbDwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57cHJvZ3Jlc3N9IC8gMTAwJTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC0zIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtMCByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgd2lkdGg6IGAke3Byb2dyZXNzfSVgLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAjMDY0ZTNiLCAke2NvbG9yfSlgLFxuICAgICAgICAgICAgICBib3hTaGFkb3c6IGAwIDAgOHB4ICR7Y29sb3J9ODBgLFxuICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcIndpZHRoIDAuMnMgZWFzZS1vdXRcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLy8g4pSA4pSAIEFJIENvcmUgUHV6emxlIG1pbmktZ2FtZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIEVhY2ggcHV6emxlOiB0aGUgY29ycmVjdCBvcmRlciBvZiBzdGVwIGxhYmVscyArIGEgdGhlbWUgbGFiZWwgc2hvd24gdG8gdGhlIHBsYXllci4gKi9cbmNvbnN0IEFJX1BVWlpMRVM6IHsgc3RlcHM6IHJlYWRvbmx5IHN0cmluZ1tdOyB0aGVtZTogc3RyaW5nOyBoaW50OiBzdHJpbmcgfVtdID0gW1xuICB7XG4gICAgc3RlcHM6IFtcIkRBVEFcIiwgXCJUUkFJTlwiLCBcIlBSRURJQ1RcIiwgXCJERVBMT1lcIl0gYXMgY29uc3QsXG4gICAgdGhlbWU6IFwiQUkgUGlwZWxpbmVcIixcbiAgICBoaW50OiBcIkNvbGxlY3QgZGF0YSDihpIgdHJhaW4gbW9kZWwg4oaSIHJ1biBwcmVkaWN0aW9ucyDihpIgc2hpcCB0byBwcm9kXCIsXG4gIH0sXG4gIHtcbiAgICBzdGVwczogW1wiQ09MTEVDVFwiLCBcIkNMRUFOXCIsIFwiTU9ERUxcIiwgXCJTSElQXCJdIGFzIGNvbnN0LFxuICAgIHRoZW1lOiBcIk1MIFdvcmtmbG93XCIsXG4gICAgaGludDogXCJSYXcgZGF0YSDihpIgY2xlYW5lZCBkYXRhc2V0IOKGkiB0cmFpbmVkIG1vZGVsIOKGkiBkZXBsb3llZFwiLFxuICB9LFxuICB7XG4gICAgc3RlcHM6IFtcIlBST01QVFwiLCBcIkVOQ09ERVwiLCBcIkdFTkVSQVRFXCIsIFwiT1VUUFVUXCJdIGFzIGNvbnN0LFxuICAgIHRoZW1lOiBcIkxMTSBGbG93XCIsXG4gICAgaGludDogXCJVc2VyIHByb21wdCDihpIgdG9rZW4gZW5jb2Rpbmcg4oaSIHRleHQgZ2VuZXJhdGlvbiDihpIgcmVzcG9uc2VcIixcbiAgfSxcbiAge1xuICAgIHN0ZXBzOiBbXCJJTkdFU1RcIiwgXCJFTUJFRFwiLCBcIlNFQVJDSFwiLCBcIlJFVFJJRVZFXCJdIGFzIGNvbnN0LFxuICAgIHRoZW1lOiBcIlJBRyBTeXN0ZW1cIixcbiAgICBoaW50OiBcIkxvYWQgZG9jcyDihpIgY3JlYXRlIGVtYmVkZGluZ3Mg4oaSIHZlY3RvciBzZWFyY2gg4oaSIGZldGNoIGNvbnRleHRcIixcbiAgfSxcbiAge1xuICAgIHN0ZXBzOiBbXCJTRU5TRVwiLCBcIkFOQUxZU0VcIiwgXCJERUNJREVcIiwgXCJBQ1RcIl0gYXMgY29uc3QsXG4gICAgdGhlbWU6IFwiQUkgQWdlbnRcIixcbiAgICBoaW50OiBcIlBlcmNlaXZlIHdvcmxkIOKGkiBhbmFseXNlIHN0YXRlIOKGkiBjaG9vc2UgYWN0aW9uIOKGkiBleGVjdXRlXCIsXG4gIH0sXG5dO1xuXG4vKiogRmlzaGVyLVlhdGVzIHNodWZmbGUg4oCUIGd1YXJhbnRlZXMgdGhlIHJlc3VsdCBpcyBuZXZlciBhbHJlYWR5IHNvcnRlZC4gKi9cbmZ1bmN0aW9uIHNodWZmbGVJbmRpY2VzKG46IG51bWJlcik6IG51bWJlcltdIHtcbiAgY29uc3QgYXJyID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogbiB9LCAoXywgaSkgPT4gaSk7XG4gIGZvciAobGV0IGkgPSBhcnIubGVuZ3RoIC0gMTsgaSA+IDA7IGktLSkge1xuICAgIGNvbnN0IGogPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAoaSArIDEpKTtcbiAgICBbYXJyW2ldLCBhcnJbal1dID0gW2FycltqXSwgYXJyW2ldXTtcbiAgfVxuICAvLyBJZiBhY2NpZGVudGFsbHkgYWxyZWFkeSBzb3J0ZWQsIGRvIG9uZSBndWFyYW50ZWVkIHN3YXAuXG4gIGNvbnN0IHNvcnRlZCA9IGFyci5ldmVyeSgodiwgaSkgPT4gdiA9PT0gaSk7XG4gIGlmIChzb3J0ZWQgJiYgbiA+IDEpIHtcbiAgICBbYXJyWzBdLCBhcnJbMV1dID0gW2FyclsxXSwgYXJyWzBdXTtcbiAgfVxuICByZXR1cm4gYXJyO1xufVxuXG5pbnRlcmZhY2UgQWlDb3JlUHV6emxlR2FtZVByb3BzIHtcbiAgcHJvZ3Jlc3M6IG51bWJlcjtcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIHNjb3JlOiBudW1iZXI7XG4gIG9uU29sdmU6ICgpID0+IHZvaWQ7XG59XG5cbmZ1bmN0aW9uIEFpQ29yZVB1enpsZUdhbWUoeyBwcm9ncmVzcywgc3RhdHVzLCBzY29yZSwgb25Tb2x2ZSB9OiBBaUNvcmVQdXp6bGVHYW1lUHJvcHMpIHtcbiAgY29uc3QgaXNDb21wbGV0ZSA9IHN0YXR1cyA9PT0gXCJjb21wbGV0ZVwiO1xuICBjb25zdCBjb2xvciA9IFwiI2MwODRmY1wiOyAvLyBwdXJwbGUg4oCUIG1vZGVsIHJvbGUgY29sb3JcblxuICBjb25zdCBbcHV6emxlSWR4LCBzZXRQdXp6bGVJZHhdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtvcmRlciwgc2V0T3JkZXJdID0gdXNlU3RhdGU8bnVtYmVyW10+KCgpID0+IHNodWZmbGVJbmRpY2VzKDQpKTtcbiAgY29uc3QgW3NlbGVjdGVkLCBzZXRTZWxlY3RlZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NvbHZlZENvdW50LCBzZXRTb2x2ZWRDb3VudF0gPSB1c2VTdGF0ZSgwKTtcbiAgLy8gc29sdmluZzogYW5pbWF0aW5nIHRoZSBjb3JyZWN0LXNvbHZlIGZsYXNoIGJlZm9yZSBsb2FkaW5nIG5leHQgcHV6emxlXG4gIGNvbnN0IFtzb2x2aW5nLCBzZXRTb2x2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBwdXp6bGUgPSBBSV9QVVpaTEVTW3B1enpsZUlkeCAlIEFJX1BVWlpMRVMubGVuZ3RoXTtcblxuICBjb25zdCBoYW5kbGVUYXAgPSB1c2VDYWxsYmFjayhcbiAgICAocG9zOiBudW1iZXIpID0+IHtcbiAgICAgIGlmIChzb2x2aW5nIHx8IGlzQ29tcGxldGUpIHJldHVybjtcblxuICAgICAgaWYgKHNlbGVjdGVkID09PSBudWxsKSB7XG4gICAgICAgIHNldFNlbGVjdGVkKHBvcyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChzZWxlY3RlZCA9PT0gcG9zKSB7XG4gICAgICAgIHNldFNlbGVjdGVkKG51bGwpOyAvLyBkZXNlbGVjdFxuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIFN3YXAgc2VsZWN0ZWQg4oaUIHRhcHBlZC5cbiAgICAgIGNvbnN0IG5leHQgPSBbLi4ub3JkZXJdO1xuICAgICAgW25leHRbc2VsZWN0ZWRdLCBuZXh0W3Bvc11dID0gW25leHRbcG9zXSwgbmV4dFtzZWxlY3RlZF1dO1xuICAgICAgc2V0T3JkZXIobmV4dCk7XG4gICAgICBzZXRTZWxlY3RlZChudWxsKTtcblxuICAgICAgLy8gQ2hlY2sgaWYgY29ycmVjdGx5IG9yZGVyZWQuXG4gICAgICBjb25zdCBjb3JyZWN0ID0gbmV4dC5ldmVyeSgodiwgaSkgPT4gdiA9PT0gaSk7XG4gICAgICBpZiAoY29ycmVjdCkge1xuICAgICAgICBzZXRTb2x2aW5nKHRydWUpO1xuICAgICAgICBvblNvbHZlKCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHNldFNvbHZpbmcoZmFsc2UpO1xuICAgICAgICAgIHNldFNvbHZlZENvdW50KChjKSA9PiBjICsgMSk7XG4gICAgICAgICAgc2V0UHV6emxlSWR4KChpKSA9PiBpICsgMSk7XG4gICAgICAgICAgc2V0T3JkZXIoc2h1ZmZsZUluZGljZXMoNCkpO1xuICAgICAgICB9LCA4NTApO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3NlbGVjdGVkLCBvcmRlciwgc29sdmluZywgaXNDb21wbGV0ZSwgb25Tb2x2ZV0sXG4gICk7XG5cbiAgLy8gUHJvZ3Jlc3MgcmluZy5cbiAgY29uc3QgcmFkaXVzID0gNTI7XG4gIGNvbnN0IGNpcmMgPSAyICogTWF0aC5QSSAqIHJhZGl1cztcbiAgY29uc3QgZGFzaE9mZnNldCA9IGNpcmMgLSAocHJvZ3Jlc3MgLyAxMDApICogY2lyYztcblxuICAvLyDilIDilIAgQ29tcGxldGlvbiBzY3JlZW4g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGlmIChpc0NvbXBsZXRlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgdy1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNlwiXG4gICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgY2VudGVyLCAjYzA4NGZjMjAgMCUsIHRyYW5zcGFyZW50IDcwJSlcIiB9fVxuICAgICAgPlxuICAgICAgICB7LyogR2xvd2luZyBicmFpbiByaW5nICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgd2lkdGg6IDE4MCxcbiAgICAgICAgICAgIGhlaWdodDogMTgwLFxuICAgICAgICAgICAgYm9yZGVyOiBcIjRweCBzb2xpZCAjYzA4NGZjXCIsXG4gICAgICAgICAgICBib3hTaGFkb3c6IFwiMCAwIDYwcHggI2MwODRmY2FhLCAwIDAgMTIwcHggI2MwODRmYzQwXCIsXG4gICAgICAgICAgICBhbmltYXRpb246IFwibW9kZWxDb21wbGV0ZSAxLjVzIGVhc2UtaW4tb3V0IGluZmluaXRlIGFsdGVybmF0ZVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiA2NCB9fT7wn6egPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCJcbiAgICAgICAgICBzdHlsZT17eyBjb2xvciwgdGV4dFNoYWRvdzogXCIwIDAgMjBweCAjYzA4NGZjXCIgfX1cbiAgICAgICAgPlxuICAgICAgICAgIE1PREVMIE9QVElNSVNFRFxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+RGVwYXJ0bWVudCBzY29yZToge3Njb3JlLnRvTG9jYWxlU3RyaW5nKCl9IHB0czwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIC8vIOKUgOKUgCBNYWluIHB1enpsZSBVSSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTMgZ2FwLTNcIj5cblxuICAgICAgey8qIEhlYWRlciBzdGF0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5Qcm9ncmVzczwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtMnhsIGZvbnQtYmxhY2tcIiBzdHlsZT17eyBjb2xvciB9fT5cbiAgICAgICAgICAgIHtwcm9ncmVzc30lXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwXCI+U2NvcmU8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNreS0zMDBcIj5cbiAgICAgICAgICAgIHtzY29yZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlNvbHZlZDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICB7c29sdmVkQ291bnR9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9ncmVzcyByaW5nICsgYnJhaW4gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCIgc3R5bGU9e3sgd2lkdGg6IDEzMCwgaGVpZ2h0OiAxMzAsIGZsZXhTaHJpbms6IDAgfX0+XG4gICAgICAgIDxzdmcgd2lkdGg9ezEzMH0gaGVpZ2h0PXsxMzB9IHZpZXdCb3g9XCIwIDAgMTMwIDEzMFwiIGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgdHJhbnNmb3JtOiBcInJvdGF0ZSgtOTBkZWcpXCIgfX0+XG4gICAgICAgICAgPGNpcmNsZSBjeD17NjV9IGN5PXs2NX0gcj17cmFkaXVzfSBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMxZTI5M2JcIiBzdHJva2VXaWR0aD17N30gLz5cbiAgICAgICAgICA8Y2lyY2xlXG4gICAgICAgICAgICBjeD17NjV9IGN5PXs2NX0gcj17cmFkaXVzfSBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICBzdHJva2U9e2NvbG9yfSBzdHJva2VXaWR0aD17N30gc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgIHN0cm9rZURhc2hhcnJheT17Y2lyY31cbiAgICAgICAgICAgIHN0cm9rZURhc2hvZmZzZXQ9e2Rhc2hPZmZzZXR9XG4gICAgICAgICAgICBzdHlsZT17eyB0cmFuc2l0aW9uOiBcInN0cm9rZS1kYXNob2Zmc2V0IDAuNHMgZWFzZS1vdXRcIiwgZmlsdGVyOiBgZHJvcC1zaGFkb3coMCAwIDVweCAke2NvbG9yfSlgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9zdmc+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAzNiB9fT7wn6egPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBtdC0wLjVcIiBzdHlsZT17eyBjb2xvciB9fT5BSSBDT1JFPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUHV6emxlIGFyZWEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBweC0yIGZsZXggZmxleC1jb2wgZ2FwLTIgZmxleC0xXCI+XG4gICAgICAgIHsvKiBUaGVtZSArIGluc3RydWN0aW9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCIgc3R5bGU9e3sgY29sb3IgfX0+XG4gICAgICAgICAgICB7cHV6emxlLnRoZW1lfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+XG4gICAgICAgICAgICBUYXAgdG8gc2VsZWN0IOKAoiB0YXAgYW5vdGhlciB0byBzd2FwIOKAoiBhcnJhbmdlIGluIG9yZGVyIOKGklxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUGlwZWxpbmUgY2FyZHMg4oCUIHZlcnRpY2FsIHN0YWNrICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTIgZmxleC0xIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAge29yZGVyLm1hcCgoc3RlcEluZGV4LCBwb3MpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxhYmVsID0gcHV6emxlLnN0ZXBzW3N0ZXBJbmRleF07XG4gICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWQgPT09IHBvcztcbiAgICAgICAgICAgIGNvbnN0IGlzQ29ycmVjdCA9IHN0ZXBJbmRleCA9PT0gcG9zO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17YCR7cHV6emxlSWR4fS0ke3Bvc31gfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGlkPXtgcHV6emxlLWNhcmQtJHtwb3N9YH1cbiAgICAgICAgICAgICAgICBvblBvaW50ZXJEb3duPXsoKSA9PiBoYW5kbGVUYXAocG9zKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1tcbiAgICAgICAgICAgICAgICAgIFwiY3RybC1idXR0b24gdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC00IHJvdW5kZWQtMnhsIHB4LTUgcHktNCB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTggc2VsZWN0LW5vbmVcIixcbiAgICAgICAgICAgICAgICAgIHNvbHZpbmcgPyBcInB1enpsZS1jYXJkLXNvbHZlXCIgOiBcIlwiLFxuICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZCAmJiAhc29sdmluZyA/IFwicHV6emxlLWNhcmQtc2VsZWN0ZWRcIiA6IFwiXCIsXG4gICAgICAgICAgICAgICAgXS5qb2luKFwiIFwiKX1cbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogc29sdmluZ1xuICAgICAgICAgICAgICAgICAgICA/IFwicmdiYSgxOTIsMTMyLDI1MiwwLjEyKVwiXG4gICAgICAgICAgICAgICAgICAgIDogaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgID8gXCJyZ2JhKDE5MiwxMzIsMjUyLDAuMTgpXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwicmdiYSgxNSwzMiw1MywwLjkpXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXI6IGlzU2VsZWN0ZWQgJiYgIXNvbHZpbmdcbiAgICAgICAgICAgICAgICAgICAgPyBcIjJweCBzb2xpZCAjYzA4NGZjXCJcbiAgICAgICAgICAgICAgICAgICAgOiBzb2x2aW5nXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIjJweCBzb2xpZCAjNGFkZTgwXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IGAxcHggc29saWQgcmdiYSgxOTIsMTMyLDI1Miwke2lzQ29ycmVjdCA/IFwiMC4zNVwiIDogXCIwLjE1XCJ9KWAsXG4gICAgICAgICAgICAgICAgICBXZWJraXRUYXBIaWdobGlnaHRDb2xvcjogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgICAgICAgICAgICAgdG91Y2hBY3Rpb246IFwibm9uZVwiLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7LyogUG9zaXRpb24gbnVtYmVyICovfVxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJsYWNrIGZvbnQtbW9ubyB3LTUgdGV4dC1jZW50ZXIgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IGlzU2VsZWN0ZWQgPyBjb2xvciA6IFwiIzQ3NTU2OVwiIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge3BvcyArIDF9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIHsvKiBBcnJvdyBjb25uZWN0b3IgKi99XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgdGV4dC14cyBzaHJpbmstMFwiPuKGkjwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7LyogU3RlcCBsYWJlbCAqL31cbiAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQtY2VudGVyIGZvbnQtYmxhY2sgdHJhY2tpbmctd2lkZXN0XCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1tb25vKVwiLFxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogMTgsXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBpc1NlbGVjdGVkID8gY29sb3IgOiBzb2x2aW5nID8gXCIjNGFkZTgwXCIgOiBcIiNlMmU4ZjBcIixcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJjb2xvciAwLjE1cyBlYXNlXCIsXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgey8qIENvcnJlY3QgaW5kaWNhdG9yIChzdWJ0bGUg4oCUIG9ubHkgd2hlbiBzb2x2aW5nKSAqL31cbiAgICAgICAgICAgICAgICB7c29sdmluZyAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTQwMCB0ZXh0LWxnIHNocmluay0wXCI+4pyTPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEhpbnQgdGV4dCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZFwiPntwdXp6bGUuaGludH08L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUHJvZ3Jlc3MgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgIDxzcGFuPkFJIENvcmU8L3NwYW4+XG4gICAgICAgICAgPHNwYW4+e3Byb2dyZXNzfSAvIDEwMCU8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMyBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIHdpZHRoOiBgJHtwcm9ncmVzc30lYCxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogYGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzRhMDQ0ZSwgJHtjb2xvcn0pYCxcbiAgICAgICAgICAgICAgYm94U2hhZG93OiBgMCAwIDhweCAke2NvbG9yfTgwYCxcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJ3aWR0aCAwLjM1cyBlYXNlLW91dFwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyDilIDilIAgQ29vbGluZyBFbmdpbmVlciBtaW5pLWdhbWUg4oCUIEd5cm9zY29wZSBzcGlyaXQgbGV2ZWwg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogVHJpZXMgdG8gcmVxdWVzdCBEZXZpY2VPcmllbnRhdGlvbkV2ZW50IHBlcm1pc3Npb24gKHJlcXVpcmVkIG9uIGlPUyAxMyspLlxuICogUmVzb2x2ZXMgdG8gJ2dyYW50ZWQnIHwgJ2RlbmllZCcgfCAndW5hdmFpbGFibGUnLlxuICovXG5hc3luYyBmdW5jdGlvbiByZXF1ZXN0T3JpZW50YXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8XCJncmFudGVkXCIgfCBcImRlbmllZFwiIHwgXCJ1bmF2YWlsYWJsZVwiPiB7XG4gIC8vIGlPUyAxMysgcmVxdWlyZXMgYW4gZXhwbGljaXQgcGVybWlzc2lvbiBjYWxsLlxuICBpZiAoXG4gICAgdHlwZW9mIERldmljZU9yaWVudGF0aW9uRXZlbnQgIT09IFwidW5kZWZpbmVkXCIgJiZcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIHR5cGVvZiAoRGV2aWNlT3JpZW50YXRpb25FdmVudCBhcyBhbnkpLnJlcXVlc3RQZXJtaXNzaW9uID09PSBcImZ1bmN0aW9uXCJcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCAoRGV2aWNlT3JpZW50YXRpb25FdmVudCBhcyBhbnkpLnJlcXVlc3RQZXJtaXNzaW9uKCk7XG4gICAgICByZXR1cm4gcmVzdWx0ID09PSBcImdyYW50ZWRcIiA/IFwiZ3JhbnRlZFwiIDogXCJkZW5pZWRcIjtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBcImRlbmllZFwiO1xuICAgIH1cbiAgfVxuICAvLyBBbmRyb2lkIC8gZGVza3RvcDogZXZlbnQgZmlyZXMgd2l0aG91dCBhIHBlcm1pc3Npb24gcHJvbXB0LlxuICBpZiAodHlwZW9mIERldmljZU9yaWVudGF0aW9uRXZlbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgXCJvbmRldmljZW9yaWVudGF0aW9uXCIgaW4gd2luZG93KSB7XG4gICAgcmV0dXJuIFwiZ3JhbnRlZFwiO1xuICB9XG4gIHJldHVybiBcInVuYXZhaWxhYmxlXCI7XG59XG5cbnR5cGUgT3JpZW50YXRpb25TdGF0ZSA9IFwiaWRsZVwiIHwgXCJyZXF1ZXN0aW5nXCIgfCBcImdyYW50ZWRcIiB8IFwiZGVuaWVkXCIgfCBcInVuYXZhaWxhYmxlXCI7XG5cbmludGVyZmFjZSBDb29saW5nR2FtZVByb3BzIHtcbiAgdGVtcGVyYXR1cmU6IG51bWJlcjtcbiAgcHJvZ3Jlc3M6IG51bWJlcjtcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIHNjb3JlOiBudW1iZXI7XG4gIG9uVGljazogKGNlbnRlcmVkbmVzczogbnVtYmVyKSA9PiB2b2lkO1xufVxuXG5mdW5jdGlvbiBDb29saW5nR2FtZSh7IHRlbXBlcmF0dXJlLCBwcm9ncmVzcywgc3RhdHVzLCBzY29yZSwgb25UaWNrIH06IENvb2xpbmdHYW1lUHJvcHMpIHtcbiAgY29uc3QgaXNDb21wbGV0ZSA9IHN0YXR1cyA9PT0gXCJjb21wbGV0ZVwiO1xuICBjb25zdCBjb2xvciA9IFwiIzM4YmRmOFwiOyAvLyBza3ktNDAwIOKAlCBjb29saW5nIHJvbGUgY29sb3VyXG5cbiAgLy8g4pSA4pSAIE9yaWVudGF0aW9uIHBlcm1pc3Npb24gc3RhdGUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IFtvcmllbnRTdGF0ZSwgc2V0T3JpZW50U3RhdGVdID0gdXNlU3RhdGU8T3JpZW50YXRpb25TdGF0ZT4oXCJpZGxlXCIpO1xuXG4gIC8vIOKUgOKUgCBMaXZlIGJ1YmJsZSBwb3NpdGlvbiBpbiBub3JtYWxpc2VkIFstMSwgMV0geC95IHNwYWNlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyB4ID0gbGVmdC9yaWdodCAoZ2FtbWEpLCB5ID0gZnJvbnQvYmFjayAoYmV0YSlcbiAgY29uc3QgYnViYmxlUG9zUmVmID0gdXNlUmVmKHsgeDogMCwgeTogMCB9KTtcbiAgY29uc3QgW2J1YmJsZVBvcywgc2V0QnViYmxlUG9zXSA9IHVzZVN0YXRlKHsgeDogMCwgeTogMCB9KTtcblxuICAvLyDilIDilIAgQm91bmRzIGNpcmNsZSByZWYgKGZvciB0b3VjaCBjb29yZGluYXRlIG1hcHBpbmcpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBib3VuZHNSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuXG4gIC8vIOKUgOKUgCBQZXJpb2RpYyBuZXR3b3JrIHRpY2sg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IGxhc3RUaWNrUmVmID0gdXNlUmVmKDApO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGlkID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgY29uc3QgeyB4LCB5IH0gPSBidWJibGVQb3NSZWYuY3VycmVudDtcbiAgICAgIC8vIGNlbnRlcmVkbmVzczogMCA9IHBlcmZlY3QgY2VudHJlLCAxID0gZWRnZVxuICAgICAgY29uc3QgY2VudGVyZWRuZXNzID0gTWF0aC5taW4oMSwgTWF0aC5zcXJ0KHggKiB4ICsgeSAqIHkpKTtcbiAgICAgIG9uVGljayhjZW50ZXJlZG5lc3MpO1xuICAgIH0sIEdBTUVfQ09ORklHLmNvb2xpbmdUaWNrVGhyb3R0bGVNcyk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaWQpO1xuICB9LCBbb25UaWNrXSk7XG5cbiAgLy8g4pSA4pSAIERldmljZSBvcmllbnRhdGlvbiBldmVudCBsaXN0ZW5lciDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3JpZW50U3RhdGUgIT09IFwiZ3JhbnRlZFwiKSByZXR1cm47XG5cbiAgICBjb25zdCBoYW5kbGVPcmllbnRhdGlvbiA9IChlOiBEZXZpY2VPcmllbnRhdGlvbkV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBnYW1tYSA9IGUuZ2FtbWEgPz8gMDsgLy8gbGVmdC9yaWdodCB0aWx0LCAtOTAgdG8gOTBcbiAgICAgIGNvbnN0IGJldGEgPSBlLmJldGEgPz8gMDsgIC8vIGZyb250L2JhY2sgdGlsdCwgLTE4MCB0byAxODBcblxuICAgICAgY29uc3QgbWF4QW5nbGUgPSBHQU1FX0NPTkZJRy5jb29saW5nTWF4VGlsdEFuZ2xlO1xuICAgICAgY29uc3QgbnggPSBNYXRoLm1pbigxLCBNYXRoLm1heCgtMSwgZ2FtbWEgLyBtYXhBbmdsZSkpO1xuICAgICAgY29uc3QgbnkgPSBNYXRoLm1pbigxLCBNYXRoLm1heCgtMSwgKGJldGEgLSA0NSkgLyBtYXhBbmdsZSkpOyAvLyA0NcKwIG9mZnNldCBmb3IgbmF0dXJhbCBob2xkXG5cbiAgICAgIGJ1YmJsZVBvc1JlZi5jdXJyZW50ID0geyB4OiBueCwgeTogbnkgfTtcbiAgICAgIHNldEJ1YmJsZVBvcyh7IHg6IG54LCB5OiBueSB9KTtcbiAgICB9O1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJkZXZpY2VvcmllbnRhdGlvblwiLCBoYW5kbGVPcmllbnRhdGlvbiwgdHJ1ZSk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiZGV2aWNlb3JpZW50YXRpb25cIiwgaGFuZGxlT3JpZW50YXRpb24sIHRydWUpO1xuICB9LCBbb3JpZW50U3RhdGVdKTtcblxuICAvLyDilIDilIAgVG91Y2ggZHJhZyBmYWxsYmFjayDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgY29uc3QgdG91Y2hBY3RpdmVSZWYgPSB1c2VSZWYoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZVRvdWNoU3RhcnQgPSB1c2VDYWxsYmFjaygoZTogUmVhY3QuVG91Y2hFdmVudCkgPT4ge1xuICAgIHRvdWNoQWN0aXZlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZVRvdWNoTW92ZSA9IHVzZUNhbGxiYWNrKChlOiBSZWFjdC5Ub3VjaEV2ZW50KSA9PiB7XG4gICAgaWYgKCF0b3VjaEFjdGl2ZVJlZi5jdXJyZW50IHx8ICFib3VuZHNSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCByZWN0ID0gYm91bmRzUmVmLmN1cnJlbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3QgdG91Y2ggPSBlLnRvdWNoZXNbMF07XG4gICAgY29uc3QgY3ggPSByZWN0LmxlZnQgKyByZWN0LndpZHRoIC8gMjtcbiAgICBjb25zdCBjeSA9IHJlY3QudG9wICsgcmVjdC5oZWlnaHQgLyAyO1xuICAgIGNvbnN0IHIgPSByZWN0LndpZHRoIC8gMjtcbiAgICBjb25zdCBkeCA9ICh0b3VjaC5jbGllbnRYIC0gY3gpIC8gcjtcbiAgICBjb25zdCBkeSA9ICh0b3VjaC5jbGllbnRZIC0gY3kpIC8gcjtcbiAgICAvLyBDbGFtcCB3aXRoaW4gdW5pdCBjaXJjbGUuXG4gICAgY29uc3QgbGVuID0gTWF0aC5zcXJ0KGR4ICogZHggKyBkeSAqIGR5KTtcbiAgICBjb25zdCBzY2FsZSA9IGxlbiA+IDEgPyAxIC8gbGVuIDogMTtcbiAgICBjb25zdCBueCA9IGR4ICogc2NhbGU7XG4gICAgY29uc3QgbnkgPSBkeSAqIHNjYWxlO1xuICAgIGJ1YmJsZVBvc1JlZi5jdXJyZW50ID0geyB4OiBueCwgeTogbnkgfTtcbiAgICBzZXRCdWJibGVQb3MoeyB4OiBueCwgeTogbnkgfSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBoYW5kbGVUb3VjaEVuZCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICB0b3VjaEFjdGl2ZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgLy8gR2xpZGUgYmFjayB0byBjZW50ZXIgb24gcmVsZWFzZS5cbiAgICBidWJibGVQb3NSZWYuY3VycmVudCA9IHsgeDogMCwgeTogMCB9O1xuICAgIHNldEJ1YmJsZVBvcyh7IHg6IDAsIHk6IDAgfSk7XG4gIH0sIFtdKTtcblxuICAvLyDilIDilIAgUmVxdWVzdCBwZXJtaXNzaW9uIG9uIGJ1dHRvbiBwcmVzcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgY29uc3QgaGFuZGxlUmVxdWVzdFBlcm1pc3Npb24gPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc2V0T3JpZW50U3RhdGUoXCJyZXF1ZXN0aW5nXCIpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlcXVlc3RPcmllbnRhdGlvblBlcm1pc3Npb24oKTtcbiAgICBzZXRPcmllbnRTdGF0ZShyZXN1bHQpO1xuICB9LCBbXSk7XG5cbiAgLy8gQXV0by1hdHRlbXB0IHBlcm1pc3Npb24gb24gbW91bnQgZm9yIG5vbi1pT1MgKG5vIHByb21wdCBuZWVkZWQpLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChvcmllbnRTdGF0ZSA9PT0gXCJpZGxlXCIpIHtcbiAgICAgIHJlcXVlc3RPcmllbnRhdGlvblBlcm1pc3Npb24oKS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgICAgLy8gT24gZGVza3RvcC9BbmRyb2lkIHdlIGdldCBncmFudGVkIGltbWVkaWF0ZWx5IHdpdGhvdXQgdXNlciBnZXN0dXJlLlxuICAgICAgICAvLyBPbiBpT1Mgd2Ugc3RheSAnaWRsZScgdW50aWwgdGhlIHVzZXIgdGFwcy5cbiAgICAgICAgaWYgKHJlc3VsdCAhPT0gXCJkZW5pZWRcIikge1xuICAgICAgICAgIHNldE9yaWVudFN0YXRlKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbXSk7XG5cbiAgLy8g4pSA4pSAIERlcml2ZWQgZGlzcGxheSB2YWx1ZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IGNlbnRlcmVkbmVzcyA9IE1hdGgubWluKDEsIE1hdGguc3FydChidWJibGVQb3MueCAqKiAyICsgYnViYmxlUG9zLnkgKiogMikpO1xuICBjb25zdCBpc0NlbnRlcmVkID0gY2VudGVyZWRuZXNzIDw9IEdBTUVfQ09ORklHLmNvb2xpbmdDZW50ZXJlZFRocmVzaG9sZDtcbiAgY29uc3QgaW5TYWZlWm9uZSA9IHRlbXBlcmF0dXJlID49IEdBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWluICYmIHRlbXBlcmF0dXJlIDw9IEdBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWF4O1xuXG4gIC8vIEJ1YmJsZSByZW5kZXI6IG1hcCBbLTEsMV0gdG8gcGl4ZWxzIHdpdGhpbiBib3VuZHMgY2lyY2xlLlxuICBjb25zdCBCT1VORFNfUiA9IDExMDsgLy8gcHggcmFkaXVzIG9mIHRoZSBib3VuZHMgY2lyY2xlXG4gIGNvbnN0IEJVQkJMRV9SID0gMjg7ICAvLyBweCByYWRpdXMgb2YgdGhlIGJ1YmJsZVxuICBjb25zdCBtYXhUcmF2ZWwgPSBCT1VORFNfUiAtIEJVQkJMRV9SO1xuICBjb25zdCBieCA9IGJ1YmJsZVBvcy54ICogbWF4VHJhdmVsO1xuICBjb25zdCBieSA9IGJ1YmJsZVBvcy55ICogbWF4VHJhdmVsO1xuXG4gIC8vIFRlbXBlcmF0dXJlIGNvbG91ciBncmFkaWVudDogYmx1ZSAoY29vbCkg4oaSIG9yYW5nZSAoaG90KVxuICBjb25zdCB0ZW1wRnJhY3Rpb24gPSBNYXRoLm1pbigxLCBNYXRoLm1heCgwLCAodGVtcGVyYXR1cmUgLSA1MCkgLyA3MCkpOyAvLyA1MMKwPTAsIDEyMMKwPTFcbiAgY29uc3QgdGVtcENvbG9yID0gaW5TYWZlWm9uZSA/IFwiIzM0ZDM5OVwiIDogdGVtcEZyYWN0aW9uID4gMC43ID8gXCIjZjg3MTcxXCIgOiB0ZW1wRnJhY3Rpb24gPiAwLjQ1ID8gXCIjZmI5MjNjXCIgOiBcIiMzOGJkZjhcIjtcblxuICAvLyBQcm9ncmVzcyByaW5nLlxuICBjb25zdCByaW5nUmFkaXVzID0gNTA7XG4gIGNvbnN0IHJpbmdDaXJjID0gMiAqIE1hdGguUEkgKiByaW5nUmFkaXVzO1xuICBjb25zdCByaW5nT2Zmc2V0ID0gcmluZ0NpcmMgLSAocHJvZ3Jlc3MgLyAxMDApICogcmluZ0NpcmM7XG5cbiAgLy8g4pSA4pSAIENvbXBsZXRpb24gc2NyZWVuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBpZiAoaXNDb21wbGV0ZSkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTZcIlxuICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBcInJhZGlhbC1ncmFkaWVudChlbGxpcHNlIGF0IGNlbnRlciwgIzM4YmRmODIwIDAlLCB0cmFuc3BhcmVudCA3MCUpXCIgfX1cbiAgICAgID5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIHdpZHRoOiAyMDAsXG4gICAgICAgICAgICBoZWlnaHQ6IDIwMCxcbiAgICAgICAgICAgIGJvcmRlcjogXCI0cHggc29saWQgIzM4YmRmOFwiLFxuICAgICAgICAgICAgYm94U2hhZG93OiBcIjAgMCA2MHB4ICMzOGJkZjhhYSwgMCAwIDEyMHB4ICMzOGJkZjg0MFwiLFxuICAgICAgICAgICAgYW5pbWF0aW9uOiBcImRhdGFDb21wbGV0ZSAxLjVzIGVhc2UtaW4tb3V0IGluZmluaXRlIGFsdGVybmF0ZVwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiA3MiB9fT7inYTvuI88L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIlxuICAgICAgICAgIHN0eWxlPXt7IGNvbG9yLCB0ZXh0U2hhZG93OiBcIjAgMCAyMHB4ICMzOGJkZjhcIiB9fVxuICAgICAgICA+XG4gICAgICAgICAgQ09PTElORyBTVEFCTEVcbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTQwMFwiPkRlcGFydG1lbnQgc2NvcmU6IHtzY29yZS50b0xvY2FsZVN0cmluZygpfSBwdHM8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICAvLyDilIDilIAgUGVybWlzc2lvbiBnYXRlIOKAlCBpT1MgbmVlZHMgYSB1c2VyLWdlc3R1cmUgdGFwIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBuZWVkc1Blcm1pc3Npb25UYXAgPSBvcmllbnRTdGF0ZSA9PT0gXCJpZGxlXCIgfHwgb3JpZW50U3RhdGUgPT09IFwicmVxdWVzdGluZ1wiO1xuICBjb25zdCBzaG93VG91Y2hGYWxsYmFjayA9IG9yaWVudFN0YXRlID09PSBcImRlbmllZFwiIHx8IG9yaWVudFN0YXRlID09PSBcInVuYXZhaWxhYmxlXCI7XG4gIGNvbnN0IHNob3dPcmllbnRVSSA9IG9yaWVudFN0YXRlID09PSBcImdyYW50ZWRcIjtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgdy1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHktMyBnYXAtMlwiIHN0eWxlPXt7IHRvdWNoQWN0aW9uOiBcIm5vbmVcIiB9fT5cblxuICAgICAgey8qIEhlYWRlciBzdGF0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1zbGF0ZS01MDBcIj5Qcm9ncmVzczwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtMnhsIGZvbnQtYmxhY2tcIiBzdHlsZT17eyBjb2xvciB9fT57cHJvZ3Jlc3N9JTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlRlbXA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhsIGZvbnQtYmxhY2tcIiBzdHlsZT17eyBjb2xvcjogdGVtcENvbG9yIH19PlxuICAgICAgICAgICAge3RlbXBlcmF0dXJlLnRvRml4ZWQoMSl9wrBDXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtNTAwXCI+U2NvcmU8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNreS0zMDBcIj57c2NvcmUudG9Mb2NhbGVTdHJpbmcoKX08L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNhZmUgem9uZSBsYWJlbCAqL31cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgcHgtMyBweS0xIHJvdW5kZWQtZnVsbFwiXG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgYmFja2dyb3VuZDogaW5TYWZlWm9uZSA/IFwicmdiYSg1MiwyMTEsMTUzLDAuMTUpXCIgOiBcInJnYmEoMjQ4LDExMywxMTMsMC4xKVwiLFxuICAgICAgICAgIGNvbG9yOiBpblNhZmVab25lID8gXCIjMzRkMzk5XCIgOiBcIiNmODcxNzFcIixcbiAgICAgICAgICBib3JkZXI6IGAxcHggc29saWQgJHtpblNhZmVab25lID8gXCIjMzRkMzk5NDBcIiA6IFwiI2Y4NzE3MTQwXCJ9YCxcbiAgICAgICAgICB0cmFuc2l0aW9uOiBcImFsbCAwLjNzIGVhc2VcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAge2luU2FmZVpvbmUgPyBg4pyTIFNhZmUgem9uZSAke0dBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWlufeKAkyR7R0FNRV9DT05GSUcuY29vbGluZ1NhZmVNYXh9wrBDYCA6IGBUYXJnZXQ6ICR7R0FNRV9DT05GSUcuY29vbGluZ1NhZmVNaW594oCTJHtHQU1FX0NPTkZJRy5jb29saW5nU2FmZU1heH3CsENgfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTcGlyaXQgbGV2ZWwgLyB0b3VjaCBhcmVhICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiIHN0eWxlPXt7IGZsZXhTaHJpbms6IDAgfX0+XG4gICAgICAgIHsvKiBPdXRlciBib3VuZHMgcmluZyAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgIHJlZj17Ym91bmRzUmVmfVxuICAgICAgICAgIG9uVG91Y2hTdGFydD17c2hvd1RvdWNoRmFsbGJhY2sgPyBoYW5kbGVUb3VjaFN0YXJ0IDogdW5kZWZpbmVkfVxuICAgICAgICAgIG9uVG91Y2hNb3ZlPXtzaG93VG91Y2hGYWxsYmFjayA/IGhhbmRsZVRvdWNoTW92ZSA6IHVuZGVmaW5lZH1cbiAgICAgICAgICBvblRvdWNoRW5kPXtzaG93VG91Y2hGYWxsYmFjayA/IGhhbmRsZVRvdWNoRW5kIDogdW5kZWZpbmVkfVxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgICAgICAgd2lkdGg6IEJPVU5EU19SICogMixcbiAgICAgICAgICAgIGhlaWdodDogQk9VTkRTX1IgKiAyLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyYWRpYWwtZ3JhZGllbnQoY2lyY2xlLCByZ2JhKDU2LDE4OSwyNDgsMC4wNykgMCUsIHJnYmEoMTUsMzIsNTMsMC45NSkgNzUlKVwiLFxuICAgICAgICAgICAgYm9yZGVyOiBgMnB4IHNvbGlkICR7aXNDZW50ZXJlZCA/IFwiIzM0ZDM5OVwiIDogXCJyZ2JhKDU2LDE4OSwyNDgsMC4zKVwifWAsXG4gICAgICAgICAgICBib3hTaGFkb3c6IGlzQ2VudGVyZWQgPyBcIjAgMCAyNHB4ICMzNGQzOTk2MFwiIDogYDAgMCAxMnB4IHJnYmEoNTYsMTg5LDI0OCwwLjE1KWAsXG4gICAgICAgICAgICB0cmFuc2l0aW9uOiBcImJvcmRlci1jb2xvciAwLjNzIGVhc2UsIGJveC1zaGFkb3cgMC4zcyBlYXNlXCIsXG4gICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgey8qIENyb3NzLWhhaXIgY2VudHJlIG1hcmtlciAqL31cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgaW5zZXQ6IDAsXG4gICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgIHBvaW50ZXJFdmVudHM6IFwibm9uZVwiLFxuICAgICAgICAgIH19PlxuICAgICAgICAgICAgey8qIENlbnRyZSByaW5nIHRhcmdldCAqL31cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3tcbiAgICAgICAgICAgICAgd2lkdGg6IEJPVU5EU19SICogMiAqIEdBTUVfQ09ORklHLmNvb2xpbmdDZW50ZXJlZFRocmVzaG9sZCAqIDIsXG4gICAgICAgICAgICAgIGhlaWdodDogQk9VTkRTX1IgKiAyICogR0FNRV9DT05GSUcuY29vbGluZ0NlbnRlcmVkVGhyZXNob2xkICogMixcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgICAgICAgICAgICBib3JkZXI6IGAxLjVweCBkYXNoZWQgJHtpc0NlbnRlcmVkID8gXCIjMzRkMzk5XCIgOiBcInJnYmEoNTYsMTg5LDI0OCwwLjQpXCJ9YCxcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJib3JkZXItY29sb3IgMC4zcyBlYXNlXCIsXG4gICAgICAgICAgICB9fSAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENyb3NzaGFpciBsaW5lcyAqL31cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgdG9wOiBcIjUwJVwiLFxuICAgICAgICAgICAgbGVmdDogMCxcbiAgICAgICAgICAgIHJpZ2h0OiAwLFxuICAgICAgICAgICAgaGVpZ2h0OiAxLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDU2LDE4OSwyNDgsMC4xMilcIixcbiAgICAgICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGVZKC0wLjVweClcIixcbiAgICAgICAgICAgIHBvaW50ZXJFdmVudHM6IFwibm9uZVwiLFxuICAgICAgICAgIH19IC8+XG4gICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgIGxlZnQ6IFwiNTAlXCIsXG4gICAgICAgICAgICB0b3A6IDAsXG4gICAgICAgICAgICBib3R0b206IDAsXG4gICAgICAgICAgICB3aWR0aDogMSxcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSg1NiwxODksMjQ4LDAuMTIpXCIsXG4gICAgICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlWCgtMC41cHgpXCIsXG4gICAgICAgICAgICBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIixcbiAgICAgICAgICB9fSAvPlxuXG4gICAgICAgICAgey8qIOKUgOKUgCBCdWJibGUg4pSA4pSAICovfVxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXG4gICAgICAgICAgICAgIHdpZHRoOiBCVUJCTEVfUiAqIDIsXG4gICAgICAgICAgICAgIGhlaWdodDogQlVCQkxFX1IgKiAyLFxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IFwiNTAlXCIsXG4gICAgICAgICAgICAgIC8vIENlbnRyZSBvZiBib3VuZHMgKyBvZmZzZXRcbiAgICAgICAgICAgICAgbGVmdDogQk9VTkRTX1IgLSBCVUJCTEVfUiArIGJ4LFxuICAgICAgICAgICAgICB0b3A6IEJPVU5EU19SIC0gQlVCQkxFX1IgKyBieSxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogYHJhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgMzUlIDM1JSwgJHtpc0NlbnRlcmVkID8gXCIjMzRkMzk5XCIgOiB0ZW1wQ29sb3J9Y2MsICR7aXNDZW50ZXJlZCA/IFwiIzM0ZDM5OVwiIDogdGVtcENvbG9yfTQ0KWAsXG4gICAgICAgICAgICAgIGJvcmRlcjogYDJweCBzb2xpZCAke2lzQ2VudGVyZWQgPyBcIiMzNGQzOTlcIiA6IHRlbXBDb2xvcn1gLFxuICAgICAgICAgICAgICBib3hTaGFkb3c6IGAwIDAgMThweCAke2lzQ2VudGVyZWQgPyBcIiMzNGQzOTlcIiA6IHRlbXBDb2xvcn04OGAsXG4gICAgICAgICAgICAgIHRyYW5zaXRpb246IG9yaWVudFN0YXRlID09PSBcImdyYW50ZWRcIiA/IFwibGVmdCAwLjA4cyBlYXNlLW91dCwgdG9wIDAuMDhzIGVhc2Utb3V0XCIgOiBcIm5vbmVcIixcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IDE4IH19PuKdhO+4jzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBpT1MgcGVybWlzc2lvbiBvdmVybGF5ICovfVxuICAgICAgICAgIHtuZWVkc1Blcm1pc3Npb25UYXAgJiYgKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgICBpbnNldDogMCxcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInJnYmEoNSwxMCwyMCwwLjgyKVwiLFxuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIGdhcDogOCxcbiAgICAgICAgICAgICAgekluZGV4OiAxMCxcbiAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAzMiB9fT7wn5SEPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNreS0zMDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWNlbnRlciBweC00XCI+XG4gICAgICAgICAgICAgICAge29yaWVudFN0YXRlID09PSBcInJlcXVlc3RpbmdcIiA/IFwiUmVxdWVzdGluZ+KAplwiIDogXCJUYXAgdG8gZW5hYmxlXFxuR3lyb3Njb3BlXCJ9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUb3VjaCBmYWxsYmFjayBoaW50IG92ZXJsYXkgKi99XG4gICAgICAgICAge3Nob3dUb3VjaEZhbGxiYWNrICYmIGNlbnRlcmVkbmVzcyA8IDAuMDUgJiYgKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17e1xuICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgICBpbnNldDogMCxcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIGdhcDogNCxcbiAgICAgICAgICAgICAgcG9pbnRlckV2ZW50czogXCJub25lXCIsXG4gICAgICAgICAgICAgIHpJbmRleDogNSxcbiAgICAgICAgICAgIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAyMiwgb3BhY2l0eTogMC41IH19PvCfkYY8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj5EcmFnIHRvIGNvbnRyb2w8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNb2RlIGxhYmVsIC8gcGVybWlzc2lvbiBidXR0b24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBweC00XCI+XG4gICAgICAgIHtuZWVkc1Blcm1pc3Npb25UYXAgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGlkPVwiY29vbGluZy1lbmFibGUtZ3lyby1idG5cIlxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXF1ZXN0UGVybWlzc2lvbn1cbiAgICAgICAgICAgIGRpc2FibGVkPXtvcmllbnRTdGF0ZSA9PT0gXCJyZXF1ZXN0aW5nXCJ9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjdHJsLWJ1dHRvbiB3LWZ1bGwgcm91bmRlZC0yeGwgcHktMyB0ZXh0LXNtIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSg1NiwxODksMjQ4LDAuMTIpXCIsXG4gICAgICAgICAgICAgIGJvcmRlcjogXCIycHggc29saWQgcmdiYSg1NiwxODksMjQ4LDAuNClcIixcbiAgICAgICAgICAgICAgY29sb3I6IFwiIzM4YmRmOFwiLFxuICAgICAgICAgICAgICBXZWJraXRUYXBIaWdobGlnaHRDb2xvcjogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDwn46uIEVuYWJsZSBHeXJvc2NvcGVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgICAge3Nob3dUb3VjaEZhbGxiYWNrICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIFRvdWNoIGZhbGxiYWNrIGFjdGl2ZSDigJQgZHJhZyB0aGUgYnViYmxlIHRvIGNlbnRyZVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgICB7c2hvd09yaWVudFVJICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIFRpbHQgeW91ciBwaG9uZSB0byBjZW50cmUgdGhlIGJ1YmJsZVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9ncmVzcyByaW5nICsgdGVtcGVyYXR1cmUgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCIgc3R5bGU9e3sgd2lkdGg6IDEyMCwgaGVpZ2h0OiAxMjAsIGZsZXhTaHJpbms6IDAgfX0+XG4gICAgICAgIDxzdmcgd2lkdGg9ezEyMH0gaGVpZ2h0PXsxMjB9IHZpZXdCb3g9XCIwIDAgMTIwIDEyMFwiIGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgdHJhbnNmb3JtOiBcInJvdGF0ZSgtOTBkZWcpXCIgfX0+XG4gICAgICAgICAgPGNpcmNsZSBjeD17NjB9IGN5PXs2MH0gcj17cmluZ1JhZGl1c30gZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjMWUyOTNiXCIgc3Ryb2tlV2lkdGg9ezd9IC8+XG4gICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgY3g9ezYwfSBjeT17NjB9IHI9e3JpbmdSYWRpdXN9IGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHN0cm9rZT17Y29sb3J9IHN0cm9rZVdpZHRoPXs3fSBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtyaW5nQ2lyY31cbiAgICAgICAgICAgIHN0cm9rZURhc2hvZmZzZXQ9e3JpbmdPZmZzZXR9XG4gICAgICAgICAgICBzdHlsZT17eyB0cmFuc2l0aW9uOiBcInN0cm9rZS1kYXNob2Zmc2V0IDAuNXMgZWFzZS1vdXRcIiwgZmlsdGVyOiBgZHJvcC1zaGFkb3coMCAwIDRweCAke2NvbG9yfSlgIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9zdmc+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAyOCB9fT7wn4yh77iPPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBtdC0wLjVcIiBzdHlsZT17eyBjb2xvciB9fT5DT09MSU5HPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUHJvZ3Jlc3MgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEgZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgIDxzcGFuPkNvb2xhbnQ8L3NwYW4+XG4gICAgICAgICAgPHNwYW4+e3Byb2dyZXNzfSAvIDEwMCU8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMyBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIHdpZHRoOiBgJHtwcm9ncmVzc30lYCxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogYGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzBjNGE2ZSwgJHtjb2xvcn0pYCxcbiAgICAgICAgICAgICAgYm94U2hhZG93OiBgMCAwIDhweCAke2NvbG9yfTgwYCxcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJ3aWR0aCAwLjVzIGVhc2Utb3V0XCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vIOKUgOKUgCBQZXItcm9sZSBkZXYgdGVzdCBhY3Rpb24gYnV0dG9ucyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuaW50ZXJmYWNlIFJvbGVEZXZQYW5lbFByb3BzIHtcbiAgcm9sZTogUGxheWVyUm9sZTtcbiAgcHJvZ3Jlc3M6IG51bWJlcjtcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIGFjdGlvbnM6IFJldHVyblR5cGU8dHlwZW9mIHVzZUZhY3RvcnlTdG9yZS51c2VBY3Rpb25zPjtcbiAgY29vbGluZ1RlbXA6IG51bWJlcjtcbn1cblxuZnVuY3Rpb24gUm9sZURldlBhbmVsKHsgcm9sZSwgcHJvZ3Jlc3MsIHN0YXR1cywgYWN0aW9ucywgY29vbGluZ1RlbXAgfTogUm9sZURldlBhbmVsUHJvcHMpIHtcbiAgY29uc3QgY29sb3IgPSBST0xFX0NPTE9SU1tyb2xlXTtcbiAgY29uc3QgYW10ID0gR0FNRV9DT05GSUcuZGV2SW5jcmVtZW50QW1vdW50O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtNiB3LWZ1bGxcIj5cbiAgICAgIHsvKiBQcm9ncmVzcyBkaXNwbGF5ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmFjdG9yeS1wYW5lbCBwLTQgZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTQwMFwiPlByb2dyZXNzPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtMnhsXCIgc3R5bGU9e3sgY29sb3IgfX0+e3Byb2dyZXNzfSU8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtNCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9ncmVzcy1maWxsIGFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwcm9ncmVzc30lYCwgYmFja2dyb3VuZDogY29sb3IgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj57c3RhdHVzfTwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBSb2xlLXNwZWNpZmljIGRldiBjb250cm9scyAqL31cbiAgICAgIHtyb2xlID09PSBcInBvd2VyXCIgJiYgKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY3RybC1idXR0b24gdy1mdWxsIHJvdW5kZWQtMnhsIHB5LTggdGV4dC0zeGwgZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBgJHtjb2xvcn0yNWAsIGJvcmRlcjogYDJweCBzb2xpZCAke2NvbG9yfTYwYCwgY29sb3IgfX1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhY3Rpb25zLmRldkluY3JlbWVudFBvd2VyKHsgYW1vdW50OiBhbXQgfSl9XG4gICAgICAgID5cbiAgICAgICAgICDimqEgVEFQIFBPV0VSXG4gICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCBub3JtYWwtY2FzZVwiPit7YW10fSUgcGVyIHRhcDwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICApfVxuXG4gICAgICB7cm9sZSA9PT0gXCJkYXRhXCIgJiYgKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY3RybC1idXR0b24gdy1mdWxsIHJvdW5kZWQtMnhsIHB5LTggdGV4dC0zeGwgZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBgJHtjb2xvcn0yNWAsIGJvcmRlcjogYDJweCBzb2xpZCAke2NvbG9yfTYwYCwgY29sb3IgfX1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhY3Rpb25zLmRldkluY3JlbWVudERhdGEoeyBhbW91bnQ6IGFtdCB9KX1cbiAgICAgICAgPlxuICAgICAgICAgIPCfkr4gU09SVCBEQVRBXG4gICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCBub3JtYWwtY2FzZVwiPit7YW10fSUgcGVyIHNvcnQ8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cblxuICAgICAge3JvbGUgPT09IFwic2VjdXJpdHlcIiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyB3LWZ1bGxcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uIGZsZXgtMSByb3VuZGVkLTJ4bCBweS04IHRleHQtMnhsIGZvbnQtYmxhY2sgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IGAke2NvbG9yfTI1YCwgYm9yZGVyOiBgMnB4IHNvbGlkICR7Y29sb3J9NjBgLCBjb2xvciB9fVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWN0aW9ucy5kZXZJbmNyZW1lbnRTZWN1cml0eSh7IGFtb3VudDogYW10IH0pfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIFpJUDxiciAvPjxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ub3JtYWxcIj4re2FtdH0lPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3RybC1idXR0b24gZmxleC0xIHJvdW5kZWQtMnhsIHB5LTggdGV4dC0yeGwgZm9udC1ibGFjayBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogYCR7Y29sb3J9MjVgLCBib3JkZXI6IGAycHggc29saWQgJHtjb2xvcn02MGAsIGNvbG9yIH19XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhY3Rpb25zLmRldkluY3JlbWVudFNlY3VyaXR5KHsgYW1vdW50OiBhbXQgfSl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgWkFQPGJyIC8+PHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbFwiPit7YW10fSU8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge3JvbGUgPT09IFwibW9kZWxcIiAmJiAoXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJjdHJsLWJ1dHRvbiB3LWZ1bGwgcm91bmRlZC0yeGwgcHktOCB0ZXh0LTN4bCBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IGAke2NvbG9yfTI1YCwgYm9yZGVyOiBgMnB4IHNvbGlkICR7Y29sb3J9NjBgLCBjb2xvciB9fVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFjdGlvbnMuZGV2SW5jcmVtZW50TW9kZWwoeyBhbW91bnQ6IGFtdCB9KX1cbiAgICAgICAgPlxuICAgICAgICAgIPCfp6AgT1BUSU1JWkVcbiAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbm9ybWFsIG5vcm1hbC1jYXNlXCI+K3thbXR9JSBwZXIgc29sdmU8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKX1cblxuICAgICAge3JvbGUgPT09IFwiY29vbGluZ1wiICYmIChcbiAgICAgICAgPENvb2xpbmdEZXZQYW5lbFxuICAgICAgICAgIHRlbXBlcmF0dXJlPXtjb29saW5nVGVtcH1cbiAgICAgICAgICBvblNldD17KHQpID0+IGFjdGlvbnMuZGV2U2V0Q29vbGluZ1RlbXAoeyB0ZW1wZXJhdHVyZTogdCB9KX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICBERVYgVEVTVCBNT0RFIMK3IFJlYWwgbWluaS1nYW1lIGluIG5leHQgbWlsZXN0b25lXG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLy8g4pSA4pSAIE1haW4gQ29udHJvbGxlciBWaWV3IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlclZpZXcoKSB7XG4gIGNvbnN0IGNvbnRyb2xsZXIgPSB1c2VBaXJKYW1Db250cm9sbGVyKCk7XG4gIC8vIFR5cGVkIHNlbGVjdG9yIHRvIGF2b2lkIGBzdGF0ZSBpcyB1bmtub3duYCBUUyBlcnJvci5cbiAgY29uc3Qgc3RhdGUgPSB1c2VGYWN0b3J5U3RvcmUoKHM6IEZhY3RvcnlTdGF0ZSkgPT4gcyk7XG4gIGNvbnN0IGFjdGlvbnMgPSB1c2VGYWN0b3J5U3RvcmUudXNlQWN0aW9ucygpO1xuICBjb25zdCByZXF1ZXN0ZWRSZWYgPSB1c2VSZWYoZmFsc2UpO1xuXG4gIGNvbnN0IG15SWQgPSBjb250cm9sbGVyLmNvbnRyb2xsZXJJZDtcbiAgY29uc3QgbXlSb2xlID0gbXlJZCA/IChzdGF0ZS5yb2xlQXNzaWdubWVudHNbbXlJZF0gYXMgUGxheWVyUm9sZSB8IHVuZGVmaW5lZCkgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IGNvbm5lY3RlZCA9IGNvbnRyb2xsZXIuY29ubmVjdGlvblN0YXR1cyA9PT0gXCJjb25uZWN0ZWRcIjtcbiAgY29uc3QgY29sb3IgPSBteVJvbGUgPyBST0xFX0NPTE9SU1tteVJvbGVdIDogXCIjMzhiZGY4XCI7XG5cbiAgLy8gQXV0by1yZXF1ZXN0IHJvbGUgb25jZSBjb25uZWN0ZWQuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGNvbm5lY3RlZCAmJiAhbXlSb2xlICYmICFyZXF1ZXN0ZWRSZWYuY3VycmVudCkge1xuICAgICAgcmVxdWVzdGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgYWN0aW9ucy5yZXF1ZXN0Um9sZSgpO1xuICAgIH1cbiAgfSwgW2Nvbm5lY3RlZCwgbXlSb2xlLCBhY3Rpb25zXSk7XG5cbiAgLy8g4pSA4pSAIENvbm5lY3Rpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGlmICghY29ubmVjdGVkKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxTdXJmYWNlVmlld3BvcnQgb3JpZW50YXRpb249XCJwb3J0cmFpdFwiIGNsYXNzTmFtZT1cImJnLVsjMDUwYTE0XVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTQgcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBhbmltYXRlLXB1bHNlXCI+8J+PrTwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1za3ktNDAwXCI+QUkgRkFDVE9SWTwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAge2NvbnRyb2xsZXIuY29ubmVjdGlvblN0YXR1cyA9PT0gXCJjb25uZWN0aW5nXCJcbiAgICAgICAgICAgICAgPyBcIkNvbm5lY3RpbmcgdG8gZmFjdG9yeeKAplwiXG4gICAgICAgICAgICAgIDogXCJSZWNvbm5lY3RpbmfigKZcIn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7Y29udHJvbGxlci5jb25uZWN0aW9uU3RhdHVzID09PSBcImRpc2Nvbm5lY3RlZFwiICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uIG10LTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNreS00MDAvMzAgcHgtNiBweS0yIHRleHQtc20gdGV4dC1za3ktNDAwIGhvdmVyOmJnLXNreS00MDAvMTBcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtjb250cm9sbGVyLnJlY29ubmVjdH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgUmV0cnkgQ29ubmVjdGlvblxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1N1cmZhY2VWaWV3cG9ydD5cbiAgICApO1xuICB9XG5cbiAgLy8g4pSA4pSAIFdhaXRpbmcgZm9yIHJvbGUgYXNzaWdubWVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgaWYgKCFteVJvbGUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPFN1cmZhY2VWaWV3cG9ydCBvcmllbnRhdGlvbj1cInBvcnRyYWl0XCIgY2xhc3NOYW1lPVwiYmctWyMwNTBhMTRdXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgdy1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtNHhsIGFuaW1hdGUtc3BpblwiPuKame+4jzwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1za3ktNDAwXCI+Sm9pbmluZyBGYWN0b3J54oCmPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwXCI+V2FpdGluZyBmb3Igcm9sZSBhc3NpZ25tZW50PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TdXJmYWNlVmlld3BvcnQ+XG4gICAgKTtcbiAgfVxuXG4gIC8vIOKUgOKUgCBMb2JieSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgaWYgKHN0YXRlLnBoYXNlID09PSBcImlkbGVcIiB8fCBzdGF0ZS5waGFzZSA9PT0gXCJsb2JieVwiKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxTdXJmYWNlVmlld3BvcnQgb3JpZW50YXRpb249XCJwb3J0cmFpdFwiIGNsYXNzTmFtZT1cImJnLVsjMDUwYTE0XVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTYgcC02XCI+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmFjdG9yeS1wYW5lbCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMyBwLTggdy1mdWxsIG1heC13LXhzXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlckNvbG9yOiBgJHtjb2xvcn02MGAsIGJveFNoYWRvdzogYDAgMCAyNHB4ICR7Y29sb3J9MjVgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTZ4bFwiPntST0xFX0lDT05TW215Um9sZV19PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTQwMFwiPllvdXIgUm9sZTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrXCIgc3R5bGU9e3sgY29sb3IgfX0+XG4gICAgICAgICAgICAgIHtST0xFX0xBQkVMU1tteVJvbGVdfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAge1JPTEVfTUlOSV9HQU1FW215Um9sZV19XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICB7T2JqZWN0LmtleXMoc3RhdGUucm9sZUFzc2lnbm1lbnRzKS5sZW5ndGh9IC8ge0dBTUVfQ09ORklHLm1heFBsYXllcnN9IGVuZ2luZWVycyByZWFkeVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXNreS00MDAgYW5pbWF0ZS1wdWxzZVwiPlxuICAgICAgICAgICAgICBXYWl0aW5nIGZvciBob3N0IHRvIHN0YXJ04oCmXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICBJRDoge215SWQ/LnNsaWNlKDAsIDEyKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1N1cmZhY2VWaWV3cG9ydD5cbiAgICApO1xuICB9XG5cbiAgLy8g4pSA4pSAIFBsYXlpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGlmIChzdGF0ZS5waGFzZSA9PT0gXCJwbGF5aW5nXCIpIHtcbiAgICBjb25zdCBkZXB0U3RhdGUgPSBzdGF0ZVtteVJvbGVdIGFzIHsgcHJvZ3Jlc3M6IG51bWJlcjsgc3RhdHVzOiBzdHJpbmcgfTtcbiAgICBjb25zdCBteUV2ZW50ID0gc3RhdGUuYWN0aXZlRXZlbnRzLmZpbmQoKGUpID0+IGUuYWZmZWN0ZWRSb2xlID09PSBteVJvbGUpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxTdXJmYWNlVmlld3BvcnQgb3JpZW50YXRpb249XCJwb3J0cmFpdFwiIGNsYXNzTmFtZT1cImJnLVsjMDUwYTE0XVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBnYXAtNCBwLTRcIj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmYWN0b3J5LXN1cmZhY2UgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtNCBweS0zXCJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGJvcmRlckNvbG9yOiBteUV2ZW50ID8gYHJnYmEoMjUxLDE0Niw2MCwwLjcpYCA6IGAke2NvbG9yfTQwYCxcbiAgICAgICAgICAgICAgYW5pbWF0aW9uOiBteUV2ZW50ID8gXCJ3YXJuaW5nUHVsc2UgMC44cyBlYXNlLWluLW91dCBpbmZpbml0ZVwiIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcImJvcmRlci1jb2xvciAwLjNzIGVhc2VcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj57Uk9MRV9JQ09OU1tteVJvbGVdfTwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+Um9sZTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ibGFja1wiIHN0eWxlPXt7IGNvbG9yIH19PlxuICAgICAgICAgICAgICAgIHtST0xFX0xBQkVMU1tteVJvbGVdfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC1hdXRvIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+VGltZTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtTdHJpbmcoTWF0aC5mbG9vcihzdGF0ZS50aW1lUmVtYWluaW5nIC8gNjApKS5wYWRTdGFydCgyLCBcIjBcIil9OlxuICAgICAgICAgICAgICAgIHtTdHJpbmcoc3RhdGUudGltZVJlbWFpbmluZyAlIDYwKS5wYWRTdGFydCgyLCBcIjBcIil9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRXZlbnQgd2FybmluZyBmb3IgdGhpcyBwbGF5ZXIncyBkZXBhcnRtZW50ICovfVxuICAgICAgICAgIHtteUV2ZW50ICYmIChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjhweCAxMnB4XCIsXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA4LFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSgyNTEsMTQ2LDYwLDAuMSlcIixcbiAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHJnYmEoMjUxLDE0Niw2MCwwLjUpXCIsXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IDExLFxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcbiAgICAgICAgICAgICAgICBjb2xvcjogXCIjZmI5MjNjXCIsXG4gICAgICAgICAgICAgICAgdGV4dEFsaWduOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNmVtXCIsXG4gICAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcbiAgICAgICAgICAgICAgICBhbmltYXRpb246IFwid2FybmluZ1B1bHNlIDAuOXMgZWFzZS1pbi1vdXQgaW5maW5pdGVcIixcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge215RXZlbnQubWVzc2FnZX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAge215Um9sZSA9PT0gXCJwb3dlclwiID8gKFxuICAgICAgICAgICAgICA8UG93ZXJHYW1lXG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3M9e2RlcHRTdGF0ZS5wcm9ncmVzc31cbiAgICAgICAgICAgICAgICBzdGF0dXM9e2RlcHRTdGF0ZS5zdGF0dXN9XG4gICAgICAgICAgICAgICAgc2NvcmU9eyhzdGF0ZS5wb3dlciBhcyB7IHNjb3JlOiBudW1iZXIgfSkuc2NvcmV9XG4gICAgICAgICAgICAgICAgb25UYXA9eygpID0+IGFjdGlvbnMudGFwUG93ZXIoKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiBteVJvbGUgPT09IFwiZGF0YVwiID8gKFxuICAgICAgICAgICAgICA8RGF0YUNsZWFuaW5nR2FtZVxuICAgICAgICAgICAgICAgIHByb2dyZXNzPXtkZXB0U3RhdGUucHJvZ3Jlc3N9XG4gICAgICAgICAgICAgICAgc3RhdHVzPXtkZXB0U3RhdGUuc3RhdHVzfVxuICAgICAgICAgICAgICAgIHNjb3JlPXsoc3RhdGUuZGF0YSBhcyB7IHNjb3JlOiBudW1iZXIgfSkuc2NvcmV9XG4gICAgICAgICAgICAgICAgb25Tb3J0PXsodG9rZW4sIGJ1Y2tldCwgY29ycmVjdCkgPT5cbiAgICAgICAgICAgICAgICAgIGFjdGlvbnMuc29ydERhdGEoeyB0b2tlbiwgYnVja2V0LCBjb3JyZWN0IH0pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSA6IG15Um9sZSA9PT0gXCJzZWN1cml0eVwiID8gKFxuICAgICAgICAgICAgICA8WmlwWmFwR2FtZVxuICAgICAgICAgICAgICAgIHByb2dyZXNzPXtkZXB0U3RhdGUucHJvZ3Jlc3N9XG4gICAgICAgICAgICAgICAgc3RhdHVzPXtkZXB0U3RhdGUuc3RhdHVzfVxuICAgICAgICAgICAgICAgIHNjb3JlPXsoc3RhdGUuc2VjdXJpdHkgYXMgeyBzY29yZTogbnVtYmVyIH0pLnNjb3JlfVxuICAgICAgICAgICAgICAgIG9uWmlwWmFwPXsoaGl0KSA9PiBhY3Rpb25zLnppcFphcCh7IGhpdCB9KX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiBteVJvbGUgPT09IFwibW9kZWxcIiA/IChcbiAgICAgICAgICAgICAgPEFpQ29yZVB1enpsZUdhbWVcbiAgICAgICAgICAgICAgICBwcm9ncmVzcz17ZGVwdFN0YXRlLnByb2dyZXNzfVxuICAgICAgICAgICAgICAgIHN0YXR1cz17ZGVwdFN0YXRlLnN0YXR1c31cbiAgICAgICAgICAgICAgICBzY29yZT17KHN0YXRlLm1vZGVsIGFzIHsgc2NvcmU6IG51bWJlciB9KS5zY29yZX1cbiAgICAgICAgICAgICAgICBvblNvbHZlPXsoKSA9PiBhY3Rpb25zLnNvbHZlUHV6emxlKCl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApIDogbXlSb2xlID09PSBcImNvb2xpbmdcIiA/IChcbiAgICAgICAgICAgICAgPENvb2xpbmdHYW1lXG4gICAgICAgICAgICAgICAgdGVtcGVyYXR1cmU9e3N0YXRlLmNvb2xpbmcudGVtcGVyYXR1cmV9XG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3M9e2RlcHRTdGF0ZS5wcm9ncmVzc31cbiAgICAgICAgICAgICAgICBzdGF0dXM9e2RlcHRTdGF0ZS5zdGF0dXN9XG4gICAgICAgICAgICAgICAgc2NvcmU9eyhzdGF0ZS5jb29saW5nIGFzIHsgc2NvcmU6IG51bWJlciB9KS5zY29yZX1cbiAgICAgICAgICAgICAgICBvblRpY2s9eyhjZW50ZXJlZG5lc3MpID0+IGFjdGlvbnMuY29vbFRpY2soeyBjZW50ZXJlZG5lc3MgfSl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8Um9sZURldlBhbmVsXG4gICAgICAgICAgICAgICAgcm9sZT17bXlSb2xlfVxuICAgICAgICAgICAgICAgIHByb2dyZXNzPXtkZXB0U3RhdGUucHJvZ3Jlc3N9XG4gICAgICAgICAgICAgICAgc3RhdHVzPXtkZXB0U3RhdGUuc3RhdHVzfVxuICAgICAgICAgICAgICAgIGFjdGlvbnM9e2FjdGlvbnN9XG4gICAgICAgICAgICAgICAgY29vbGluZ1RlbXA9e3N0YXRlLmNvb2xpbmcudGVtcGVyYXR1cmV9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU3VyZmFjZVZpZXdwb3J0PlxuICAgICk7XG4gIH1cblxuICAvLyDilIDilIAgRW5kZWQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IHN1Y2Nlc3MgPSBzdGF0ZS5maW5hbFJlc3VsdCA9PT0gXCJzdWNjZXNzXCI7XG4gIHJldHVybiAoXG4gICAgPFN1cmZhY2VWaWV3cG9ydCBvcmllbnRhdGlvbj1cInBvcnRyYWl0XCIgY2xhc3NOYW1lPVwiYmctWyMwNTBhMTRdXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIHctZnVsbCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTYgcC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC02eGxcIj57c3VjY2VzcyA/IFwi8J+OiVwiIDogXCLwn5KlXCJ9PC9kaXY+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtY2VudGVyXCJcbiAgICAgICAgICBzdHlsZT17eyBjb2xvcjogc3VjY2VzcyA/IFwiIzRhZGU4MFwiIDogXCIjZjg3MTcxXCIgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHtzdWNjZXNzID8gXCJBSSBERVBMT1lFRCFcIiA6IFwiRkFDVE9SWSBGQUlMRURcIn1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmFjdG9yeS1wYW5lbCBwLTYgdy1mdWxsIG1heC13LXhzIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+WW91ciBEZXBhcnRtZW50PC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCBtdC0xXCIgc3R5bGU9e3sgY29sb3IgfX0+XG4gICAgICAgICAgICB7Uk9MRV9JQ09OU1tteVJvbGVdfSB7Uk9MRV9MQUJFTFNbbXlSb2xlXX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgbXQtMlwiIHN0eWxlPXt7IGNvbG9yIH19PlxuICAgICAgICAgICAgeyhzdGF0ZVtteVJvbGVdIGFzIHsgcHJvZ3Jlc3M6IG51bWJlciB9KS5wcm9ncmVzc30lXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICBGYWN0b3J5IEhlYWx0aDp7XCIgXCJ9XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj57c3RhdGUuZmFjdG9yeUhlYWx0aH0lPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgVGVhbSBTY29yZTp7XCIgXCJ9XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2t5LTQwMFwiPntzdGF0ZS50ZWFtU2NvcmUudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9TdXJmYWNlVmlld3BvcnQ+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0FpRmFjdG9yeS9zcmMvY29udHJvbGxlci9pbmRleC50c3gifQ==