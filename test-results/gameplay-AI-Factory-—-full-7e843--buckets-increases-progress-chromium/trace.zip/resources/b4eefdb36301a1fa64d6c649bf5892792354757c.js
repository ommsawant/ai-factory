import {
  agentAction,
  agentActionInput,
  agentStore,
  defineAirJamAgentContract,
  defineAirJamAgentStores
} from "/node_modules/.vite/deps/@air-jam_sdk.js?v=c74894a2";
import { z } from "/node_modules/.vite/deps/zod.js?v=c74894a2";
const stores = defineAirJamAgentStores({
  default: agentStore()
});
export const agentContract = defineAirJamAgentContract({
  stores,
  snapshotDescription: "AI Factory game state snapshot: phase, timer, department progresses, factory health, team score, and role assignments.",
  projectSnapshot: (context) => {
    const state = context.stores.default;
    if (!state) {
      return { available: false, summary: "Factory store not yet available." };
    }
    return {
      available: true,
      phase: state.phase,
      timeRemaining: state.timeRemaining,
      roleAssignments: state.roleAssignments,
      playerCount: Object.keys(state.roleAssignments).length,
      departments: {
        power: { progress: state.power.progress, status: state.power.status, score: state.power.score },
        data: { progress: state.data.progress, status: state.data.status, score: state.data.score },
        security: { progress: state.security.progress, status: state.security.status, score: state.security.score },
        model: { progress: state.model.progress, status: state.model.status, score: state.model.score },
        cooling: {
          progress: state.cooling.progress,
          status: state.cooling.status,
          score: state.cooling.score,
          temperature: state.cooling.temperature
        }
      },
      factoryHealth: state.factoryHealth,
      teamScore: state.teamScore,
      activeEvents: state.activeEvents,
      finalResult: state.finalResult
    };
  },
  actions: {
    start_game: agentAction.host(
      { actionName: "startGame" },
      {
        input: agentActionInput.none(),
        description: "Start the AI Factory game session. Requires all 5 roles to be filled.",
        availability: "Only when phase is 'lobby' and 5 players are connected.",
        resultDescription: "Phase transitions to 'playing'. All departments become active."
      }
    ),
    reset_game: agentAction.host(
      { actionName: "resetGame" },
      {
        input: agentActionInput.none(),
        description: "Reset the entire session back to idle state.",
        availability: "Any time.",
        resultDescription: "All state is cleared. Phase returns to 'idle'."
      }
    ),
    tap_power: agentAction.participant(
      { actionName: "tapPower" },
      {
        input: agentActionInput.none(),
        description: "Send a single power tap from the Power Engineer controller. Increments Power progress by the configured amount.",
        availability: "Only while phase is 'playing' and the caller is assigned the 'power' role.",
        resultDescription: "Power progress increases. Factory health and team score update. When progress reaches 100, Power is marked COMPLETE."
      }
    ),
    sort_data: agentAction.participant(
      { actionName: "sortData" },
      {
        input: agentActionInput.zod(
          z.object({
            token: z.string().describe("The data token being sorted, e.g. '42' or 'AI'."),
            bucket: z.enum(["numbers", "ai_terms"]).describe("The bucket the player placed the token into."),
            correct: z.boolean().describe("True when the player placed the token in the correct bucket.")
          })
        ),
        description: "Send a data sort action from the Data Engineer controller. Correct placements advance Data progress; incorrect ones are acknowledged with no penalty.",
        availability: "Only while phase is 'playing' and the caller is assigned the 'data' role.",
        resultDescription: "On correct=true: Data progress increases by dataIncrementPerSort, factory health and team score update. On correct=false: no state change."
      }
    ),
    zip_zap: agentAction.participant(
      { actionName: "zipZap" },
      {
        input: agentActionInput.zod(
          z.object({
            hit: z.boolean().describe(
              "True when the Security Engineer pressed the correct ZIP or ZAP button for the current sequence step. False when they pressed the wrong button."
            )
          })
        ),
        description: "Send a Zip-Zap Firewall press from the Security Engineer controller. The controller owns the sequence and validates locally; the store receives only whether the press was correct.",
        availability: "Only while phase is 'playing' and the caller is assigned the 'security' role.",
        resultDescription: "On hit=true: Security progress increases by securityIncrementPerHit, factory health and team score update. On hit=false: Security progress decreases by securityPenaltyPerMiss (clamped to 0), no score change."
      }
    ),
    solve_puzzle: agentAction.participant(
      { actionName: "solvePuzzle" },
      {
        input: agentActionInput.zod(z.object({})),
        description: "Send a puzzle solve action from the AI Model Engineer controller. This indicates the player successfully arranged the current AI pipeline puzzle. The puzzle validation is handled locally by the controller.",
        availability: "Only while phase is 'playing' and the caller is assigned the 'model' role.",
        resultDescription: "Model progress increases by modelIncrementPerSolve, factory health and team score update."
      }
    ),
    dev_increment_power: agentAction.participant(
      { actionName: "devIncrementPower" },
      {
        input: agentActionInput.zod(
          z.object({ amount: z.number().int().min(1).max(100) })
        ),
        description: "[DEV] Increment the Power department progress by the given amount.",
        availability: "Only while phase is 'playing'.",
        resultDescription: "Power progress, factory health, and team score update."
      }
    ),
    dev_increment_data: agentAction.participant(
      { actionName: "devIncrementData" },
      {
        input: agentActionInput.zod(
          z.object({ amount: z.number().int().min(1).max(100) })
        ),
        description: "[DEV] Increment the Data department progress.",
        availability: "Only while phase is 'playing'.",
        resultDescription: "Data progress, factory health, and team score update."
      }
    ),
    dev_increment_security: agentAction.participant(
      { actionName: "devIncrementSecurity" },
      {
        input: agentActionInput.zod(
          z.object({ amount: z.number().int().min(1).max(100) })
        ),
        description: "[DEV] Increment the Security department progress.",
        availability: "Only while phase is 'playing'.",
        resultDescription: "Security progress, factory health, and team score update."
      }
    ),
    dev_increment_model: agentAction.participant(
      { actionName: "devIncrementModel" },
      {
        input: agentActionInput.zod(
          z.object({ amount: z.number().int().min(1).max(100) })
        ),
        description: "[DEV] Increment the AI Model department progress.",
        availability: "Only while phase is 'playing'.",
        resultDescription: "Model progress, factory health, and team score update."
      }
    ),
    dev_set_cooling_temp: agentAction.participant(
      { actionName: "devSetCoolingTemp" },
      {
        input: agentActionInput.zod(
          z.object({ temperature: z.number().min(50).max(120) })
        ),
        description: "[DEV] Set the Cooling department temperature directly.",
        availability: "Only while phase is 'playing'.",
        resultDescription: "Cooling temperature, progress, and factory health update."
      }
    )
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogU2VtYW50aWMgYWdlbnQgY29udHJhY3QgZm9yIEFJIEZhY3RvcnkuXG4gKlxuICogRXhwb3NlcyBhIHNuYXBzaG90IG9mIHRoZSBGYWN0b3J5U3RhdGUgZm9yIE1DUCB0b29scyBhbmQgYXV0b21hdGVkIGFnZW50cyxcbiAqIGFuZCBkZWNsYXJlcyB0aGUgYXZhaWxhYmxlIHNlbWFudGljIGFjdGlvbnMuXG4gKi9cbmltcG9ydCB7XG4gIGFnZW50QWN0aW9uLFxuICBhZ2VudEFjdGlvbklucHV0LFxuICBhZ2VudFN0b3JlLFxuICBkZWZpbmVBaXJKYW1BZ2VudENvbnRyYWN0LFxuICBkZWZpbmVBaXJKYW1BZ2VudFN0b3Jlcyxcbn0gZnJvbSBcIkBhaXItamFtL3Nka1wiO1xuaW1wb3J0IHsgeiB9IGZyb20gXCJ6b2RcIjtcbmltcG9ydCB0eXBlIHsgRmFjdG9yeVN0YXRlIH0gZnJvbSBcIi4uL3N0b3JlL2ZhY3RvcnlTdG9yZVwiO1xuXG5jb25zdCBzdG9yZXMgPSBkZWZpbmVBaXJKYW1BZ2VudFN0b3Jlcyh7XG4gIGRlZmF1bHQ6IGFnZW50U3RvcmU8RmFjdG9yeVN0YXRlPigpLFxufSk7XG5cbmV4cG9ydCBjb25zdCBhZ2VudENvbnRyYWN0ID0gZGVmaW5lQWlySmFtQWdlbnRDb250cmFjdCh7XG4gIHN0b3JlcyxcbiAgc25hcHNob3REZXNjcmlwdGlvbjpcbiAgICBcIkFJIEZhY3RvcnkgZ2FtZSBzdGF0ZSBzbmFwc2hvdDogcGhhc2UsIHRpbWVyLCBkZXBhcnRtZW50IHByb2dyZXNzZXMsIGZhY3RvcnkgaGVhbHRoLCB0ZWFtIHNjb3JlLCBhbmQgcm9sZSBhc3NpZ25tZW50cy5cIixcbiAgcHJvamVjdFNuYXBzaG90OiAoY29udGV4dCkgPT4ge1xuICAgIGNvbnN0IHN0YXRlID0gY29udGV4dC5zdG9yZXMuZGVmYXVsdDtcbiAgICBpZiAoIXN0YXRlKSB7XG4gICAgICByZXR1cm4geyBhdmFpbGFibGU6IGZhbHNlLCBzdW1tYXJ5OiBcIkZhY3Rvcnkgc3RvcmUgbm90IHlldCBhdmFpbGFibGUuXCIgfTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgcGhhc2U6IHN0YXRlLnBoYXNlLFxuICAgICAgdGltZVJlbWFpbmluZzogc3RhdGUudGltZVJlbWFpbmluZyxcbiAgICAgIHJvbGVBc3NpZ25tZW50czogc3RhdGUucm9sZUFzc2lnbm1lbnRzLFxuICAgICAgcGxheWVyQ291bnQ6IE9iamVjdC5rZXlzKHN0YXRlLnJvbGVBc3NpZ25tZW50cykubGVuZ3RoLFxuICAgICAgZGVwYXJ0bWVudHM6IHtcbiAgICAgICAgcG93ZXI6IHsgcHJvZ3Jlc3M6IHN0YXRlLnBvd2VyLnByb2dyZXNzLCBzdGF0dXM6IHN0YXRlLnBvd2VyLnN0YXR1cywgc2NvcmU6IHN0YXRlLnBvd2VyLnNjb3JlIH0sXG4gICAgICAgIGRhdGE6IHsgcHJvZ3Jlc3M6IHN0YXRlLmRhdGEucHJvZ3Jlc3MsIHN0YXR1czogc3RhdGUuZGF0YS5zdGF0dXMsIHNjb3JlOiBzdGF0ZS5kYXRhLnNjb3JlIH0sXG4gICAgICAgIHNlY3VyaXR5OiB7IHByb2dyZXNzOiBzdGF0ZS5zZWN1cml0eS5wcm9ncmVzcywgc3RhdHVzOiBzdGF0ZS5zZWN1cml0eS5zdGF0dXMsIHNjb3JlOiBzdGF0ZS5zZWN1cml0eS5zY29yZSB9LFxuICAgICAgICBtb2RlbDogeyBwcm9ncmVzczogc3RhdGUubW9kZWwucHJvZ3Jlc3MsIHN0YXR1czogc3RhdGUubW9kZWwuc3RhdHVzLCBzY29yZTogc3RhdGUubW9kZWwuc2NvcmUgfSxcbiAgICAgICAgY29vbGluZzoge1xuICAgICAgICAgIHByb2dyZXNzOiBzdGF0ZS5jb29saW5nLnByb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogc3RhdGUuY29vbGluZy5zdGF0dXMsXG4gICAgICAgICAgc2NvcmU6IHN0YXRlLmNvb2xpbmcuc2NvcmUsXG4gICAgICAgICAgdGVtcGVyYXR1cmU6IHN0YXRlLmNvb2xpbmcudGVtcGVyYXR1cmUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgZmFjdG9yeUhlYWx0aDogc3RhdGUuZmFjdG9yeUhlYWx0aCxcbiAgICAgIHRlYW1TY29yZTogc3RhdGUudGVhbVNjb3JlLFxuICAgICAgYWN0aXZlRXZlbnRzOiBzdGF0ZS5hY3RpdmVFdmVudHMsXG4gICAgICBmaW5hbFJlc3VsdDogc3RhdGUuZmluYWxSZXN1bHQsXG4gICAgfTtcbiAgfSxcbiAgYWN0aW9uczoge1xuICAgIHN0YXJ0X2dhbWU6IGFnZW50QWN0aW9uLmhvc3QoXG4gICAgICB7IGFjdGlvbk5hbWU6IFwic3RhcnRHYW1lXCIgfSxcbiAgICAgIHtcbiAgICAgICAgaW5wdXQ6IGFnZW50QWN0aW9uSW5wdXQubm9uZSgpLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTdGFydCB0aGUgQUkgRmFjdG9yeSBnYW1lIHNlc3Npb24uIFJlcXVpcmVzIGFsbCA1IHJvbGVzIHRvIGJlIGZpbGxlZC5cIixcbiAgICAgICAgYXZhaWxhYmlsaXR5OiBcIk9ubHkgd2hlbiBwaGFzZSBpcyAnbG9iYnknIGFuZCA1IHBsYXllcnMgYXJlIGNvbm5lY3RlZC5cIixcbiAgICAgICAgcmVzdWx0RGVzY3JpcHRpb246IFwiUGhhc2UgdHJhbnNpdGlvbnMgdG8gJ3BsYXlpbmcnLiBBbGwgZGVwYXJ0bWVudHMgYmVjb21lIGFjdGl2ZS5cIixcbiAgICAgIH0sXG4gICAgKSxcbiAgICByZXNldF9nYW1lOiBhZ2VudEFjdGlvbi5ob3N0KFxuICAgICAgeyBhY3Rpb25OYW1lOiBcInJlc2V0R2FtZVwiIH0sXG4gICAgICB7XG4gICAgICAgIGlucHV0OiBhZ2VudEFjdGlvbklucHV0Lm5vbmUoKSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiUmVzZXQgdGhlIGVudGlyZSBzZXNzaW9uIGJhY2sgdG8gaWRsZSBzdGF0ZS5cIixcbiAgICAgICAgYXZhaWxhYmlsaXR5OiBcIkFueSB0aW1lLlwiLFxuICAgICAgICByZXN1bHREZXNjcmlwdGlvbjogXCJBbGwgc3RhdGUgaXMgY2xlYXJlZC4gUGhhc2UgcmV0dXJucyB0byAnaWRsZScuXCIsXG4gICAgICB9LFxuICAgICksXG4gICAgdGFwX3Bvd2VyOiBhZ2VudEFjdGlvbi5wYXJ0aWNpcGFudChcbiAgICAgIHsgYWN0aW9uTmFtZTogXCJ0YXBQb3dlclwiIH0sXG4gICAgICB7XG4gICAgICAgIGlucHV0OiBhZ2VudEFjdGlvbklucHV0Lm5vbmUoKSxcbiAgICAgICAgZGVzY3JpcHRpb246XG4gICAgICAgICAgXCJTZW5kIGEgc2luZ2xlIHBvd2VyIHRhcCBmcm9tIHRoZSBQb3dlciBFbmdpbmVlciBjb250cm9sbGVyLiBJbmNyZW1lbnRzIFBvd2VyIHByb2dyZXNzIGJ5IHRoZSBjb25maWd1cmVkIGFtb3VudC5cIixcbiAgICAgICAgYXZhaWxhYmlsaXR5OiBcIk9ubHkgd2hpbGUgcGhhc2UgaXMgJ3BsYXlpbmcnIGFuZCB0aGUgY2FsbGVyIGlzIGFzc2lnbmVkIHRoZSAncG93ZXInIHJvbGUuXCIsXG4gICAgICAgIHJlc3VsdERlc2NyaXB0aW9uOlxuICAgICAgICAgIFwiUG93ZXIgcHJvZ3Jlc3MgaW5jcmVhc2VzLiBGYWN0b3J5IGhlYWx0aCBhbmQgdGVhbSBzY29yZSB1cGRhdGUuIFdoZW4gcHJvZ3Jlc3MgcmVhY2hlcyAxMDAsIFBvd2VyIGlzIG1hcmtlZCBDT01QTEVURS5cIixcbiAgICAgIH0sXG4gICAgKSxcbiAgICBzb3J0X2RhdGE6IGFnZW50QWN0aW9uLnBhcnRpY2lwYW50KFxuICAgICAgeyBhY3Rpb25OYW1lOiBcInNvcnREYXRhXCIgfSxcbiAgICAgIHtcbiAgICAgICAgaW5wdXQ6IGFnZW50QWN0aW9uSW5wdXQuem9kKFxuICAgICAgICAgIHoub2JqZWN0KHtcbiAgICAgICAgICAgIHRva2VuOiB6LnN0cmluZygpLmRlc2NyaWJlKFwiVGhlIGRhdGEgdG9rZW4gYmVpbmcgc29ydGVkLCBlLmcuICc0Micgb3IgJ0FJJy5cIiksXG4gICAgICAgICAgICBidWNrZXQ6IHouZW51bShbXCJudW1iZXJzXCIsIFwiYWlfdGVybXNcIl0pLmRlc2NyaWJlKFwiVGhlIGJ1Y2tldCB0aGUgcGxheWVyIHBsYWNlZCB0aGUgdG9rZW4gaW50by5cIiksXG4gICAgICAgICAgICBjb3JyZWN0OiB6LmJvb2xlYW4oKS5kZXNjcmliZShcIlRydWUgd2hlbiB0aGUgcGxheWVyIHBsYWNlZCB0aGUgdG9rZW4gaW4gdGhlIGNvcnJlY3QgYnVja2V0LlwiKSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgKSxcbiAgICAgICAgZGVzY3JpcHRpb246XG4gICAgICAgICAgXCJTZW5kIGEgZGF0YSBzb3J0IGFjdGlvbiBmcm9tIHRoZSBEYXRhIEVuZ2luZWVyIGNvbnRyb2xsZXIuIENvcnJlY3QgcGxhY2VtZW50cyBhZHZhbmNlIERhdGEgcHJvZ3Jlc3M7IGluY29ycmVjdCBvbmVzIGFyZSBhY2tub3dsZWRnZWQgd2l0aCBubyBwZW5hbHR5LlwiLFxuICAgICAgICBhdmFpbGFiaWxpdHk6IFwiT25seSB3aGlsZSBwaGFzZSBpcyAncGxheWluZycgYW5kIHRoZSBjYWxsZXIgaXMgYXNzaWduZWQgdGhlICdkYXRhJyByb2xlLlwiLFxuICAgICAgICByZXN1bHREZXNjcmlwdGlvbjpcbiAgICAgICAgICBcIk9uIGNvcnJlY3Q9dHJ1ZTogRGF0YSBwcm9ncmVzcyBpbmNyZWFzZXMgYnkgZGF0YUluY3JlbWVudFBlclNvcnQsIGZhY3RvcnkgaGVhbHRoIGFuZCB0ZWFtIHNjb3JlIHVwZGF0ZS4gT24gY29ycmVjdD1mYWxzZTogbm8gc3RhdGUgY2hhbmdlLlwiLFxuICAgICAgfSxcbiAgICApLFxuICAgIHppcF96YXA6IGFnZW50QWN0aW9uLnBhcnRpY2lwYW50KFxuICAgICAgeyBhY3Rpb25OYW1lOiBcInppcFphcFwiIH0sXG4gICAgICB7XG4gICAgICAgIGlucHV0OiBhZ2VudEFjdGlvbklucHV0LnpvZChcbiAgICAgICAgICB6Lm9iamVjdCh7XG4gICAgICAgICAgICBoaXQ6IHpcbiAgICAgICAgICAgICAgLmJvb2xlYW4oKVxuICAgICAgICAgICAgICAuZGVzY3JpYmUoXG4gICAgICAgICAgICAgICAgXCJUcnVlIHdoZW4gdGhlIFNlY3VyaXR5IEVuZ2luZWVyIHByZXNzZWQgdGhlIGNvcnJlY3QgWklQIG9yIFpBUCBidXR0b24gZm9yIHRoZSBjdXJyZW50IHNlcXVlbmNlIHN0ZXAuIEZhbHNlIHdoZW4gdGhleSBwcmVzc2VkIHRoZSB3cm9uZyBidXR0b24uXCIsXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgfSksXG4gICAgICAgICksXG4gICAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAgIFwiU2VuZCBhIFppcC1aYXAgRmlyZXdhbGwgcHJlc3MgZnJvbSB0aGUgU2VjdXJpdHkgRW5naW5lZXIgY29udHJvbGxlci4gVGhlIGNvbnRyb2xsZXIgb3ducyB0aGUgc2VxdWVuY2UgYW5kIHZhbGlkYXRlcyBsb2NhbGx5OyB0aGUgc3RvcmUgcmVjZWl2ZXMgb25seSB3aGV0aGVyIHRoZSBwcmVzcyB3YXMgY29ycmVjdC5cIixcbiAgICAgICAgYXZhaWxhYmlsaXR5OiBcIk9ubHkgd2hpbGUgcGhhc2UgaXMgJ3BsYXlpbmcnIGFuZCB0aGUgY2FsbGVyIGlzIGFzc2lnbmVkIHRoZSAnc2VjdXJpdHknIHJvbGUuXCIsXG4gICAgICAgIHJlc3VsdERlc2NyaXB0aW9uOlxuICAgICAgICAgIFwiT24gaGl0PXRydWU6IFNlY3VyaXR5IHByb2dyZXNzIGluY3JlYXNlcyBieSBzZWN1cml0eUluY3JlbWVudFBlckhpdCwgZmFjdG9yeSBoZWFsdGggYW5kIHRlYW0gc2NvcmUgdXBkYXRlLiBPbiBoaXQ9ZmFsc2U6IFNlY3VyaXR5IHByb2dyZXNzIGRlY3JlYXNlcyBieSBzZWN1cml0eVBlbmFsdHlQZXJNaXNzIChjbGFtcGVkIHRvIDApLCBubyBzY29yZSBjaGFuZ2UuXCIsXG4gICAgICB9LFxuICAgICksXG4gICAgc29sdmVfcHV6emxlOiBhZ2VudEFjdGlvbi5wYXJ0aWNpcGFudChcbiAgICAgIHsgYWN0aW9uTmFtZTogXCJzb2x2ZVB1enpsZVwiIH0sXG4gICAgICB7XG4gICAgICAgIGlucHV0OiBhZ2VudEFjdGlvbklucHV0LnpvZCh6Lm9iamVjdCh7fSkpLFxuICAgICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgICBcIlNlbmQgYSBwdXp6bGUgc29sdmUgYWN0aW9uIGZyb20gdGhlIEFJIE1vZGVsIEVuZ2luZWVyIGNvbnRyb2xsZXIuIFRoaXMgaW5kaWNhdGVzIHRoZSBwbGF5ZXIgc3VjY2Vzc2Z1bGx5IGFycmFuZ2VkIHRoZSBjdXJyZW50IEFJIHBpcGVsaW5lIHB1enpsZS4gVGhlIHB1enpsZSB2YWxpZGF0aW9uIGlzIGhhbmRsZWQgbG9jYWxseSBieSB0aGUgY29udHJvbGxlci5cIixcbiAgICAgICAgYXZhaWxhYmlsaXR5OiBcIk9ubHkgd2hpbGUgcGhhc2UgaXMgJ3BsYXlpbmcnIGFuZCB0aGUgY2FsbGVyIGlzIGFzc2lnbmVkIHRoZSAnbW9kZWwnIHJvbGUuXCIsXG4gICAgICAgIHJlc3VsdERlc2NyaXB0aW9uOlxuICAgICAgICAgIFwiTW9kZWwgcHJvZ3Jlc3MgaW5jcmVhc2VzIGJ5IG1vZGVsSW5jcmVtZW50UGVyU29sdmUsIGZhY3RvcnkgaGVhbHRoIGFuZCB0ZWFtIHNjb3JlIHVwZGF0ZS5cIixcbiAgICAgIH0sXG4gICAgKSxcbiAgICBkZXZfaW5jcmVtZW50X3Bvd2VyOiBhZ2VudEFjdGlvbi5wYXJ0aWNpcGFudChcbiAgICAgIHsgYWN0aW9uTmFtZTogXCJkZXZJbmNyZW1lbnRQb3dlclwiIH0sXG4gICAgICB7XG4gICAgICAgIGlucHV0OiBhZ2VudEFjdGlvbklucHV0LnpvZChcbiAgICAgICAgICB6Lm9iamVjdCh7IGFtb3VudDogei5udW1iZXIoKS5pbnQoKS5taW4oMSkubWF4KDEwMCkgfSksXG4gICAgICAgICksXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIltERVZdIEluY3JlbWVudCB0aGUgUG93ZXIgZGVwYXJ0bWVudCBwcm9ncmVzcyBieSB0aGUgZ2l2ZW4gYW1vdW50LlwiLFxuICAgICAgICBhdmFpbGFiaWxpdHk6IFwiT25seSB3aGlsZSBwaGFzZSBpcyAncGxheWluZycuXCIsXG4gICAgICAgIHJlc3VsdERlc2NyaXB0aW9uOiBcIlBvd2VyIHByb2dyZXNzLCBmYWN0b3J5IGhlYWx0aCwgYW5kIHRlYW0gc2NvcmUgdXBkYXRlLlwiLFxuICAgICAgfSxcbiAgICApLFxuICAgIGRldl9pbmNyZW1lbnRfZGF0YTogYWdlbnRBY3Rpb24ucGFydGljaXBhbnQoXG4gICAgICB7IGFjdGlvbk5hbWU6IFwiZGV2SW5jcmVtZW50RGF0YVwiIH0sXG4gICAgICB7XG4gICAgICAgIGlucHV0OiBhZ2VudEFjdGlvbklucHV0LnpvZChcbiAgICAgICAgICB6Lm9iamVjdCh7IGFtb3VudDogei5udW1iZXIoKS5pbnQoKS5taW4oMSkubWF4KDEwMCkgfSksXG4gICAgICAgICksXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIltERVZdIEluY3JlbWVudCB0aGUgRGF0YSBkZXBhcnRtZW50IHByb2dyZXNzLlwiLFxuICAgICAgICBhdmFpbGFiaWxpdHk6IFwiT25seSB3aGlsZSBwaGFzZSBpcyAncGxheWluZycuXCIsXG4gICAgICAgIHJlc3VsdERlc2NyaXB0aW9uOiBcIkRhdGEgcHJvZ3Jlc3MsIGZhY3RvcnkgaGVhbHRoLCBhbmQgdGVhbSBzY29yZSB1cGRhdGUuXCIsXG4gICAgICB9LFxuICAgICksXG4gICAgZGV2X2luY3JlbWVudF9zZWN1cml0eTogYWdlbnRBY3Rpb24ucGFydGljaXBhbnQoXG4gICAgICB7IGFjdGlvbk5hbWU6IFwiZGV2SW5jcmVtZW50U2VjdXJpdHlcIiB9LFxuICAgICAge1xuICAgICAgICBpbnB1dDogYWdlbnRBY3Rpb25JbnB1dC56b2QoXG4gICAgICAgICAgei5vYmplY3QoeyBhbW91bnQ6IHoubnVtYmVyKCkuaW50KCkubWluKDEpLm1heCgxMDApIH0pLFxuICAgICAgICApLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJbREVWXSBJbmNyZW1lbnQgdGhlIFNlY3VyaXR5IGRlcGFydG1lbnQgcHJvZ3Jlc3MuXCIsXG4gICAgICAgIGF2YWlsYWJpbGl0eTogXCJPbmx5IHdoaWxlIHBoYXNlIGlzICdwbGF5aW5nJy5cIixcbiAgICAgICAgcmVzdWx0RGVzY3JpcHRpb246IFwiU2VjdXJpdHkgcHJvZ3Jlc3MsIGZhY3RvcnkgaGVhbHRoLCBhbmQgdGVhbSBzY29yZSB1cGRhdGUuXCIsXG4gICAgICB9LFxuICAgICksXG4gICAgZGV2X2luY3JlbWVudF9tb2RlbDogYWdlbnRBY3Rpb24ucGFydGljaXBhbnQoXG4gICAgICB7IGFjdGlvbk5hbWU6IFwiZGV2SW5jcmVtZW50TW9kZWxcIiB9LFxuICAgICAge1xuICAgICAgICBpbnB1dDogYWdlbnRBY3Rpb25JbnB1dC56b2QoXG4gICAgICAgICAgei5vYmplY3QoeyBhbW91bnQ6IHoubnVtYmVyKCkuaW50KCkubWluKDEpLm1heCgxMDApIH0pLFxuICAgICAgICApLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJbREVWXSBJbmNyZW1lbnQgdGhlIEFJIE1vZGVsIGRlcGFydG1lbnQgcHJvZ3Jlc3MuXCIsXG4gICAgICAgIGF2YWlsYWJpbGl0eTogXCJPbmx5IHdoaWxlIHBoYXNlIGlzICdwbGF5aW5nJy5cIixcbiAgICAgICAgcmVzdWx0RGVzY3JpcHRpb246IFwiTW9kZWwgcHJvZ3Jlc3MsIGZhY3RvcnkgaGVhbHRoLCBhbmQgdGVhbSBzY29yZSB1cGRhdGUuXCIsXG4gICAgICB9LFxuICAgICksXG4gICAgZGV2X3NldF9jb29saW5nX3RlbXA6IGFnZW50QWN0aW9uLnBhcnRpY2lwYW50KFxuICAgICAgeyBhY3Rpb25OYW1lOiBcImRldlNldENvb2xpbmdUZW1wXCIgfSxcbiAgICAgIHtcbiAgICAgICAgaW5wdXQ6IGFnZW50QWN0aW9uSW5wdXQuem9kKFxuICAgICAgICAgIHoub2JqZWN0KHsgdGVtcGVyYXR1cmU6IHoubnVtYmVyKCkubWluKDUwKS5tYXgoMTIwKSB9KSxcbiAgICAgICAgKSxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiW0RFVl0gU2V0IHRoZSBDb29saW5nIGRlcGFydG1lbnQgdGVtcGVyYXR1cmUgZGlyZWN0bHkuXCIsXG4gICAgICAgIGF2YWlsYWJpbGl0eTogXCJPbmx5IHdoaWxlIHBoYXNlIGlzICdwbGF5aW5nJy5cIixcbiAgICAgICAgcmVzdWx0RGVzY3JpcHRpb246IFwiQ29vbGluZyB0ZW1wZXJhdHVyZSwgcHJvZ3Jlc3MsIGFuZCBmYWN0b3J5IGhlYWx0aCB1cGRhdGUuXCIsXG4gICAgICB9LFxuICAgICksXG4gIH0sXG59KTtcbiJdLCJtYXBwaW5ncyI6IkFBTUE7QUFBQSxFQUNFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLE9BQ0s7QUFDUCxTQUFTLFNBQVM7QUFHbEIsTUFBTSxTQUFTLHdCQUF3QjtBQUFBLEVBQ3JDLFNBQVMsV0FBeUI7QUFDcEMsQ0FBQztBQUVNLGFBQU0sZ0JBQWdCLDBCQUEwQjtBQUFBLEVBQ3JEO0FBQUEsRUFDQSxxQkFDRTtBQUFBLEVBQ0YsaUJBQWlCLENBQUMsWUFBWTtBQUM1QixVQUFNLFFBQVEsUUFBUSxPQUFPO0FBQzdCLFFBQUksQ0FBQyxPQUFPO0FBQ1YsYUFBTyxFQUFFLFdBQVcsT0FBTyxTQUFTLG1DQUFtQztBQUFBLElBQ3pFO0FBRUEsV0FBTztBQUFBLE1BQ0wsV0FBVztBQUFBLE1BQ1gsT0FBTyxNQUFNO0FBQUEsTUFDYixlQUFlLE1BQU07QUFBQSxNQUNyQixpQkFBaUIsTUFBTTtBQUFBLE1BQ3ZCLGFBQWEsT0FBTyxLQUFLLE1BQU0sZUFBZSxFQUFFO0FBQUEsTUFDaEQsYUFBYTtBQUFBLFFBQ1gsT0FBTyxFQUFFLFVBQVUsTUFBTSxNQUFNLFVBQVUsUUFBUSxNQUFNLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBTSxNQUFNO0FBQUEsUUFDOUYsTUFBTSxFQUFFLFVBQVUsTUFBTSxLQUFLLFVBQVUsUUFBUSxNQUFNLEtBQUssUUFBUSxPQUFPLE1BQU0sS0FBSyxNQUFNO0FBQUEsUUFDMUYsVUFBVSxFQUFFLFVBQVUsTUFBTSxTQUFTLFVBQVUsUUFBUSxNQUFNLFNBQVMsUUFBUSxPQUFPLE1BQU0sU0FBUyxNQUFNO0FBQUEsUUFDMUcsT0FBTyxFQUFFLFVBQVUsTUFBTSxNQUFNLFVBQVUsUUFBUSxNQUFNLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBTSxNQUFNO0FBQUEsUUFDOUYsU0FBUztBQUFBLFVBQ1AsVUFBVSxNQUFNLFFBQVE7QUFBQSxVQUN4QixRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQ3RCLE9BQU8sTUFBTSxRQUFRO0FBQUEsVUFDckIsYUFBYSxNQUFNLFFBQVE7QUFBQSxRQUM3QjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLGVBQWUsTUFBTTtBQUFBLE1BQ3JCLFdBQVcsTUFBTTtBQUFBLE1BQ2pCLGNBQWMsTUFBTTtBQUFBLE1BQ3BCLGFBQWEsTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsU0FBUztBQUFBLElBQ1AsWUFBWSxZQUFZO0FBQUEsTUFDdEIsRUFBRSxZQUFZLFlBQVk7QUFBQSxNQUMxQjtBQUFBLFFBQ0UsT0FBTyxpQkFBaUIsS0FBSztBQUFBLFFBQzdCLGFBQWE7QUFBQSxRQUNiLGNBQWM7QUFBQSxRQUNkLG1CQUFtQjtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLElBQ0EsWUFBWSxZQUFZO0FBQUEsTUFDdEIsRUFBRSxZQUFZLFlBQVk7QUFBQSxNQUMxQjtBQUFBLFFBQ0UsT0FBTyxpQkFBaUIsS0FBSztBQUFBLFFBQzdCLGFBQWE7QUFBQSxRQUNiLGNBQWM7QUFBQSxRQUNkLG1CQUFtQjtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLElBQ0EsV0FBVyxZQUFZO0FBQUEsTUFDckIsRUFBRSxZQUFZLFdBQVc7QUFBQSxNQUN6QjtBQUFBLFFBQ0UsT0FBTyxpQkFBaUIsS0FBSztBQUFBLFFBQzdCLGFBQ0U7QUFBQSxRQUNGLGNBQWM7QUFBQSxRQUNkLG1CQUNFO0FBQUEsTUFDSjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFdBQVcsWUFBWTtBQUFBLE1BQ3JCLEVBQUUsWUFBWSxXQUFXO0FBQUEsTUFDekI7QUFBQSxRQUNFLE9BQU8saUJBQWlCO0FBQUEsVUFDdEIsRUFBRSxPQUFPO0FBQUEsWUFDUCxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsaURBQWlEO0FBQUEsWUFDNUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxXQUFXLFVBQVUsQ0FBQyxFQUFFLFNBQVMsOENBQThDO0FBQUEsWUFDL0YsU0FBUyxFQUFFLFFBQVEsRUFBRSxTQUFTLDhEQUE4RDtBQUFBLFVBQzlGLENBQUM7QUFBQSxRQUNIO0FBQUEsUUFDQSxhQUNFO0FBQUEsUUFDRixjQUFjO0FBQUEsUUFDZCxtQkFDRTtBQUFBLE1BQ0o7QUFBQSxJQUNGO0FBQUEsSUFDQSxTQUFTLFlBQVk7QUFBQSxNQUNuQixFQUFFLFlBQVksU0FBUztBQUFBLE1BQ3ZCO0FBQUEsUUFDRSxPQUFPLGlCQUFpQjtBQUFBLFVBQ3RCLEVBQUUsT0FBTztBQUFBLFlBQ1AsS0FBSyxFQUNGLFFBQVEsRUFDUjtBQUFBLGNBQ0M7QUFBQSxZQUNGO0FBQUEsVUFDSixDQUFDO0FBQUEsUUFDSDtBQUFBLFFBQ0EsYUFDRTtBQUFBLFFBQ0YsY0FBYztBQUFBLFFBQ2QsbUJBQ0U7QUFBQSxNQUNKO0FBQUEsSUFDRjtBQUFBLElBQ0EsY0FBYyxZQUFZO0FBQUEsTUFDeEIsRUFBRSxZQUFZLGNBQWM7QUFBQSxNQUM1QjtBQUFBLFFBQ0UsT0FBTyxpQkFBaUIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFBQSxRQUN4QyxhQUNFO0FBQUEsUUFDRixjQUFjO0FBQUEsUUFDZCxtQkFDRTtBQUFBLE1BQ0o7QUFBQSxJQUNGO0FBQUEsSUFDQSxxQkFBcUIsWUFBWTtBQUFBLE1BQy9CLEVBQUUsWUFBWSxvQkFBb0I7QUFBQSxNQUNsQztBQUFBLFFBQ0UsT0FBTyxpQkFBaUI7QUFBQSxVQUN0QixFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDdkQ7QUFBQSxRQUNBLGFBQWE7QUFBQSxRQUNiLGNBQWM7QUFBQSxRQUNkLG1CQUFtQjtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLElBQ0Esb0JBQW9CLFlBQVk7QUFBQSxNQUM5QixFQUFFLFlBQVksbUJBQW1CO0FBQUEsTUFDakM7QUFBQSxRQUNFLE9BQU8saUJBQWlCO0FBQUEsVUFDdEIsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ3ZEO0FBQUEsUUFDQSxhQUFhO0FBQUEsUUFDYixjQUFjO0FBQUEsUUFDZCxtQkFBbUI7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFBQSxJQUNBLHdCQUF3QixZQUFZO0FBQUEsTUFDbEMsRUFBRSxZQUFZLHVCQUF1QjtBQUFBLE1BQ3JDO0FBQUEsUUFDRSxPQUFPLGlCQUFpQjtBQUFBLFVBQ3RCLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFFLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxRQUN2RDtBQUFBLFFBQ0EsYUFBYTtBQUFBLFFBQ2IsY0FBYztBQUFBLFFBQ2QsbUJBQW1CO0FBQUEsTUFDckI7QUFBQSxJQUNGO0FBQUEsSUFDQSxxQkFBcUIsWUFBWTtBQUFBLE1BQy9CLEVBQUUsWUFBWSxvQkFBb0I7QUFBQSxNQUNsQztBQUFBLFFBQ0UsT0FBTyxpQkFBaUI7QUFBQSxVQUN0QixFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDdkQ7QUFBQSxRQUNBLGFBQWE7QUFBQSxRQUNiLGNBQWM7QUFBQSxRQUNkLG1CQUFtQjtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLElBQ0Esc0JBQXNCLFlBQVk7QUFBQSxNQUNoQyxFQUFFLFlBQVksb0JBQW9CO0FBQUEsTUFDbEM7QUFBQSxRQUNFLE9BQU8saUJBQWlCO0FBQUEsVUFDdEIsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDdkQ7QUFBQSxRQUNBLGFBQWE7QUFBQSxRQUNiLGNBQWM7QUFBQSxRQUNkLG1CQUFtQjtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRixDQUFDOyIsIm5hbWVzIjpbXX0=