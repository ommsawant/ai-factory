import {
  Button,
  Slider,
  buttonVariants,
  cn,
  shellFieldClassName,
  shellHeaderClassName,
  shellHelperTextClassName,
  shellLabelClassName,
  shellUtilityButtonClassName
} from "/node_modules/.vite/deps/chunk-PH4EEG7B.js?v=c74894a2";
import {
  createControllerPresentationSyncMessage,
  readEmbeddedControllerRuntimeParams,
  useAirJamController
} from "/node_modules/.vite/deps/chunk-FTUKOCBU.js?v=c74894a2";
import {
  Bot,
  Check,
  Copy,
  ExternalLink,
  Headphones,
  House,
  Music,
  Pause,
  Play,
  QrCode,
  RotateCcw,
  Volume2,
  VolumeX,
  usePlatformAudioSettings,
  useSessionScope
} from "/node_modules/.vite/deps/chunk-B6OEUIDA.js?v=c74894a2";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-GZR6XUHA.js?v=c74894a2";
import "/node_modules/.vite/deps/chunk-KQIFYUJI.js?v=c74894a2";
import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-FA4F7MSV.js?v=c74894a2";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-DOQUEKBH.js?v=c74894a2";
import {
  __commonJS,
  __toESM
} from "/node_modules/.vite/deps/chunk-DP4XHQAG.js?v=c74894a2";

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/can-promise.js
var require_can_promise = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/can-promise.js"(exports, module) {
    module.exports = function() {
      return typeof Promise === "function" && Promise.prototype && Promise.prototype.then;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/utils.js
var require_utils = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/utils.js"(exports) {
    var toSJISFunction;
    var CODEWORDS_COUNT = [
      0,
      // Not used
      26,
      44,
      70,
      100,
      134,
      172,
      196,
      242,
      292,
      346,
      404,
      466,
      532,
      581,
      655,
      733,
      815,
      901,
      991,
      1085,
      1156,
      1258,
      1364,
      1474,
      1588,
      1706,
      1828,
      1921,
      2051,
      2185,
      2323,
      2465,
      2611,
      2761,
      2876,
      3034,
      3196,
      3362,
      3532,
      3706
    ];
    exports.getSymbolSize = function getSymbolSize(version) {
      if (!version) throw new Error('"version" cannot be null or undefined');
      if (version < 1 || version > 40) throw new Error('"version" should be in range from 1 to 40');
      return version * 4 + 17;
    };
    exports.getSymbolTotalCodewords = function getSymbolTotalCodewords(version) {
      return CODEWORDS_COUNT[version];
    };
    exports.getBCHDigit = function(data) {
      let digit = 0;
      while (data !== 0) {
        digit++;
        data >>>= 1;
      }
      return digit;
    };
    exports.setToSJISFunction = function setToSJISFunction(f) {
      if (typeof f !== "function") {
        throw new Error('"toSJISFunc" is not a valid function.');
      }
      toSJISFunction = f;
    };
    exports.isKanjiModeEnabled = function() {
      return typeof toSJISFunction !== "undefined";
    };
    exports.toSJIS = function toSJIS(kanji) {
      return toSJISFunction(kanji);
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/error-correction-level.js
var require_error_correction_level = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/error-correction-level.js"(exports) {
    exports.L = { bit: 1 };
    exports.M = { bit: 0 };
    exports.Q = { bit: 3 };
    exports.H = { bit: 2 };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "l":
        case "low":
          return exports.L;
        case "m":
        case "medium":
          return exports.M;
        case "q":
        case "quartile":
          return exports.Q;
        case "h":
        case "high":
          return exports.H;
        default:
          throw new Error("Unknown EC Level: " + string);
      }
    }
    exports.isValid = function isValid(level) {
      return level && typeof level.bit !== "undefined" && level.bit >= 0 && level.bit < 4;
    };
    exports.from = function from(value, defaultValue) {
      if (exports.isValid(value)) {
        return value;
      }
      try {
        return fromString(value);
      } catch (e) {
        return defaultValue;
      }
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/bit-buffer.js
var require_bit_buffer = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/bit-buffer.js"(exports, module) {
    function BitBuffer() {
      this.buffer = [];
      this.length = 0;
    }
    BitBuffer.prototype = {
      get: function(index) {
        const bufIndex = Math.floor(index / 8);
        return (this.buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
      },
      put: function(num, length) {
        for (let i = 0; i < length; i++) {
          this.putBit((num >>> length - i - 1 & 1) === 1);
        }
      },
      getLengthInBits: function() {
        return this.length;
      },
      putBit: function(bit) {
        const bufIndex = Math.floor(this.length / 8);
        if (this.buffer.length <= bufIndex) {
          this.buffer.push(0);
        }
        if (bit) {
          this.buffer[bufIndex] |= 128 >>> this.length % 8;
        }
        this.length++;
      }
    };
    module.exports = BitBuffer;
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/bit-matrix.js
var require_bit_matrix = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/bit-matrix.js"(exports, module) {
    function BitMatrix(size) {
      if (!size || size < 1) {
        throw new Error("BitMatrix size must be defined and greater than 0");
      }
      this.size = size;
      this.data = new Uint8Array(size * size);
      this.reservedBit = new Uint8Array(size * size);
    }
    BitMatrix.prototype.set = function(row, col, value, reserved) {
      const index = row * this.size + col;
      this.data[index] = value;
      if (reserved) this.reservedBit[index] = true;
    };
    BitMatrix.prototype.get = function(row, col) {
      return this.data[row * this.size + col];
    };
    BitMatrix.prototype.xor = function(row, col, value) {
      this.data[row * this.size + col] ^= value;
    };
    BitMatrix.prototype.isReserved = function(row, col) {
      return this.reservedBit[row * this.size + col];
    };
    module.exports = BitMatrix;
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/alignment-pattern.js
var require_alignment_pattern = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/alignment-pattern.js"(exports) {
    var getSymbolSize = require_utils().getSymbolSize;
    exports.getRowColCoords = function getRowColCoords(version) {
      if (version === 1) return [];
      const posCount = Math.floor(version / 7) + 2;
      const size = getSymbolSize(version);
      const intervals = size === 145 ? 26 : Math.ceil((size - 13) / (2 * posCount - 2)) * 2;
      const positions = [size - 7];
      for (let i = 1; i < posCount - 1; i++) {
        positions[i] = positions[i - 1] - intervals;
      }
      positions.push(6);
      return positions.reverse();
    };
    exports.getPositions = function getPositions(version) {
      const coords = [];
      const pos = exports.getRowColCoords(version);
      const posLength = pos.length;
      for (let i = 0; i < posLength; i++) {
        for (let j = 0; j < posLength; j++) {
          if (i === 0 && j === 0 || // top-left
          i === 0 && j === posLength - 1 || // bottom-left
          i === posLength - 1 && j === 0) {
            continue;
          }
          coords.push([pos[i], pos[j]]);
        }
      }
      return coords;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/finder-pattern.js
var require_finder_pattern = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/finder-pattern.js"(exports) {
    var getSymbolSize = require_utils().getSymbolSize;
    var FINDER_PATTERN_SIZE = 7;
    exports.getPositions = function getPositions(version) {
      const size = getSymbolSize(version);
      return [
        // top-left
        [0, 0],
        // top-right
        [size - FINDER_PATTERN_SIZE, 0],
        // bottom-left
        [0, size - FINDER_PATTERN_SIZE]
      ];
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/mask-pattern.js
var require_mask_pattern = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/mask-pattern.js"(exports) {
    exports.Patterns = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    };
    var PenaltyScores = {
      N1: 3,
      N2: 3,
      N3: 40,
      N4: 10
    };
    exports.isValid = function isValid(mask) {
      return mask != null && mask !== "" && !isNaN(mask) && mask >= 0 && mask <= 7;
    };
    exports.from = function from(value) {
      return exports.isValid(value) ? parseInt(value, 10) : void 0;
    };
    exports.getPenaltyN1 = function getPenaltyN1(data) {
      const size = data.size;
      let points = 0;
      let sameCountCol = 0;
      let sameCountRow = 0;
      let lastCol = null;
      let lastRow = null;
      for (let row = 0; row < size; row++) {
        sameCountCol = sameCountRow = 0;
        lastCol = lastRow = null;
        for (let col = 0; col < size; col++) {
          let module2 = data.get(row, col);
          if (module2 === lastCol) {
            sameCountCol++;
          } else {
            if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
            lastCol = module2;
            sameCountCol = 1;
          }
          module2 = data.get(col, row);
          if (module2 === lastRow) {
            sameCountRow++;
          } else {
            if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
            lastRow = module2;
            sameCountRow = 1;
          }
        }
        if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
        if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
      }
      return points;
    };
    exports.getPenaltyN2 = function getPenaltyN2(data) {
      const size = data.size;
      let points = 0;
      for (let row = 0; row < size - 1; row++) {
        for (let col = 0; col < size - 1; col++) {
          const last = data.get(row, col) + data.get(row, col + 1) + data.get(row + 1, col) + data.get(row + 1, col + 1);
          if (last === 4 || last === 0) points++;
        }
      }
      return points * PenaltyScores.N2;
    };
    exports.getPenaltyN3 = function getPenaltyN3(data) {
      const size = data.size;
      let points = 0;
      let bitsCol = 0;
      let bitsRow = 0;
      for (let row = 0; row < size; row++) {
        bitsCol = bitsRow = 0;
        for (let col = 0; col < size; col++) {
          bitsCol = bitsCol << 1 & 2047 | data.get(row, col);
          if (col >= 10 && (bitsCol === 1488 || bitsCol === 93)) points++;
          bitsRow = bitsRow << 1 & 2047 | data.get(col, row);
          if (col >= 10 && (bitsRow === 1488 || bitsRow === 93)) points++;
        }
      }
      return points * PenaltyScores.N3;
    };
    exports.getPenaltyN4 = function getPenaltyN4(data) {
      let darkCount = 0;
      const modulesCount = data.data.length;
      for (let i = 0; i < modulesCount; i++) darkCount += data.data[i];
      const k = Math.abs(Math.ceil(darkCount * 100 / modulesCount / 5) - 10);
      return k * PenaltyScores.N4;
    };
    function getMaskAt(maskPattern, i, j) {
      switch (maskPattern) {
        case exports.Patterns.PATTERN000:
          return (i + j) % 2 === 0;
        case exports.Patterns.PATTERN001:
          return i % 2 === 0;
        case exports.Patterns.PATTERN010:
          return j % 3 === 0;
        case exports.Patterns.PATTERN011:
          return (i + j) % 3 === 0;
        case exports.Patterns.PATTERN100:
          return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
        case exports.Patterns.PATTERN101:
          return i * j % 2 + i * j % 3 === 0;
        case exports.Patterns.PATTERN110:
          return (i * j % 2 + i * j % 3) % 2 === 0;
        case exports.Patterns.PATTERN111:
          return (i * j % 3 + (i + j) % 2) % 2 === 0;
        default:
          throw new Error("bad maskPattern:" + maskPattern);
      }
    }
    exports.applyMask = function applyMask(pattern, data) {
      const size = data.size;
      for (let col = 0; col < size; col++) {
        for (let row = 0; row < size; row++) {
          if (data.isReserved(row, col)) continue;
          data.xor(row, col, getMaskAt(pattern, row, col));
        }
      }
    };
    exports.getBestMask = function getBestMask(data, setupFormatFunc) {
      const numPatterns = Object.keys(exports.Patterns).length;
      let bestPattern = 0;
      let lowerPenalty = Infinity;
      for (let p = 0; p < numPatterns; p++) {
        setupFormatFunc(p);
        exports.applyMask(p, data);
        const penalty = exports.getPenaltyN1(data) + exports.getPenaltyN2(data) + exports.getPenaltyN3(data) + exports.getPenaltyN4(data);
        exports.applyMask(p, data);
        if (penalty < lowerPenalty) {
          lowerPenalty = penalty;
          bestPattern = p;
        }
      }
      return bestPattern;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/error-correction-code.js
var require_error_correction_code = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/error-correction-code.js"(exports) {
    var ECLevel = require_error_correction_level();
    var EC_BLOCKS_TABLE = [
      // L  M  Q  H
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      2,
      2,
      1,
      2,
      2,
      4,
      1,
      2,
      4,
      4,
      2,
      4,
      4,
      4,
      2,
      4,
      6,
      5,
      2,
      4,
      6,
      6,
      2,
      5,
      8,
      8,
      4,
      5,
      8,
      8,
      4,
      5,
      8,
      11,
      4,
      8,
      10,
      11,
      4,
      9,
      12,
      16,
      4,
      9,
      16,
      16,
      6,
      10,
      12,
      18,
      6,
      10,
      17,
      16,
      6,
      11,
      16,
      19,
      6,
      13,
      18,
      21,
      7,
      14,
      21,
      25,
      8,
      16,
      20,
      25,
      8,
      17,
      23,
      25,
      9,
      17,
      23,
      34,
      9,
      18,
      25,
      30,
      10,
      20,
      27,
      32,
      12,
      21,
      29,
      35,
      12,
      23,
      34,
      37,
      12,
      25,
      34,
      40,
      13,
      26,
      35,
      42,
      14,
      28,
      38,
      45,
      15,
      29,
      40,
      48,
      16,
      31,
      43,
      51,
      17,
      33,
      45,
      54,
      18,
      35,
      48,
      57,
      19,
      37,
      51,
      60,
      19,
      38,
      53,
      63,
      20,
      40,
      56,
      66,
      21,
      43,
      59,
      70,
      22,
      45,
      62,
      74,
      24,
      47,
      65,
      77,
      25,
      49,
      68,
      81
    ];
    var EC_CODEWORDS_TABLE = [
      // L  M  Q  H
      7,
      10,
      13,
      17,
      10,
      16,
      22,
      28,
      15,
      26,
      36,
      44,
      20,
      36,
      52,
      64,
      26,
      48,
      72,
      88,
      36,
      64,
      96,
      112,
      40,
      72,
      108,
      130,
      48,
      88,
      132,
      156,
      60,
      110,
      160,
      192,
      72,
      130,
      192,
      224,
      80,
      150,
      224,
      264,
      96,
      176,
      260,
      308,
      104,
      198,
      288,
      352,
      120,
      216,
      320,
      384,
      132,
      240,
      360,
      432,
      144,
      280,
      408,
      480,
      168,
      308,
      448,
      532,
      180,
      338,
      504,
      588,
      196,
      364,
      546,
      650,
      224,
      416,
      600,
      700,
      224,
      442,
      644,
      750,
      252,
      476,
      690,
      816,
      270,
      504,
      750,
      900,
      300,
      560,
      810,
      960,
      312,
      588,
      870,
      1050,
      336,
      644,
      952,
      1110,
      360,
      700,
      1020,
      1200,
      390,
      728,
      1050,
      1260,
      420,
      784,
      1140,
      1350,
      450,
      812,
      1200,
      1440,
      480,
      868,
      1290,
      1530,
      510,
      924,
      1350,
      1620,
      540,
      980,
      1440,
      1710,
      570,
      1036,
      1530,
      1800,
      570,
      1064,
      1590,
      1890,
      600,
      1120,
      1680,
      1980,
      630,
      1204,
      1770,
      2100,
      660,
      1260,
      1860,
      2220,
      720,
      1316,
      1950,
      2310,
      750,
      1372,
      2040,
      2430
    ];
    exports.getBlocksCount = function getBlocksCount(version, errorCorrectionLevel) {
      switch (errorCorrectionLevel) {
        case ECLevel.L:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 0];
        case ECLevel.M:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 1];
        case ECLevel.Q:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 2];
        case ECLevel.H:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 3];
        default:
          return void 0;
      }
    };
    exports.getTotalCodewordsCount = function getTotalCodewordsCount(version, errorCorrectionLevel) {
      switch (errorCorrectionLevel) {
        case ECLevel.L:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 0];
        case ECLevel.M:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 1];
        case ECLevel.Q:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 2];
        case ECLevel.H:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 3];
        default:
          return void 0;
      }
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/galois-field.js
var require_galois_field = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/galois-field.js"(exports) {
    var EXP_TABLE = new Uint8Array(512);
    var LOG_TABLE = new Uint8Array(256);
    (function initTables() {
      let x = 1;
      for (let i = 0; i < 255; i++) {
        EXP_TABLE[i] = x;
        LOG_TABLE[x] = i;
        x <<= 1;
        if (x & 256) {
          x ^= 285;
        }
      }
      for (let i = 255; i < 512; i++) {
        EXP_TABLE[i] = EXP_TABLE[i - 255];
      }
    })();
    exports.log = function log(n) {
      if (n < 1) throw new Error("log(" + n + ")");
      return LOG_TABLE[n];
    };
    exports.exp = function exp(n) {
      return EXP_TABLE[n];
    };
    exports.mul = function mul(x, y) {
      if (x === 0 || y === 0) return 0;
      return EXP_TABLE[LOG_TABLE[x] + LOG_TABLE[y]];
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/polynomial.js
var require_polynomial = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/polynomial.js"(exports) {
    var GF = require_galois_field();
    exports.mul = function mul(p1, p2) {
      const coeff = new Uint8Array(p1.length + p2.length - 1);
      for (let i = 0; i < p1.length; i++) {
        for (let j = 0; j < p2.length; j++) {
          coeff[i + j] ^= GF.mul(p1[i], p2[j]);
        }
      }
      return coeff;
    };
    exports.mod = function mod(divident, divisor) {
      let result = new Uint8Array(divident);
      while (result.length - divisor.length >= 0) {
        const coeff = result[0];
        for (let i = 0; i < divisor.length; i++) {
          result[i] ^= GF.mul(divisor[i], coeff);
        }
        let offset = 0;
        while (offset < result.length && result[offset] === 0) offset++;
        result = result.slice(offset);
      }
      return result;
    };
    exports.generateECPolynomial = function generateECPolynomial(degree) {
      let poly = new Uint8Array([1]);
      for (let i = 0; i < degree; i++) {
        poly = exports.mul(poly, new Uint8Array([1, GF.exp(i)]));
      }
      return poly;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/reed-solomon-encoder.js
var require_reed_solomon_encoder = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/reed-solomon-encoder.js"(exports, module) {
    var Polynomial = require_polynomial();
    function ReedSolomonEncoder(degree) {
      this.genPoly = void 0;
      this.degree = degree;
      if (this.degree) this.initialize(this.degree);
    }
    ReedSolomonEncoder.prototype.initialize = function initialize(degree) {
      this.degree = degree;
      this.genPoly = Polynomial.generateECPolynomial(this.degree);
    };
    ReedSolomonEncoder.prototype.encode = function encode(data) {
      if (!this.genPoly) {
        throw new Error("Encoder not initialized");
      }
      const paddedData = new Uint8Array(data.length + this.degree);
      paddedData.set(data);
      const remainder = Polynomial.mod(paddedData, this.genPoly);
      const start = this.degree - remainder.length;
      if (start > 0) {
        const buff = new Uint8Array(this.degree);
        buff.set(remainder, start);
        return buff;
      }
      return remainder;
    };
    module.exports = ReedSolomonEncoder;
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/version-check.js
var require_version_check = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/version-check.js"(exports) {
    exports.isValid = function isValid(version) {
      return !isNaN(version) && version >= 1 && version <= 40;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/regex.js
var require_regex = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/regex.js"(exports) {
    var numeric = "[0-9]+";
    var alphanumeric = "[A-Z $%*+\\-./:]+";
    var kanji = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
    kanji = kanji.replace(/u/g, "\\u");
    var byte = "(?:(?![A-Z0-9 $%*+\\-./:]|" + kanji + ")(?:.|[\r\n]))+";
    exports.KANJI = new RegExp(kanji, "g");
    exports.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g");
    exports.BYTE = new RegExp(byte, "g");
    exports.NUMERIC = new RegExp(numeric, "g");
    exports.ALPHANUMERIC = new RegExp(alphanumeric, "g");
    var TEST_KANJI = new RegExp("^" + kanji + "$");
    var TEST_NUMERIC = new RegExp("^" + numeric + "$");
    var TEST_ALPHANUMERIC = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
    exports.testKanji = function testKanji(str) {
      return TEST_KANJI.test(str);
    };
    exports.testNumeric = function testNumeric(str) {
      return TEST_NUMERIC.test(str);
    };
    exports.testAlphanumeric = function testAlphanumeric(str) {
      return TEST_ALPHANUMERIC.test(str);
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/mode.js
var require_mode = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/mode.js"(exports) {
    var VersionCheck = require_version_check();
    var Regex = require_regex();
    exports.NUMERIC = {
      id: "Numeric",
      bit: 1 << 0,
      ccBits: [10, 12, 14]
    };
    exports.ALPHANUMERIC = {
      id: "Alphanumeric",
      bit: 1 << 1,
      ccBits: [9, 11, 13]
    };
    exports.BYTE = {
      id: "Byte",
      bit: 1 << 2,
      ccBits: [8, 16, 16]
    };
    exports.KANJI = {
      id: "Kanji",
      bit: 1 << 3,
      ccBits: [8, 10, 12]
    };
    exports.MIXED = {
      bit: -1
    };
    exports.getCharCountIndicator = function getCharCountIndicator(mode, version) {
      if (!mode.ccBits) throw new Error("Invalid mode: " + mode);
      if (!VersionCheck.isValid(version)) {
        throw new Error("Invalid version: " + version);
      }
      if (version >= 1 && version < 10) return mode.ccBits[0];
      else if (version < 27) return mode.ccBits[1];
      return mode.ccBits[2];
    };
    exports.getBestModeForData = function getBestModeForData(dataStr) {
      if (Regex.testNumeric(dataStr)) return exports.NUMERIC;
      else if (Regex.testAlphanumeric(dataStr)) return exports.ALPHANUMERIC;
      else if (Regex.testKanji(dataStr)) return exports.KANJI;
      else return exports.BYTE;
    };
    exports.toString = function toString(mode) {
      if (mode && mode.id) return mode.id;
      throw new Error("Invalid mode");
    };
    exports.isValid = function isValid(mode) {
      return mode && mode.bit && mode.ccBits;
    };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "numeric":
          return exports.NUMERIC;
        case "alphanumeric":
          return exports.ALPHANUMERIC;
        case "kanji":
          return exports.KANJI;
        case "byte":
          return exports.BYTE;
        default:
          throw new Error("Unknown mode: " + string);
      }
    }
    exports.from = function from(value, defaultValue) {
      if (exports.isValid(value)) {
        return value;
      }
      try {
        return fromString(value);
      } catch (e) {
        return defaultValue;
      }
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/version.js
var require_version = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/version.js"(exports) {
    var Utils = require_utils();
    var ECCode = require_error_correction_code();
    var ECLevel = require_error_correction_level();
    var Mode = require_mode();
    var VersionCheck = require_version_check();
    var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
    var G18_BCH = Utils.getBCHDigit(G18);
    function getBestVersionForDataLength(mode, length, errorCorrectionLevel) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, mode)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    function getReservedBitsCount(mode, version) {
      return Mode.getCharCountIndicator(mode, version) + 4;
    }
    function getTotalBitsFromDataArray(segments, version) {
      let totalBits = 0;
      segments.forEach(function(data) {
        const reservedBits = getReservedBitsCount(data.mode, version);
        totalBits += reservedBits + data.getBitsLength();
      });
      return totalBits;
    }
    function getBestVersionForMixedData(segments, errorCorrectionLevel) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        const length = getTotalBitsFromDataArray(segments, currentVersion);
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, Mode.MIXED)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    exports.from = function from(value, defaultValue) {
      if (VersionCheck.isValid(value)) {
        return parseInt(value, 10);
      }
      return defaultValue;
    };
    exports.getCapacity = function getCapacity(version, errorCorrectionLevel, mode) {
      if (!VersionCheck.isValid(version)) {
        throw new Error("Invalid QR Code version");
      }
      if (typeof mode === "undefined") mode = Mode.BYTE;
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (mode === Mode.MIXED) return dataTotalCodewordsBits;
      const usableBits = dataTotalCodewordsBits - getReservedBitsCount(mode, version);
      switch (mode) {
        case Mode.NUMERIC:
          return Math.floor(usableBits / 10 * 3);
        case Mode.ALPHANUMERIC:
          return Math.floor(usableBits / 11 * 2);
        case Mode.KANJI:
          return Math.floor(usableBits / 13);
        case Mode.BYTE:
        default:
          return Math.floor(usableBits / 8);
      }
    };
    exports.getBestVersionForData = function getBestVersionForData(data, errorCorrectionLevel) {
      let seg;
      const ecl = ECLevel.from(errorCorrectionLevel, ECLevel.M);
      if (Array.isArray(data)) {
        if (data.length > 1) {
          return getBestVersionForMixedData(data, ecl);
        }
        if (data.length === 0) {
          return 1;
        }
        seg = data[0];
      } else {
        seg = data;
      }
      return getBestVersionForDataLength(seg.mode, seg.getLength(), ecl);
    };
    exports.getEncodedBits = function getEncodedBits(version) {
      if (!VersionCheck.isValid(version) || version < 7) {
        throw new Error("Invalid QR Code version");
      }
      let d = version << 12;
      while (Utils.getBCHDigit(d) - G18_BCH >= 0) {
        d ^= G18 << Utils.getBCHDigit(d) - G18_BCH;
      }
      return version << 12 | d;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/format-info.js
var require_format_info = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/format-info.js"(exports) {
    var Utils = require_utils();
    var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
    var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
    var G15_BCH = Utils.getBCHDigit(G15);
    exports.getEncodedBits = function getEncodedBits(errorCorrectionLevel, mask) {
      const data = errorCorrectionLevel.bit << 3 | mask;
      let d = data << 10;
      while (Utils.getBCHDigit(d) - G15_BCH >= 0) {
        d ^= G15 << Utils.getBCHDigit(d) - G15_BCH;
      }
      return (data << 10 | d) ^ G15_MASK;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/numeric-data.js
var require_numeric_data = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/numeric-data.js"(exports, module) {
    var Mode = require_mode();
    function NumericData(data) {
      this.mode = Mode.NUMERIC;
      this.data = data.toString();
    }
    NumericData.getBitsLength = function getBitsLength(length) {
      return 10 * Math.floor(length / 3) + (length % 3 ? length % 3 * 3 + 1 : 0);
    };
    NumericData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    NumericData.prototype.getBitsLength = function getBitsLength() {
      return NumericData.getBitsLength(this.data.length);
    };
    NumericData.prototype.write = function write(bitBuffer) {
      let i, group, value;
      for (i = 0; i + 3 <= this.data.length; i += 3) {
        group = this.data.substr(i, 3);
        value = parseInt(group, 10);
        bitBuffer.put(value, 10);
      }
      const remainingNum = this.data.length - i;
      if (remainingNum > 0) {
        group = this.data.substr(i);
        value = parseInt(group, 10);
        bitBuffer.put(value, remainingNum * 3 + 1);
      }
    };
    module.exports = NumericData;
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/alphanumeric-data.js
var require_alphanumeric_data = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/alphanumeric-data.js"(exports, module) {
    var Mode = require_mode();
    var ALPHA_NUM_CHARS = [
      "0",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z",
      " ",
      "$",
      "%",
      "*",
      "+",
      "-",
      ".",
      "/",
      ":"
    ];
    function AlphanumericData(data) {
      this.mode = Mode.ALPHANUMERIC;
      this.data = data;
    }
    AlphanumericData.getBitsLength = function getBitsLength(length) {
      return 11 * Math.floor(length / 2) + 6 * (length % 2);
    };
    AlphanumericData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    AlphanumericData.prototype.getBitsLength = function getBitsLength() {
      return AlphanumericData.getBitsLength(this.data.length);
    };
    AlphanumericData.prototype.write = function write(bitBuffer) {
      let i;
      for (i = 0; i + 2 <= this.data.length; i += 2) {
        let value = ALPHA_NUM_CHARS.indexOf(this.data[i]) * 45;
        value += ALPHA_NUM_CHARS.indexOf(this.data[i + 1]);
        bitBuffer.put(value, 11);
      }
      if (this.data.length % 2) {
        bitBuffer.put(ALPHA_NUM_CHARS.indexOf(this.data[i]), 6);
      }
    };
    module.exports = AlphanumericData;
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/byte-data.js
var require_byte_data = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/byte-data.js"(exports, module) {
    var Mode = require_mode();
    function ByteData(data) {
      this.mode = Mode.BYTE;
      if (typeof data === "string") {
        this.data = new TextEncoder().encode(data);
      } else {
        this.data = new Uint8Array(data);
      }
    }
    ByteData.getBitsLength = function getBitsLength(length) {
      return length * 8;
    };
    ByteData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    ByteData.prototype.getBitsLength = function getBitsLength() {
      return ByteData.getBitsLength(this.data.length);
    };
    ByteData.prototype.write = function(bitBuffer) {
      for (let i = 0, l = this.data.length; i < l; i++) {
        bitBuffer.put(this.data[i], 8);
      }
    };
    module.exports = ByteData;
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/kanji-data.js
var require_kanji_data = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/kanji-data.js"(exports, module) {
    var Mode = require_mode();
    var Utils = require_utils();
    function KanjiData(data) {
      this.mode = Mode.KANJI;
      this.data = data;
    }
    KanjiData.getBitsLength = function getBitsLength(length) {
      return length * 13;
    };
    KanjiData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    KanjiData.prototype.getBitsLength = function getBitsLength() {
      return KanjiData.getBitsLength(this.data.length);
    };
    KanjiData.prototype.write = function(bitBuffer) {
      let i;
      for (i = 0; i < this.data.length; i++) {
        let value = Utils.toSJIS(this.data[i]);
        if (value >= 33088 && value <= 40956) {
          value -= 33088;
        } else if (value >= 57408 && value <= 60351) {
          value -= 49472;
        } else {
          throw new Error(
            "Invalid SJIS character: " + this.data[i] + "\nMake sure your charset is UTF-8"
          );
        }
        value = (value >>> 8 & 255) * 192 + (value & 255);
        bitBuffer.put(value, 13);
      }
    };
    module.exports = KanjiData;
  }
});

// node_modules/.pnpm/dijkstrajs@1.0.3/node_modules/dijkstrajs/dijkstra.js
var require_dijkstra = __commonJS({
  "node_modules/.pnpm/dijkstrajs@1.0.3/node_modules/dijkstrajs/dijkstra.js"(exports, module) {
    "use strict";
    var dijkstra = {
      single_source_shortest_paths: function(graph, s, d) {
        var predecessors = {};
        var costs = {};
        costs[s] = 0;
        var open = dijkstra.PriorityQueue.make();
        open.push(s, 0);
        var closest, u, v, cost_of_s_to_u, adjacent_nodes, cost_of_e, cost_of_s_to_u_plus_cost_of_e, cost_of_s_to_v, first_visit;
        while (!open.empty()) {
          closest = open.pop();
          u = closest.value;
          cost_of_s_to_u = closest.cost;
          adjacent_nodes = graph[u] || {};
          for (v in adjacent_nodes) {
            if (adjacent_nodes.hasOwnProperty(v)) {
              cost_of_e = adjacent_nodes[v];
              cost_of_s_to_u_plus_cost_of_e = cost_of_s_to_u + cost_of_e;
              cost_of_s_to_v = costs[v];
              first_visit = typeof costs[v] === "undefined";
              if (first_visit || cost_of_s_to_v > cost_of_s_to_u_plus_cost_of_e) {
                costs[v] = cost_of_s_to_u_plus_cost_of_e;
                open.push(v, cost_of_s_to_u_plus_cost_of_e);
                predecessors[v] = u;
              }
            }
          }
        }
        if (typeof d !== "undefined" && typeof costs[d] === "undefined") {
          var msg = ["Could not find a path from ", s, " to ", d, "."].join("");
          throw new Error(msg);
        }
        return predecessors;
      },
      extract_shortest_path_from_predecessor_list: function(predecessors, d) {
        var nodes = [];
        var u = d;
        var predecessor;
        while (u) {
          nodes.push(u);
          predecessor = predecessors[u];
          u = predecessors[u];
        }
        nodes.reverse();
        return nodes;
      },
      find_path: function(graph, s, d) {
        var predecessors = dijkstra.single_source_shortest_paths(graph, s, d);
        return dijkstra.extract_shortest_path_from_predecessor_list(
          predecessors,
          d
        );
      },
      /**
       * A very naive priority queue implementation.
       */
      PriorityQueue: {
        make: function(opts) {
          var T = dijkstra.PriorityQueue, t = {}, key;
          opts = opts || {};
          for (key in T) {
            if (T.hasOwnProperty(key)) {
              t[key] = T[key];
            }
          }
          t.queue = [];
          t.sorter = opts.sorter || T.default_sorter;
          return t;
        },
        default_sorter: function(a, b) {
          return a.cost - b.cost;
        },
        /**
         * Add a new item to the queue and ensure the highest priority element
         * is at the front of the queue.
         */
        push: function(value, cost) {
          var item = { value, cost };
          this.queue.push(item);
          this.queue.sort(this.sorter);
        },
        /**
         * Return the highest priority element in the queue.
         */
        pop: function() {
          return this.queue.shift();
        },
        empty: function() {
          return this.queue.length === 0;
        }
      }
    };
    if (typeof module !== "undefined") {
      module.exports = dijkstra;
    }
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/segments.js
var require_segments = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/segments.js"(exports) {
    var Mode = require_mode();
    var NumericData = require_numeric_data();
    var AlphanumericData = require_alphanumeric_data();
    var ByteData = require_byte_data();
    var KanjiData = require_kanji_data();
    var Regex = require_regex();
    var Utils = require_utils();
    var dijkstra = require_dijkstra();
    function getStringByteLength(str) {
      return unescape(encodeURIComponent(str)).length;
    }
    function getSegments(regex, mode, str) {
      const segments = [];
      let result;
      while ((result = regex.exec(str)) !== null) {
        segments.push({
          data: result[0],
          index: result.index,
          mode,
          length: result[0].length
        });
      }
      return segments;
    }
    function getSegmentsFromString(dataStr) {
      const numSegs = getSegments(Regex.NUMERIC, Mode.NUMERIC, dataStr);
      const alphaNumSegs = getSegments(Regex.ALPHANUMERIC, Mode.ALPHANUMERIC, dataStr);
      let byteSegs;
      let kanjiSegs;
      if (Utils.isKanjiModeEnabled()) {
        byteSegs = getSegments(Regex.BYTE, Mode.BYTE, dataStr);
        kanjiSegs = getSegments(Regex.KANJI, Mode.KANJI, dataStr);
      } else {
        byteSegs = getSegments(Regex.BYTE_KANJI, Mode.BYTE, dataStr);
        kanjiSegs = [];
      }
      const segs = numSegs.concat(alphaNumSegs, byteSegs, kanjiSegs);
      return segs.sort(function(s1, s2) {
        return s1.index - s2.index;
      }).map(function(obj) {
        return {
          data: obj.data,
          mode: obj.mode,
          length: obj.length
        };
      });
    }
    function getSegmentBitsLength(length, mode) {
      switch (mode) {
        case Mode.NUMERIC:
          return NumericData.getBitsLength(length);
        case Mode.ALPHANUMERIC:
          return AlphanumericData.getBitsLength(length);
        case Mode.KANJI:
          return KanjiData.getBitsLength(length);
        case Mode.BYTE:
          return ByteData.getBitsLength(length);
      }
    }
    function mergeSegments(segs) {
      return segs.reduce(function(acc, curr) {
        const prevSeg = acc.length - 1 >= 0 ? acc[acc.length - 1] : null;
        if (prevSeg && prevSeg.mode === curr.mode) {
          acc[acc.length - 1].data += curr.data;
          return acc;
        }
        acc.push(curr);
        return acc;
      }, []);
    }
    function buildNodes(segs) {
      const nodes = [];
      for (let i = 0; i < segs.length; i++) {
        const seg = segs[i];
        switch (seg.mode) {
          case Mode.NUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.ALPHANUMERIC, length: seg.length },
              { data: seg.data, mode: Mode.BYTE, length: seg.length }
            ]);
            break;
          case Mode.ALPHANUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.BYTE, length: seg.length }
            ]);
            break;
          case Mode.KANJI:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
            ]);
            break;
          case Mode.BYTE:
            nodes.push([
              { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
            ]);
        }
      }
      return nodes;
    }
    function buildGraph(nodes, version) {
      const table = {};
      const graph = { start: {} };
      let prevNodeIds = ["start"];
      for (let i = 0; i < nodes.length; i++) {
        const nodeGroup = nodes[i];
        const currentNodeIds = [];
        for (let j = 0; j < nodeGroup.length; j++) {
          const node = nodeGroup[j];
          const key = "" + i + j;
          currentNodeIds.push(key);
          table[key] = { node, lastCount: 0 };
          graph[key] = {};
          for (let n = 0; n < prevNodeIds.length; n++) {
            const prevNodeId = prevNodeIds[n];
            if (table[prevNodeId] && table[prevNodeId].node.mode === node.mode) {
              graph[prevNodeId][key] = getSegmentBitsLength(table[prevNodeId].lastCount + node.length, node.mode) - getSegmentBitsLength(table[prevNodeId].lastCount, node.mode);
              table[prevNodeId].lastCount += node.length;
            } else {
              if (table[prevNodeId]) table[prevNodeId].lastCount = node.length;
              graph[prevNodeId][key] = getSegmentBitsLength(node.length, node.mode) + 4 + Mode.getCharCountIndicator(node.mode, version);
            }
          }
        }
        prevNodeIds = currentNodeIds;
      }
      for (let n = 0; n < prevNodeIds.length; n++) {
        graph[prevNodeIds[n]].end = 0;
      }
      return { map: graph, table };
    }
    function buildSingleSegment(data, modesHint) {
      let mode;
      const bestMode = Mode.getBestModeForData(data);
      mode = Mode.from(modesHint, bestMode);
      if (mode !== Mode.BYTE && mode.bit < bestMode.bit) {
        throw new Error('"' + data + '" cannot be encoded with mode ' + Mode.toString(mode) + ".\n Suggested mode is: " + Mode.toString(bestMode));
      }
      if (mode === Mode.KANJI && !Utils.isKanjiModeEnabled()) {
        mode = Mode.BYTE;
      }
      switch (mode) {
        case Mode.NUMERIC:
          return new NumericData(data);
        case Mode.ALPHANUMERIC:
          return new AlphanumericData(data);
        case Mode.KANJI:
          return new KanjiData(data);
        case Mode.BYTE:
          return new ByteData(data);
      }
    }
    exports.fromArray = function fromArray(array) {
      return array.reduce(function(acc, seg) {
        if (typeof seg === "string") {
          acc.push(buildSingleSegment(seg, null));
        } else if (seg.data) {
          acc.push(buildSingleSegment(seg.data, seg.mode));
        }
        return acc;
      }, []);
    };
    exports.fromString = function fromString(data, version) {
      const segs = getSegmentsFromString(data, Utils.isKanjiModeEnabled());
      const nodes = buildNodes(segs);
      const graph = buildGraph(nodes, version);
      const path = dijkstra.find_path(graph.map, "start", "end");
      const optimizedSegs = [];
      for (let i = 1; i < path.length - 1; i++) {
        optimizedSegs.push(graph.table[path[i]].node);
      }
      return exports.fromArray(mergeSegments(optimizedSegs));
    };
    exports.rawSplit = function rawSplit(data) {
      return exports.fromArray(
        getSegmentsFromString(data, Utils.isKanjiModeEnabled())
      );
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/qrcode.js
var require_qrcode = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/core/qrcode.js"(exports) {
    var Utils = require_utils();
    var ECLevel = require_error_correction_level();
    var BitBuffer = require_bit_buffer();
    var BitMatrix = require_bit_matrix();
    var AlignmentPattern = require_alignment_pattern();
    var FinderPattern = require_finder_pattern();
    var MaskPattern = require_mask_pattern();
    var ECCode = require_error_correction_code();
    var ReedSolomonEncoder = require_reed_solomon_encoder();
    var Version = require_version();
    var FormatInfo = require_format_info();
    var Mode = require_mode();
    var Segments = require_segments();
    function setupFinderPattern(matrix, version) {
      const size = matrix.size;
      const pos = FinderPattern.getPositions(version);
      for (let i = 0; i < pos.length; i++) {
        const row = pos[i][0];
        const col = pos[i][1];
        for (let r = -1; r <= 7; r++) {
          if (row + r <= -1 || size <= row + r) continue;
          for (let c = -1; c <= 7; c++) {
            if (col + c <= -1 || size <= col + c) continue;
            if (r >= 0 && r <= 6 && (c === 0 || c === 6) || c >= 0 && c <= 6 && (r === 0 || r === 6) || r >= 2 && r <= 4 && c >= 2 && c <= 4) {
              matrix.set(row + r, col + c, true, true);
            } else {
              matrix.set(row + r, col + c, false, true);
            }
          }
        }
      }
    }
    function setupTimingPattern(matrix) {
      const size = matrix.size;
      for (let r = 8; r < size - 8; r++) {
        const value = r % 2 === 0;
        matrix.set(r, 6, value, true);
        matrix.set(6, r, value, true);
      }
    }
    function setupAlignmentPattern(matrix, version) {
      const pos = AlignmentPattern.getPositions(version);
      for (let i = 0; i < pos.length; i++) {
        const row = pos[i][0];
        const col = pos[i][1];
        for (let r = -2; r <= 2; r++) {
          for (let c = -2; c <= 2; c++) {
            if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
              matrix.set(row + r, col + c, true, true);
            } else {
              matrix.set(row + r, col + c, false, true);
            }
          }
        }
      }
    }
    function setupVersionInfo(matrix, version) {
      const size = matrix.size;
      const bits = Version.getEncodedBits(version);
      let row, col, mod;
      for (let i = 0; i < 18; i++) {
        row = Math.floor(i / 3);
        col = i % 3 + size - 8 - 3;
        mod = (bits >> i & 1) === 1;
        matrix.set(row, col, mod, true);
        matrix.set(col, row, mod, true);
      }
    }
    function setupFormatInfo(matrix, errorCorrectionLevel, maskPattern) {
      const size = matrix.size;
      const bits = FormatInfo.getEncodedBits(errorCorrectionLevel, maskPattern);
      let i, mod;
      for (i = 0; i < 15; i++) {
        mod = (bits >> i & 1) === 1;
        if (i < 6) {
          matrix.set(i, 8, mod, true);
        } else if (i < 8) {
          matrix.set(i + 1, 8, mod, true);
        } else {
          matrix.set(size - 15 + i, 8, mod, true);
        }
        if (i < 8) {
          matrix.set(8, size - i - 1, mod, true);
        } else if (i < 9) {
          matrix.set(8, 15 - i - 1 + 1, mod, true);
        } else {
          matrix.set(8, 15 - i - 1, mod, true);
        }
      }
      matrix.set(size - 8, 8, 1, true);
    }
    function setupData(matrix, data) {
      const size = matrix.size;
      let inc = -1;
      let row = size - 1;
      let bitIndex = 7;
      let byteIndex = 0;
      for (let col = size - 1; col > 0; col -= 2) {
        if (col === 6) col--;
        while (true) {
          for (let c = 0; c < 2; c++) {
            if (!matrix.isReserved(row, col - c)) {
              let dark = false;
              if (byteIndex < data.length) {
                dark = (data[byteIndex] >>> bitIndex & 1) === 1;
              }
              matrix.set(row, col - c, dark);
              bitIndex--;
              if (bitIndex === -1) {
                byteIndex++;
                bitIndex = 7;
              }
            }
          }
          row += inc;
          if (row < 0 || size <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    }
    function createData(version, errorCorrectionLevel, segments) {
      const buffer = new BitBuffer();
      segments.forEach(function(data) {
        buffer.put(data.mode.bit, 4);
        buffer.put(data.getLength(), Mode.getCharCountIndicator(data.mode, version));
        data.write(buffer);
      });
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (buffer.getLengthInBits() + 4 <= dataTotalCodewordsBits) {
        buffer.put(0, 4);
      }
      while (buffer.getLengthInBits() % 8 !== 0) {
        buffer.putBit(0);
      }
      const remainingByte = (dataTotalCodewordsBits - buffer.getLengthInBits()) / 8;
      for (let i = 0; i < remainingByte; i++) {
        buffer.put(i % 2 ? 17 : 236, 8);
      }
      return createCodewords(buffer, version, errorCorrectionLevel);
    }
    function createCodewords(bitBuffer, version, errorCorrectionLevel) {
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewords = totalCodewords - ecTotalCodewords;
      const ecTotalBlocks = ECCode.getBlocksCount(version, errorCorrectionLevel);
      const blocksInGroup2 = totalCodewords % ecTotalBlocks;
      const blocksInGroup1 = ecTotalBlocks - blocksInGroup2;
      const totalCodewordsInGroup1 = Math.floor(totalCodewords / ecTotalBlocks);
      const dataCodewordsInGroup1 = Math.floor(dataTotalCodewords / ecTotalBlocks);
      const dataCodewordsInGroup2 = dataCodewordsInGroup1 + 1;
      const ecCount = totalCodewordsInGroup1 - dataCodewordsInGroup1;
      const rs = new ReedSolomonEncoder(ecCount);
      let offset = 0;
      const dcData = new Array(ecTotalBlocks);
      const ecData = new Array(ecTotalBlocks);
      let maxDataSize = 0;
      const buffer = new Uint8Array(bitBuffer.buffer);
      for (let b = 0; b < ecTotalBlocks; b++) {
        const dataSize = b < blocksInGroup1 ? dataCodewordsInGroup1 : dataCodewordsInGroup2;
        dcData[b] = buffer.slice(offset, offset + dataSize);
        ecData[b] = rs.encode(dcData[b]);
        offset += dataSize;
        maxDataSize = Math.max(maxDataSize, dataSize);
      }
      const data = new Uint8Array(totalCodewords);
      let index = 0;
      let i, r;
      for (i = 0; i < maxDataSize; i++) {
        for (r = 0; r < ecTotalBlocks; r++) {
          if (i < dcData[r].length) {
            data[index++] = dcData[r][i];
          }
        }
      }
      for (i = 0; i < ecCount; i++) {
        for (r = 0; r < ecTotalBlocks; r++) {
          data[index++] = ecData[r][i];
        }
      }
      return data;
    }
    function createSymbol(data, version, errorCorrectionLevel, maskPattern) {
      let segments;
      if (Array.isArray(data)) {
        segments = Segments.fromArray(data);
      } else if (typeof data === "string") {
        let estimatedVersion = version;
        if (!estimatedVersion) {
          const rawSegments = Segments.rawSplit(data);
          estimatedVersion = Version.getBestVersionForData(rawSegments, errorCorrectionLevel);
        }
        segments = Segments.fromString(data, estimatedVersion || 40);
      } else {
        throw new Error("Invalid data");
      }
      const bestVersion = Version.getBestVersionForData(segments, errorCorrectionLevel);
      if (!bestVersion) {
        throw new Error("The amount of data is too big to be stored in a QR Code");
      }
      if (!version) {
        version = bestVersion;
      } else if (version < bestVersion) {
        throw new Error(
          "\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + bestVersion + ".\n"
        );
      }
      const dataBits = createData(version, errorCorrectionLevel, segments);
      const moduleCount = Utils.getSymbolSize(version);
      const modules = new BitMatrix(moduleCount);
      setupFinderPattern(modules, version);
      setupTimingPattern(modules);
      setupAlignmentPattern(modules, version);
      setupFormatInfo(modules, errorCorrectionLevel, 0);
      if (version >= 7) {
        setupVersionInfo(modules, version);
      }
      setupData(modules, dataBits);
      if (isNaN(maskPattern)) {
        maskPattern = MaskPattern.getBestMask(
          modules,
          setupFormatInfo.bind(null, modules, errorCorrectionLevel)
        );
      }
      MaskPattern.applyMask(maskPattern, modules);
      setupFormatInfo(modules, errorCorrectionLevel, maskPattern);
      return {
        modules,
        version,
        errorCorrectionLevel,
        maskPattern,
        segments
      };
    }
    exports.create = function create(data, options) {
      if (typeof data === "undefined" || data === "") {
        throw new Error("No input text");
      }
      let errorCorrectionLevel = ECLevel.M;
      let version;
      let mask;
      if (typeof options !== "undefined") {
        errorCorrectionLevel = ECLevel.from(options.errorCorrectionLevel, ECLevel.M);
        version = Version.from(options.version);
        mask = MaskPattern.from(options.maskPattern);
        if (options.toSJISFunc) {
          Utils.setToSJISFunction(options.toSJISFunc);
        }
      }
      return createSymbol(data, version, errorCorrectionLevel, mask);
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/renderer/utils.js
var require_utils2 = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/renderer/utils.js"(exports) {
    function hex2rgba(hex) {
      if (typeof hex === "number") {
        hex = hex.toString();
      }
      if (typeof hex !== "string") {
        throw new Error("Color should be defined as hex string");
      }
      let hexCode = hex.slice().replace("#", "").split("");
      if (hexCode.length < 3 || hexCode.length === 5 || hexCode.length > 8) {
        throw new Error("Invalid hex color: " + hex);
      }
      if (hexCode.length === 3 || hexCode.length === 4) {
        hexCode = Array.prototype.concat.apply([], hexCode.map(function(c) {
          return [c, c];
        }));
      }
      if (hexCode.length === 6) hexCode.push("F", "F");
      const hexValue = parseInt(hexCode.join(""), 16);
      return {
        r: hexValue >> 24 & 255,
        g: hexValue >> 16 & 255,
        b: hexValue >> 8 & 255,
        a: hexValue & 255,
        hex: "#" + hexCode.slice(0, 6).join("")
      };
    }
    exports.getOptions = function getOptions(options) {
      if (!options) options = {};
      if (!options.color) options.color = {};
      const margin = typeof options.margin === "undefined" || options.margin === null || options.margin < 0 ? 4 : options.margin;
      const width = options.width && options.width >= 21 ? options.width : void 0;
      const scale = options.scale || 4;
      return {
        width,
        scale: width ? 4 : scale,
        margin,
        color: {
          dark: hex2rgba(options.color.dark || "#000000ff"),
          light: hex2rgba(options.color.light || "#ffffffff")
        },
        type: options.type,
        rendererOpts: options.rendererOpts || {}
      };
    };
    exports.getScale = function getScale(qrSize, opts) {
      return opts.width && opts.width >= qrSize + opts.margin * 2 ? opts.width / (qrSize + opts.margin * 2) : opts.scale;
    };
    exports.getImageWidth = function getImageWidth(qrSize, opts) {
      const scale = exports.getScale(qrSize, opts);
      return Math.floor((qrSize + opts.margin * 2) * scale);
    };
    exports.qrToImageData = function qrToImageData(imgData, qr, opts) {
      const size = qr.modules.size;
      const data = qr.modules.data;
      const scale = exports.getScale(size, opts);
      const symbolSize = Math.floor((size + opts.margin * 2) * scale);
      const scaledMargin = opts.margin * scale;
      const palette = [opts.color.light, opts.color.dark];
      for (let i = 0; i < symbolSize; i++) {
        for (let j = 0; j < symbolSize; j++) {
          let posDst = (i * symbolSize + j) * 4;
          let pxColor = opts.color.light;
          if (i >= scaledMargin && j >= scaledMargin && i < symbolSize - scaledMargin && j < symbolSize - scaledMargin) {
            const iSrc = Math.floor((i - scaledMargin) / scale);
            const jSrc = Math.floor((j - scaledMargin) / scale);
            pxColor = palette[data[iSrc * size + jSrc] ? 1 : 0];
          }
          imgData[posDst++] = pxColor.r;
          imgData[posDst++] = pxColor.g;
          imgData[posDst++] = pxColor.b;
          imgData[posDst] = pxColor.a;
        }
      }
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/renderer/canvas.js
var require_canvas = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/renderer/canvas.js"(exports) {
    var Utils = require_utils2();
    function clearCanvas(ctx, canvas, size) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (!canvas.style) canvas.style = {};
      canvas.height = size;
      canvas.width = size;
      canvas.style.height = size + "px";
      canvas.style.width = size + "px";
    }
    function getCanvasElement() {
      try {
        return document.createElement("canvas");
      } catch (e) {
        throw new Error("You need to specify a canvas element");
      }
    }
    exports.render = function render(qrData, canvas, options) {
      let opts = options;
      let canvasEl = canvas;
      if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
        opts = canvas;
        canvas = void 0;
      }
      if (!canvas) {
        canvasEl = getCanvasElement();
      }
      opts = Utils.getOptions(opts);
      const size = Utils.getImageWidth(qrData.modules.size, opts);
      const ctx = canvasEl.getContext("2d");
      const image = ctx.createImageData(size, size);
      Utils.qrToImageData(image.data, qrData, opts);
      clearCanvas(ctx, canvasEl, size);
      ctx.putImageData(image, 0, 0);
      return canvasEl;
    };
    exports.renderToDataURL = function renderToDataURL(qrData, canvas, options) {
      let opts = options;
      if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
        opts = canvas;
        canvas = void 0;
      }
      if (!opts) opts = {};
      const canvasEl = exports.render(qrData, canvas, opts);
      const type = opts.type || "image/png";
      const rendererOpts = opts.rendererOpts || {};
      return canvasEl.toDataURL(type, rendererOpts.quality);
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/renderer/svg-tag.js
var require_svg_tag = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/renderer/svg-tag.js"(exports) {
    var Utils = require_utils2();
    function getColorAttrib(color, attrib) {
      const alpha = color.a / 255;
      const str = attrib + '="' + color.hex + '"';
      return alpha < 1 ? str + " " + attrib + '-opacity="' + alpha.toFixed(2).slice(1) + '"' : str;
    }
    function svgCmd(cmd, x, y) {
      let str = cmd + x;
      if (typeof y !== "undefined") str += " " + y;
      return str;
    }
    function qrToPath(data, size, margin) {
      let path = "";
      let moveBy = 0;
      let newRow = false;
      let lineLength = 0;
      for (let i = 0; i < data.length; i++) {
        const col = Math.floor(i % size);
        const row = Math.floor(i / size);
        if (!col && !newRow) newRow = true;
        if (data[i]) {
          lineLength++;
          if (!(i > 0 && col > 0 && data[i - 1])) {
            path += newRow ? svgCmd("M", col + margin, 0.5 + row + margin) : svgCmd("m", moveBy, 0);
            moveBy = 0;
            newRow = false;
          }
          if (!(col + 1 < size && data[i + 1])) {
            path += svgCmd("h", lineLength);
            lineLength = 0;
          }
        } else {
          moveBy++;
        }
      }
      return path;
    }
    exports.render = function render(qrData, options, cb) {
      const opts = Utils.getOptions(options);
      const size = qrData.modules.size;
      const data = qrData.modules.data;
      const qrcodesize = size + opts.margin * 2;
      const bg = !opts.color.light.a ? "" : "<path " + getColorAttrib(opts.color.light, "fill") + ' d="M0 0h' + qrcodesize + "v" + qrcodesize + 'H0z"/>';
      const path = "<path " + getColorAttrib(opts.color.dark, "stroke") + ' d="' + qrToPath(data, size, opts.margin) + '"/>';
      const viewBox = 'viewBox="0 0 ' + qrcodesize + " " + qrcodesize + '"';
      const width = !opts.width ? "" : 'width="' + opts.width + '" height="' + opts.width + '" ';
      const svgTag = '<svg xmlns="http://www.w3.org/2000/svg" ' + width + viewBox + ' shape-rendering="crispEdges">' + bg + path + "</svg>\n";
      if (typeof cb === "function") {
        cb(null, svgTag);
      }
      return svgTag;
    };
  }
});

// node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/browser.js
var require_browser = __commonJS({
  "node_modules/.pnpm/qrcode@1.5.4/node_modules/qrcode/lib/browser.js"(exports) {
    var canPromise = require_can_promise();
    var QRCode = require_qrcode();
    var CanvasRenderer = require_canvas();
    var SvgRenderer = require_svg_tag();
    function renderCanvas(renderFunc, canvas, text, opts, cb) {
      const args = [].slice.call(arguments, 1);
      const argsNum = args.length;
      const isLastArgCb = typeof args[argsNum - 1] === "function";
      if (!isLastArgCb && !canPromise()) {
        throw new Error("Callback required as last argument");
      }
      if (isLastArgCb) {
        if (argsNum < 2) {
          throw new Error("Too few arguments provided");
        }
        if (argsNum === 2) {
          cb = text;
          text = canvas;
          canvas = opts = void 0;
        } else if (argsNum === 3) {
          if (canvas.getContext && typeof cb === "undefined") {
            cb = opts;
            opts = void 0;
          } else {
            cb = opts;
            opts = text;
            text = canvas;
            canvas = void 0;
          }
        }
      } else {
        if (argsNum < 1) {
          throw new Error("Too few arguments provided");
        }
        if (argsNum === 1) {
          text = canvas;
          canvas = opts = void 0;
        } else if (argsNum === 2 && !canvas.getContext) {
          opts = text;
          text = canvas;
          canvas = void 0;
        }
        return new Promise(function(resolve, reject) {
          try {
            const data = QRCode.create(text, opts);
            resolve(renderFunc(data, canvas, opts));
          } catch (e) {
            reject(e);
          }
        });
      }
      try {
        const data = QRCode.create(text, opts);
        cb(null, renderFunc(data, canvas, opts));
      } catch (e) {
        cb(e);
      }
    }
    exports.create = QRCode.create;
    exports.toCanvas = renderCanvas.bind(null, CanvasRenderer.render);
    exports.toDataURL = renderCanvas.bind(null, CanvasRenderer.renderToDataURL);
    exports.toString = renderCanvas.bind(null, function(data, _, opts) {
      return SvgRenderer.render(data, opts);
    });
  }
});

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/ui.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var import_react = __toESM(require_react());
var import_jsx_runtime2 = __toESM(require_jsx_runtime());
var import_jsx_runtime3 = __toESM(require_jsx_runtime());
var import_jsx_runtime4 = __toESM(require_jsx_runtime());
var import_react2 = __toESM(require_react());
var import_react_dom = __toESM(require_react_dom());
var import_qrcode = __toESM(require_browser());
var import_react3 = __toESM(require_react());
var import_jsx_runtime5 = __toESM(require_jsx_runtime());
var import_jsx_runtime6 = __toESM(require_jsx_runtime());
var import_jsx_runtime7 = __toESM(require_jsx_runtime());
var import_react4 = __toESM(require_react());
var import_jsx_runtime8 = __toESM(require_jsx_runtime());
var import_jsx_runtime9 = __toESM(require_jsx_runtime());
var import_jsx_runtime10 = __toESM(require_jsx_runtime());
var import_jsx_runtime11 = __toESM(require_jsx_runtime());
var import_jsx_runtime12 = __toESM(require_jsx_runtime());
var import_jsx_runtime13 = __toESM(require_jsx_runtime());
var import_react5 = __toESM(require_react());
var import_jsx_runtime14 = __toESM(require_jsx_runtime());
var import_jsx_runtime15 = __toESM(require_jsx_runtime());
var import_react6 = __toESM(require_react());
var statusLabelByConnection = {
  connected: "Live",
  connecting: "Syncing",
  reconnecting: "Syncing",
  disconnected: "Offline",
  idle: "Idle"
};
var statusToneByConnection = {
  connected: "border-emerald-400/18 bg-emerald-400/8 text-emerald-50",
  connecting: "border-amber-400/18 bg-amber-400/8 text-amber-50",
  reconnecting: "border-amber-400/18 bg-amber-400/8 text-amber-50",
  disconnected: "border-rose-400/18 bg-rose-400/8 text-rose-50",
  idle: "border-white/10 bg-white/[0.05] text-white/78"
};
var statusDotToneByConnection = {
  connected: "bg-emerald-300",
  connecting: "bg-amber-300",
  reconnecting: "bg-amber-300",
  disconnected: "bg-rose-300",
  idle: "bg-white/45"
};
var ConnectionStatusPill = ({
  status,
  className
}) => {
  return (0, import_jsx_runtime.jsxs)(
    "span",
    {
      className: cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.625rem] font-semibold tracking-[0.16em] uppercase",
        statusToneByConnection[status],
        className
      ),
      children: [
        (0, import_jsx_runtime.jsx)(
          "span",
          {
            className: cn(
              "h-1.5 w-1.5 shrink-0 rounded-full",
              statusDotToneByConnection[status]
            ),
            "aria-hidden": true
          }
        ),
        statusLabelByConnection[status]
      ]
    }
  );
};
var LABEL_MAX = 24;
var DEFAULT_DEBOUNCE_MS = 400;
var ControllerPlayerNameField = ({
  fieldLabel = "Your name",
  className,
  labelClassName,
  inputClassName,
  debounceMs = DEFAULT_DEBOUNCE_MS
}) => {
  var _a, _b;
  const controller = useAirJamController();
  const [local, setLocal] = (0, import_react.useState)("");
  const inputRef = (0, import_react.useRef)(null);
  const debounceTimerRef = (0, import_react.useRef)(null);
  const nextPlayerLabel = ((_b = (_a = controller.selfPlayer) == null ? void 0 : _a.label) == null ? void 0 : _b.trim()) ?? "";
  (0, import_react.useEffect)(() => {
    if (inputRef.current === document.activeElement) {
      return;
    }
    setLocal(nextPlayerLabel);
  }, [controller.controllerId, nextPlayerLabel]);
  (0, import_react.useEffect)(
    () => () => {
      if (debounceTimerRef.current !== null) {
        clearTimeout(debounceTimerRef.current);
      }
    },
    []
  );
  const pushRoomName = (0, import_react.useCallback)(
    (raw) => {
      const trimmed = raw.trim().slice(0, LABEL_MAX);
      if (trimmed.length < 1) {
        return;
      }
      controller.setNickname(trimmed);
      void controller.updatePlayerProfile({ label: trimmed });
    },
    [controller]
  );
  const schedulePush = (0, import_react.useCallback)(
    (raw) => {
      if (debounceTimerRef.current !== null) {
        clearTimeout(debounceTimerRef.current);
      }
      debounceTimerRef.current = setTimeout(() => {
        debounceTimerRef.current = null;
        pushRoomName(raw);
      }, debounceMs);
    },
    [debounceMs, pushRoomName]
  );
  const connected = controller.connectionStatus === "connected";
  return (0, import_jsx_runtime2.jsxs)("div", { className: cn("min-w-0", className), children: [
    (0, import_jsx_runtime2.jsx)(
      "label",
      {
        className: cn("mb-1 block", labelClassName),
        htmlFor: "airjam-controller-player-name",
        children: fieldLabel
      }
    ),
    (0, import_jsx_runtime2.jsx)(
      "input",
      {
        ref: inputRef,
        id: "airjam-controller-player-name",
        type: "text",
        name: "airjam-controller-player-name",
        autoComplete: "nickname",
        enterKeyHint: "done",
        maxLength: LABEL_MAX,
        disabled: !connected,
        value: local,
        placeholder: connected ? "Enter name" : "Connect to edit",
        className: cn(inputClassName),
        onChange: (event) => {
          const next = event.target.value.slice(0, LABEL_MAX);
          setLocal(next);
          schedulePush(next);
        },
        onBlur: () => {
          if (debounceTimerRef.current !== null) {
            clearTimeout(debounceTimerRef.current);
            debounceTimerRef.current = null;
          }
          const trimmed = local.trim();
          if (trimmed.length < 1) {
            setLocal(nextPlayerLabel);
            return;
          }
          pushRoomName(local);
        }
      }
    )
  ] });
};
var ControllerPrimaryAction = ({
  label,
  helper,
  icon,
  disabled,
  onPress,
  testId,
  className,
  buttonClassName
}) => {
  return (0, import_jsx_runtime3.jsx)("div", { className: cn("mt-auto pt-3", className), children: (0, import_jsx_runtime3.jsxs)(
    Button,
    {
      type: "button",
      onClick: onPress,
      disabled,
      "data-testid": testId,
      "aria-label": label,
      title: label,
      className: cn(
        "flex h-auto min-h-18 w-full items-center justify-between rounded-[1.5rem] border border-white/15 px-5 py-4 text-left shadow-lg",
        buttonClassName
      ),
      children: [
        (0, import_jsx_runtime3.jsxs)("div", { className: "min-w-0", children: [
          (0, import_jsx_runtime3.jsx)("div", { className: "truncate text-base font-black tracking-[0.12em] uppercase sm:text-lg", children: label }),
          helper ? (0, import_jsx_runtime3.jsx)("div", { className: "mt-1 text-sm/5 font-medium tracking-normal normal-case opacity-80", children: helper }) : null
        ] }),
        icon ? (0, import_jsx_runtime3.jsx)("div", { className: "ml-4 flex shrink-0 items-center justify-center", children: icon }) : null
      ]
    }
  ) });
};
function HostMuteButton({
  muted,
  onToggle,
  className,
  labelClassName,
  mutedLabel = "Unmute",
  unmutedLabel = "Mute"
}) {
  const label = muted ? mutedLabel : unmutedLabel;
  return (0, import_jsx_runtime4.jsxs)(
    Button,
    {
      type: "button",
      variant: "ghost",
      size: "sm",
      onClick: onToggle,
      "aria-pressed": muted,
      "aria-label": label,
      title: label,
      className: cn(
        "rounded-full border border-white/25 bg-black/35 px-3 text-white backdrop-blur-sm hover:bg-black/55",
        className
      ),
      children: [
        muted ? (0, import_jsx_runtime4.jsx)(VolumeX, { className: "size-4" }) : (0, import_jsx_runtime4.jsx)(Volume2, { className: "size-4" }),
        (0, import_jsx_runtime4.jsx)(
          "span",
          {
            className: cn(
              "text-[11px] font-semibold tracking-[0.16em] uppercase",
              labelClassName
            ),
            children: label
          }
        )
      ]
    }
  );
}
var RoomQrCode = ({
  value,
  size = 180,
  padding = 1,
  foregroundColor = "#111111",
  backgroundColor = "#ffffff",
  errorCorrectionLevel = "M",
  className = "",
  style,
  alt = "Room join QR code"
}) => {
  const trimmed = value.trim();
  const qrKey = `${trimmed}\0${size}\0${padding}\0${foregroundColor}\0${backgroundColor}\0${errorCorrectionLevel}`;
  const [qrState, setQrState] = (0, import_react3.useState)({
    key: null,
    dataUrl: null,
    error: false
  });
  (0, import_react3.useEffect)(() => {
    if (!trimmed) {
      return;
    }
    let cancelled = false;
    void (0, import_qrcode.toDataURL)(trimmed, {
      width: size,
      margin: padding,
      errorCorrectionLevel,
      color: {
        dark: foregroundColor,
        light: backgroundColor
      }
    }).then((nextUrl) => {
      if (!cancelled) {
        setQrState({
          key: qrKey,
          dataUrl: nextUrl,
          error: false
        });
      }
    }).catch(() => {
      if (!cancelled) {
        setQrState({
          key: qrKey,
          dataUrl: null,
          error: true
        });
      }
    });
    return () => {
      cancelled = true;
    };
  }, [
    backgroundColor,
    errorCorrectionLevel,
    foregroundColor,
    padding,
    size,
    qrKey,
    trimmed
  ]);
  const imageSrc = trimmed && qrState.key === qrKey && qrState.dataUrl ? qrState.dataUrl : null;
  const isLoading = !!trimmed && qrState.key !== qrKey;
  const isUnavailable = !trimmed || qrState.key === qrKey && qrState.error;
  return (0, import_jsx_runtime5.jsx)(
    "div",
    {
      className,
      style: {
        width: size,
        height: size,
        ...style
      },
      "aria-live": "polite",
      "aria-label": alt,
      children: imageSrc ? (0, import_jsx_runtime5.jsx)(
        "img",
        {
          src: imageSrc,
          alt,
          width: size,
          height: size,
          className: "h-full w-full rounded-md object-cover"
        }
      ) : isLoading ? (0, import_jsx_runtime5.jsxs)("div", { className: "flex h-full w-full flex-col items-center justify-center gap-2 rounded-md bg-black/15 text-xs text-white/70", children: [
        (0, import_jsx_runtime5.jsx)("span", { className: "h-5 w-5 animate-spin rounded-full border-2 border-white/20 border-t-white/80" }),
        (0, import_jsx_runtime5.jsx)("span", { children: "Generating QR…" })
      ] }) : (0, import_jsx_runtime5.jsx)("div", { className: "flex h-full w-full items-center justify-center rounded-md bg-black/15 text-xs text-white/70", children: isUnavailable ? "QR unavailable" : "Generating QR…" })
    }
  );
};
var JoinQrOverlay = ({
  open,
  value,
  status = "ready",
  roomId,
  onClose,
  title = "Scan QR code to join as a controller",
  roomLabel = "Join room",
  description = "Scan with your phone to connect as a controller.",
  unavailableLabel = "Join URL unavailable right now.",
  loadingLabel = "Preparing join QR…",
  qrAlt,
  showCloseButton = false,
  className,
  panelClassName,
  qrClassName,
  bodyClassName,
  messageClassName,
  descriptionClassName,
  closeButtonClassName,
  size = 260
}) => {
  const joinUrlValue = (value == null ? void 0 : value.trim()) ?? "";
  const effectiveStatus = status === "ready" && joinUrlValue.length === 0 ? "unavailable" : status;
  const overlaySize = `min(72vw, ${size}px)`;
  const [entered, setEntered] = (0, import_react2.useState)(false);
  (0, import_react2.useEffect)(() => {
    if (!open || typeof window === "undefined") {
      return;
    }
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        onClose == null ? void 0 : onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose, open]);
  (0, import_react2.useEffect)(() => {
    if (!open || typeof window === "undefined") {
      setEntered(false);
      return;
    }
    setEntered(false);
    const frame = window.requestAnimationFrame(() => {
      setEntered(true);
    });
    return () => {
      window.cancelAnimationFrame(frame);
    };
  }, [open]);
  if (!open) {
    return null;
  }
  const handlePanelClick = (event) => {
    event.stopPropagation();
  };
  const dialog = (0, import_jsx_runtime6.jsx)(
    "div",
    {
      role: "dialog",
      "aria-modal": "true",
      "aria-label": roomId ? `Join room ${roomId}` : title,
      className: cn(
        "pointer-events-auto fixed inset-0 z-[120] flex cursor-pointer flex-col items-center justify-center bg-black/85 px-6 backdrop-blur-md transition-opacity duration-200 ease-out",
        entered ? "opacity-100" : "opacity-0",
        className
      ),
      onClick: onClose,
      children: (0, import_jsx_runtime6.jsxs)(
        "div",
        {
          className: cn(
            "flex cursor-default flex-col items-center gap-6 text-center transition-transform duration-200 ease-out",
            entered ? "translate-y-0" : "-translate-y-4",
            panelClassName
          ),
          onClick: handlePanelClick,
          children: [
            (0, import_jsx_runtime6.jsxs)("div", { className: "space-y-1", children: [
              (0, import_jsx_runtime6.jsx)("p", { className: "text-[11px] tracking-[0.18em] text-slate-400 uppercase", children: roomLabel }),
              roomId ? (0, import_jsx_runtime6.jsx)("p", { className: "text-2xl font-semibold tracking-tight text-white tabular-nums", children: roomId }) : null
            ] }),
            effectiveStatus === "loading" ? (0, import_jsx_runtime6.jsxs)(
              "div",
              {
                className: cn(
                  "flex flex-col items-center justify-center gap-3 rounded-lg border border-white/25 bg-white/6 px-5 py-10 text-sm text-white/70 shadow-sm",
                  bodyClassName
                ),
                style: {
                  width: overlaySize,
                  height: "auto",
                  aspectRatio: "1 / 1"
                },
                children: [
                  (0, import_jsx_runtime6.jsx)("span", { className: "h-8 w-8 animate-spin rounded-full border-2 border-white/15 border-t-white/85" }),
                  (0, import_jsx_runtime6.jsx)("span", { children: loadingLabel })
                ]
              }
            ) : effectiveStatus === "ready" ? (0, import_jsx_runtime6.jsx)(
              RoomQrCode,
              {
                value: joinUrlValue,
                size,
                padding: 2,
                foregroundColor: "#111827",
                backgroundColor: "#ffffff",
                className: cn(
                  "rounded-lg border border-white/25 bg-white/6 shadow-sm",
                  qrClassName
                ),
                style: {
                  width: overlaySize,
                  height: "auto",
                  aspectRatio: "1 / 1"
                },
                alt: qrAlt ?? (roomId ? `QR code to join room ${roomId}` : "QR code to join as a controller")
              }
            ) : (0, import_jsx_runtime6.jsx)(
              "div",
              {
                className: cn(
                  "flex items-center justify-center rounded-lg border border-white/25 bg-white/6 px-5 py-10 text-sm text-white/70 shadow-sm",
                  messageClassName
                ),
                style: {
                  width: overlaySize,
                  height: "auto",
                  aspectRatio: "1 / 1"
                },
                children: unavailableLabel
              }
            ),
            (0, import_jsx_runtime6.jsx)(
              "p",
              {
                className: cn(
                  "max-w-xs text-center text-sm text-slate-400",
                  descriptionClassName
                ),
                children: description
              }
            ),
            showCloseButton ? (0, import_jsx_runtime6.jsx)(
              Button,
              {
                type: "button",
                variant: "outline",
                onClick: onClose,
                className: cn(
                  "rounded-2xl px-5",
                  shellUtilityButtonClassName,
                  closeButtonClassName
                ),
                children: "Close"
              }
            ) : null
          ]
        }
      )
    }
  );
  if (typeof document === "undefined") {
    return dialog;
  }
  return (0, import_react_dom.createPortal)(dialog, document.body);
};
var JoinUrlActionButtons = ({
  hasValue,
  copied = false,
  onCopy,
  onOpen,
  qrVisible = false,
  onToggleQr,
  className,
  buttonClassName
}) => {
  const showsQrButton = typeof onToggleQr === "function";
  return (0, import_jsx_runtime7.jsxs)(
    "div",
    {
      className: cn(
        "grid w-full gap-2",
        showsQrButton ? "grid-cols-3" : "grid-cols-2",
        className
      ),
      children: [
        (0, import_jsx_runtime7.jsxs)(
          Button,
          {
            type: "button",
            variant: "outline",
            disabled: !hasValue || !onCopy,
            onClick: onCopy,
            "aria-label": copied ? "Copied join link" : "Copy join link",
            title: copied ? "Copied" : "Copy join link",
            className: cn(
              "h-11 min-w-0 justify-center rounded-2xl px-3 text-sm",
              shellUtilityButtonClassName,
              buttonClassName
            ),
            children: [
              copied ? (0, import_jsx_runtime7.jsx)(Check, { className: "h-4 w-4", "aria-hidden": true }) : (0, import_jsx_runtime7.jsx)(Copy, { className: "h-4 w-4", "aria-hidden": true }),
              (0, import_jsx_runtime7.jsx)("span", { className: "truncate", children: copied ? "Copied" : "Copy" })
            ]
          }
        ),
        (0, import_jsx_runtime7.jsxs)(
          Button,
          {
            type: "button",
            variant: "outline",
            disabled: !hasValue || !onOpen,
            onClick: onOpen,
            "aria-label": "Open join link",
            title: "Open join link",
            className: cn(
              "h-11 min-w-0 justify-center rounded-2xl px-3 text-sm",
              shellUtilityButtonClassName,
              buttonClassName
            ),
            children: [
              (0, import_jsx_runtime7.jsx)(ExternalLink, { className: "h-4 w-4", "aria-hidden": true }),
              (0, import_jsx_runtime7.jsx)("span", { className: "truncate", children: "New tab" })
            ]
          }
        ),
        showsQrButton ? (0, import_jsx_runtime7.jsxs)(
          Button,
          {
            type: "button",
            variant: "outline",
            disabled: !hasValue,
            "aria-pressed": qrVisible,
            onClick: onToggleQr,
            "aria-label": qrVisible ? "Hide join QR" : "Show join QR",
            title: qrVisible ? "Hide join QR" : "Show join QR",
            className: cn(
              "h-11 min-w-0 justify-center rounded-2xl px-3 text-sm",
              shellUtilityButtonClassName,
              buttonClassName
            ),
            children: [
              (0, import_jsx_runtime7.jsx)(QrCode, { className: "h-4 w-4", "aria-hidden": true }),
              (0, import_jsx_runtime7.jsx)("span", { className: "truncate", children: qrVisible ? "Hide QR" : "QR code" })
            ]
          }
        ) : null
      ]
    }
  );
};
var JoinUrlField = ({
  value,
  label = "Controller link",
  helperText,
  className,
  inputClassName,
  inputId,
  inputName = "airjam-controller-link"
}) => {
  const hasValue = Boolean(value && value.trim().length > 0);
  const generatedInputId = (0, import_react4.useId)();
  const resolvedInputId = inputId ?? generatedInputId;
  return (0, import_jsx_runtime8.jsxs)("div", { className: cn("space-y-2.5", className), children: [
    (0, import_jsx_runtime8.jsx)("label", { className: shellLabelClassName, htmlFor: resolvedInputId, children: label }),
    (0, import_jsx_runtime8.jsx)(
      "input",
      {
        id: resolvedInputId,
        name: inputName,
        type: "text",
        readOnly: true,
        value: value ?? "",
        placeholder: hasValue ? void 0 : "Generating join link...",
        "aria-label": typeof label === "string" ? label : "Controller join link",
        className: cn(shellFieldClassName, inputClassName)
      }
    ),
    helperText ? (0, import_jsx_runtime8.jsx)("div", { className: shellHelperTextClassName, children: helperText }) : null
  ] });
};
var JoinUrlControls = ({
  value,
  label = "Controller link",
  helperText,
  copied = false,
  onCopy,
  onOpen,
  qrVisible = false,
  onToggleQr,
  className,
  inputClassName,
  buttonClassName
}) => {
  const hasValue = Boolean(value && value.trim().length > 0);
  return (0, import_jsx_runtime9.jsx)("div", { className: cn("w-full space-y-3", className), children: (0, import_jsx_runtime9.jsxs)("div", { className: "flex flex-col gap-3", children: [
    (0, import_jsx_runtime9.jsx)(
      JoinUrlField,
      {
        value,
        label,
        helperText,
        className: "w-full min-w-0",
        inputClassName
      }
    ),
    (0, import_jsx_runtime9.jsx)(
      JoinUrlActionButtons,
      {
        hasValue,
        copied,
        onCopy,
        onOpen,
        qrVisible,
        onToggleQr,
        className: "w-full",
        buttonClassName
      }
    )
  ] }) });
};
var useLifecycleActionGroupModel = ({
  phase,
  runtimeState,
  canInteract = true,
  onStart,
  onTogglePause,
  onBackToLobby,
  onRestart,
  startLabel = "Start",
  restartLabel = "Restart",
  backLabel = "Back to Lobby",
  pauseLabel = "Pause",
  resumeLabel = "Resume"
}) => {
  const isPaused = runtimeState === "paused";
  const actions = [];
  if (phase === "lobby" && onStart) {
    actions.push({
      kind: "start",
      label: startLabel,
      disabled: !canInteract,
      tone: "primary",
      onPress: onStart
    });
  }
  if (phase === "playing" && onTogglePause) {
    actions.push({
      kind: "pause-toggle",
      label: isPaused ? resumeLabel : pauseLabel,
      disabled: !canInteract,
      tone: "secondary",
      onPress: onTogglePause
    });
  }
  if (phase === "ended" && (onRestart || onStart)) {
    actions.push({
      kind: "restart",
      label: restartLabel,
      disabled: !canInteract,
      tone: "primary",
      onPress: onRestart ?? onStart
    });
  }
  if (phase !== "lobby" && onBackToLobby) {
    actions.push({
      kind: "back-to-lobby",
      label: backLabel,
      disabled: !canInteract,
      tone: "secondary",
      onPress: onBackToLobby
    });
  }
  return { isPaused, actions };
};
var LifecycleActionGroup = ({
  phase,
  runtimeState,
  canInteract = true,
  onStart,
  onTogglePause,
  onBackToLobby,
  onRestart,
  startLabel = "Start",
  restartLabel = "Restart",
  backLabel = "Back to Lobby",
  presentation = "pill",
  visibleKinds,
  className,
  buttonClassName
}) => {
  const { actions: allActions } = useLifecycleActionGroupModel({
    phase,
    runtimeState,
    canInteract,
    onStart,
    onTogglePause,
    onBackToLobby,
    onRestart,
    startLabel,
    restartLabel,
    backLabel
  });
  const actions = visibleKinds ? allActions.filter((action) => visibleKinds.includes(action.kind)) : allActions;
  if (actions.length === 0) {
    return null;
  }
  const renderIcon = (kind, label) => {
    switch (kind) {
      case "start":
        return (0, import_jsx_runtime10.jsx)(Play, { "aria-hidden": true, className: "size-4.5" });
      case "pause-toggle":
        return label.toLowerCase() === "resume" ? (0, import_jsx_runtime10.jsx)(Play, { "aria-hidden": true, className: "size-4.5" }) : (0, import_jsx_runtime10.jsx)(Pause, { "aria-hidden": true, className: "size-4.5" });
      case "restart":
        return (0, import_jsx_runtime10.jsx)(RotateCcw, { "aria-hidden": true, className: "size-4.5" });
      case "back-to-lobby":
        return (0, import_jsx_runtime10.jsx)(House, { "aria-hidden": true, className: "size-4.5" });
    }
  };
  return (0, import_jsx_runtime10.jsx)(
    "div",
    {
      className: cn(
        "flex min-w-0 flex-nowrap items-center justify-end gap-1.5 overflow-x-auto",
        className
      ),
      children: actions.map((action) => (0, import_jsx_runtime10.jsx)(
        Button,
        {
          type: "button",
          variant: presentation === "icon" ? action.tone === "primary" ? "secondary" : "ghost" : action.tone === "primary" ? "default" : "outline",
          size: presentation === "icon" ? "icon-sm" : void 0,
          onClick: action.onPress,
          disabled: action.disabled,
          "aria-label": action.label,
          title: action.label,
          className: cn(
            presentation === "icon" ? action.tone === "primary" ? "size-9 shrink-0 rounded-full border border-white/20 bg-white text-black hover:bg-white/90 sm:size-10" : "size-9 shrink-0 rounded-full border border-white/12 bg-white/6 text-white hover:bg-white/12 sm:size-10" : action.tone === "primary" ? "h-8 shrink-0 rounded-full border border-white/15 bg-white px-3 py-0 text-[9px] font-semibold tracking-[0.12em] whitespace-nowrap text-black uppercase hover:bg-white/90 sm:h-9 sm:px-4 sm:text-[10px] sm:tracking-[0.16em]" : "h-8 shrink-0 rounded-full border-white/15 bg-white/5 px-3 py-0 text-[9px] font-semibold tracking-[0.12em] whitespace-nowrap text-white uppercase hover:bg-white/10 sm:h-9 sm:px-4 sm:text-[10px] sm:tracking-[0.16em]",
            buttonClassName
          ),
          children: presentation === "icon" ? renderIcon(action.kind, action.label) : action.label
        },
        action.kind
      ))
    }
  );
};
var DIEBEAR_ADVENTURER_NEUTRAL_SVG_BASE = "https://api.dicebear.com/9.x/adventurer-neutral/svg";
var AIRJAM_DEFAULT_AVATAR_SEEDS = [
  "Aiko",
  "Brayden",
  "Caleb",
  "Dylan",
  "Emery",
  "Finley",
  "Grayson",
  "Harper"
];
var resolvePlayerAvatarSeed = (player) => {
  var _a;
  const raw = (_a = player.avatarId) == null ? void 0 : _a.trim();
  if (!raw) {
    return player.id;
  }
  const match = /^aj-(\d+)$/.exec(raw);
  if (match) {
    const index = Number(match[1]) - 1;
    if (index >= 0 && index < AIRJAM_DEFAULT_AVATAR_SEEDS.length) {
      return AIRJAM_DEFAULT_AVATAR_SEEDS[index];
    }
  }
  return raw;
};
var getDiceBearAdventurerNeutralUrl = (seed) => `${DIEBEAR_ADVENTURER_NEUTRAL_SVG_BASE}?seed=${encodeURIComponent(seed)}`;
var getPlayerAvatarImageUrl = (player) => getDiceBearAdventurerNeutralUrl(resolvePlayerAvatarSeed(player));
var hexToRgba = (hex, opacity) => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return `rgba(0, 0, 0, ${opacity})`;
  const r = parseInt(result[1], 16);
  const g = parseInt(result[2], 16);
  const b = parseInt(result[3], 16);
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
};
var PlayerAvatar = ({
  player,
  isBot = false,
  size = "md",
  className = ""
}) => {
  const accentColor = player.color || "hsl(var(--border))";
  const sizeClasses = {
    sm: "h-9 w-9 border-2",
    md: "h-12 w-12 border-4",
    lg: "h-16 w-16 border-4"
  };
  const shadowStyles = {
    sm: player.color ? `inset 0 0 4px rgba(0, 0, 0, 0.2), 0 0 8px ${hexToRgba(player.color, 0.4)}` : "inset 0 0 4px rgba(0, 0, 0, 0.2)",
    md: player.color ? `inset 0 0 10px rgba(0, 0, 0, 0.4), 0 0 20px ${hexToRgba(player.color, 0.6)}, 0 0 10px ${hexToRgba(player.color, 0.8)}` : "inset 0 0 10px rgba(0, 0, 0, 0.4), 0 0 20px hsl(var(--border) / 0.5)",
    lg: player.color ? `inset 0 0 12px rgba(0, 0, 0, 0.4), 0 0 24px ${hexToRgba(player.color, 0.6)}, 0 0 12px ${hexToRgba(player.color, 0.8)}` : "inset 0 0 12px rgba(0, 0, 0, 0.4), 0 0 24px hsl(var(--border) / 0.5)"
  };
  const iconSizeClasses = {
    sm: "h-4 w-4",
    md: "h-5 w-5",
    lg: "h-6 w-6"
  };
  const shellClassName = cn(
    "shrink-0 rounded-full shadow-lg",
    sizeClasses[size],
    className
  );
  if (isBot) {
    return (0, import_jsx_runtime11.jsx)(
      "div",
      {
        role: "img",
        "aria-label": player.label,
        className: cn(
          "bg-secondary/40 flex items-center justify-center",
          shellClassName
        ),
        style: {
          borderColor: accentColor,
          color: accentColor,
          boxShadow: shadowStyles[size]
        },
        children: (0, import_jsx_runtime11.jsx)(Bot, { "aria-hidden": "true", className: iconSizeClasses[size] })
      }
    );
  }
  return (0, import_jsx_runtime11.jsx)(
    "img",
    {
      src: getPlayerAvatarImageUrl(player),
      alt: player.label,
      className: cn("bg-secondary/30", shellClassName),
      style: {
        borderColor: accentColor,
        boxShadow: shadowStyles[size]
      }
    }
  );
};
var overflowSizeClasses = {
  sm: "h-9 w-9 min-h-9 min-w-9 text-[0.625rem]",
  md: "h-12 w-12 min-h-12 min-w-12 text-[11px]",
  lg: "h-16 w-16 min-h-16 min-w-16 text-xs"
};
var PlayerAvatarStrip = ({
  players,
  maxVisible = 4,
  size = "sm",
  className,
  avatarClassName = "",
  overflowBadgeClassName = ""
}) => {
  const visible = players.slice(0, maxVisible);
  const overflow = Math.max(0, players.length - maxVisible);
  return (0, import_jsx_runtime12.jsxs)("div", { className: cn("flex items-center -space-x-2", className), children: [
    visible.map((player) => (0, import_jsx_runtime12.jsx)(
      PlayerAvatar,
      {
        player,
        size,
        className: avatarClassName
      },
      player.id
    )),
    overflow > 0 && (0, import_jsx_runtime12.jsxs)(
      "div",
      {
        className: cn(
          "bg-secondary/50 text-foreground flex shrink-0 items-center justify-center rounded-full border-2 border-[hsl(var(--border))] font-semibold tabular-nums shadow-sm",
          overflowSizeClasses[size],
          overflowBadgeClassName
        ),
        "aria-label": `${overflow} more players`,
        children: [
          "+",
          overflow
        ]
      }
    )
  ] });
};
var RuntimeShellHeader = ({
  connectionStatus,
  leftSlot,
  rightSlot,
  className
}) => {
  return (0, import_jsx_runtime13.jsxs)(
    "header",
    {
      className: cn(
        "flex min-h-16 items-center gap-2.5 px-3 py-2.5 sm:px-4",
        shellHeaderClassName,
        className
      ),
      children: [
        (0, import_jsx_runtime13.jsx)("div", { className: "min-w-0 flex-1", children: leftSlot }),
        (0, import_jsx_runtime13.jsxs)("div", { className: "flex shrink-0 items-center gap-2.5", children: [
          (0, import_jsx_runtime13.jsx)(ConnectionStatusPill, { status: connectionStatus }),
          rightSlot ? (0, import_jsx_runtime13.jsx)("div", { className: "flex items-center justify-end", children: rightSlot }) : null
        ] })
      ]
    }
  );
};
var publishEmbeddedControllerPresentation = (orientation) => {
  if (typeof window === "undefined" || window.parent === window) {
    return;
  }
  const runtimeParams = readEmbeddedControllerRuntimeParams();
  if (!runtimeParams) {
    return;
  }
  window.parent.postMessage(
    createControllerPresentationSyncMessage({
      orientation,
      arcadeSurface: runtimeParams.arcadeSurface
    }),
    runtimeParams.topology.embedParentOrigin ?? "*"
  );
};
var AIRJAM_SAFE_AREA_TOP = "env(safe-area-inset-top, 0px)";
var AIRJAM_SAFE_AREA_RIGHT = "env(safe-area-inset-right, 0px)";
var AIRJAM_SAFE_AREA_BOTTOM = "env(safe-area-inset-bottom, 0px)";
var AIRJAM_SAFE_AREA_LEFT = "env(safe-area-inset-left, 0px)";
var AIRJAM_SAFE_VIEWPORT_WIDTH = `calc(100dvw - ${AIRJAM_SAFE_AREA_LEFT} - ${AIRJAM_SAFE_AREA_RIGHT})`;
var AIRJAM_SAFE_VIEWPORT_HEIGHT = `calc(100dvh - ${AIRJAM_SAFE_AREA_TOP} - ${AIRJAM_SAFE_AREA_BOTTOM})`;
var createSurfaceViewportOuterStyle = () => ({
  ["--airjam-safe-area-top"]: AIRJAM_SAFE_AREA_TOP,
  ["--airjam-safe-area-right"]: AIRJAM_SAFE_AREA_RIGHT,
  ["--airjam-safe-area-bottom"]: AIRJAM_SAFE_AREA_BOTTOM,
  ["--airjam-safe-area-left"]: AIRJAM_SAFE_AREA_LEFT,
  ["--airjam-safe-viewport-width"]: AIRJAM_SAFE_VIEWPORT_WIDTH,
  ["--airjam-safe-viewport-height"]: AIRJAM_SAFE_VIEWPORT_HEIGHT
});
var resolveForcedOrientationFrameStyle = (desired, needsRotation) => {
  if (!needsRotation) {
    return {
      position: "absolute",
      top: AIRJAM_SAFE_AREA_TOP,
      left: AIRJAM_SAFE_AREA_LEFT,
      width: AIRJAM_SAFE_VIEWPORT_WIDTH,
      height: AIRJAM_SAFE_VIEWPORT_HEIGHT,
      overflow: "hidden"
    };
  }
  if (desired === "landscape") {
    return {
      position: "absolute",
      top: AIRJAM_SAFE_AREA_TOP,
      left: AIRJAM_SAFE_AREA_LEFT,
      width: AIRJAM_SAFE_VIEWPORT_HEIGHT,
      height: AIRJAM_SAFE_VIEWPORT_WIDTH,
      overflow: "hidden",
      transformOrigin: "top left",
      transform: `translateX(${AIRJAM_SAFE_VIEWPORT_WIDTH}) rotate(90deg)`
    };
  }
  return {
    position: "absolute",
    top: AIRJAM_SAFE_AREA_TOP,
    left: AIRJAM_SAFE_AREA_LEFT,
    width: AIRJAM_SAFE_VIEWPORT_HEIGHT,
    height: AIRJAM_SAFE_VIEWPORT_WIDTH,
    overflow: "hidden",
    transformOrigin: "top left",
    transform: `translateY(${AIRJAM_SAFE_VIEWPORT_HEIGHT}) rotate(-90deg)`
  };
};
var CONTROLLER_REFERENCE_SIZE = {
  portrait: {
    width: 412,
    height: 915
  },
  landscape: {
    width: 915,
    height: 412
  }
};
var HOST_REFERENCE_SIZE = {
  portrait: {
    width: 900,
    height: 1600
  },
  landscape: {
    width: 1600,
    height: 900
  }
};
var resolveSurfaceViewportScopeReferenceSize = (sessionScope) => {
  if (sessionScope === "controller") {
    return CONTROLLER_REFERENCE_SIZE;
  }
  if (sessionScope === "host") {
    return HOST_REFERENCE_SIZE;
  }
  return null;
};
var resolveSurfaceViewportReferenceSize = ({
  sessionScope,
  designWidth,
  designHeight,
  orientation,
  availableWidth,
  availableHeight
}) => {
  if (typeof designWidth === "number" && Number.isFinite(designWidth) && designWidth > 0 && typeof designHeight === "number" && Number.isFinite(designHeight) && designHeight > 0) {
    return {
      width: designWidth,
      height: designHeight
    };
  }
  const scopedReferenceSize = resolveSurfaceViewportScopeReferenceSize(sessionScope);
  if (scopedReferenceSize) {
    return scopedReferenceSize[orientation];
  }
  return {
    width: Math.max(availableWidth, 1),
    height: Math.max(availableHeight, 1)
  };
};
var SURFACE_VIEWPORT_TEXT_SIZE_BASES = {
  xs: "0.75rem",
  sm: "0.875rem",
  base: "1rem",
  lg: "1.125rem",
  xl: "1.25rem",
  "2xl": "1.5rem",
  "3xl": "1.875rem",
  "4xl": "2.25rem",
  "5xl": "3rem",
  "6xl": "3.75rem",
  "7xl": "4.5rem",
  "8xl": "6rem",
  "9xl": "8rem"
};
var SURFACE_VIEWPORT_CONTAINER_BASES = {
  "3xs": "16rem",
  "2xs": "18rem",
  xs: "20rem",
  sm: "24rem",
  md: "28rem",
  lg: "32rem",
  xl: "36rem",
  "2xl": "42rem",
  "3xl": "48rem",
  "4xl": "56rem",
  "5xl": "64rem",
  "6xl": "72rem",
  "7xl": "80rem"
};
var SURFACE_VIEWPORT_RADIUS_BASES = {
  xs: "0.125rem",
  sm: "0.375rem",
  md: "0.5rem",
  lg: "0.625rem",
  xl: "0.875rem",
  "2xl": "1rem",
  "3xl": "1.5rem",
  "4xl": "2rem"
};
var resolveSurfaceViewportAvailableSize = ({
  safeViewportWidth,
  safeViewportHeight,
  orientation,
  needsRotation
}) => {
  if (!orientation || !needsRotation) {
    return {
      width: safeViewportWidth,
      height: safeViewportHeight
    };
  }
  return {
    width: safeViewportHeight,
    height: safeViewportWidth
  };
};
var resolveSurfaceViewportScale = ({
  availableWidth,
  availableHeight,
  referenceWidth,
  referenceHeight,
  scaleMode = "fit",
  uiScaleMultiplier = 1,
  minScale,
  maxScale
}) => {
  const safeAvailableWidth = Math.max(availableWidth, 1);
  const safeAvailableHeight = Math.max(availableHeight, 1);
  const safeReferenceWidth = Math.max(referenceWidth, 1);
  const safeReferenceHeight = Math.max(referenceHeight, 1);
  const widthScale = safeAvailableWidth / safeReferenceWidth;
  const heightScale = safeAvailableHeight / safeReferenceHeight;
  const baseScale = scaleMode === "width" ? widthScale : scaleMode === "height" ? heightScale : Math.min(widthScale, heightScale);
  let scale = baseScale * uiScaleMultiplier;
  if (typeof minScale === "number" && Number.isFinite(minScale)) {
    scale = Math.max(scale, minScale);
  }
  if (typeof maxScale === "number" && Number.isFinite(maxScale)) {
    scale = Math.min(scale, maxScale);
  }
  return scale;
};
var createScaledVariableValue = (baseValue) => `calc(${baseValue} * var(--airjam-ui-scale))`;
var createSurfaceViewportScaleStyle = ({
  scale,
  referenceWidth,
  referenceHeight
}) => {
  const style = {
    position: "relative",
    width: "100%",
    height: "100%",
    overflow: "hidden",
    fontSize: createScaledVariableValue("1rem"),
    "--airjam-ui-scale": String(scale),
    "--airjam-ui-rem": createScaledVariableValue("1rem"),
    "--airjam-reference-width": `${referenceWidth}px`,
    "--airjam-reference-height": `${referenceHeight}px`,
    "--spacing": createScaledVariableValue("0.25rem"),
    "--radius": createScaledVariableValue("0.625rem")
  };
  for (const [name, baseValue] of Object.entries(
    SURFACE_VIEWPORT_TEXT_SIZE_BASES
  )) {
    style[`--text-${name}`] = createScaledVariableValue(baseValue);
  }
  for (const [name, baseValue] of Object.entries(
    SURFACE_VIEWPORT_CONTAINER_BASES
  )) {
    style[`--container-${name}`] = createScaledVariableValue(baseValue);
  }
  for (const [name, baseValue] of Object.entries(
    SURFACE_VIEWPORT_RADIUS_BASES
  )) {
    style[`--radius-${name}`] = createScaledVariableValue(baseValue);
  }
  return style;
};
var readLayoutViewportSize = () => {
  if (typeof window === "undefined") {
    return { width: 0, height: 0 };
  }
  return {
    width: window.innerWidth,
    height: window.innerHeight
  };
};
var isTextEntryElement = (element) => {
  if (!element) {
    return false;
  }
  if (element instanceof HTMLTextAreaElement) {
    return true;
  }
  if (element instanceof HTMLInputElement) {
    return ![
      "button",
      "checkbox",
      "color",
      "file",
      "hidden",
      "image",
      "radio",
      "range",
      "reset",
      "submit"
    ].includes(element.type);
  }
  return element instanceof HTMLElement && element.isContentEditable;
};
var isKeyboardResize = (previous, next) => {
  if (!previous || typeof document === "undefined") {
    return false;
  }
  if (!isTextEntryElement(document.activeElement)) {
    return false;
  }
  const sameWidth = Math.abs(previous.width - next.width) <= 2;
  const heightShrank = next.height < previous.height;
  return sameWidth && heightShrank;
};
var getOrientation = ({
  width,
  height
}) => {
  var _a, _b;
  if (typeof window !== "undefined") {
    if (window.matchMedia) {
      if (window.matchMedia("(orientation: portrait)").matches) {
        return "portrait";
      }
      if (window.matchMedia("(orientation: landscape)").matches) {
        return "landscape";
      }
    }
    if ((_b = (_a = window.screen) == null ? void 0 : _a.orientation) == null ? void 0 : _b.type) {
      if (window.screen.orientation.type.startsWith("portrait")) {
        return "portrait";
      }
      if (window.screen.orientation.type.startsWith("landscape")) {
        return "landscape";
      }
    }
  }
  if (width > 0 && height > 0) {
    return width >= height ? "landscape" : "portrait";
  }
  return width >= height ? "landscape" : "portrait";
};
var SurfaceViewport = ({
  children,
  orientation,
  lockOnGesture = true,
  className,
  contentClassName,
  style,
  designWidth,
  designHeight,
  uiScaleMultiplier,
  minScale,
  maxScale
}) => {
  const [viewport, setViewport] = (0, import_react5.useState)(null);
  const viewportRef = (0, import_react5.useRef)(null);
  const sessionScope = useSessionScope();
  (0, import_react5.useEffect)(() => {
    var _a;
    if (typeof window === "undefined") {
      return;
    }
    const updateViewport = () => {
      const nextViewport = readLayoutViewportSize();
      if (isKeyboardResize(viewportRef.current, nextViewport)) {
        return;
      }
      viewportRef.current = nextViewport;
      setViewport(nextViewport);
    };
    updateViewport();
    window.addEventListener("resize", updateViewport);
    (_a = window.visualViewport) == null ? void 0 : _a.addEventListener("resize", updateViewport);
    window.addEventListener("orientationchange", updateViewport);
    return () => {
      var _a2;
      window.removeEventListener("resize", updateViewport);
      (_a2 = window.visualViewport) == null ? void 0 : _a2.removeEventListener("resize", updateViewport);
      window.removeEventListener("orientationchange", updateViewport);
    };
  }, []);
  (0, import_react5.useEffect)(() => {
    if (typeof window === "undefined" || !orientation || !lockOnGesture) {
      return;
    }
    const tryLock = () => {
      if (!("orientation" in screen)) {
        return;
      }
      const screenOrientation = screen.orientation;
      if (!(screenOrientation == null ? void 0 : screenOrientation.lock)) {
        return;
      }
      void screenOrientation.lock(orientation).catch(() => {
      });
    };
    const onFirstGesture = () => {
      tryLock();
      window.removeEventListener("pointerdown", onFirstGesture, true);
    };
    window.addEventListener("pointerdown", onFirstGesture, true);
    return () => {
      window.removeEventListener("pointerdown", onFirstGesture, true);
    };
  }, [orientation, lockOnGesture]);
  (0, import_react5.useEffect)(() => {
    if (!orientation || sessionScope !== "controller") {
      return;
    }
    publishEmbeddedControllerPresentation(orientation);
  }, [orientation, sessionScope]);
  const currentOrientation = viewport ? getOrientation(viewport) : "portrait";
  const effectiveOrientation = orientation ?? currentOrientation;
  const needsRotation = orientation ? currentOrientation !== orientation : false;
  const shellStyle = (0, import_react5.useMemo)(
    () => orientation ? resolveForcedOrientationFrameStyle(orientation, needsRotation) : resolveForcedOrientationFrameStyle(effectiveOrientation, false),
    [effectiveOrientation, needsRotation, orientation]
  );
  const availableSize = (0, import_react5.useMemo)(
    () => resolveSurfaceViewportAvailableSize({
      safeViewportWidth: (viewport == null ? void 0 : viewport.width) ?? 0,
      safeViewportHeight: (viewport == null ? void 0 : viewport.height) ?? 0,
      orientation,
      needsRotation
    }),
    [needsRotation, orientation, viewport]
  );
  const referenceSize = (0, import_react5.useMemo)(
    () => resolveSurfaceViewportReferenceSize({
      sessionScope,
      designWidth,
      designHeight,
      orientation: effectiveOrientation,
      availableWidth: availableSize.width,
      availableHeight: availableSize.height
    }),
    [
      availableSize.height,
      availableSize.width,
      designHeight,
      designWidth,
      effectiveOrientation,
      sessionScope
    ]
  );
  const scale = (0, import_react5.useMemo)(() => {
    const scaleMode = sessionScope === "controller" ? effectiveOrientation === "portrait" ? "width" : "height" : "fit";
    return resolveSurfaceViewportScale({
      availableWidth: availableSize.width,
      availableHeight: availableSize.height,
      referenceWidth: referenceSize.width,
      referenceHeight: referenceSize.height,
      scaleMode,
      uiScaleMultiplier,
      minScale,
      maxScale
    });
  }, [
    availableSize.height,
    availableSize.width,
    effectiveOrientation,
    maxScale,
    minScale,
    referenceSize.height,
    referenceSize.width,
    sessionScope,
    uiScaleMultiplier
  ]);
  return (0, import_jsx_runtime14.jsx)(
    "div",
    {
      className: cn("fixed inset-0 overflow-hidden", className),
      style: {
        ...createSurfaceViewportOuterStyle(),
        ...style
      },
      children: (0, import_jsx_runtime14.jsx)("div", { style: shellStyle, children: (0, import_jsx_runtime14.jsx)(
        "div",
        {
          className: cn("h-full w-full overflow-hidden", contentClassName),
          "data-airjam-surface-viewport": "true",
          style: createSurfaceViewportScaleStyle({
            scale,
            referenceWidth: referenceSize.width,
            referenceHeight: referenceSize.height
          }),
          children: (0, import_jsx_runtime14.jsx)("div", { className: "h-full w-full", "data-airjam-surface-root": "true", children })
        }
      ) })
    }
  );
};
function VolumeControls(props) {
  if (props.values) {
    return (0, import_jsx_runtime15.jsx)(ControlledVolumeControls, { ...props });
  }
  return (0, import_jsx_runtime15.jsx)(OwnedVolumeControls, { ...props });
}
function OwnedVolumeControls({ className, compact }) {
  const {
    masterVolume,
    musicVolume,
    sfxVolume,
    setMasterVolume,
    setMusicVolume,
    setSfxVolume
  } = usePlatformAudioSettings();
  return (0, import_jsx_runtime15.jsx)(
    ControlledVolumeControls,
    {
      className,
      compact,
      values: { masterVolume, musicVolume, sfxVolume },
      onMasterVolumeChange: setMasterVolume,
      onMusicVolumeChange: setMusicVolume,
      onSfxVolumeChange: setSfxVolume,
      readOnly: false
    }
  );
}
function ControlledVolumeControls({
  className,
  compact,
  values,
  readOnly = false,
  onMasterVolumeChange,
  onMusicVolumeChange,
  onSfxVolumeChange
}) {
  if (!values) {
    throw new Error("ControlledVolumeControls requires values");
  }
  const { masterVolume, musicVolume, sfxVolume } = values;
  return (0, import_jsx_runtime15.jsxs)("div", { className: cn("flex flex-col gap-3", compact && "gap-1", className), children: [
    (0, import_jsx_runtime15.jsxs)("div", { className: "flex items-center gap-2", children: [
      (0, import_jsx_runtime15.jsx)(Volume2, { className: "text-muted-foreground h-4 w-4" }),
      (0, import_jsx_runtime15.jsx)("span", { className: "text-sm font-medium", children: "Volume" })
    ] }),
    (0, import_jsx_runtime15.jsxs)("div", { className: "space-y-1.5", children: [
      (0, import_jsx_runtime15.jsxs)("div", { className: "flex items-center justify-between", children: [
        (0, import_jsx_runtime15.jsx)("label", { className: "text-muted-foreground text-xs", children: "Master" }),
        (0, import_jsx_runtime15.jsxs)("span", { className: "text-muted-foreground font-mono text-xs", children: [
          Math.round(masterVolume * 100),
          "%"
        ] })
      ] }),
      (0, import_jsx_runtime15.jsx)(
        Slider,
        {
          "data-testid": "platform-settings-master-volume",
          value: [masterVolume * 100],
          onValueChange: (sliderValues) => onMasterVolumeChange == null ? void 0 : onMasterVolumeChange(sliderValues[0] / 100),
          min: 0,
          max: 100,
          step: 1,
          className: "w-full",
          "aria-label": "Master volume",
          disabled: readOnly
        }
      )
    ] }),
    (0, import_jsx_runtime15.jsxs)("div", { className: "space-y-1.5", children: [
      (0, import_jsx_runtime15.jsxs)("div", { className: "flex items-center justify-between", children: [
        (0, import_jsx_runtime15.jsxs)("div", { className: "flex items-center gap-1.5", children: [
          (0, import_jsx_runtime15.jsx)(Music, { className: "text-muted-foreground h-3 w-3" }),
          (0, import_jsx_runtime15.jsx)("label", { className: "text-muted-foreground text-xs", children: "Music" })
        ] }),
        (0, import_jsx_runtime15.jsxs)("span", { className: "text-muted-foreground font-mono text-xs", children: [
          Math.round(musicVolume * 100),
          "%"
        ] })
      ] }),
      (0, import_jsx_runtime15.jsx)(
        Slider,
        {
          "data-testid": "platform-settings-music-volume",
          value: [musicVolume * 100],
          onValueChange: (sliderValues) => onMusicVolumeChange == null ? void 0 : onMusicVolumeChange(sliderValues[0] / 100),
          min: 0,
          max: 100,
          step: 1,
          className: "w-full",
          "aria-label": "Music volume",
          disabled: readOnly
        }
      )
    ] }),
    (0, import_jsx_runtime15.jsxs)("div", { className: "space-y-1.5", children: [
      (0, import_jsx_runtime15.jsxs)("div", { className: "flex items-center justify-between", children: [
        (0, import_jsx_runtime15.jsxs)("div", { className: "flex items-center gap-1.5", children: [
          (0, import_jsx_runtime15.jsx)(Headphones, { className: "text-muted-foreground h-3 w-3" }),
          (0, import_jsx_runtime15.jsx)("label", { className: "text-muted-foreground text-xs", children: "SFX" })
        ] }),
        (0, import_jsx_runtime15.jsxs)("span", { className: "text-muted-foreground font-mono text-xs", children: [
          Math.round(sfxVolume * 100),
          "%"
        ] })
      ] }),
      (0, import_jsx_runtime15.jsx)(
        Slider,
        {
          "data-testid": "platform-settings-sfx-volume",
          value: [sfxVolume * 100],
          onValueChange: (sliderValues) => onSfxVolumeChange == null ? void 0 : onSfxVolumeChange(sliderValues[0] / 100),
          min: 0,
          max: 100,
          step: 1,
          className: "w-full",
          "aria-label": "SFX volume",
          disabled: readOnly
        }
      )
    ] })
  ] });
}
var useControllerLifecycleIntents = ({
  onStart,
  onTogglePause,
  onBackToLobby,
  onRestart
}) => {
  return {
    onStart,
    onTogglePause,
    onBackToLobby,
    onRestart
  };
};
var useControllerLifecyclePermissions = ({
  phase,
  canStartMatch = false,
  canSendSystemCommand = false
}) => {
  const canStart = phase === "lobby" && canStartMatch;
  const canPauseToggle = phase === "playing" && canSendSystemCommand;
  const canRestart = phase === "ended" && canSendSystemCommand;
  const canBackToLobby = phase !== "lobby" && canSendSystemCommand;
  const canInteractForPhase = phase === "lobby" ? canStart : canSendSystemCommand;
  return {
    canStart,
    canPauseToggle,
    canRestart,
    canBackToLobby,
    canInteractForPhase
  };
};
var useControllerShellStatus = ({
  roomId,
  connectionStatus,
  playerLabel,
  fallbackLabel = "Controller",
  roomFallback = "----"
}) => {
  const trimmedLabel = (playerLabel == null ? void 0 : playerLabel.trim()) ?? "";
  const displayName = trimmedLabel || fallbackLabel;
  const roomDisplay = roomId ?? roomFallback;
  const identityInitial = displayName.charAt(0).toUpperCase() || "M";
  return {
    connectionStatus,
    displayName,
    roomDisplay,
    roomLine: `Room ${roomDisplay}`,
    hasIdentity: trimmedLabel.length > 0,
    identityInitial
  };
};
var copyTextToClipboard = async (text) => {
  if (!text) {
    return false;
  }
  try {
    if (typeof navigator !== "undefined" && navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
  }
  if (typeof document === "undefined") {
    return false;
  }
  const fallbackField = document.createElement("textarea");
  fallbackField.value = text;
  fallbackField.style.position = "fixed";
  fallbackField.style.opacity = "0";
  document.body.appendChild(fallbackField);
  fallbackField.select();
  try {
    return document.execCommand("copy");
  } catch {
    return false;
  } finally {
    document.body.removeChild(fallbackField);
  }
};
var useHostJoinControls = ({
  joinUrl,
  canStartMatch = false,
  onStartMatch,
  copiedDurationMs = 1800
}) => {
  const [copied, setCopied] = (0, import_react6.useState)(false);
  const [joinQrVisible, setJoinQrVisible] = (0, import_react6.useState)(false);
  const resetTimerRef = (0, import_react6.useRef)(null);
  const joinUrlValue = (0, import_react6.useMemo)(() => joinUrl ?? "", [joinUrl]);
  const hasJoinUrl = joinUrlValue.length > 0;
  (0, import_react6.useEffect)(() => {
    if (!hasJoinUrl) {
      setJoinQrVisible(false);
    }
  }, [hasJoinUrl]);
  const handleCopy = (0, import_react6.useCallback)(async () => {
    if (!joinUrlValue) {
      return;
    }
    const copiedSuccessfully = await copyTextToClipboard(joinUrlValue);
    if (!copiedSuccessfully || typeof window === "undefined") {
      return;
    }
    setCopied(true);
    if (resetTimerRef.current !== null) {
      window.clearTimeout(resetTimerRef.current);
    }
    resetTimerRef.current = window.setTimeout(() => {
      setCopied(false);
      resetTimerRef.current = null;
    }, copiedDurationMs);
  }, [copiedDurationMs, joinUrlValue]);
  const handleOpen = (0, import_react6.useCallback)(() => {
    if (!joinUrlValue || typeof window === "undefined") {
      return;
    }
    window.open(joinUrlValue, "_blank", "noopener,noreferrer");
  }, [joinUrlValue]);
  const showJoinQr = (0, import_react6.useCallback)(() => {
    if (!hasJoinUrl) {
      return;
    }
    setJoinQrVisible(true);
  }, [hasJoinUrl]);
  const hideJoinQr = (0, import_react6.useCallback)(() => {
    setJoinQrVisible(false);
  }, []);
  const toggleJoinQr = (0, import_react6.useCallback)(() => {
    if (!hasJoinUrl) {
      return;
    }
    setJoinQrVisible((current) => !current);
  }, [hasJoinUrl]);
  const handleStart = (0, import_react6.useCallback)(() => {
    if (!canStartMatch) {
      return;
    }
    onStartMatch == null ? void 0 : onStartMatch();
  }, [canStartMatch, onStartMatch]);
  return {
    joinUrlValue,
    hasJoinUrl,
    copied,
    joinQrVisible,
    canStartMatch,
    handleCopy,
    handleOpen,
    showJoinQr,
    hideJoinQr,
    toggleJoinQr,
    handleStart
  };
};
export {
  AIRJAM_DEFAULT_AVATAR_SEEDS,
  Button,
  ConnectionStatusPill,
  ControllerPlayerNameField,
  ControllerPrimaryAction,
  HostMuteButton,
  JoinQrOverlay,
  JoinUrlActionButtons,
  JoinUrlControls,
  JoinUrlField,
  LifecycleActionGroup,
  PlayerAvatar,
  PlayerAvatarStrip,
  RoomQrCode,
  RuntimeShellHeader,
  Slider,
  SurfaceViewport,
  VolumeControls,
  buttonVariants,
  getDiceBearAdventurerNeutralUrl,
  getPlayerAvatarImageUrl,
  resolvePlayerAvatarSeed,
  useControllerLifecycleIntents,
  useControllerLifecyclePermissions,
  useControllerShellStatus,
  useHostJoinControls,
  useLifecycleActionGroupModel
};
//# sourceMappingURL=@air-jam_sdk_ui.js.map
