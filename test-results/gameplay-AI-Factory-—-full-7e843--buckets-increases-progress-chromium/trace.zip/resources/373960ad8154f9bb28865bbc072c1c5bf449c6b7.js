import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/host/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c74894a2"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/AiFactory/src/host/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { useAirJamHost, useHostTick } from "/node_modules/.vite/deps/@air-jam_sdk.js?v=c74894a2";
import { HostPreviewControllerWorkspace } from "/node_modules/.vite/deps/@air-jam_sdk_preview.js?v=c74894a2";
import { RoomQrCode, SurfaceViewport } from "/node_modules/.vite/deps/@air-jam_sdk_ui.js?v=c74894a2";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=c74894a2"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useRef = __vite__cjsImport6_react["useRef"]; const useState = __vite__cjsImport6_react["useState"];
import {
  ALL_ROLES,
  ROLE_COLORS,
  ROLE_ICONS,
  ROLE_LABELS,
  ROLE_MINI_GAME
} from "/src/game/domain/types.ts";
import { GAME_CONFIG } from "/src/game/config/gameConfig.ts";
import { useFactoryStore } from "/src/game/store/factoryStore.ts";
function formatTime(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}
function healthColor(health) {
  if (health >= 70) return "#4ade80";
  if (health >= 50) return "#fb923c";
  return "#f87171";
}
function statusColor(status) {
  const map = {
    inactive: "#4b5563",
    working: "#60a5fa",
    stable: "#34d399",
    complete: "#4ade80",
    warning: "#fb923c",
    critical: "#f87171",
    failed: "#ef4444"
  };
  return map[status] ?? "#64748b";
}
function AmbientParticles() {
  const particles = Array.from({ length: 18 }, (_, i) => ({
    id: i,
    left: `${5 + i * 5.5 % 90}%`,
    bottom: `${i * 13 % 40}%`,
    duration: `${3 + i * 0.7 % 4}s`,
    delay: `${i * 0.4 % 3}s`,
    size: i % 3 === 0 ? 6 : i % 3 === 1 ? 4 : 3,
    color: i % 5 === 0 ? "rgba(250,204,21,0.6)" : i % 5 === 1 ? "rgba(192,132,252,0.5)" : i % 5 === 2 ? "rgba(52,211,153,0.5)" : "rgba(56,189,248,0.6)"
  }));
  return /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }, children: particles.map(
    (p) => /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "idle-particle",
        style: {
          left: p.left,
          bottom: p.bottom,
          width: p.size,
          height: p.size,
          background: p.color,
          animationDuration: p.duration,
          animationDelay: p.delay
        }
      },
      p.id,
      false,
      {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 90,
        columnNumber: 7
      },
      this
    )
  ) }, void 0, false, {
    fileName: "D:/AiFactory/src/host/index.tsx",
    lineNumber: 88,
    columnNumber: 5
  }, this);
}
_c = AmbientParticles;
function EventBanner({ message }) {
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "event-banner-enter",
      style: {
        position: "relative",
        width: "100%",
        padding: "10px 20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        overflow: "hidden",
        animation: "warningPulse 1s ease-in-out infinite",
        borderTop: "2px solid rgba(251,146,60,0.6)",
        borderBottom: "2px solid rgba(251,146,60,0.6)",
        background: "repeating-linear-gradient(45deg, rgba(251,146,60,0.08) 0px, rgba(251,146,60,0.08) 12px, transparent 12px, transparent 24px)"
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              position: "absolute",
              inset: 0,
              background: "linear-gradient(90deg, transparent 0%, rgba(251,146,60,0.12) 50%, transparent 100%)",
              animation: "threatScan 2s linear infinite",
              pointerEvents: "none"
            }
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 135,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 20, zIndex: 1 }, children: "🚨" }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 144,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "span",
          {
            style: {
              fontSize: 14,
              fontWeight: 900,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              color: "#fb923c",
              zIndex: 1,
              textShadow: "0 0 12px rgba(251,146,60,0.7)"
            },
            children: message
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 145,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 20, zIndex: 1 }, children: "🚨" }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 158,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 116,
      columnNumber: 5
    },
    this
  );
}
_c2 = EventBanner;
function AICore({ health, allComplete, temperature }) {
  const coreColor = allComplete ? "#4ade80" : healthColor(health);
  const animation = allComplete ? "aiCoreVictory 2s ease-in-out infinite" : "aiCorePulse 3s ease-in-out infinite";
  return /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }, children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: {
          position: "relative",
          width: 160,
          height: 160,
          borderRadius: "50%",
          border: `3px solid ${coreColor}60`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          animation
        },
        children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                width: 120,
                height: 120,
                borderRadius: "50%",
                background: `radial-gradient(circle at 35% 35%, ${coreColor}30, ${coreColor}08)`,
                border: `2px solid ${coreColor}80`,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2
              },
              children: [
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 36 }, children: "🤖" }, void 0, false, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 208,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    style: {
                      fontSize: 22,
                      fontWeight: 900,
                      fontFamily: "var(--font-mono)",
                      color: coreColor,
                      lineHeight: 1
                    },
                    children: [
                      health,
                      "%"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 209,
                    columnNumber: 11
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 9, letterSpacing: "0.15em", color: "#64748b", textTransform: "uppercase" }, children: "Health" }, void 0, false, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 220,
                  columnNumber: 11
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 194,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                position: "absolute",
                width: 10,
                height: 10,
                borderRadius: "50%",
                background: coreColor,
                boxShadow: `0 0 10px ${coreColor}`,
                animation: "orbitPulse 4s linear infinite",
                transformOrigin: "center",
                top: "50%",
                left: "50%",
                marginTop: -5,
                marginLeft: -5
              }
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 226,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 180,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center" }, children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            fontSize: 11,
            fontWeight: 900,
            letterSpacing: "0.2em",
            textTransform: "uppercase",
            color: coreColor,
            textShadow: `0 0 10px ${coreColor}80`
          },
          children: allComplete ? "✓ ALL SYSTEMS GO" : "AI CORE"
        },
        void 0,
        false,
        {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 246,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#475569", letterSpacing: "0.12em", textTransform: "uppercase" }, children: [
        temperature.toFixed(0),
        "°C"
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 258,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 245,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/host/index.tsx",
    lineNumber: 178,
    columnNumber: 5
  }, this);
}
_c3 = AICore;
function DeptPanel({ role, progress, status, score, extra, flashing }) {
  const color = ROLE_COLORS[role];
  const isComplete = status === "complete";
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      style: {
        background: "rgba(15,32,53,0.92)",
        border: `1.5px solid ${isComplete ? color : color + "40"}`,
        borderRadius: 12,
        padding: "10px 12px",
        display: "flex",
        flexDirection: "column",
        gap: 6,
        width: 160,
        boxShadow: flashing ? `0 0 28px ${color}cc, 0 0 8px ${color}88, inset 0 0 12px ${color}15` : isComplete ? `0 0 16px ${color}55` : `0 0 6px rgba(56,189,248,0.1)`,
        transition: "box-shadow 0.15s ease-out",
        backdropFilter: "blur(4px)"
      },
      children: [
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 6 }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 16 }, children: ROLE_ICONS[role] }, void 0, false, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 303,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                flex: 1,
                fontSize: 9,
                fontWeight: 900,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color
              },
              children: ROLE_LABELS[role]
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 304,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                fontSize: 9,
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                padding: "1px 5px",
                borderRadius: 4,
                background: statusColor(status) + "25",
                color: statusColor(status)
              },
              children: isComplete ? "✓" : status
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 316,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 302,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              position: "relative",
              height: 6,
              borderRadius: 3,
              background: "#1e293b",
              overflow: "hidden"
            },
            children: /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "progress-fill",
                style: {
                  position: "absolute",
                  inset: "0 auto 0 0",
                  width: `${progress}%`,
                  borderRadius: 3,
                  background: isComplete ? color : `${color}cc`,
                  boxShadow: `0 0 6px ${color}60`
                }
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 342,
                columnNumber: 9
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 333,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                fontFamily: "var(--font-mono)",
                fontSize: 18,
                fontWeight: 900,
                color,
                lineHeight: 1
              },
              children: [
                progress,
                "%"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 357,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { style: { fontFamily: "var(--font-mono)", fontSize: 9, color: "#475569" }, children: [
            score.toLocaleString(),
            " pts"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 368,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 356,
          columnNumber: 7
        }, this),
        extra
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 282,
      columnNumber: 5
    },
    this
  );
}
_c4 = DeptPanel;
function PipelineOverlay({ flashes, statuses }) {
  const paths = [
    { role: "power", d: "M 14% 24% C 30% 30%, 40% 45%, 50% 50%" },
    { role: "data", d: "M 86% 24% C 70% 30%, 60% 45%, 50% 50%" },
    { role: "security", d: "M 14% 72% C 30% 65%, 40% 58%, 50% 50%" },
    { role: "model", d: "M 86% 72% C 70% 65%, 60% 58%, 50% 50%" },
    { role: "cooling", d: "M 50% 88% C 50% 76%, 50% 64%, 50% 50%" }
  ];
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      style: {
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        overflow: "visible"
      },
      children: [
        /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV("filter", { id: "pipeline-glow", children: [
          /* @__PURE__ */ jsxDEV("feGaussianBlur", { stdDeviation: "2", result: "coloredBlur" }, void 0, false, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 409,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("feMerge", { children: [
            /* @__PURE__ */ jsxDEV("feMergeNode", { in: "coloredBlur" }, void 0, false, {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 411,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("feMergeNode", { in: "SourceGraphic" }, void 0, false, {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 412,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 410,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 408,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 407,
          columnNumber: 7
        }, this),
        paths.map(({ role, d }) => {
          const color = ROLE_COLORS[role];
          const isComplete = statuses[role] === "complete";
          const isFlashing = flashes[role];
          const isActive = statuses[role] !== "inactive";
          return /* @__PURE__ */ jsxDEV("g", { children: [
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                d,
                fill: "none",
                stroke: color,
                strokeWidth: 1.5,
                strokeOpacity: isActive ? 0.25 : 0.08,
                style: { transition: "stroke-opacity 0.5s ease" }
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 426,
                columnNumber: 13
              },
              this
            ),
            isActive && !isComplete && /* @__PURE__ */ jsxDEV(
              "path",
              {
                d,
                fill: "none",
                stroke: color,
                strokeWidth: 2,
                strokeDasharray: "12 18",
                style: {
                  animation: "pipelineFlow 2s linear infinite",
                  filter: "url(#pipeline-glow)"
                }
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 436,
                columnNumber: 13
              },
              this
            ),
            isComplete && /* @__PURE__ */ jsxDEV(
              "path",
              {
                d,
                fill: "none",
                stroke: color,
                strokeWidth: 2.5,
                strokeOpacity: 0.7,
                filter: "url(#pipeline-glow)",
                style: { transition: "stroke-opacity 0.5s ease" }
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 450,
                columnNumber: 13
              },
              this
            ),
            isFlashing && /* @__PURE__ */ jsxDEV(
              "path",
              {
                d,
                fill: "none",
                stroke: color,
                strokeWidth: 4,
                strokeOpacity: 0.9,
                filter: "url(#pipeline-glow)",
                style: { animation: "pipelineFlash 0.35s ease-out forwards" }
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 462,
                columnNumber: 13
              },
              this
            )
          ] }, role, true, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 424,
            columnNumber: 11
          }, this);
        })
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 397,
      columnNumber: 5
    },
    this
  );
}
_c5 = PipelineOverlay;
export function HostView() {
  _s();
  const host = useAirJamHost();
  const state = useFactoryStore((s) => s);
  const actions = useFactoryStore.useActions();
  const [flashes, setFlashes] = useState({
    power: false,
    data: false,
    security: false,
    model: false,
    cooling: false
  });
  const flashTimers = useRef({});
  function triggerFlash(role, durationMs = 200) {
    if (flashTimers.current[role]) clearTimeout(flashTimers.current[role]);
    setFlashes((prev) => ({ ...prev, [role]: true }));
    flashTimers.current[role] = setTimeout(
      () => setFlashes((prev) => ({ ...prev, [role]: false })),
      durationMs
    );
  }
  useFactoryStore.useHostActionListener(() => triggerFlash("power", 180), { actionNames: ["tapPower"] });
  useFactoryStore.useHostActionListener(() => triggerFlash("data", 180), { actionNames: ["sortData"] });
  useFactoryStore.useHostActionListener(() => triggerFlash("security", 180), { actionNames: ["zipZap"] });
  useFactoryStore.useHostActionListener(() => triggerFlash("model", 250), { actionNames: ["solvePuzzle"] });
  useFactoryStore.useHostActionListener(() => triggerFlash("cooling", 350), { actionNames: ["coolTick"] });
  useHostTick({
    mode: "interval",
    intervalMs: 1e3,
    onTick: () => {
      if (state.phase === "playing") actions.tickTimer();
    }
  });
  const [devOpen, setDevOpen] = useState(false);
  const allComplete = ["power", "data", "security", "model", "cooling"].every(
    (r) => state[r].status === "complete"
  );
  const currentEvent = state.activeEvents[state.activeEvents.length - 1] ?? null;
  const timerDanger = state.timeRemaining < 30;
  const timerWarning = state.timeRemaining < 60 && state.timeRemaining >= 30;
  if (state.phase === "idle") {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(SurfaceViewport, { className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "relative flex h-full w-full flex-col items-center justify-center gap-8 p-8 overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV(AmbientParticles, {}, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 533,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "scan-line absolute inset-0 pointer-events-none" }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 536,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center z-10", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-6xl font-black tracking-tight",
              style: {
                color: "#38bdf8",
                textShadow: "0 0 40px rgba(56,189,248,0.6), 0 0 80px rgba(56,189,248,0.2)"
              },
              children: "🏭 AI FACTORY"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 540,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "mt-2 text-lg font-semibold tracking-[0.4em] uppercase",
              style: { color: "#475569" },
              children: "Build • Break • Survive"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 549,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "mt-3 text-sm tracking-widest uppercase",
              style: { color: "#38bdf8", opacity: 0.7 },
              children: "5-Player Cooperative Engineering Mission"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 555,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 539,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "factory-panel z-10 flex flex-col items-center gap-4 p-8",
            style: { boxShadow: "0 0 40px rgba(56,189,248,0.15)" },
            children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "text-sm font-bold tracking-[0.3em] uppercase",
                  style: { color: "#38bdf8" },
                  children: "Scan to Join"
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 568,
                  columnNumber: 15
                },
                this
              ),
              host.joinUrl ? /* @__PURE__ */ jsxDEV(
                "div",
                {
                  style: {
                    padding: 12,
                    background: "white",
                    borderRadius: 8,
                    boxShadow: "0 0 30px rgba(56,189,248,0.3)"
                  },
                  children: /* @__PURE__ */ jsxDEV(RoomQrCode, { value: host.joinUrl, size: 180 }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 583,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 575,
                  columnNumber: 15
                },
                this
              ) : /* @__PURE__ */ jsxDEV("div", { className: "h-[180px] w-[180px] flex items-center justify-center text-slate-600 text-sm", children: "Connecting…" }, void 0, false, {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 586,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-xs", style: { color: "#475569" }, children: [
                "Room:",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono", style: { color: "#38bdf8" }, children: host.roomId ?? "—" }, void 0, false, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 592,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 590,
                columnNumber: 15
              }, this),
              host.joinUrl && /* @__PURE__ */ jsxDEV(
                "span",
                {
                  "data-testid": "join-url",
                  style: { display: "none" },
                  "aria-hidden": "true",
                  children: host.joinUrl
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 598,
                  columnNumber: 15
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 564,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "z-10 flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-4xl font-black text-white", children: host.players.length }, void 0, false, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 610,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-slate-600", children: "/" }, void 0, false, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 611,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-4xl font-black", style: { color: "#1e3a5f" }, children: GAME_CONFIG.maxPlayers }, void 0, false, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 612,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm uppercase tracking-widest", style: { color: "#475569" }, children: "Engineers" }, void 0, false, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 615,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 609,
          columnNumber: 13
        }, this),
        host.players.length > 0 && /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "z-10 text-xs animate-pulse",
            style: { color: "#38bdf8", letterSpacing: "0.15em" },
            children: "Engineers joining… awaiting full crew"
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 621,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 532,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 531,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(HostPreviewControllerWorkspace, {}, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 630,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 530,
      columnNumber: 7
    }, this);
  }
  if (state.phase === "lobby") {
    const playerCount = Object.keys(state.roleAssignments).length;
    const allFilled = playerCount >= GAME_CONFIG.maxPlayers;
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(SurfaceViewport, { className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV("div", { className: "relative flex h-full w-full flex-col items-center gap-6 p-8", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => actions.resetGame(),
            style: {
              position: "absolute",
              top: 16,
              right: 16,
              background: "rgba(239,68,68,0.08)",
              border: "1px solid rgba(239,68,68,0.25)",
              color: "#f87171",
              borderRadius: 8,
              padding: "4px 10px",
              fontSize: 11,
              fontWeight: 700,
              cursor: "pointer",
              letterSpacing: "0.08em"
            },
            className: "ctrl-button",
            children: "↺ RESET"
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 646,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center mt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-4xl font-black",
              style: { color: "#38bdf8", textShadow: "0 0 30px rgba(56,189,248,0.5)" },
              children: "🏭 AI FACTORY LOBBY"
            },
            void 0,
            false,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 670,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-sm uppercase tracking-widest", style: { color: "#475569" }, children: [
            playerCount,
            " / ",
            GAME_CONFIG.maxPlayers,
            " Engineers Ready"
          ] }, void 0, true, {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 676,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 669,
          columnNumber: 13
        }, this),
        host.joinUrl && /* @__PURE__ */ jsxDEV("div", { style: { padding: 10, background: "white", borderRadius: 8 }, children: /* @__PURE__ */ jsxDEV(RoomQrCode, { value: host.joinUrl, size: 100 }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 684,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 683,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-xl flex flex-col gap-3", children: ALL_ROLES.map((role) => {
          const assignedPlayerId = Object.entries(state.roleAssignments).find(
            ([, r]) => r === role
          )?.[0];
          const player = host.players.find((p) => p.id === assignedPlayerId);
          const filled = !!assignedPlayerId;
          const color = ROLE_COLORS[role];
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                gap: 14,
                padding: "12px 16px",
                borderRadius: 12,
                border: `1.5px solid ${filled ? color + "70" : "rgba(56,189,248,0.1)"}`,
                background: filled ? color + "10" : "rgba(13,24,37,0.6)",
                transition: "all 0.3s ease",
                boxShadow: filled ? `0 0 20px ${color}20` : "none"
              },
              children: [
                /* @__PURE__ */ jsxDEV("span", { style: { fontSize: 24 }, children: ROLE_ICONS[role] }, void 0, false, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 713,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { flex: 1 }, children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      style: {
                        fontSize: 12,
                        fontWeight: 900,
                        textTransform: "uppercase",
                        letterSpacing: "0.1em",
                        color
                      },
                      children: ROLE_LABELS[role]
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 715,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 10, color: "#475569" }, children: ROLE_MINI_GAME[role] }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 726,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 714,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "right" }, children: filled ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 12, fontWeight: 700, color: "#4ade80" }, children: [
                    "✓ ",
                    player?.label ?? "Engineer"
                  ] }, void 0, true, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 731,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#334155", fontFamily: "var(--font-mono)" }, children: assignedPlayerId?.slice(0, 8) }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 734,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 730,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      fontSize: 10,
                      color: "#334155",
                      textTransform: "uppercase",
                      letterSpacing: "0.08em"
                    },
                    children: "Waiting…"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 739,
                    columnNumber: 23
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 728,
                  columnNumber: 21
                }, this)
              ]
            },
            role,
            true,
            {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 699,
              columnNumber: 19
            },
            this
          );
        }) }, void 0, false, {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 689,
          columnNumber: 13
        }, this),
        allFilled ? /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => actions.startGame(),
            className: "ctrl-button",
            style: {
              background: "linear-gradient(135deg, #0369a1, #38bdf8)",
              border: "none",
              borderRadius: 16,
              padding: "16px 48px",
              fontSize: 20,
              fontWeight: 900,
              color: "white",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              boxShadow: "0 0 40px rgba(56,189,248,0.4)",
              cursor: "pointer",
              transition: "transform 0.1s, box-shadow 0.1s"
            },
            children: "🚀 LAUNCH MISSION"
          },
          void 0,
          false,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 758,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "animate-pulse text-sm",
            style: { color: "#475569", letterSpacing: "0.12em", textTransform: "uppercase" },
            children: [
              "Awaiting ",
              GAME_CONFIG.maxPlayers - playerCount,
              " more engineer",
              GAME_CONFIG.maxPlayers - playerCount !== 1 ? "s" : "",
              "…"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 780,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 643,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 642,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(HostPreviewControllerWorkspace, {}, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 789,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 641,
      columnNumber: 7
    }, this);
  }
  if (state.phase === "playing") {
    const statuses = {
      power: state.power.status,
      data: state.data.status,
      security: state.security.status,
      model: state.model.status,
      cooling: state.cooling.status
    };
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(SurfaceViewport, { className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            display: "flex",
            flexDirection: "column",
            height: "100%",
            overflow: "hidden",
            position: "relative"
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "10px 20px",
                  borderBottom: "1px solid rgba(56,189,248,0.1)",
                  background: "rgba(5,10,20,0.8)",
                  flexShrink: 0
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      style: {
                        fontSize: 18,
                        fontWeight: 900,
                        color: "#38bdf8",
                        textShadow: "0 0 20px rgba(56,189,248,0.5)",
                        letterSpacing: "0.05em"
                      },
                      children: "🏭 AI FACTORY"
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 828,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { style: { display: "flex", alignItems: "center", gap: 24 }, children: [
                    /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center" }, children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }, children: "Time" }, void 0, false, {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 844,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: timerDanger ? "timer-danger" : "",
                          style: {
                            fontFamily: "var(--font-mono)",
                            fontSize: 28,
                            fontWeight: 900,
                            color: timerDanger ? "#f87171" : timerWarning ? "#fb923c" : "#f0f9ff",
                            transition: "color 0.5s ease"
                          },
                          children: formatTime(state.timeRemaining)
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 847,
                          columnNumber: 19
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 843,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center" }, children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }, children: "Factory Health" }, void 0, false, {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 863,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          style: {
                            fontFamily: "var(--font-mono)",
                            fontSize: 28,
                            fontWeight: 900,
                            color: healthColor(state.factoryHealth),
                            transition: "color 0.5s ease"
                          },
                          children: [
                            state.factoryHealth,
                            "%"
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 866,
                          columnNumber: 19
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 862,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center" }, children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }, children: "Score" }, void 0, false, {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 881,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          style: {
                            fontFamily: "var(--font-mono)",
                            fontSize: 28,
                            fontWeight: 900,
                            color: "#38bdf8"
                          },
                          children: state.teamScore.toLocaleString()
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 884,
                          columnNumber: 19
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 880,
                      columnNumber: 17
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 841,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 817,
                columnNumber: 13
              },
              this
            ),
            currentEvent && /* @__PURE__ */ jsxDEV(EventBanner, { message: currentEvent.message }, void 0, false, {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 899,
              columnNumber: 30
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: { padding: "6px 20px", flexShrink: 0 }, children: /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  position: "relative",
                  height: 8,
                  borderRadius: 4,
                  background: "#0f172a",
                  overflow: "hidden"
                },
                children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "progress-fill",
                    style: {
                      position: "absolute",
                      inset: "0 auto 0 0",
                      width: `${state.factoryHealth}%`,
                      borderRadius: 4,
                      background: `linear-gradient(90deg, ${healthColor(state.factoryHealth)}80, ${healthColor(state.factoryHealth)})`,
                      boxShadow: `0 0 10px ${healthColor(state.factoryHealth)}60`
                    }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 912,
                    columnNumber: 17
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 903,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 902,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  position: "relative",
                  flex: 1,
                  minHeight: 0
                },
                children: [
                  /* @__PURE__ */ jsxDEV(PipelineOverlay, { flashes, statuses }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 935,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", top: "4%", left: "4%" }, children: /* @__PURE__ */ jsxDEV(
                    DeptPanel,
                    {
                      role: "power",
                      progress: state.power.progress,
                      status: state.power.status,
                      score: state.power.score,
                      flashing: flashes.power
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 939,
                      columnNumber: 17
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 938,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", top: "4%", right: "4%" }, children: /* @__PURE__ */ jsxDEV(
                    DeptPanel,
                    {
                      role: "data",
                      progress: state.data.progress,
                      status: state.data.status,
                      score: state.data.score,
                      flashing: flashes.data
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 950,
                      columnNumber: 17
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 949,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", bottom: "26%", left: "4%" }, children: /* @__PURE__ */ jsxDEV(
                    DeptPanel,
                    {
                      role: "security",
                      progress: state.security.progress,
                      status: state.security.status,
                      score: state.security.score,
                      flashing: flashes.security
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 961,
                      columnNumber: 17
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 960,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { position: "absolute", bottom: "26%", right: "4%" }, children: /* @__PURE__ */ jsxDEV(
                    DeptPanel,
                    {
                      role: "model",
                      progress: state.model.progress,
                      status: state.model.status,
                      score: state.model.score,
                      flashing: flashes.model
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 972,
                      columnNumber: 17
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 971,
                    columnNumber: 15
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      style: {
                        position: "absolute",
                        bottom: "4%",
                        left: "50%",
                        transform: "translateX(-50%)"
                      },
                      children: /* @__PURE__ */ jsxDEV(
                        DeptPanel,
                        {
                          role: "cooling",
                          progress: state.cooling.progress,
                          status: state.cooling.status,
                          score: state.cooling.score,
                          flashing: flashes.cooling,
                          extra: /* @__PURE__ */ jsxDEV(
                            "div",
                            {
                              style: {
                                textAlign: "center",
                                fontFamily: "var(--font-mono)",
                                fontSize: 14,
                                fontWeight: 700,
                                color: state.cooling.temperature <= GAME_CONFIG.coolingSafeMax ? "#34d399" : state.cooling.temperature > 85 ? "#f87171" : "#fb923c"
                              },
                              children: [
                                state.cooling.temperature.toFixed(1),
                                "°C"
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "D:/AiFactory/src/host/index.tsx",
                              lineNumber: 997,
                              columnNumber: 19
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 990,
                          columnNumber: 17
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 982,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      style: {
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                        zIndex: 10
                      },
                      children: /* @__PURE__ */ jsxDEV(
                        AICore,
                        {
                          health: state.factoryHealth,
                          allComplete,
                          temperature: state.cooling.temperature
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 1027,
                          columnNumber: 17
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 1018,
                      columnNumber: 15
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 927,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setDevOpen((o) => !o),
                className: "ctrl-button",
                style: {
                  position: "absolute",
                  bottom: 8,
                  right: 8,
                  background: "rgba(245,158,11,0.08)",
                  border: "1px solid rgba(245,158,11,0.2)",
                  borderRadius: 6,
                  padding: "3px 8px",
                  fontSize: 10,
                  color: "#f59e0b",
                  cursor: "pointer",
                  zIndex: 20,
                  letterSpacing: "0.06em",
                  fontWeight: 700
                },
                children: [
                  "🔧 ",
                  devOpen ? "CLOSE" : "DEV"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 1036,
                columnNumber: 13
              },
              this
            ),
            devOpen && /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  position: "absolute",
                  bottom: 36,
                  right: 8,
                  background: "rgba(15,32,53,0.98)",
                  border: "1px solid rgba(245,158,11,0.3)",
                  borderRadius: 10,
                  padding: "12px 14px",
                  zIndex: 20,
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                  minWidth: 260,
                  backdropFilter: "blur(8px)"
                },
                children: [
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#f59e0b", fontWeight: 900, letterSpacing: "0.1em", textTransform: "uppercase" }, children: "🔧 Dev Test Panel" }, void 0, false, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 1077,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }, children: [
                    ["power", "data", "security", "model"].map(
                      (role) => /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          className: "ctrl-button",
                          onClick: () => {
                            if (role === "power") actions.devIncrementPower({ amount: GAME_CONFIG.devIncrementAmount });
                            if (role === "data") actions.devIncrementData({ amount: GAME_CONFIG.devIncrementAmount });
                            if (role === "security") actions.devIncrementSecurity({ amount: GAME_CONFIG.devIncrementAmount });
                            if (role === "model") actions.devIncrementModel({ amount: GAME_CONFIG.devIncrementAmount });
                          },
                          style: {
                            background: ROLE_COLORS[role] + "15",
                            border: `1px solid ${ROLE_COLORS[role]}40`,
                            borderRadius: 6,
                            padding: "5px 8px",
                            fontSize: 10,
                            color: ROLE_COLORS[role],
                            cursor: "pointer",
                            fontWeight: 700,
                            textAlign: "left"
                          },
                          children: [
                            ROLE_ICONS[role],
                            " +",
                            GAME_CONFIG.devIncrementAmount,
                            "%"
                          ]
                        },
                        role,
                        true,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 1082,
                          columnNumber: 17
                        },
                        this
                      )
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        className: "ctrl-button",
                        onClick: () => actions.devSetCoolingTemp({ temperature: Math.max(50, state.cooling.temperature - 5) }),
                        style: {
                          background: "#38bdf815",
                          border: "1px solid #38bdf840",
                          borderRadius: 6,
                          padding: "5px 8px",
                          fontSize: 10,
                          color: "#38bdf8",
                          cursor: "pointer",
                          fontWeight: 700,
                          textAlign: "left"
                        },
                        children: "🌡 Cool −5°C"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 1107,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        className: "ctrl-button",
                        onClick: () => actions.resetGame(),
                        style: {
                          background: "rgba(239,68,68,0.1)",
                          border: "1px solid rgba(239,68,68,0.3)",
                          borderRadius: 6,
                          padding: "5px 8px",
                          fontSize: 10,
                          color: "#f87171",
                          cursor: "pointer",
                          fontWeight: 700
                        },
                        children: "↺ Reset"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 1125,
                        columnNumber: 19
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 1080,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 9, color: "#334155" }, children: [
                    host.players.length,
                    " controller(s) · ",
                    Object.keys(state.roleAssignments).length,
                    " role(s)"
                  ] }, void 0, true, {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 1143,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 1060,
                columnNumber: 13
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 807,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 806,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(HostPreviewControllerWorkspace, {}, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 1150,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 805,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(EndedScreen, { state, actions }, void 0, false, {
    fileName: "D:/AiFactory/src/host/index.tsx",
    lineNumber: 1156,
    columnNumber: 10
  }, this);
}
_s(HostView, "IPWmKtQ6YxFiuIkrIpq7QQqSKYA=", false, function() {
  return [useAirJamHost, useFactoryStore, useFactoryStore.useActions, useFactoryStore.useHostActionListener, useFactoryStore.useHostActionListener, useFactoryStore.useHostActionListener, useFactoryStore.useHostActionListener, useFactoryStore.useHostActionListener, useHostTick];
});
_c6 = HostView;
function EndedScreen({
  state,
  actions
}) {
  _s2();
  const success = state.finalResult === "success";
  const [deployPhase, setDeployPhase] = useState(
    success ? "deploying" : "revealed"
  );
  useEffect(() => {
    if (success) {
      const t = setTimeout(() => setDeployPhase("revealed"), 2500);
      return () => clearTimeout(t);
    }
  }, [success]);
  const criticalMin = GAME_CONFIG.criticalDeptMinimum;
  const deptResults = ALL_ROLES.map((role) => {
    const dept = state[role];
    const passed = dept.progress >= criticalMin;
    return { role, progress: dept.progress, score: dept.score, passed };
  });
  if (deployPhase === "deploying") {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(SurfaceViewport, { className: "bg-[#050a14]", children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          style: {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            height: "100%",
            gap: 32,
            padding: 40
          },
          children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  fontSize: 48,
                  fontWeight: 900,
                  letterSpacing: "0.05em",
                  color: "#38bdf8",
                  textShadow: "0 0 40px rgba(56,189,248,0.7)",
                  textAlign: "center"
                },
                children: "AI CORE DEPLOYING"
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 1204,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  fontSize: 14,
                  color: "#475569",
                  letterSpacing: "0.15em",
                  textTransform: "uppercase",
                  animation: "warningPulse 1s ease-in-out infinite"
                },
                children: "Initialising neural pathways…"
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 1216,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                style: {
                  width: "min(480px, 90%)",
                  background: "#0f172a",
                  borderRadius: 8,
                  height: 16,
                  overflow: "hidden",
                  border: "1px solid rgba(56,189,248,0.2)",
                  boxShadow: "0 0 20px rgba(56,189,248,0.15)"
                },
                children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      height: "100%",
                      borderRadius: 8,
                      background: "linear-gradient(90deg, #0369a1, #38bdf8, #4ade80)",
                      boxShadow: "0 0 12px rgba(56,189,248,0.6)",
                      animation: "deployFill 2.2s ease-out forwards"
                    }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 1240,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 1229,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 64 }, children: "🤖" }, void 0, false, {
              fileName: "D:/AiFactory/src/host/index.tsx",
              lineNumber: 1251,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/AiFactory/src/host/index.tsx",
          lineNumber: 1193,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 1192,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(HostPreviewControllerWorkspace, {}, void 0, false, {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 1254,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 1191,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      SurfaceViewport,
      {
        style: {
          background: success ? "radial-gradient(ellipse at center, rgba(74,222,128,0.06) 0%, #050a14 70%)" : "radial-gradient(ellipse at center, rgba(239,68,68,0.08) 0%, #050a14 70%)"
        },
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            style: {
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              gap: 24,
              padding: 32,
              overflow: "auto"
            },
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "result-reveal", style: { textAlign: "center" }, children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      fontSize: 52,
                      fontWeight: 900,
                      letterSpacing: "0.04em",
                      color: success ? "#4ade80" : "#f87171",
                      textShadow: success ? "0 0 50px rgba(74,222,128,0.7)" : "0 0 50px rgba(239,68,68,0.7)",
                      lineHeight: 1.1
                    },
                    children: success ? "🏭 AI FACTORY ONLINE" : "🚨 AI FACTORY FAILED"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 1283,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    style: {
                      marginTop: 8,
                      fontSize: 20,
                      fontWeight: 700,
                      color: success ? "#86efac" : "#fca5a5",
                      letterSpacing: "0.1em",
                      textTransform: "uppercase"
                    },
                    children: success ? "AI Successfully Deployed" : "AI Deployment Unsuccessful"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/AiFactory/src/host/index.tsx",
                    lineNumber: 1297,
                    columnNumber: 13
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/AiFactory/src/host/index.tsx",
                lineNumber: 1282,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "result-reveal result-reveal-delay-1",
                  style: {
                    display: "flex",
                    gap: 32,
                    background: "rgba(15,32,53,0.8)",
                    border: "1px solid rgba(56,189,248,0.15)",
                    borderRadius: 16,
                    padding: "16px 32px"
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center" }, children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 11, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }, children: "Factory Health" }, void 0, false, {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 1324,
                        columnNumber: 15
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          style: {
                            fontFamily: "var(--font-mono)",
                            fontSize: 40,
                            fontWeight: 900,
                            color: healthColor(state.factoryHealth)
                          },
                          children: [
                            state.factoryHealth,
                            "%"
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 1327,
                          columnNumber: 15
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 1323,
                      columnNumber: 13
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { style: { width: 1, background: "rgba(56,189,248,0.1)" } }, void 0, false, {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 1338,
                      columnNumber: 13
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { style: { textAlign: "center" }, children: [
                      /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 11, color: "#475569", textTransform: "uppercase", letterSpacing: "0.1em" }, children: "Team Score" }, void 0, false, {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 1340,
                        columnNumber: 15
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          style: {
                            fontFamily: "var(--font-mono)",
                            fontSize: 40,
                            fontWeight: 900,
                            color: "#38bdf8"
                          },
                          children: state.teamScore.toLocaleString()
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/AiFactory/src/host/index.tsx",
                          lineNumber: 1343,
                          columnNumber: 15
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/AiFactory/src/host/index.tsx",
                      lineNumber: 1339,
                      columnNumber: 13
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 1312,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "result-reveal result-reveal-delay-2",
                  style: {
                    display: "grid",
                    gridTemplateColumns: "repeat(5, 1fr)",
                    gap: 10,
                    width: "100%",
                    maxWidth: 640
                  },
                  children: deptResults.map(({ role, progress, passed }) => {
                    const color = ROLE_COLORS[role];
                    return /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        style: {
                          textAlign: "center",
                          background: passed ? color + "10" : "rgba(239,68,68,0.08)",
                          border: `1.5px solid ${passed ? color + "50" : "rgba(239,68,68,0.4)"}`,
                          borderRadius: 12,
                          padding: "10px 6px"
                        },
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 20, marginBottom: 4 }, children: ROLE_ICONS[role] }, void 0, false, {
                            fileName: "D:/AiFactory/src/host/index.tsx",
                            lineNumber: 1380,
                            columnNumber: 19
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "div",
                            {
                              style: {
                                fontSize: 9,
                                color: passed ? color : "#f87171",
                                fontWeight: 900,
                                textTransform: "uppercase",
                                letterSpacing: "0.06em",
                                marginBottom: 6
                              },
                              children: ROLE_LABELS[role].replace(" Engineer", "")
                            },
                            void 0,
                            false,
                            {
                              fileName: "D:/AiFactory/src/host/index.tsx",
                              lineNumber: 1381,
                              columnNumber: 19
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "div",
                            {
                              style: {
                                fontFamily: "var(--font-mono)",
                                fontSize: 22,
                                fontWeight: 900,
                                color: passed ? color : "#f87171"
                              },
                              children: [
                                progress,
                                "%"
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "D:/AiFactory/src/host/index.tsx",
                              lineNumber: 1393,
                              columnNumber: 19
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("div", { style: { fontSize: 16, marginTop: 2 }, children: passed ? "✓" : "✗" }, void 0, false, {
                            fileName: "D:/AiFactory/src/host/index.tsx",
                            lineNumber: 1403,
                            columnNumber: 19
                          }, this)
                        ]
                      },
                      role,
                      true,
                      {
                        fileName: "D:/AiFactory/src/host/index.tsx",
                        lineNumber: 1370,
                        columnNumber: 17
                      },
                      this
                    );
                  })
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 1357,
                  columnNumber: 11
                },
                this
              ),
              !success && /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "result-reveal result-reveal-delay-3",
                  style: {
                    color: "#f87171",
                    fontSize: 12,
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    background: "rgba(239,68,68,0.08)",
                    border: "1px solid rgba(239,68,68,0.25)",
                    borderRadius: 8,
                    padding: "6px 16px"
                  },
                  children: state.factoryHealth < GAME_CONFIG.factorySuccessThreshold ? `Factory Health ${state.factoryHealth}% — Required ${GAME_CONFIG.factorySuccessThreshold}%` : `Critical dept below ${GAME_CONFIG.criticalDeptMinimum}% — ${deptResults.find((d) => !d.passed) ? ROLE_LABELS[deptResults.find((d) => !d.passed).role] : "Unknown"} failed`
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 1411,
                  columnNumber: 11
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => actions.resetGame(),
                  className: "ctrl-button result-reveal result-reveal-delay-4",
                  style: {
                    background: success ? "linear-gradient(135deg, #14532d, #4ade80)" : "linear-gradient(135deg, #1e3a5f, #38bdf8)",
                    border: "none",
                    borderRadius: 16,
                    padding: "16px 48px",
                    fontSize: 20,
                    fontWeight: 900,
                    color: "white",
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    cursor: "pointer",
                    boxShadow: success ? "0 0 40px rgba(74,222,128,0.3)" : "0 0 40px rgba(56,189,248,0.3)"
                  },
                  children: success ? "🎉 Play Again" : "🔄 Try Again"
                },
                void 0,
                false,
                {
                  fileName: "D:/AiFactory/src/host/index.tsx",
                  lineNumber: 1436,
                  columnNumber: 11
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/AiFactory/src/host/index.tsx",
            lineNumber: 1269,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/host/index.tsx",
        lineNumber: 1262,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(HostPreviewControllerWorkspace, {}, void 0, false, {
      fileName: "D:/AiFactory/src/host/index.tsx",
      lineNumber: 1462,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/host/index.tsx",
    lineNumber: 1261,
    columnNumber: 5
  }, this);
}
_s2(EndedScreen, "QIFkOykKEZt80UuOS3kZNGzEg6Q=");
_c7 = EndedScreen;
var _c, _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c, "AmbientParticles");
$RefreshReg$(_c2, "EventBanner");
$RefreshReg$(_c3, "AICore");
$RefreshReg$(_c4, "DeptPanel");
$RefreshReg$(_c5, "PipelineOverlay");
$RefreshReg$(_c6, "HostView");
$RefreshReg$(_c7, "EndedScreen");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/AiFactory/src/host/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/AiFactory/src/host/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0VRLFNBd2JGLFVBeGJFOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdEUixTQUFTQSxlQUFlQyxtQkFBbUI7QUFDM0MsU0FBU0Msc0NBQXNDO0FBQy9DLFNBQVNDLFlBQVlDLHVCQUF1QjtBQUM1QyxTQUFTQyxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUVLO0FBQ1AsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHVCQUEwQztBQUluRCxTQUFTQyxXQUFXQyxTQUF5QjtBQUMzQyxRQUFNQyxJQUFJQyxLQUFLQyxNQUFNSCxVQUFVLEVBQUUsRUFBRUksU0FBUyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUM3RCxRQUFNQyxLQUFLTixVQUFVLElBQUlJLFNBQVMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDbkQsU0FBTyxHQUFHSixDQUFDLElBQUlLLENBQUM7QUFDbEI7QUFFQSxTQUFTQyxZQUFZQyxRQUF3QjtBQUMzQyxNQUFJQSxVQUFVLEdBQUksUUFBTztBQUN6QixNQUFJQSxVQUFVLEdBQUksUUFBTztBQUN6QixTQUFPO0FBQ1Q7QUFFQSxTQUFTQyxZQUFZQyxRQUF3QjtBQUMzQyxRQUFNQyxNQUE4QjtBQUFBLElBQ2xDQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsRUFDVjtBQUNBLFNBQU9QLElBQUlELE1BQU0sS0FBSztBQUN4QjtBQUlBLFNBQVNTLG1CQUFtQjtBQUMxQixRQUFNQyxZQUFZQyxNQUFNQyxLQUFLLEVBQUVDLFFBQVEsR0FBRyxHQUFHLENBQUNDLEdBQUdDLE9BQU87QUFBQSxJQUN0REMsSUFBSUQ7QUFBQUEsSUFDSkUsTUFBTSxHQUFHLElBQUtGLElBQUksTUFBTyxFQUFFO0FBQUEsSUFDM0JHLFFBQVEsR0FBSUgsSUFBSSxLQUFNLEVBQUU7QUFBQSxJQUN4QkksVUFBVSxHQUFHLElBQUtKLElBQUksTUFBTyxDQUFDO0FBQUEsSUFDOUJLLE9BQU8sR0FBSUwsSUFBSSxNQUFPLENBQUM7QUFBQSxJQUN2Qk0sTUFBTU4sSUFBSSxNQUFNLElBQUksSUFBSUEsSUFBSSxNQUFNLElBQUksSUFBSTtBQUFBLElBQzFDTyxPQUFPUCxJQUFJLE1BQU0sSUFBSSx5QkFDZEEsSUFBSSxNQUFNLElBQUksMEJBQ2RBLElBQUksTUFBTSxJQUFJLHlCQUNBO0FBQUEsRUFDdkIsRUFBRTtBQUVGLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVRLFVBQVUsWUFBWUMsT0FBTyxHQUFHQyxVQUFVLFVBQVVDLGVBQWUsT0FBTyxHQUNyRmhCLG9CQUFVVDtBQUFBQSxJQUFJLENBQUMwQixNQUNkO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxXQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsVUFDTFYsTUFBTVUsRUFBRVY7QUFBQUEsVUFDUkMsUUFBUVMsRUFBRVQ7QUFBQUEsVUFDVlUsT0FBT0QsRUFBRU47QUFBQUEsVUFDVFEsUUFBUUYsRUFBRU47QUFBQUEsVUFDVlMsWUFBWUgsRUFBRUw7QUFBQUEsVUFDZFMsbUJBQW1CSixFQUFFUjtBQUFBQSxVQUNyQmEsZ0JBQWdCTCxFQUFFUDtBQUFBQSxRQUNwQjtBQUFBO0FBQUEsTUFWS08sRUFBRVg7QUFBQUEsTUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0k7QUFBQSxFQUVMLEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBRUFpQixLQW5DU3hCO0FBeUNULFNBQVN5QixZQUFZLEVBQUVDLFFBQTBCLEdBQUc7QUFDbEQsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBVTtBQUFBLE1BQ1YsT0FBTztBQUFBLFFBQ0xaLFVBQVU7QUFBQSxRQUNWSyxPQUFPO0FBQUEsUUFDUFEsU0FBUztBQUFBLFFBQ1RDLFNBQVM7QUFBQSxRQUNUQyxZQUFZO0FBQUEsUUFDWkMsZ0JBQWdCO0FBQUEsUUFDaEJDLEtBQUs7QUFBQSxRQUNMZixVQUFVO0FBQUEsUUFDVmdCLFdBQVc7QUFBQSxRQUNYQyxXQUFXO0FBQUEsUUFDWEMsY0FBYztBQUFBLFFBQ2RiLFlBQ0U7QUFBQSxNQUNKO0FBQUEsTUFHQTtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPO0FBQUEsY0FDTFAsVUFBVTtBQUFBLGNBQ1ZDLE9BQU87QUFBQSxjQUNQTSxZQUFZO0FBQUEsY0FDWlcsV0FBVztBQUFBLGNBQ1hmLGVBQWU7QUFBQSxZQUNqQjtBQUFBO0FBQUEsVUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPSTtBQUFBLFFBRUosdUJBQUMsVUFBSyxPQUFPLEVBQUVrQixVQUFVLElBQUlDLFFBQVEsRUFBRSxHQUFHLGtCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNMRCxVQUFVO0FBQUEsY0FDVkUsWUFBWTtBQUFBLGNBQ1pDLGVBQWU7QUFBQSxjQUNmQyxlQUFlO0FBQUEsY0FDZjFCLE9BQU87QUFBQSxjQUNQdUIsUUFBUTtBQUFBLGNBQ1JJLFlBQVk7QUFBQSxZQUNkO0FBQUEsWUFFQ2Q7QUFBQUE7QUFBQUEsVUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVTLFVBQVUsSUFBSUMsUUFBUSxFQUFFLEdBQUcsa0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQTtBQUFBO0FBQUEsSUExQzlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQTJDQTtBQUVKO0FBRUFLLE1BakRTaEI7QUF5RFQsU0FBU2lCLE9BQU8sRUFBRXJELFFBQVFzRCxhQUFhQyxZQUF5QixHQUFHO0FBQ2pFLFFBQU1DLFlBQVlGLGNBQWMsWUFBWXZELFlBQVlDLE1BQU07QUFDOUQsUUFBTTJDLFlBQVlXLGNBQ2QsMENBQ0E7QUFFSixTQUNFLHVCQUFDLFNBQUksT0FBTyxFQUFFZixTQUFTLFFBQVFrQixlQUFlLFVBQVVqQixZQUFZLFVBQVVFLEtBQUssRUFBRSxHQUVuRjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPO0FBQUEsVUFDTGpCLFVBQVU7QUFBQSxVQUNWSyxPQUFPO0FBQUEsVUFDUEMsUUFBUTtBQUFBLFVBQ1IyQixjQUFjO0FBQUEsVUFDZEMsUUFBUSxhQUFhSCxTQUFTO0FBQUEsVUFDOUJqQixTQUFTO0FBQUEsVUFDVEMsWUFBWTtBQUFBLFVBQ1pDLGdCQUFnQjtBQUFBLFVBQ2hCRTtBQUFBQSxRQUNGO0FBQUEsUUFHQTtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0xiLE9BQU87QUFBQSxnQkFDUEMsUUFBUTtBQUFBLGdCQUNSMkIsY0FBYztBQUFBLGdCQUNkMUIsWUFBWSxzQ0FBc0N3QixTQUFTLE9BQU9BLFNBQVM7QUFBQSxnQkFDM0VHLFFBQVEsYUFBYUgsU0FBUztBQUFBLGdCQUM5QmpCLFNBQVM7QUFBQSxnQkFDVGtCLGVBQWU7QUFBQSxnQkFDZmpCLFlBQVk7QUFBQSxnQkFDWkMsZ0JBQWdCO0FBQUEsZ0JBQ2hCQyxLQUFLO0FBQUEsY0FDUDtBQUFBLGNBRUE7QUFBQSx1Q0FBQyxVQUFLLE9BQU8sRUFBRUksVUFBVSxHQUFHLEdBQUcsa0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2pDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU87QUFBQSxzQkFDTEEsVUFBVTtBQUFBLHNCQUNWRSxZQUFZO0FBQUEsc0JBQ1pZLFlBQVk7QUFBQSxzQkFDWnBDLE9BQU9nQztBQUFBQSxzQkFDUEssWUFBWTtBQUFBLG9CQUNkO0FBQUEsb0JBRUM3RDtBQUFBQTtBQUFBQSxzQkFBTztBQUFBO0FBQUE7QUFBQSxrQkFUVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLE9BQU8sRUFBRThDLFVBQVUsR0FBR0csZUFBZSxVQUFVekIsT0FBTyxXQUFXMEIsZUFBZSxZQUFZLEdBQUUsc0JBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNkJBO0FBQUEsVUFHQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTztBQUFBLGdCQUNMekIsVUFBVTtBQUFBLGdCQUNWSyxPQUFPO0FBQUEsZ0JBQ1BDLFFBQVE7QUFBQSxnQkFDUjJCLGNBQWM7QUFBQSxnQkFDZDFCLFlBQVl3QjtBQUFBQSxnQkFDWk0sV0FBVyxZQUFZTixTQUFTO0FBQUEsZ0JBQ2hDYixXQUFXO0FBQUEsZ0JBQ1hvQixpQkFBaUI7QUFBQSxnQkFDakJDLEtBQUs7QUFBQSxnQkFDTDdDLE1BQU07QUFBQSxnQkFDTjhDLFdBQVc7QUFBQSxnQkFDWEMsWUFBWTtBQUFBLGNBQ2Q7QUFBQTtBQUFBLFlBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0k7QUFBQTtBQUFBO0FBQUEsTUE1RE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOERBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsV0FBVyxTQUFTLEdBQ2hDO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxZQUNMckIsVUFBVTtBQUFBLFlBQ1ZFLFlBQVk7QUFBQSxZQUNaQyxlQUFlO0FBQUEsWUFDZkMsZUFBZTtBQUFBLFlBQ2YxQixPQUFPZ0M7QUFBQUEsWUFDUEwsWUFBWSxZQUFZSyxTQUFTO0FBQUEsVUFDbkM7QUFBQSxVQUVDRix3QkFBYyxxQkFBcUI7QUFBQTtBQUFBLFFBVnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVIsVUFBVSxHQUFHdEIsT0FBTyxXQUFXeUIsZUFBZSxVQUFVQyxlQUFlLFlBQVksR0FDOUZLO0FBQUFBLG9CQUFZYSxRQUFRLENBQUM7QUFBQSxRQUFFO0FBQUEsV0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsT0FuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9GQTtBQUVKO0FBRUFDLE1BL0ZTaEI7QUEwR1QsU0FBU2lCLFVBQVUsRUFBRUMsTUFBTUMsVUFBVXRFLFFBQVF1RSxPQUFPQyxPQUFPQyxTQUF5QixHQUFHO0FBQ3JGLFFBQU1uRCxRQUFRdkMsWUFBWXNGLElBQUk7QUFDOUIsUUFBTUssYUFBYTFFLFdBQVc7QUFFOUIsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsT0FBTztBQUFBLFFBQ0w4QixZQUFZO0FBQUEsUUFDWjJCLFFBQVEsZUFBZWlCLGFBQWFwRCxRQUFRQSxRQUFRLElBQUk7QUFBQSxRQUN4RGtDLGNBQWM7QUFBQSxRQUNkcEIsU0FBUztBQUFBLFFBQ1RDLFNBQVM7QUFBQSxRQUNUa0IsZUFBZTtBQUFBLFFBQ2ZmLEtBQUs7QUFBQSxRQUNMWixPQUFPO0FBQUEsUUFDUGdDLFdBQVdhLFdBQ1AsWUFBWW5ELEtBQUssZUFBZUEsS0FBSyxzQkFBc0JBLEtBQUssT0FDaEVvRCxhQUNFLFlBQVlwRCxLQUFLLE9BQ2pCO0FBQUEsUUFDTnFELFlBQVk7QUFBQSxRQUNaQyxnQkFBZ0I7QUFBQSxNQUNsQjtBQUFBLE1BR0E7QUFBQSwrQkFBQyxTQUFJLE9BQU8sRUFBRXZDLFNBQVMsUUFBUUMsWUFBWSxVQUFVRSxLQUFLLEVBQUUsR0FDMUQ7QUFBQSxpQ0FBQyxVQUFLLE9BQU8sRUFBRUksVUFBVSxHQUFHLEdBQUk1RCxxQkFBV3FGLElBQUksS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUQ7QUFBQSxVQUNqRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTztBQUFBLGdCQUNMUSxNQUFNO0FBQUEsZ0JBQ05qQyxVQUFVO0FBQUEsZ0JBQ1ZFLFlBQVk7QUFBQSxnQkFDWkMsZUFBZTtBQUFBLGdCQUNmQyxlQUFlO0FBQUEsZ0JBQ2YxQjtBQUFBQSxjQUNGO0FBQUEsY0FFQ3JDLHNCQUFZb0YsSUFBSTtBQUFBO0FBQUEsWUFWbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0x6QixVQUFVO0FBQUEsZ0JBQ1ZFLFlBQVk7QUFBQSxnQkFDWkUsZUFBZTtBQUFBLGdCQUNmRCxlQUFlO0FBQUEsZ0JBQ2ZYLFNBQVM7QUFBQSxnQkFDVG9CLGNBQWM7QUFBQSxnQkFDZDFCLFlBQVkvQixZQUFZQyxNQUFNLElBQUk7QUFBQSxnQkFDbENzQixPQUFPdkIsWUFBWUMsTUFBTTtBQUFBLGNBQzNCO0FBQUEsY0FFQzBFLHVCQUFhLE1BQU0xRTtBQUFBQTtBQUFBQSxZQVp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPO0FBQUEsY0FDTHVCLFVBQVU7QUFBQSxjQUNWTSxRQUFRO0FBQUEsY0FDUjJCLGNBQWM7QUFBQSxjQUNkMUIsWUFBWTtBQUFBLGNBQ1pMLFVBQVU7QUFBQSxZQUNaO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixPQUFPO0FBQUEsa0JBQ0xGLFVBQVU7QUFBQSxrQkFDVkMsT0FBTztBQUFBLGtCQUNQSSxPQUFPLEdBQUcwQyxRQUFRO0FBQUEsa0JBQ2xCZCxjQUFjO0FBQUEsa0JBQ2QxQixZQUFZNEMsYUFBYXBELFFBQVEsR0FBR0EsS0FBSztBQUFBLGtCQUN6Q3NDLFdBQVcsV0FBV3RDLEtBQUs7QUFBQSxnQkFDN0I7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0k7QUFBQTtBQUFBLFVBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVlLFNBQVMsUUFBUUUsZ0JBQWdCLGlCQUFpQkQsWUFBWSxTQUFTLEdBQ25GO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU87QUFBQSxnQkFDTG9CLFlBQVk7QUFBQSxnQkFDWmQsVUFBVTtBQUFBLGdCQUNWRSxZQUFZO0FBQUEsZ0JBQ1p4QjtBQUFBQSxnQkFDQXFDLFlBQVk7QUFBQSxjQUNkO0FBQUEsY0FFQ1c7QUFBQUE7QUFBQUEsZ0JBQVM7QUFBQTtBQUFBO0FBQUEsWUFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxPQUFPLEVBQUVaLFlBQVksb0JBQW9CZCxVQUFVLEdBQUd0QixPQUFPLFVBQVUsR0FDMUVpRDtBQUFBQSxrQkFBTU8sZUFBZTtBQUFBLFlBQUU7QUFBQSxlQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUVDTjtBQUFBQTtBQUFBQTtBQUFBQSxJQTNGSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE0RkE7QUFFSjtBQUVBTyxNQXJHU1g7QUE0R1QsU0FBU1ksZ0JBQWdCLEVBQUVDLFNBQVNDLFNBQStCLEdBQUc7QUFHcEUsUUFBTUMsUUFBMkM7QUFBQSxJQUMvQyxFQUFFZCxNQUFNLFNBQVllLEdBQUcsd0NBQXdDO0FBQUEsSUFDL0QsRUFBRWYsTUFBTSxRQUFZZSxHQUFHLHdDQUF3QztBQUFBLElBQy9ELEVBQUVmLE1BQU0sWUFBWWUsR0FBRyx3Q0FBd0M7QUFBQSxJQUMvRCxFQUFFZixNQUFNLFNBQVllLEdBQUcsd0NBQXdDO0FBQUEsSUFDL0QsRUFBRWYsTUFBTSxXQUFZZSxHQUFHLHdDQUF3QztBQUFBLEVBQUM7QUFHbEUsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsT0FBTztBQUFBLFFBQ0w3RCxVQUFVO0FBQUEsUUFDVkMsT0FBTztBQUFBLFFBQ1BJLE9BQU87QUFBQSxRQUNQQyxRQUFRO0FBQUEsUUFDUkgsZUFBZTtBQUFBLFFBQ2ZELFVBQVU7QUFBQSxNQUNaO0FBQUEsTUFFQTtBQUFBLCtCQUFDLFVBQ0MsaUNBQUMsWUFBTyxJQUFHLGlCQUNUO0FBQUEsaUNBQUMsb0JBQWUsY0FBYSxLQUFJLFFBQU8saUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsVUFDckQsdUJBQUMsYUFDQztBQUFBLG1DQUFDLGlCQUFZLElBQUcsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFDN0IsdUJBQUMsaUJBQVksSUFBRyxtQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxlQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVDMEQsTUFBTWxGLElBQUksQ0FBQyxFQUFFb0UsTUFBTWUsRUFBRSxNQUFNO0FBQzFCLGdCQUFNOUQsUUFBUXZDLFlBQVlzRixJQUFJO0FBQzlCLGdCQUFNSyxhQUFhUSxTQUFTYixJQUFJLE1BQU07QUFDdEMsZ0JBQU1nQixhQUFhSixRQUFRWixJQUFJO0FBQy9CLGdCQUFNaUIsV0FBV0osU0FBU2IsSUFBSSxNQUFNO0FBRXBDLGlCQUNFLHVCQUFDLE9BRUM7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFFBQVEvQztBQUFBQSxnQkFDUixhQUFhO0FBQUEsZ0JBQ2IsZUFBZWdFLFdBQVcsT0FBTztBQUFBLGdCQUNqQyxPQUFPLEVBQUVYLFlBQVksMkJBQTJCO0FBQUE7QUFBQSxjQU5sRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNb0Q7QUFBQSxZQUduRFcsWUFBWSxDQUFDWixjQUNaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsUUFBUXBEO0FBQUFBLGdCQUNSLGFBQWE7QUFBQSxnQkFDYixpQkFBZ0I7QUFBQSxnQkFDaEIsT0FBTztBQUFBLGtCQUNMbUIsV0FBVztBQUFBLGtCQUNYOEMsUUFBUTtBQUFBLGdCQUNWO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNJO0FBQUEsWUFJTGIsY0FDQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFFBQVFwRDtBQUFBQSxnQkFDUixhQUFhO0FBQUEsZ0JBQ2IsZUFBZTtBQUFBLGdCQUNmLFFBQU87QUFBQSxnQkFDUCxPQUFPLEVBQUVxRCxZQUFZLDJCQUEyQjtBQUFBO0FBQUEsY0FQbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT29EO0FBQUEsWUFJckRVLGNBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLE1BQUs7QUFBQSxnQkFDTCxRQUFRL0Q7QUFBQUEsZ0JBQ1IsYUFBYTtBQUFBLGdCQUNiLGVBQWU7QUFBQSxnQkFDZixRQUFPO0FBQUEsZ0JBQ1AsT0FBTyxFQUFFbUIsV0FBVyx3Q0FBd0M7QUFBQTtBQUFBLGNBUDlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9nRTtBQUFBLGVBN0M1RDRCLE1BQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnREE7QUFBQSxRQUVKLENBQUM7QUFBQTtBQUFBO0FBQUEsSUE3RUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBOEVBO0FBRUo7QUFFQW1CLE1BOUZTUjtBQWdHRixnQkFBU1MsV0FBVztBQUFBQyxLQUFBO0FBQ3pCLFFBQU1DLE9BQU9ySCxjQUFjO0FBQzNCLFFBQU1zSCxRQUFReEcsZ0JBQWdCLENBQUNRLE1BQW9CQSxDQUFDO0FBQ3BELFFBQU1pRyxVQUFVekcsZ0JBQWdCMEcsV0FBVztBQUczQyxRQUFNLENBQUNiLFNBQVNjLFVBQVUsSUFBSWxILFNBQXNDO0FBQUEsSUFDbEVtSCxPQUFPO0FBQUEsSUFBT0MsTUFBTTtBQUFBLElBQU9DLFVBQVU7QUFBQSxJQUFPQyxPQUFPO0FBQUEsSUFBT0MsU0FBUztBQUFBLEVBQ3JFLENBQUM7QUFDRCxRQUFNQyxjQUFjekgsT0FBbUUsQ0FBQyxDQUFDO0FBRXpGLFdBQVMwSCxhQUFhakMsTUFBa0JrQyxhQUFhLEtBQUs7QUFDeEQsUUFBSUYsWUFBWUcsUUFBUW5DLElBQUksRUFBR29DLGNBQWFKLFlBQVlHLFFBQVFuQyxJQUFJLENBQUM7QUFDckUwQixlQUFXLENBQUNXLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNyQyxJQUFJLEdBQUcsS0FBSyxFQUFFO0FBQ2hEZ0MsZ0JBQVlHLFFBQVFuQyxJQUFJLElBQUlzQztBQUFBQSxNQUMxQixNQUFNWixXQUFXLENBQUNXLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNyQyxJQUFJLEdBQUcsTUFBTSxFQUFFO0FBQUEsTUFDdkRrQztBQUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBbkgsa0JBQWdCd0gsc0JBQXNCLE1BQU1OLGFBQWEsU0FBUyxHQUFHLEdBQU8sRUFBRU8sYUFBYSxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBQ3pHekgsa0JBQWdCd0gsc0JBQXNCLE1BQU1OLGFBQWEsUUFBUSxHQUFHLEdBQVEsRUFBRU8sYUFBYSxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBQ3pHekgsa0JBQWdCd0gsc0JBQXNCLE1BQU1OLGFBQWEsWUFBWSxHQUFHLEdBQUksRUFBRU8sYUFBYSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQ3ZHekgsa0JBQWdCd0gsc0JBQXNCLE1BQU1OLGFBQWEsU0FBUyxHQUFHLEdBQU8sRUFBRU8sYUFBYSxDQUFDLGFBQWEsRUFBRSxDQUFDO0FBQzVHekgsa0JBQWdCd0gsc0JBQXNCLE1BQU1OLGFBQWEsV0FBVyxHQUFHLEdBQUssRUFBRU8sYUFBYSxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBR3pHdEksY0FBWTtBQUFBLElBQ1Z1SSxNQUFNO0FBQUEsSUFDTkMsWUFBWTtBQUFBLElBQ1pDLFFBQVFBLE1BQU07QUFDWixVQUFJcEIsTUFBTXFCLFVBQVUsVUFBV3BCLFNBQVFxQixVQUFVO0FBQUEsSUFDbkQ7QUFBQSxFQUNGLENBQUM7QUFHRCxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSXZJLFNBQVMsS0FBSztBQUc1QyxRQUFNdUUsY0FBZSxDQUFDLFNBQVMsUUFBUSxZQUFZLFNBQVMsU0FBUyxFQUFtQmlFO0FBQUFBLElBQ3RGLENBQUNDLE1BQU0xQixNQUFNMEIsQ0FBQyxFQUFFdEgsV0FBVztBQUFBLEVBQzdCO0FBQ0EsUUFBTXVILGVBQWUzQixNQUFNNEIsYUFBYTVCLE1BQU00QixhQUFhM0csU0FBUyxDQUFDLEtBQUs7QUFDMUUsUUFBTTRHLGNBQWM3QixNQUFNOEIsZ0JBQWdCO0FBQzFDLFFBQU1DLGVBQWUvQixNQUFNOEIsZ0JBQWdCLE1BQU05QixNQUFNOEIsaUJBQWlCO0FBR3hFLE1BQUk5QixNQUFNcUIsVUFBVSxRQUFRO0FBQzFCLFdBQ0UsbUNBQ0U7QUFBQSw2QkFBQyxtQkFBZ0IsV0FBVSxnQkFDekIsaUNBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsK0JBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBR2pCLHVCQUFDLFNBQUksV0FBVSxvREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFHL0QsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU87QUFBQSxnQkFDTDNGLE9BQU87QUFBQSxnQkFDUDJCLFlBQVk7QUFBQSxjQUNkO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRTNCLE9BQU8sVUFBVTtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFQSxPQUFPLFdBQVdzRyxTQUFTLElBQUk7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixPQUFPLEVBQUVoRSxXQUFXLGlDQUFpQztBQUFBLFlBRXJEO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU8sRUFBRXRDLE9BQU8sVUFBVTtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNDcUUsS0FBS2tDLFVBQ0o7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTztBQUFBLG9CQUNMekYsU0FBUztBQUFBLG9CQUNUTixZQUFZO0FBQUEsb0JBQ1owQixjQUFjO0FBQUEsb0JBQ2RJLFdBQVc7QUFBQSxrQkFDYjtBQUFBLGtCQUVBLGlDQUFDLGNBQVcsT0FBTytCLEtBQUtrQyxTQUFTLE1BQU0sT0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkM7QUFBQTtBQUFBLGdCQVI3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwrRUFBNkUsMkJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVGLHVCQUFDLFNBQUksV0FBVSxXQUFVLE9BQU8sRUFBRXZHLE9BQU8sVUFBVSxHQUFFO0FBQUE7QUFBQSxnQkFDN0M7QUFBQSxnQkFDTix1QkFBQyxVQUFLLFdBQVUsYUFBWSxPQUFPLEVBQUVBLE9BQU8sVUFBVSxHQUNuRHFFLGVBQUttQyxVQUFVLE9BRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFQ25DLEtBQUtrQyxXQUNKO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQVk7QUFBQSxrQkFDWixPQUFPLEVBQUV4RixTQUFTLE9BQU87QUFBQSxrQkFDekIsZUFBWTtBQUFBLGtCQUVYc0QsZUFBS2tDO0FBQUFBO0FBQUFBLGdCQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUE7QUFBQTtBQUFBLFVBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTBDQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGtDQUFrQ2xDLGVBQUtvQyxRQUFRbEgsVUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RSx1QkFBQyxVQUFLLFdBQVUsa0JBQWlCLGlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQ2xDLHVCQUFDLFVBQUssV0FBVSx1QkFBc0IsT0FBTyxFQUFFUyxPQUFPLFVBQVUsR0FDN0RuQyxzQkFBWTZJLGNBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQyxPQUFPLEVBQUUxRyxPQUFPLFVBQVUsR0FBRSx5QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQ3FFLEtBQUtvQyxRQUFRbEgsU0FBUyxLQUNyQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTyxFQUFFUyxPQUFPLFdBQVd5QixlQUFlLFNBQVM7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBOUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnR0EsS0FqR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtHQTtBQUFBLE1BQ0EsdUJBQUMsb0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLFNBcEdqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUdBO0FBQUEsRUFFSjtBQUdBLE1BQUk2QyxNQUFNcUIsVUFBVSxTQUFTO0FBQzNCLFVBQU1nQixjQUFjQyxPQUFPQyxLQUFLdkMsTUFBTXdDLGVBQWUsRUFBRXZIO0FBQ3ZELFVBQU13SCxZQUFZSixlQUFlOUksWUFBWTZJO0FBRTdDLFdBQ0UsbUNBQ0U7QUFBQSw2QkFBQyxtQkFBZ0IsV0FBVSxnQkFDekIsaUNBQUMsU0FBSSxXQUFVLCtEQUdiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTW5DLFFBQVF5QyxVQUFVO0FBQUEsWUFDakMsT0FBTztBQUFBLGNBQ0wvRyxVQUFVO0FBQUEsY0FDVnVDLEtBQUs7QUFBQSxjQUNMeUUsT0FBTztBQUFBLGNBQ1B6RyxZQUFZO0FBQUEsY0FDWjJCLFFBQVE7QUFBQSxjQUNSbkMsT0FBTztBQUFBLGNBQ1BrQyxjQUFjO0FBQUEsY0FDZHBCLFNBQVM7QUFBQSxjQUNUUSxVQUFVO0FBQUEsY0FDVkUsWUFBWTtBQUFBLGNBQ1owRixRQUFRO0FBQUEsY0FDUnpGLGVBQWU7QUFBQSxZQUNqQjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQWE7QUFBQTtBQUFBLFVBakJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPLEVBQUV6QixPQUFPLFdBQVcyQixZQUFZLGdDQUFnQztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQXlDLE9BQU8sRUFBRTNCLE9BQU8sVUFBVSxHQUMvRTJHO0FBQUFBO0FBQUFBLFlBQVk7QUFBQSxZQUFJOUksWUFBWTZJO0FBQUFBLFlBQVc7QUFBQSxlQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdDckMsS0FBS2tDLFdBQ0osdUJBQUMsU0FBSSxPQUFPLEVBQUV6RixTQUFTLElBQUlOLFlBQVksU0FBUzBCLGNBQWMsRUFBRSxHQUM5RCxpQ0FBQyxjQUFXLE9BQU9tQyxLQUFLa0MsU0FBUyxNQUFNLE9BQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsdUNBQ1ovSSxvQkFBVW1CLElBQUksQ0FBQ29FLFNBQVM7QUFDdkIsZ0JBQU1vRSxtQkFBbUJQLE9BQU9RLFFBQVE5QyxNQUFNd0MsZUFBZSxFQUFFTztBQUFBQSxZQUM3RCxDQUFDLEdBQUdyQixDQUFDLE1BQU1BLE1BQU1qRDtBQUFBQSxVQUNuQixJQUFJLENBQUM7QUFDTCxnQkFBTXVFLFNBQVNqRCxLQUFLb0MsUUFBUVksS0FBSyxDQUFDaEgsTUFBTUEsRUFBRVgsT0FBT3lILGdCQUFnQjtBQUNqRSxnQkFBTUksU0FBUyxDQUFDLENBQUNKO0FBQ2pCLGdCQUFNbkgsUUFBUXZDLFlBQVlzRixJQUFJO0FBRTlCLGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxPQUFPO0FBQUEsZ0JBQ0xoQyxTQUFTO0FBQUEsZ0JBQ1RDLFlBQVk7QUFBQSxnQkFDWkUsS0FBSztBQUFBLGdCQUNMSixTQUFTO0FBQUEsZ0JBQ1RvQixjQUFjO0FBQUEsZ0JBQ2RDLFFBQVEsZUFBZW9GLFNBQVN2SCxRQUFRLE9BQU8sc0JBQXNCO0FBQUEsZ0JBQ3JFUSxZQUFZK0csU0FBU3ZILFFBQVEsT0FBTztBQUFBLGdCQUNwQ3FELFlBQVk7QUFBQSxnQkFDWmYsV0FBV2lGLFNBQVMsWUFBWXZILEtBQUssT0FBTztBQUFBLGNBQzlDO0FBQUEsY0FFQTtBQUFBLHVDQUFDLFVBQUssT0FBTyxFQUFFc0IsVUFBVSxHQUFHLEdBQUk1RCxxQkFBV3FGLElBQUksS0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUQ7QUFBQSxnQkFDakQsdUJBQUMsU0FBSSxPQUFPLEVBQUVRLE1BQU0sRUFBRSxHQUNwQjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU87QUFBQSx3QkFDTGpDLFVBQVU7QUFBQSx3QkFDVkUsWUFBWTtBQUFBLHdCQUNaRSxlQUFlO0FBQUEsd0JBQ2ZELGVBQWU7QUFBQSx3QkFDZnpCO0FBQUFBLHNCQUNGO0FBQUEsc0JBRUNyQyxzQkFBWW9GLElBQUk7QUFBQTtBQUFBLG9CQVRuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXpCLFVBQVUsSUFBSXRCLE9BQU8sVUFBVSxHQUFJcEMseUJBQWVtRixJQUFJLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNFO0FBQUEscUJBWnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUosV0FBVyxRQUFRLEdBQzlCNEUsbUJBQ0MsbUNBQ0U7QUFBQSx5Q0FBQyxTQUFJLE9BQU8sRUFBRWpHLFVBQVUsSUFBSUUsWUFBWSxLQUFLeEIsT0FBTyxVQUFVLEdBQUU7QUFBQTtBQUFBLG9CQUMzRHNILFFBQVFFLFNBQVM7QUFBQSx1QkFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFbEcsVUFBVSxHQUFHdEIsT0FBTyxXQUFXb0MsWUFBWSxtQkFBbUIsR0FDekUrRSw0QkFBa0JNLE1BQU0sR0FBRyxDQUFDLEtBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BLElBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsT0FBTztBQUFBLHNCQUNMbkcsVUFBVTtBQUFBLHNCQUNWdEIsT0FBTztBQUFBLHNCQUNQMEIsZUFBZTtBQUFBLHNCQUNmRCxlQUFlO0FBQUEsb0JBQ2pCO0FBQUEsb0JBQUU7QUFBQTtBQUFBLGtCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTQSxLQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNCQTtBQUFBO0FBQUE7QUFBQSxZQWxES3NCO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9EQTtBQUFBLFFBRUosQ0FBQyxLQWhFSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUVBO0FBQUEsUUFHQ2dFLFlBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTXhDLFFBQVFtRCxVQUFVO0FBQUEsWUFDakMsV0FBVTtBQUFBLFlBQ1YsT0FBTztBQUFBLGNBQ0xsSCxZQUFZO0FBQUEsY0FDWjJCLFFBQVE7QUFBQSxjQUNSRCxjQUFjO0FBQUEsY0FDZHBCLFNBQVM7QUFBQSxjQUNUUSxVQUFVO0FBQUEsY0FDVkUsWUFBWTtBQUFBLGNBQ1p4QixPQUFPO0FBQUEsY0FDUHlCLGVBQWU7QUFBQSxjQUNmQyxlQUFlO0FBQUEsY0FDZlksV0FBVztBQUFBLGNBQ1g0RSxRQUFRO0FBQUEsY0FDUjdELFlBQVk7QUFBQSxZQUNkO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JBLElBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVU7QUFBQSxZQUNWLE9BQU8sRUFBRXJELE9BQU8sV0FBV3lCLGVBQWUsVUFBVUMsZUFBZSxZQUFZO0FBQUEsWUFBRTtBQUFBO0FBQUEsY0FFdkU3RCxZQUFZNkksYUFBYUM7QUFBQUEsY0FBWTtBQUFBLGNBQWU5SSxZQUFZNkksYUFBYUMsZ0JBQWdCLElBQUksTUFBTTtBQUFBLGNBQUc7QUFBQTtBQUFBO0FBQUEsVUFKdEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQTlJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0pBLEtBakpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrSkE7QUFBQSxNQUNBLHVCQUFDLG9DQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxTQXBKakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFKQTtBQUFBLEVBRUo7QUFHQSxNQUFJckMsTUFBTXFCLFVBQVUsV0FBVztBQUM3QixVQUFNL0IsV0FBVztBQUFBLE1BQ2ZjLE9BQU9KLE1BQU1JLE1BQU1oRztBQUFBQSxNQUNuQmlHLE1BQU1MLE1BQU1LLEtBQUtqRztBQUFBQSxNQUNqQmtHLFVBQVVOLE1BQU1NLFNBQVNsRztBQUFBQSxNQUN6Qm1HLE9BQU9QLE1BQU1PLE1BQU1uRztBQUFBQSxNQUNuQm9HLFNBQVNSLE1BQU1RLFFBQVFwRztBQUFBQSxJQUN6QjtBQUVBLFdBQ0UsbUNBQ0U7QUFBQSw2QkFBQyxtQkFBZ0IsV0FBVSxnQkFDekI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxZQUNMcUMsU0FBUztBQUFBLFlBQ1RrQixlQUFlO0FBQUEsWUFDZjFCLFFBQVE7QUFBQSxZQUNSSixVQUFVO0FBQUEsWUFDVkYsVUFBVTtBQUFBLFVBQ1o7QUFBQSxVQUdBO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPO0FBQUEsa0JBQ0xjLFNBQVM7QUFBQSxrQkFDVEMsWUFBWTtBQUFBLGtCQUNaQyxnQkFBZ0I7QUFBQSxrQkFDaEJILFNBQVM7QUFBQSxrQkFDVE8sY0FBYztBQUFBLGtCQUNkYixZQUFZO0FBQUEsa0JBQ1ptSCxZQUFZO0FBQUEsZ0JBQ2Q7QUFBQSxnQkFFQTtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU87QUFBQSx3QkFDTHJHLFVBQVU7QUFBQSx3QkFDVkUsWUFBWTtBQUFBLHdCQUNaeEIsT0FBTztBQUFBLHdCQUNQMkIsWUFBWTtBQUFBLHdCQUNaRixlQUFlO0FBQUEsc0JBQ2pCO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFVixTQUFTLFFBQVFDLFlBQVksVUFBVUUsS0FBSyxHQUFHLEdBRTNEO0FBQUEsMkNBQUMsU0FBSSxPQUFPLEVBQUV5QixXQUFXLFNBQVMsR0FDaEM7QUFBQSw2Q0FBQyxTQUFJLE9BQU8sRUFBRXJCLFVBQVUsR0FBR3RCLE9BQU8sV0FBVzBCLGVBQWUsYUFBYUQsZUFBZSxRQUFRLEdBQUUsb0JBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXMEUsY0FBYyxpQkFBaUI7QUFBQSwwQkFDMUMsT0FBTztBQUFBLDRCQUNML0QsWUFBWTtBQUFBLDRCQUNaZCxVQUFVO0FBQUEsNEJBQ1ZFLFlBQVk7QUFBQSw0QkFDWnhCLE9BQU9tRyxjQUFjLFlBQVlFLGVBQWUsWUFBWTtBQUFBLDRCQUM1RGhELFlBQVk7QUFBQSwwQkFDZDtBQUFBLDBCQUVDdEYscUJBQVd1RyxNQUFNOEIsYUFBYTtBQUFBO0FBQUEsd0JBVmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFXQTtBQUFBLHlCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZ0JBO0FBQUEsb0JBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV6RCxXQUFXLFNBQVMsR0FDaEM7QUFBQSw2Q0FBQyxTQUFJLE9BQU8sRUFBRXJCLFVBQVUsR0FBR3RCLE9BQU8sV0FBVzBCLGVBQWUsYUFBYUQsZUFBZSxRQUFRLEdBQUUsOEJBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFPO0FBQUEsNEJBQ0xXLFlBQVk7QUFBQSw0QkFDWmQsVUFBVTtBQUFBLDRCQUNWRSxZQUFZO0FBQUEsNEJBQ1p4QixPQUFPekIsWUFBWStGLE1BQU1zRCxhQUFhO0FBQUEsNEJBQ3RDdkUsWUFBWTtBQUFBLDBCQUNkO0FBQUEsMEJBRUNpQjtBQUFBQSxrQ0FBTXNEO0FBQUFBLDRCQUFjO0FBQUE7QUFBQTtBQUFBLHdCQVR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBVUE7QUFBQSx5QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWVBO0FBQUEsb0JBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUVqRixXQUFXLFNBQVMsR0FDaEM7QUFBQSw2Q0FBQyxTQUFJLE9BQU8sRUFBRXJCLFVBQVUsR0FBR3RCLE9BQU8sV0FBVzBCLGVBQWUsYUFBYUQsZUFBZSxRQUFRLEdBQUUscUJBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFPO0FBQUEsNEJBQ0xXLFlBQVk7QUFBQSw0QkFDWmQsVUFBVTtBQUFBLDRCQUNWRSxZQUFZO0FBQUEsNEJBQ1p4QixPQUFPO0FBQUEsMEJBQ1Q7QUFBQSwwQkFFQ3NFLGdCQUFNdUQsVUFBVXJFLGVBQWU7QUFBQTtBQUFBLHdCQVJsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBU0E7QUFBQSx5QkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWNBO0FBQUEsdUJBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBc0RBO0FBQUE7QUFBQTtBQUFBLGNBOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQStFQTtBQUFBLFlBR0N5QyxnQkFBZ0IsdUJBQUMsZUFBWSxTQUFTQSxhQUFhcEYsV0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkM7QUFBQSxZQUc1RCx1QkFBQyxTQUFJLE9BQU8sRUFBRUMsU0FBUyxZQUFZNkcsWUFBWSxFQUFFLEdBQy9DO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTztBQUFBLGtCQUNMMUgsVUFBVTtBQUFBLGtCQUNWTSxRQUFRO0FBQUEsa0JBQ1IyQixjQUFjO0FBQUEsa0JBQ2QxQixZQUFZO0FBQUEsa0JBQ1pMLFVBQVU7QUFBQSxnQkFDWjtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPO0FBQUEsc0JBQ0xGLFVBQVU7QUFBQSxzQkFDVkMsT0FBTztBQUFBLHNCQUNQSSxPQUFPLEdBQUdnRSxNQUFNc0QsYUFBYTtBQUFBLHNCQUM3QjFGLGNBQWM7QUFBQSxzQkFDZDFCLFlBQVksMEJBQTBCakMsWUFBWStGLE1BQU1zRCxhQUFhLENBQUMsT0FBT3JKLFlBQVkrRixNQUFNc0QsYUFBYSxDQUFDO0FBQUEsc0JBQzdHdEYsV0FBVyxZQUFZL0QsWUFBWStGLE1BQU1zRCxhQUFhLENBQUM7QUFBQSxvQkFDekQ7QUFBQTtBQUFBLGtCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTSTtBQUFBO0FBQUEsY0FsQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBLEtBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFHQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU87QUFBQSxrQkFDTDNILFVBQVU7QUFBQSxrQkFDVnNELE1BQU07QUFBQSxrQkFDTnVFLFdBQVc7QUFBQSxnQkFDYjtBQUFBLGdCQUdBO0FBQUEseUNBQUMsbUJBQWdCLFNBQWtCLFlBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNEO0FBQUEsa0JBR3RELHVCQUFDLFNBQUksT0FBTyxFQUFFN0gsVUFBVSxZQUFZdUMsS0FBSyxNQUFNN0MsTUFBTSxLQUFLLEdBQ3hEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxVQUFVMkUsTUFBTUksTUFBTTFCO0FBQUFBLHNCQUN0QixRQUFRc0IsTUFBTUksTUFBTWhHO0FBQUFBLHNCQUNwQixPQUFPNEYsTUFBTUksTUFBTXpCO0FBQUFBLHNCQUNuQixVQUFVVSxRQUFRZTtBQUFBQTtBQUFBQSxvQkFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUswQixLQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUV6RSxVQUFVLFlBQVl1QyxLQUFLLE1BQU15RSxPQUFPLEtBQUssR0FDekQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFVBQVUzQyxNQUFNSyxLQUFLM0I7QUFBQUEsc0JBQ3JCLFFBQVFzQixNQUFNSyxLQUFLakc7QUFBQUEsc0JBQ25CLE9BQU80RixNQUFNSyxLQUFLMUI7QUFBQUEsc0JBQ2xCLFVBQVVVLFFBQVFnQjtBQUFBQTtBQUFBQSxvQkFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUt5QixLQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxPQUFPLEVBQUUxRSxVQUFVLFlBQVlMLFFBQVEsT0FBT0QsTUFBTSxLQUFLLEdBQzVEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxVQUFVMkUsTUFBTU0sU0FBUzVCO0FBQUFBLHNCQUN6QixRQUFRc0IsTUFBTU0sU0FBU2xHO0FBQUFBLHNCQUN2QixPQUFPNEYsTUFBTU0sU0FBUzNCO0FBQUFBLHNCQUN0QixVQUFVVSxRQUFRaUI7QUFBQUE7QUFBQUEsb0JBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLNkIsS0FOL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksT0FBTyxFQUFFM0UsVUFBVSxZQUFZTCxRQUFRLE9BQU9xSCxPQUFPLEtBQUssR0FDN0Q7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFVBQVUzQyxNQUFNTyxNQUFNN0I7QUFBQUEsc0JBQ3RCLFFBQVFzQixNQUFNTyxNQUFNbkc7QUFBQUEsc0JBQ3BCLE9BQU80RixNQUFNTyxNQUFNNUI7QUFBQUEsc0JBQ25CLFVBQVVVLFFBQVFrQjtBQUFBQTtBQUFBQSxvQkFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUswQixLQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBR0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTztBQUFBLHdCQUNMNUUsVUFBVTtBQUFBLHdCQUNWTCxRQUFRO0FBQUEsd0JBQ1JELE1BQU07QUFBQSx3QkFDTm9JLFdBQVc7QUFBQSxzQkFDYjtBQUFBLHNCQUVBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxVQUFVekQsTUFBTVEsUUFBUTlCO0FBQUFBLDBCQUN4QixRQUFRc0IsTUFBTVEsUUFBUXBHO0FBQUFBLDBCQUN0QixPQUFPNEYsTUFBTVEsUUFBUTdCO0FBQUFBLDBCQUNyQixVQUFVVSxRQUFRbUI7QUFBQUEsMEJBQ2xCLE9BQ0U7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsT0FBTztBQUFBLGdDQUNMbkMsV0FBVztBQUFBLGdDQUNYUCxZQUFZO0FBQUEsZ0NBQ1pkLFVBQVU7QUFBQSxnQ0FDVkUsWUFBWTtBQUFBLGdDQUNaeEIsT0FDRXNFLE1BQU1RLFFBQVEvQyxlQUFlbEUsWUFBWW1LLGlCQUNyQyxZQUNBMUQsTUFBTVEsUUFBUS9DLGNBQWMsS0FDMUIsWUFDQTtBQUFBLDhCQUNWO0FBQUEsOEJBRUN1QztBQUFBQSxzQ0FBTVEsUUFBUS9DLFlBQVlhLFFBQVEsQ0FBQztBQUFBLGdDQUFFO0FBQUE7QUFBQTtBQUFBLDRCQWR4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBZUE7QUFBQTtBQUFBLHdCQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBdUJHO0FBQUE7QUFBQSxvQkEvQkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWlDQTtBQUFBLGtCQUdBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU87QUFBQSx3QkFDTDNDLFVBQVU7QUFBQSx3QkFDVnVDLEtBQUs7QUFBQSx3QkFDTDdDLE1BQU07QUFBQSx3QkFDTm9JLFdBQVc7QUFBQSx3QkFDWHhHLFFBQVE7QUFBQSxzQkFDVjtBQUFBLHNCQUVBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFFBQVErQyxNQUFNc0Q7QUFBQUEsMEJBQ2Q7QUFBQSwwQkFDQSxhQUFhdEQsTUFBTVEsUUFBUS9DO0FBQUFBO0FBQUFBLHdCQUg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBR3lDO0FBQUE7QUFBQSxvQkFaM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWNBO0FBQUE7QUFBQTtBQUFBLGNBekdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTBHQTtBQUFBLFlBR0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNK0QsV0FBVyxDQUFDbUMsTUFBTSxDQUFDQSxDQUFDO0FBQUEsZ0JBQ25DLFdBQVU7QUFBQSxnQkFDVixPQUFPO0FBQUEsa0JBQ0xoSSxVQUFVO0FBQUEsa0JBQ1ZMLFFBQVE7QUFBQSxrQkFDUnFILE9BQU87QUFBQSxrQkFDUHpHLFlBQVk7QUFBQSxrQkFDWjJCLFFBQVE7QUFBQSxrQkFDUkQsY0FBYztBQUFBLGtCQUNkcEIsU0FBUztBQUFBLGtCQUNUUSxVQUFVO0FBQUEsa0JBQ1Z0QixPQUFPO0FBQUEsa0JBQ1BrSCxRQUFRO0FBQUEsa0JBQ1IzRixRQUFRO0FBQUEsa0JBQ1JFLGVBQWU7QUFBQSxrQkFDZkQsWUFBWTtBQUFBLGdCQUNkO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGtCQUVFcUUsVUFBVSxVQUFVO0FBQUE7QUFBQTtBQUFBLGNBcEIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFxQkE7QUFBQSxZQUVDQSxXQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTztBQUFBLGtCQUNMNUYsVUFBVTtBQUFBLGtCQUNWTCxRQUFRO0FBQUEsa0JBQ1JxSCxPQUFPO0FBQUEsa0JBQ1B6RyxZQUFZO0FBQUEsa0JBQ1oyQixRQUFRO0FBQUEsa0JBQ1JELGNBQWM7QUFBQSxrQkFDZHBCLFNBQVM7QUFBQSxrQkFDVFMsUUFBUTtBQUFBLGtCQUNSUixTQUFTO0FBQUEsa0JBQ1RrQixlQUFlO0FBQUEsa0JBQ2ZmLEtBQUs7QUFBQSxrQkFDTGdILFVBQVU7QUFBQSxrQkFDVjVFLGdCQUFnQjtBQUFBLGdCQUNsQjtBQUFBLGdCQUVBO0FBQUEseUNBQUMsU0FBSSxPQUFPLEVBQUVoQyxVQUFVLEdBQUd0QixPQUFPLFdBQVd3QixZQUFZLEtBQUtDLGVBQWUsU0FBU0MsZUFBZSxZQUFZLEdBQUUsaUNBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRVgsU0FBUyxRQUFRb0gscUJBQXFCLFdBQVdqSCxLQUFLLEVBQUUsR0FDbEU7QUFBQSxxQkFBQyxTQUFTLFFBQVEsWUFBWSxPQUFPLEVBQW1CdkM7QUFBQUEsc0JBQUksQ0FBQ29FLFNBQzdEO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUVDLE1BQUs7QUFBQSwwQkFDTCxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNO0FBQ2IsZ0NBQUlBLFNBQVMsUUFBU3dCLFNBQVE2RCxrQkFBa0IsRUFBRUMsUUFBUXhLLFlBQVl5SyxtQkFBbUIsQ0FBQztBQUMxRixnQ0FBSXZGLFNBQVMsT0FBUXdCLFNBQVFnRSxpQkFBaUIsRUFBRUYsUUFBUXhLLFlBQVl5SyxtQkFBbUIsQ0FBQztBQUN4RixnQ0FBSXZGLFNBQVMsV0FBWXdCLFNBQVFpRSxxQkFBcUIsRUFBRUgsUUFBUXhLLFlBQVl5SyxtQkFBbUIsQ0FBQztBQUNoRyxnQ0FBSXZGLFNBQVMsUUFBU3dCLFNBQVFrRSxrQkFBa0IsRUFBRUosUUFBUXhLLFlBQVl5SyxtQkFBbUIsQ0FBQztBQUFBLDBCQUM1RjtBQUFBLDBCQUNBLE9BQU87QUFBQSw0QkFDTDlILFlBQVkvQyxZQUFZc0YsSUFBSSxJQUFJO0FBQUEsNEJBQ2hDWixRQUFRLGFBQWExRSxZQUFZc0YsSUFBSSxDQUFDO0FBQUEsNEJBQ3RDYixjQUFjO0FBQUEsNEJBQ2RwQixTQUFTO0FBQUEsNEJBQ1RRLFVBQVU7QUFBQSw0QkFDVnRCLE9BQU92QyxZQUFZc0YsSUFBSTtBQUFBLDRCQUN2Qm1FLFFBQVE7QUFBQSw0QkFDUjFGLFlBQVk7QUFBQSw0QkFDWm1CLFdBQVc7QUFBQSwwQkFDYjtBQUFBLDBCQUVDakY7QUFBQUEsdUNBQVdxRixJQUFJO0FBQUEsNEJBQUU7QUFBQSw0QkFBR2xGLFlBQVl5SztBQUFBQSw0QkFBbUI7QUFBQTtBQUFBO0FBQUEsd0JBckIvQ3ZGO0FBQUFBLHdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBdUJBO0FBQUEsb0JBQ0Q7QUFBQSxvQkFDRDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTXdCLFFBQVFtRSxrQkFBa0IsRUFBRTNHLGFBQWE3RCxLQUFLeUssSUFBSSxJQUFJckUsTUFBTVEsUUFBUS9DLGNBQWMsQ0FBQyxFQUFFLENBQUM7QUFBQSx3QkFDckcsT0FBTztBQUFBLDBCQUNMdkIsWUFBWTtBQUFBLDBCQUNaMkIsUUFBUTtBQUFBLDBCQUNSRCxjQUFjO0FBQUEsMEJBQ2RwQixTQUFTO0FBQUEsMEJBQ1RRLFVBQVU7QUFBQSwwQkFDVnRCLE9BQU87QUFBQSwwQkFDUGtILFFBQVE7QUFBQSwwQkFDUjFGLFlBQVk7QUFBQSwwQkFDWm1CLFdBQVc7QUFBQSx3QkFDYjtBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaUJBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU00QixRQUFReUMsVUFBVTtBQUFBLHdCQUNqQyxPQUFPO0FBQUEsMEJBQ0x4RyxZQUFZO0FBQUEsMEJBQ1oyQixRQUFRO0FBQUEsMEJBQ1JELGNBQWM7QUFBQSwwQkFDZHBCLFNBQVM7QUFBQSwwQkFDVFEsVUFBVTtBQUFBLDBCQUNWdEIsT0FBTztBQUFBLDBCQUNQa0gsUUFBUTtBQUFBLDBCQUNSMUYsWUFBWTtBQUFBLHdCQUNkO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFnQkE7QUFBQSx1QkE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4REE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUYsVUFBVSxHQUFHdEIsT0FBTyxVQUFVLEdBQ3pDcUU7QUFBQUEseUJBQUtvQyxRQUFRbEg7QUFBQUEsb0JBQU87QUFBQSxvQkFBa0JxSCxPQUFPQyxLQUFLdkMsTUFBTXdDLGVBQWUsRUFBRXZIO0FBQUFBLG9CQUFPO0FBQUEsdUJBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FyRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBc0ZBO0FBQUE7QUFBQTtBQUFBLFFBblZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXFWQSxLQXRWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdVZBO0FBQUEsTUFDQSx1QkFBQyxvQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsU0F6VmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwVkE7QUFBQSxFQUVKO0FBR0EsU0FBTyx1QkFBQyxlQUFZLE9BQWMsV0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUNyRDtBQUVBNkUsR0F0cUJnQkQsVUFBUTtBQUFBLFVBQ1RuSCxlQUNDYyxpQkFDRUEsZ0JBQWdCMEcsWUFpQmhDMUcsZ0JBQWdCd0gsdUJBQ2hCeEgsZ0JBQWdCd0gsdUJBQ2hCeEgsZ0JBQWdCd0gsdUJBQ2hCeEgsZ0JBQWdCd0gsdUJBQ2hCeEgsZ0JBQWdCd0gsdUJBR2hCckksV0FBVztBQUFBO0FBQUEsTUEzQkdrSDtBQXdxQmhCLFNBQVN5RSxZQUFZO0FBQUEsRUFDbkJ0RTtBQUFBQSxFQUNBQztBQUlGLEdBQUc7QUFBQXNFLE1BQUE7QUFDRCxRQUFNQyxVQUFVeEUsTUFBTXlFLGdCQUFnQjtBQUN0QyxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSTFMO0FBQUFBLElBQ3BDdUwsVUFBVSxjQUFjO0FBQUEsRUFDMUI7QUFFQXpMLFlBQVUsTUFBTTtBQUNkLFFBQUl5TCxTQUFTO0FBQ1gsWUFBTUksSUFBSTdELFdBQVcsTUFBTTRELGVBQWUsVUFBVSxHQUFHLElBQUk7QUFDM0QsYUFBTyxNQUFNOUQsYUFBYStELENBQUM7QUFBQSxJQUM3QjtBQUFBLEVBQ0YsR0FBRyxDQUFDSixPQUFPLENBQUM7QUFFWixRQUFNSyxjQUFjdEwsWUFBWXVMO0FBRWhDLFFBQU1DLGNBQWM3TCxVQUFVbUIsSUFBSSxDQUFDb0UsU0FBUztBQUMxQyxVQUFNdUcsT0FBT2hGLE1BQU12QixJQUFJO0FBQ3ZCLFVBQU13RyxTQUFTRCxLQUFLdEcsWUFBWW1HO0FBQ2hDLFdBQU8sRUFBRXBHLE1BQU1DLFVBQVVzRyxLQUFLdEcsVUFBVUMsT0FBT3FHLEtBQUtyRyxPQUFPc0csT0FBTztBQUFBLEVBQ3BFLENBQUM7QUFHRCxNQUFJUCxnQkFBZ0IsYUFBYTtBQUMvQixXQUNFLG1DQUNFO0FBQUEsNkJBQUMsbUJBQWdCLFdBQVUsZ0JBQ3pCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPO0FBQUEsWUFDTGpJLFNBQVM7QUFBQSxZQUNUa0IsZUFBZTtBQUFBLFlBQ2ZqQixZQUFZO0FBQUEsWUFDWkMsZ0JBQWdCO0FBQUEsWUFDaEJWLFFBQVE7QUFBQSxZQUNSVyxLQUFLO0FBQUEsWUFDTEosU0FBUztBQUFBLFVBQ1g7QUFBQSxVQUVBO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPO0FBQUEsa0JBQ0xRLFVBQVU7QUFBQSxrQkFDVkUsWUFBWTtBQUFBLGtCQUNaQyxlQUFlO0FBQUEsa0JBQ2Z6QixPQUFPO0FBQUEsa0JBQ1AyQixZQUFZO0FBQUEsa0JBQ1pnQixXQUFXO0FBQUEsZ0JBQ2I7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPO0FBQUEsa0JBQ0xyQixVQUFVO0FBQUEsa0JBQ1Z0QixPQUFPO0FBQUEsa0JBQ1B5QixlQUFlO0FBQUEsa0JBQ2ZDLGVBQWU7QUFBQSxrQkFDZlAsV0FBVztBQUFBLGdCQUNiO0FBQUEsZ0JBQUU7QUFBQTtBQUFBLGNBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxZQUdBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTztBQUFBLGtCQUNMYixPQUFPO0FBQUEsa0JBQ1BFLFlBQVk7QUFBQSxrQkFDWjBCLGNBQWM7QUFBQSxrQkFDZDNCLFFBQVE7QUFBQSxrQkFDUkosVUFBVTtBQUFBLGtCQUNWZ0MsUUFBUTtBQUFBLGtCQUNSRyxXQUFXO0FBQUEsZ0JBQ2I7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPO0FBQUEsc0JBQ0wvQixRQUFRO0FBQUEsc0JBQ1IyQixjQUFjO0FBQUEsc0JBQ2QxQixZQUFZO0FBQUEsc0JBQ1o4QixXQUFXO0FBQUEsc0JBQ1huQixXQUFXO0FBQUEsb0JBQ2I7QUFBQTtBQUFBLGtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPSTtBQUFBO0FBQUEsY0FsQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLE9BQU8sRUFBRUcsVUFBVSxHQUFHLEdBQUcsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUE7QUFBQTtBQUFBLFFBMURsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEyREEsS0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZEQTtBQUFBLE1BQ0EsdUJBQUMsb0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLFNBL0RqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0VBO0FBQUEsRUFFSjtBQUdBLFNBQ0UsbUNBQ0U7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFVBQ0xkLFlBQVlzSSxVQUNSLDhFQUNBO0FBQUEsUUFDTjtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNML0gsU0FBUztBQUFBLGNBQ1RrQixlQUFlO0FBQUEsY0FDZmpCLFlBQVk7QUFBQSxjQUNaQyxnQkFBZ0I7QUFBQSxjQUNoQlYsUUFBUTtBQUFBLGNBQ1JXLEtBQUs7QUFBQSxjQUNMSixTQUFTO0FBQUEsY0FDVFgsVUFBVTtBQUFBLFlBQ1o7QUFBQSxZQUdBO0FBQUEscUNBQUMsU0FBSSxXQUFVLGlCQUFnQixPQUFPLEVBQUV3QyxXQUFXLFNBQVMsR0FDMUQ7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPO0FBQUEsc0JBQ0xyQixVQUFVO0FBQUEsc0JBQ1ZFLFlBQVk7QUFBQSxzQkFDWkMsZUFBZTtBQUFBLHNCQUNmekIsT0FBTzhJLFVBQVUsWUFBWTtBQUFBLHNCQUM3Qm5ILFlBQVltSCxVQUNSLGtDQUNBO0FBQUEsc0JBQ0p6RyxZQUFZO0FBQUEsb0JBQ2Q7QUFBQSxvQkFFQ3lHLG9CQUFVLHlCQUF5QjtBQUFBO0FBQUEsa0JBWnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU87QUFBQSxzQkFDTHJHLFdBQVc7QUFBQSxzQkFDWG5CLFVBQVU7QUFBQSxzQkFDVkUsWUFBWTtBQUFBLHNCQUNaeEIsT0FBTzhJLFVBQVUsWUFBWTtBQUFBLHNCQUM3QnJILGVBQWU7QUFBQSxzQkFDZkMsZUFBZTtBQUFBLG9CQUNqQjtBQUFBLG9CQUVDb0gsb0JBQVUsNkJBQTZCO0FBQUE7QUFBQSxrQkFWMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVdBO0FBQUEsbUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkJBO0FBQUEsY0FHQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTztBQUFBLG9CQUNML0gsU0FBUztBQUFBLG9CQUNURyxLQUFLO0FBQUEsb0JBQ0xWLFlBQVk7QUFBQSxvQkFDWjJCLFFBQVE7QUFBQSxvQkFDUkQsY0FBYztBQUFBLG9CQUNkcEIsU0FBUztBQUFBLGtCQUNYO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxTQUFJLE9BQU8sRUFBRTZCLFdBQVcsU0FBUyxHQUNoQztBQUFBLDZDQUFDLFNBQUksT0FBTyxFQUFFckIsVUFBVSxJQUFJdEIsT0FBTyxXQUFXMEIsZUFBZSxhQUFhRCxlQUFlLFFBQVEsR0FBRSw4QkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE9BQU87QUFBQSw0QkFDTFcsWUFBWTtBQUFBLDRCQUNaZCxVQUFVO0FBQUEsNEJBQ1ZFLFlBQVk7QUFBQSw0QkFDWnhCLE9BQU96QixZQUFZK0YsTUFBTXNELGFBQWE7QUFBQSwwQkFDeEM7QUFBQSwwQkFFQ3REO0FBQUFBLGtDQUFNc0Q7QUFBQUEsNEJBQWM7QUFBQTtBQUFBO0FBQUEsd0JBUnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFTQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBY0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLE9BQU8sRUFBRXRILE9BQU8sR0FBR0UsWUFBWSx1QkFBdUIsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkQ7QUFBQSxvQkFDN0QsdUJBQUMsU0FBSSxPQUFPLEVBQUVtQyxXQUFXLFNBQVMsR0FDaEM7QUFBQSw2Q0FBQyxTQUFJLE9BQU8sRUFBRXJCLFVBQVUsSUFBSXRCLE9BQU8sV0FBVzBCLGVBQWUsYUFBYUQsZUFBZSxRQUFRLEdBQUUsMEJBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFPO0FBQUEsNEJBQ0xXLFlBQVk7QUFBQSw0QkFDWmQsVUFBVTtBQUFBLDRCQUNWRSxZQUFZO0FBQUEsNEJBQ1p4QixPQUFPO0FBQUEsMEJBQ1Q7QUFBQSwwQkFFQ3NFLGdCQUFNdUQsVUFBVXJFLGVBQWU7QUFBQTtBQUFBLHdCQVJsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBU0E7QUFBQSx5QkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWNBO0FBQUE7QUFBQTtBQUFBLGdCQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EwQ0E7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPO0FBQUEsb0JBQ0x6QyxTQUFTO0FBQUEsb0JBQ1RvSCxxQkFBcUI7QUFBQSxvQkFDckJqSCxLQUFLO0FBQUEsb0JBQ0xaLE9BQU87QUFBQSxvQkFDUGtKLFVBQVU7QUFBQSxrQkFDWjtBQUFBLGtCQUVDSCxzQkFBWTFLLElBQUksQ0FBQyxFQUFFb0UsTUFBTUMsVUFBVXVHLE9BQU8sTUFBTTtBQUMvQywwQkFBTXZKLFFBQVF2QyxZQUFZc0YsSUFBSTtBQUM5QiwyQkFDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxPQUFPO0FBQUEsMEJBQ0xKLFdBQVc7QUFBQSwwQkFDWG5DLFlBQVkrSSxTQUFTdkosUUFBUSxPQUFPO0FBQUEsMEJBQ3BDbUMsUUFBUSxlQUFlb0gsU0FBU3ZKLFFBQVEsT0FBTyxxQkFBcUI7QUFBQSwwQkFDcEVrQyxjQUFjO0FBQUEsMEJBQ2RwQixTQUFTO0FBQUEsd0JBQ1g7QUFBQSx3QkFFQTtBQUFBLGlEQUFDLFNBQUksT0FBTyxFQUFFUSxVQUFVLElBQUltSSxjQUFjLEVBQUUsR0FBSS9MLHFCQUFXcUYsSUFBSSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpRTtBQUFBLDBCQUNqRTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxPQUFPO0FBQUEsZ0NBQ0x6QixVQUFVO0FBQUEsZ0NBQ1Z0QixPQUFPdUosU0FBU3ZKLFFBQVE7QUFBQSxnQ0FDeEJ3QixZQUFZO0FBQUEsZ0NBQ1pFLGVBQWU7QUFBQSxnQ0FDZkQsZUFBZTtBQUFBLGdDQUNmZ0ksY0FBYztBQUFBLDhCQUNoQjtBQUFBLDhCQUVDOUwsc0JBQVlvRixJQUFJLEVBQUUyRyxRQUFRLGFBQWEsRUFBRTtBQUFBO0FBQUEsNEJBVjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFXQTtBQUFBLDBCQUNBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLE9BQU87QUFBQSxnQ0FDTHRILFlBQVk7QUFBQSxnQ0FDWmQsVUFBVTtBQUFBLGdDQUNWRSxZQUFZO0FBQUEsZ0NBQ1p4QixPQUFPdUosU0FBU3ZKLFFBQVE7QUFBQSw4QkFDMUI7QUFBQSw4QkFFQ2dEO0FBQUFBO0FBQUFBLGdDQUFTO0FBQUE7QUFBQTtBQUFBLDRCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFTQTtBQUFBLDBCQUNBLHVCQUFDLFNBQUksT0FBTyxFQUFFMUIsVUFBVSxJQUFJbUIsV0FBVyxFQUFFLEdBQUk4RyxtQkFBUyxNQUFNLE9BQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdFO0FBQUE7QUFBQTtBQUFBLHNCQWhDM0R4RztBQUFBQSxzQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWtDQTtBQUFBLGtCQUVKLENBQUM7QUFBQTtBQUFBLGdCQWpESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FrREE7QUFBQSxjQUdDLENBQUMrRixXQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPO0FBQUEsb0JBQ0w5SSxPQUFPO0FBQUEsb0JBQ1BzQixVQUFVO0FBQUEsb0JBQ1ZFLFlBQVk7QUFBQSxvQkFDWkMsZUFBZTtBQUFBLG9CQUNmQyxlQUFlO0FBQUEsb0JBQ2ZsQixZQUFZO0FBQUEsb0JBQ1oyQixRQUFRO0FBQUEsb0JBQ1JELGNBQWM7QUFBQSxvQkFDZHBCLFNBQVM7QUFBQSxrQkFDWDtBQUFBLGtCQUVDd0QsZ0JBQU1zRCxnQkFBZ0IvSixZQUFZOEwsMEJBQy9CLGtCQUFrQnJGLE1BQU1zRCxhQUFhLGdCQUFnQi9KLFlBQVk4TCx1QkFBdUIsTUFDeEYsdUJBQXVCOUwsWUFBWXVMLG1CQUFtQixPQUNwREMsWUFBWWhDLEtBQUssQ0FBQ3ZELE1BQU0sQ0FBQ0EsRUFBRXlGLE1BQU0sSUFDN0I1TCxZQUFZMEwsWUFBWWhDLEtBQUssQ0FBQ3ZELE1BQU0sQ0FBQ0EsRUFBRXlGLE1BQU0sRUFBR3hHLElBQUksSUFDcEQsU0FBUztBQUFBO0FBQUEsZ0JBbkJyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FxQkE7QUFBQSxjQUlGO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU13QixRQUFReUMsVUFBVTtBQUFBLGtCQUNqQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTztBQUFBLG9CQUNMeEcsWUFBWXNJLFVBQ1IsOENBQ0E7QUFBQSxvQkFDSjNHLFFBQVE7QUFBQSxvQkFDUkQsY0FBYztBQUFBLG9CQUNkcEIsU0FBUztBQUFBLG9CQUNUUSxVQUFVO0FBQUEsb0JBQ1ZFLFlBQVk7QUFBQSxvQkFDWnhCLE9BQU87QUFBQSxvQkFDUHlCLGVBQWU7QUFBQSxvQkFDZkMsZUFBZTtBQUFBLG9CQUNmd0YsUUFBUTtBQUFBLG9CQUNSNUUsV0FBV3dHLFVBQ1Asa0NBQ0E7QUFBQSxrQkFDTjtBQUFBLGtCQUVDQSxvQkFBVSxrQkFBa0I7QUFBQTtBQUFBLGdCQXRCL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdUJBO0FBQUE7QUFBQTtBQUFBLFVBOUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQStMQTtBQUFBO0FBQUEsTUF0TUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdU1BO0FBQUEsSUFDQSx1QkFBQyxvQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsT0F6TWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwTUE7QUFFSjtBQUFDRCxJQWhUUUQsYUFBVztBQUFBLE1BQVhBO0FBQVcsSUFBQWpJLElBQUFpQixLQUFBaUIsS0FBQVksS0FBQVMsS0FBQTBGLEtBQUFDO0FBQUEsYUFBQWxKLElBQUE7QUFBQSxhQUFBaUIsS0FBQTtBQUFBLGFBQUFpQixLQUFBO0FBQUEsYUFBQVksS0FBQTtBQUFBLGFBQUFTLEtBQUE7QUFBQSxhQUFBMEYsS0FBQTtBQUFBLGFBQUFDLEtBQUEiLCJuYW1lcyI6WyJ1c2VBaXJKYW1Ib3N0IiwidXNlSG9zdFRpY2siLCJIb3N0UHJldmlld0NvbnRyb2xsZXJXb3Jrc3BhY2UiLCJSb29tUXJDb2RlIiwiU3VyZmFjZVZpZXdwb3J0IiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJBTExfUk9MRVMiLCJST0xFX0NPTE9SUyIsIlJPTEVfSUNPTlMiLCJST0xFX0xBQkVMUyIsIlJPTEVfTUlOSV9HQU1FIiwiR0FNRV9DT05GSUciLCJ1c2VGYWN0b3J5U3RvcmUiLCJmb3JtYXRUaW1lIiwic2Vjb25kcyIsIm0iLCJNYXRoIiwiZmxvb3IiLCJ0b1N0cmluZyIsInBhZFN0YXJ0IiwicyIsImhlYWx0aENvbG9yIiwiaGVhbHRoIiwic3RhdHVzQ29sb3IiLCJzdGF0dXMiLCJtYXAiLCJpbmFjdGl2ZSIsIndvcmtpbmciLCJzdGFibGUiLCJjb21wbGV0ZSIsIndhcm5pbmciLCJjcml0aWNhbCIsImZhaWxlZCIsIkFtYmllbnRQYXJ0aWNsZXMiLCJwYXJ0aWNsZXMiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfIiwiaSIsImlkIiwibGVmdCIsImJvdHRvbSIsImR1cmF0aW9uIiwiZGVsYXkiLCJzaXplIiwiY29sb3IiLCJwb3NpdGlvbiIsImluc2V0Iiwib3ZlcmZsb3ciLCJwb2ludGVyRXZlbnRzIiwicCIsIndpZHRoIiwiaGVpZ2h0IiwiYmFja2dyb3VuZCIsImFuaW1hdGlvbkR1cmF0aW9uIiwiYW5pbWF0aW9uRGVsYXkiLCJfYyIsIkV2ZW50QmFubmVyIiwibWVzc2FnZSIsInBhZGRpbmciLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiZ2FwIiwiYW5pbWF0aW9uIiwiYm9yZGVyVG9wIiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJ6SW5kZXgiLCJmb250V2VpZ2h0IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJ0ZXh0U2hhZG93IiwiX2MyIiwiQUlDb3JlIiwiYWxsQ29tcGxldGUiLCJ0ZW1wZXJhdHVyZSIsImNvcmVDb2xvciIsImZsZXhEaXJlY3Rpb24iLCJib3JkZXJSYWRpdXMiLCJib3JkZXIiLCJmb250RmFtaWx5IiwibGluZUhlaWdodCIsImJveFNoYWRvdyIsInRyYW5zZm9ybU9yaWdpbiIsInRvcCIsIm1hcmdpblRvcCIsIm1hcmdpbkxlZnQiLCJ0ZXh0QWxpZ24iLCJ0b0ZpeGVkIiwiX2MzIiwiRGVwdFBhbmVsIiwicm9sZSIsInByb2dyZXNzIiwic2NvcmUiLCJleHRyYSIsImZsYXNoaW5nIiwiaXNDb21wbGV0ZSIsInRyYW5zaXRpb24iLCJiYWNrZHJvcEZpbHRlciIsImZsZXgiLCJ0b0xvY2FsZVN0cmluZyIsIl9jNCIsIlBpcGVsaW5lT3ZlcmxheSIsImZsYXNoZXMiLCJzdGF0dXNlcyIsInBhdGhzIiwiZCIsImlzRmxhc2hpbmciLCJpc0FjdGl2ZSIsImZpbHRlciIsIl9jNSIsIkhvc3RWaWV3IiwiX3MiLCJob3N0Iiwic3RhdGUiLCJhY3Rpb25zIiwidXNlQWN0aW9ucyIsInNldEZsYXNoZXMiLCJwb3dlciIsImRhdGEiLCJzZWN1cml0eSIsIm1vZGVsIiwiY29vbGluZyIsImZsYXNoVGltZXJzIiwidHJpZ2dlckZsYXNoIiwiZHVyYXRpb25NcyIsImN1cnJlbnQiLCJjbGVhclRpbWVvdXQiLCJwcmV2Iiwic2V0VGltZW91dCIsInVzZUhvc3RBY3Rpb25MaXN0ZW5lciIsImFjdGlvbk5hbWVzIiwibW9kZSIsImludGVydmFsTXMiLCJvblRpY2siLCJwaGFzZSIsInRpY2tUaW1lciIsImRldk9wZW4iLCJzZXREZXZPcGVuIiwiZXZlcnkiLCJyIiwiY3VycmVudEV2ZW50IiwiYWN0aXZlRXZlbnRzIiwidGltZXJEYW5nZXIiLCJ0aW1lUmVtYWluaW5nIiwidGltZXJXYXJuaW5nIiwib3BhY2l0eSIsImpvaW5VcmwiLCJyb29tSWQiLCJwbGF5ZXJzIiwibWF4UGxheWVycyIsInBsYXllckNvdW50IiwiT2JqZWN0Iiwia2V5cyIsInJvbGVBc3NpZ25tZW50cyIsImFsbEZpbGxlZCIsInJlc2V0R2FtZSIsInJpZ2h0IiwiY3Vyc29yIiwiYXNzaWduZWRQbGF5ZXJJZCIsImVudHJpZXMiLCJmaW5kIiwicGxheWVyIiwiZmlsbGVkIiwibGFiZWwiLCJzbGljZSIsInN0YXJ0R2FtZSIsImZsZXhTaHJpbmsiLCJmYWN0b3J5SGVhbHRoIiwidGVhbVNjb3JlIiwibWluSGVpZ2h0IiwidHJhbnNmb3JtIiwiY29vbGluZ1NhZmVNYXgiLCJvIiwibWluV2lkdGgiLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwiZGV2SW5jcmVtZW50UG93ZXIiLCJhbW91bnQiLCJkZXZJbmNyZW1lbnRBbW91bnQiLCJkZXZJbmNyZW1lbnREYXRhIiwiZGV2SW5jcmVtZW50U2VjdXJpdHkiLCJkZXZJbmNyZW1lbnRNb2RlbCIsImRldlNldENvb2xpbmdUZW1wIiwibWF4IiwiRW5kZWRTY3JlZW4iLCJfczIiLCJzdWNjZXNzIiwiZmluYWxSZXN1bHQiLCJkZXBsb3lQaGFzZSIsInNldERlcGxveVBoYXNlIiwidCIsImNyaXRpY2FsTWluIiwiY3JpdGljYWxEZXB0TWluaW11bSIsImRlcHRSZXN1bHRzIiwiZGVwdCIsInBhc3NlZCIsIm1heFdpZHRoIiwibWFyZ2luQm90dG9tIiwicmVwbGFjZSIsImZhY3RvcnlTdWNjZXNzVGhyZXNob2xkIiwiX2M2IiwiX2M3Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEhvc3Qgc2NyZWVuIOKAlCBBSSBGYWN0b3J5LlxuICpcbiAqIFBoYXNlczpcbiAqICBpZGxlICAgIOKGkiBBdHRyYWN0IHNjcmVlbiB3aXRoIFFSIGNvZGUgKyBhbWJpZW50IHBhcnRpY2xlc1xuICogIGxvYmJ5ICAg4oaSIFBsYXllciByb3N0ZXI7IFN0YXJ0IEdhbWUgd2hlbiA1LzUgZmlsbGVkXG4gKiAgcGxheWluZyDihpIgQUkgQ29udHJvbCBSb29tOiBodWItYW5kLXNwb2tlIGxheW91dCwgU1ZHIHBpcGVsaW5lcywgZXZlbnQgYmFubmVyXG4gKiAgZW5kZWQgICDihpIgRGVwbG95IGFuaW1hdGlvbiDihpIgU3VjY2VzcyAvIEZhaWx1cmUgcmVzdWx0IHNjcmVlblxuICovXG5pbXBvcnQgeyB1c2VBaXJKYW1Ib3N0LCB1c2VIb3N0VGljayB9IGZyb20gXCJAYWlyLWphbS9zZGtcIjtcbmltcG9ydCB7IEhvc3RQcmV2aWV3Q29udHJvbGxlcldvcmtzcGFjZSB9IGZyb20gXCJAYWlyLWphbS9zZGsvcHJldmlld1wiO1xuaW1wb3J0IHsgUm9vbVFyQ29kZSwgU3VyZmFjZVZpZXdwb3J0IH0gZnJvbSBcIkBhaXItamFtL3Nkay91aVwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBBTExfUk9MRVMsXG4gIFJPTEVfQ09MT1JTLFxuICBST0xFX0lDT05TLFxuICBST0xFX0xBQkVMUyxcbiAgUk9MRV9NSU5JX0dBTUUsXG4gIHR5cGUgUGxheWVyUm9sZSxcbn0gZnJvbSBcIi4uL2dhbWUvZG9tYWluL3R5cGVzXCI7XG5pbXBvcnQgeyBHQU1FX0NPTkZJRyB9IGZyb20gXCIuLi9nYW1lL2NvbmZpZy9nYW1lQ29uZmlnXCI7XG5pbXBvcnQgeyB1c2VGYWN0b3J5U3RvcmUsIHR5cGUgRmFjdG9yeVN0YXRlIH0gZnJvbSBcIi4uL2dhbWUvc3RvcmUvZmFjdG9yeVN0b3JlXCI7XG5cbi8vIOKUgOKUgCBIZWxwZXJzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5mdW5jdGlvbiBmb3JtYXRUaW1lKHNlY29uZHM6IG51bWJlcik6IHN0cmluZyB7XG4gIGNvbnN0IG0gPSBNYXRoLmZsb29yKHNlY29uZHMgLyA2MCkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCBcIjBcIik7XG4gIGNvbnN0IHMgPSAoc2Vjb25kcyAlIDYwKS50b1N0cmluZygpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcbiAgcmV0dXJuIGAke219OiR7c31gO1xufVxuXG5mdW5jdGlvbiBoZWFsdGhDb2xvcihoZWFsdGg6IG51bWJlcik6IHN0cmluZyB7XG4gIGlmIChoZWFsdGggPj0gNzApIHJldHVybiBcIiM0YWRlODBcIjtcbiAgaWYgKGhlYWx0aCA+PSA1MCkgcmV0dXJuIFwiI2ZiOTIzY1wiO1xuICByZXR1cm4gXCIjZjg3MTcxXCI7XG59XG5cbmZ1bmN0aW9uIHN0YXR1c0NvbG9yKHN0YXR1czogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgbWFwOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgIGluYWN0aXZlOiBcIiM0YjU1NjNcIixcbiAgICB3b3JraW5nOiBcIiM2MGE1ZmFcIixcbiAgICBzdGFibGU6IFwiIzM0ZDM5OVwiLFxuICAgIGNvbXBsZXRlOiBcIiM0YWRlODBcIixcbiAgICB3YXJuaW5nOiBcIiNmYjkyM2NcIixcbiAgICBjcml0aWNhbDogXCIjZjg3MTcxXCIsXG4gICAgZmFpbGVkOiBcIiNlZjQ0NDRcIixcbiAgfTtcbiAgcmV0dXJuIG1hcFtzdGF0dXNdID8/IFwiIzY0NzQ4YlwiO1xufVxuXG4vLyDilIDilIAgQW1iaWVudCBQYXJ0aWNsZSAoaWRsZSBzY3JlZW4pIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5mdW5jdGlvbiBBbWJpZW50UGFydGljbGVzKCkge1xuICBjb25zdCBwYXJ0aWNsZXMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiAxOCB9LCAoXywgaSkgPT4gKHtcbiAgICBpZDogaSxcbiAgICBsZWZ0OiBgJHs1ICsgKGkgKiA1LjUpICUgOTB9JWAsXG4gICAgYm90dG9tOiBgJHsoaSAqIDEzKSAlIDQwfSVgLFxuICAgIGR1cmF0aW9uOiBgJHszICsgKGkgKiAwLjcpICUgNH1zYCxcbiAgICBkZWxheTogYCR7KGkgKiAwLjQpICUgM31zYCxcbiAgICBzaXplOiBpICUgMyA9PT0gMCA/IDYgOiBpICUgMyA9PT0gMSA/IDQgOiAzLFxuICAgIGNvbG9yOiBpICUgNSA9PT0gMCA/IFwicmdiYSgyNTAsMjA0LDIxLDAuNilcIiA6XG4gICAgICAgICAgIGkgJSA1ID09PSAxID8gXCJyZ2JhKDE5MiwxMzIsMjUyLDAuNSlcIiA6XG4gICAgICAgICAgIGkgJSA1ID09PSAyID8gXCJyZ2JhKDUyLDIxMSwxNTMsMC41KVwiIDpcbiAgICAgICAgICAgICAgICAgICAgICAgICBcInJnYmEoNTYsMTg5LDI0OCwwLjYpXCIsXG4gIH0pKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgaW5zZXQ6IDAsIG92ZXJmbG93OiBcImhpZGRlblwiLCBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIiB9fT5cbiAgICAgIHtwYXJ0aWNsZXMubWFwKChwKSA9PiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICBrZXk9e3AuaWR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiaWRsZS1wYXJ0aWNsZVwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGxlZnQ6IHAubGVmdCxcbiAgICAgICAgICAgIGJvdHRvbTogcC5ib3R0b20sXG4gICAgICAgICAgICB3aWR0aDogcC5zaXplLFxuICAgICAgICAgICAgaGVpZ2h0OiBwLnNpemUsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBwLmNvbG9yLFxuICAgICAgICAgICAgYW5pbWF0aW9uRHVyYXRpb246IHAuZHVyYXRpb24sXG4gICAgICAgICAgICBhbmltYXRpb25EZWxheTogcC5kZWxheSxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vIOKUgOKUgCBFdmVudCBCYW5uZXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmludGVyZmFjZSBFdmVudEJhbm5lclByb3BzIHtcbiAgbWVzc2FnZTogc3RyaW5nO1xufVxuXG5mdW5jdGlvbiBFdmVudEJhbm5lcih7IG1lc3NhZ2UgfTogRXZlbnRCYW5uZXJQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cImV2ZW50LWJhbm5lci1lbnRlclwiXG4gICAgICBzdHlsZT17e1xuICAgICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgIHBhZGRpbmc6IFwiMTBweCAyMHB4XCIsXG4gICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgZ2FwOiAxMCxcbiAgICAgICAgb3ZlcmZsb3c6IFwiaGlkZGVuXCIsXG4gICAgICAgIGFuaW1hdGlvbjogXCJ3YXJuaW5nUHVsc2UgMXMgZWFzZS1pbi1vdXQgaW5maW5pdGVcIixcbiAgICAgICAgYm9yZGVyVG9wOiBcIjJweCBzb2xpZCByZ2JhKDI1MSwxNDYsNjAsMC42KVwiLFxuICAgICAgICBib3JkZXJCb3R0b206IFwiMnB4IHNvbGlkIHJnYmEoMjUxLDE0Niw2MCwwLjYpXCIsXG4gICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgXCJyZXBlYXRpbmctbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCByZ2JhKDI1MSwxNDYsNjAsMC4wOCkgMHB4LCByZ2JhKDI1MSwxNDYsNjAsMC4wOCkgMTJweCwgdHJhbnNwYXJlbnQgMTJweCwgdHJhbnNwYXJlbnQgMjRweClcIixcbiAgICAgIH19XG4gICAgPlxuICAgICAgey8qIFNjYW4gb3ZlcmxheSAqL31cbiAgICAgIDxkaXZcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgIGluc2V0OiAwLFxuICAgICAgICAgIGJhY2tncm91bmQ6IFwibGluZWFyLWdyYWRpZW50KDkwZGVnLCB0cmFuc3BhcmVudCAwJSwgcmdiYSgyNTEsMTQ2LDYwLDAuMTIpIDUwJSwgdHJhbnNwYXJlbnQgMTAwJSlcIixcbiAgICAgICAgICBhbmltYXRpb246IFwidGhyZWF0U2NhbiAycyBsaW5lYXIgaW5maW5pdGVcIixcbiAgICAgICAgICBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIixcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogMjAsIHpJbmRleDogMSB9fT7wn5qoPC9zcGFuPlxuICAgICAgPHNwYW5cbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBmb250U2l6ZTogMTQsXG4gICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIixcbiAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLFxuICAgICAgICAgIGNvbG9yOiBcIiNmYjkyM2NcIixcbiAgICAgICAgICB6SW5kZXg6IDEsXG4gICAgICAgICAgdGV4dFNoYWRvdzogXCIwIDAgMTJweCByZ2JhKDI1MSwxNDYsNjAsMC43KVwiLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICB7bWVzc2FnZX1cbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAyMCwgekluZGV4OiAxIH19PvCfmqg8L3NwYW4+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8vIOKUgOKUgCBBSSBDb3JlIENlbnRyZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuaW50ZXJmYWNlIEFJQ29yZVByb3BzIHtcbiAgaGVhbHRoOiBudW1iZXI7XG4gIGFsbENvbXBsZXRlOiBib29sZWFuO1xuICB0ZW1wZXJhdHVyZTogbnVtYmVyO1xufVxuXG5mdW5jdGlvbiBBSUNvcmUoeyBoZWFsdGgsIGFsbENvbXBsZXRlLCB0ZW1wZXJhdHVyZSB9OiBBSUNvcmVQcm9wcykge1xuICBjb25zdCBjb3JlQ29sb3IgPSBhbGxDb21wbGV0ZSA/IFwiIzRhZGU4MFwiIDogaGVhbHRoQ29sb3IoaGVhbHRoKTtcbiAgY29uc3QgYW5pbWF0aW9uID0gYWxsQ29tcGxldGVcbiAgICA/IFwiYWlDb3JlVmljdG9yeSAycyBlYXNlLWluLW91dCBpbmZpbml0ZVwiXG4gICAgOiBcImFpQ29yZVB1bHNlIDNzIGVhc2UtaW4tb3V0IGluZmluaXRlXCI7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDggfX0+XG4gICAgICB7LyogT3V0ZXIgcmluZyAqL31cbiAgICAgIDxkaXZcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgICAgIHdpZHRoOiAxNjAsXG4gICAgICAgICAgaGVpZ2h0OiAxNjAsXG4gICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgICAgICAgIGJvcmRlcjogYDNweCBzb2xpZCAke2NvcmVDb2xvcn02MGAsXG4gICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICBhbmltYXRpb24sXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIHsvKiBJbm5lciBvcmIgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgd2lkdGg6IDEyMCxcbiAgICAgICAgICAgIGhlaWdodDogMTIwLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiBcIjUwJVwiLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogYHJhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgMzUlIDM1JSwgJHtjb3JlQ29sb3J9MzAsICR7Y29yZUNvbG9yfTA4KWAsXG4gICAgICAgICAgICBib3JkZXI6IGAycHggc29saWQgJHtjb3JlQ29sb3J9ODBgLFxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgICAgICAgZ2FwOiAyLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogMzYgfX0+8J+kljwvc3Bhbj5cbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgZm9udFNpemU6IDIyLFxuICAgICAgICAgICAgICBmb250V2VpZ2h0OiA5MDAsXG4gICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1tb25vKVwiLFxuICAgICAgICAgICAgICBjb2xvcjogY29yZUNvbG9yLFxuICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiAxLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aGVhbHRofSVcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IDksIGxldHRlclNwYWNpbmc6IFwiMC4xNWVtXCIsIGNvbG9yOiBcIiM2NDc0OGJcIiwgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIiB9fT5cbiAgICAgICAgICAgIEhlYWx0aFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE9yYml0aW5nIGRvdCAqL31cbiAgICAgICAgPGRpdlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgd2lkdGg6IDEwLFxuICAgICAgICAgICAgaGVpZ2h0OiAxMCxcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCI1MCVcIixcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGNvcmVDb2xvcixcbiAgICAgICAgICAgIGJveFNoYWRvdzogYDAgMCAxMHB4ICR7Y29yZUNvbG9yfWAsXG4gICAgICAgICAgICBhbmltYXRpb246IFwib3JiaXRQdWxzZSA0cyBsaW5lYXIgaW5maW5pdGVcIixcbiAgICAgICAgICAgIHRyYW5zZm9ybU9yaWdpbjogXCJjZW50ZXJcIixcbiAgICAgICAgICAgIHRvcDogXCI1MCVcIixcbiAgICAgICAgICAgIGxlZnQ6IFwiNTAlXCIsXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IC01LFxuICAgICAgICAgICAgbWFyZ2luTGVmdDogLTUsXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQUkgQ09SRSBsYWJlbCAqL31cbiAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGZvbnRTaXplOiAxMSxcbiAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDkwMCxcbiAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4yZW1cIixcbiAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsXG4gICAgICAgICAgICBjb2xvcjogY29yZUNvbG9yLFxuICAgICAgICAgICAgdGV4dFNoYWRvdzogYDAgMCAxMHB4ICR7Y29yZUNvbG9yfTgwYCxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge2FsbENvbXBsZXRlID8gXCLinJMgQUxMIFNZU1RFTVMgR09cIiA6IFwiQUkgQ09SRVwifVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogOSwgY29sb3I6IFwiIzQ3NTU2OVwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMTJlbVwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiIH19PlxuICAgICAgICAgIHt0ZW1wZXJhdHVyZS50b0ZpeGVkKDApfcKwQ1xuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyDilIDilIAgRGVwYXJ0bWVudCBQYW5lbCAoaHViLWFuZC1zcG9rZSBjYXJkKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuaW50ZXJmYWNlIERlcHRQYW5lbFByb3BzIHtcbiAgcm9sZTogUGxheWVyUm9sZTtcbiAgcHJvZ3Jlc3M6IG51bWJlcjtcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIHNjb3JlOiBudW1iZXI7XG4gIGV4dHJhPzogUmVhY3QuUmVhY3ROb2RlO1xuICBmbGFzaGluZz86IGJvb2xlYW47XG59XG5cbmZ1bmN0aW9uIERlcHRQYW5lbCh7IHJvbGUsIHByb2dyZXNzLCBzdGF0dXMsIHNjb3JlLCBleHRyYSwgZmxhc2hpbmcgfTogRGVwdFBhbmVsUHJvcHMpIHtcbiAgY29uc3QgY29sb3IgPSBST0xFX0NPTE9SU1tyb2xlXTtcbiAgY29uc3QgaXNDb21wbGV0ZSA9IHN0YXR1cyA9PT0gXCJjb21wbGV0ZVwiO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDE1LDMyLDUzLDAuOTIpXCIsXG4gICAgICAgIGJvcmRlcjogYDEuNXB4IHNvbGlkICR7aXNDb21wbGV0ZSA/IGNvbG9yIDogY29sb3IgKyBcIjQwXCJ9YCxcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAxMixcbiAgICAgICAgcGFkZGluZzogXCIxMHB4IDEycHhcIixcbiAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgIGdhcDogNixcbiAgICAgICAgd2lkdGg6IDE2MCxcbiAgICAgICAgYm94U2hhZG93OiBmbGFzaGluZ1xuICAgICAgICAgID8gYDAgMCAyOHB4ICR7Y29sb3J9Y2MsIDAgMCA4cHggJHtjb2xvcn04OCwgaW5zZXQgMCAwIDEycHggJHtjb2xvcn0xNWBcbiAgICAgICAgICA6IGlzQ29tcGxldGVcbiAgICAgICAgICAgID8gYDAgMCAxNnB4ICR7Y29sb3J9NTVgXG4gICAgICAgICAgICA6IGAwIDAgNnB4IHJnYmEoNTYsMTg5LDI0OCwwLjEpYCxcbiAgICAgICAgdHJhbnNpdGlvbjogXCJib3gtc2hhZG93IDAuMTVzIGVhc2Utb3V0XCIsXG4gICAgICAgIGJhY2tkcm9wRmlsdGVyOiBcImJsdXIoNHB4KVwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiA2IH19PlxuICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogMTYgfX0+e1JPTEVfSUNPTlNbcm9sZV19PC9zcGFuPlxuICAgICAgICA8c3BhblxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBmbGV4OiAxLFxuICAgICAgICAgICAgZm9udFNpemU6IDksXG4gICAgICAgICAgICBmb250V2VpZ2h0OiA5MDAsXG4gICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMTJlbVwiLFxuICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcbiAgICAgICAgICAgIGNvbG9yLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICB7Uk9MRV9MQUJFTFNbcm9sZV19XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgZm9udFNpemU6IDksXG4gICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXG4gICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLFxuICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIixcbiAgICAgICAgICAgIHBhZGRpbmc6IFwiMXB4IDVweFwiLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA0LFxuICAgICAgICAgICAgYmFja2dyb3VuZDogc3RhdHVzQ29sb3Ioc3RhdHVzKSArIFwiMjVcIixcbiAgICAgICAgICAgIGNvbG9yOiBzdGF0dXNDb2xvcihzdGF0dXMpLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICB7aXNDb21wbGV0ZSA/IFwi4pyTXCIgOiBzdGF0dXN9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUHJvZ3Jlc3MgYmFyICovfVxuICAgICAgPGRpdlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsXG4gICAgICAgICAgaGVpZ2h0OiA2LFxuICAgICAgICAgIGJvcmRlclJhZGl1czogMyxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiMxZTI5M2JcIixcbiAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cInByb2dyZXNzLWZpbGxcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgaW5zZXQ6IFwiMCBhdXRvIDAgMFwiLFxuICAgICAgICAgICAgd2lkdGg6IGAke3Byb2dyZXNzfSVgLFxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAzLFxuICAgICAgICAgICAgYmFja2dyb3VuZDogaXNDb21wbGV0ZSA/IGNvbG9yIDogYCR7Y29sb3J9Y2NgLFxuICAgICAgICAgICAgYm94U2hhZG93OiBgMCAwIDZweCAke2NvbG9yfTYwYCxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTdGF0cyAqL31cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWJldHdlZW5cIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LW1vbm8pXCIsXG4gICAgICAgICAgICBmb250U2l6ZTogMTgsXG4gICAgICAgICAgICBmb250V2VpZ2h0OiA5MDAsXG4gICAgICAgICAgICBjb2xvcixcbiAgICAgICAgICAgIGxpbmVIZWlnaHQ6IDEsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHtwcm9ncmVzc30lXG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LW1vbm8pXCIsIGZvbnRTaXplOiA5LCBjb2xvcjogXCIjNDc1NTY5XCIgfX0+XG4gICAgICAgICAge3Njb3JlLnRvTG9jYWxlU3RyaW5nKCl9IHB0c1xuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2V4dHJhfVxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyDilIDilIAgU1ZHIFBpcGVsaW5lIE92ZXJsYXkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmludGVyZmFjZSBQaXBlbGluZU92ZXJsYXlQcm9wcyB7XG4gIGZsYXNoZXM6IFJlY29yZDxQbGF5ZXJSb2xlLCBib29sZWFuPjtcbiAgc3RhdHVzZXM6IFJlY29yZDxQbGF5ZXJSb2xlLCBzdHJpbmc+O1xufVxuXG5mdW5jdGlvbiBQaXBlbGluZU92ZXJsYXkoeyBmbGFzaGVzLCBzdGF0dXNlcyB9OiBQaXBlbGluZU92ZXJsYXlQcm9wcykge1xuICAvLyBQYXRocyBmcm9tIGVhY2ggZGVwdCBjYXJkIGNlbnRyZSB0byBBSSBjb3JlIGNlbnRyZSAoaW4gMTAwJSB2aWV3cG9ydCB1bml0cykuXG4gIC8vIFRoZXNlIG11c3QgbWF0Y2ggdGhlIGFic29sdXRlIHBvc2l0aW9ucyBvZiB0aGUgZGVwdCBwYW5lbHMuXG4gIGNvbnN0IHBhdGhzOiB7IHJvbGU6IFBsYXllclJvbGU7IGQ6IHN0cmluZyB9W10gPSBbXG4gICAgeyByb2xlOiBcInBvd2VyXCIsICAgIGQ6IFwiTSAxNCUgMjQlIEMgMzAlIDMwJSwgNDAlIDQ1JSwgNTAlIDUwJVwiIH0sXG4gICAgeyByb2xlOiBcImRhdGFcIiwgICAgIGQ6IFwiTSA4NiUgMjQlIEMgNzAlIDMwJSwgNjAlIDQ1JSwgNTAlIDUwJVwiIH0sXG4gICAgeyByb2xlOiBcInNlY3VyaXR5XCIsIGQ6IFwiTSAxNCUgNzIlIEMgMzAlIDY1JSwgNDAlIDU4JSwgNTAlIDUwJVwiIH0sXG4gICAgeyByb2xlOiBcIm1vZGVsXCIsICAgIGQ6IFwiTSA4NiUgNzIlIEMgNzAlIDY1JSwgNjAlIDU4JSwgNTAlIDUwJVwiIH0sXG4gICAgeyByb2xlOiBcImNvb2xpbmdcIiwgIGQ6IFwiTSA1MCUgODglIEMgNTAlIDc2JSwgNTAlIDY0JSwgNTAlIDUwJVwiIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICBzdHlsZT17e1xuICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICBpbnNldDogMCxcbiAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxuICAgICAgICBoZWlnaHQ6IFwiMTAwJVwiLFxuICAgICAgICBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIixcbiAgICAgICAgb3ZlcmZsb3c6IFwidmlzaWJsZVwiLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8ZGVmcz5cbiAgICAgICAgPGZpbHRlciBpZD1cInBpcGVsaW5lLWdsb3dcIj5cbiAgICAgICAgICA8ZmVHYXVzc2lhbkJsdXIgc3RkRGV2aWF0aW9uPVwiMlwiIHJlc3VsdD1cImNvbG9yZWRCbHVyXCIgLz5cbiAgICAgICAgICA8ZmVNZXJnZT5cbiAgICAgICAgICAgIDxmZU1lcmdlTm9kZSBpbj1cImNvbG9yZWRCbHVyXCIgLz5cbiAgICAgICAgICAgIDxmZU1lcmdlTm9kZSBpbj1cIlNvdXJjZUdyYXBoaWNcIiAvPlxuICAgICAgICAgIDwvZmVNZXJnZT5cbiAgICAgICAgPC9maWx0ZXI+XG4gICAgICA8L2RlZnM+XG5cbiAgICAgIHtwYXRocy5tYXAoKHsgcm9sZSwgZCB9KSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbG9yID0gUk9MRV9DT0xPUlNbcm9sZV07XG4gICAgICAgIGNvbnN0IGlzQ29tcGxldGUgPSBzdGF0dXNlc1tyb2xlXSA9PT0gXCJjb21wbGV0ZVwiO1xuICAgICAgICBjb25zdCBpc0ZsYXNoaW5nID0gZmxhc2hlc1tyb2xlXTtcbiAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBzdGF0dXNlc1tyb2xlXSAhPT0gXCJpbmFjdGl2ZVwiO1xuXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPGcga2V5PXtyb2xlfT5cbiAgICAgICAgICAgIHsvKiBCYXNlIHdpcmUg4oCUIGFsd2F5cyB2aXNpYmxlICovfVxuICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgZD17ZH1cbiAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICBzdHJva2U9e2NvbG9yfVxuICAgICAgICAgICAgICBzdHJva2VXaWR0aD17MS41fVxuICAgICAgICAgICAgICBzdHJva2VPcGFjaXR5PXtpc0FjdGl2ZSA/IDAuMjUgOiAwLjA4fVxuICAgICAgICAgICAgICBzdHlsZT17eyB0cmFuc2l0aW9uOiBcInN0cm9rZS1vcGFjaXR5IDAuNXMgZWFzZVwiIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgey8qIEFuaW1hdGVkIGZsb3cgKi99XG4gICAgICAgICAgICB7aXNBY3RpdmUgJiYgIWlzQ29tcGxldGUgJiYgKFxuICAgICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICAgIGQ9e2R9XG4gICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICAgIHN0cm9rZT17Y29sb3J9XG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XG4gICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PVwiMTIgMThcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBhbmltYXRpb246IFwicGlwZWxpbmVGbG93IDJzIGxpbmVhciBpbmZpbml0ZVwiLFxuICAgICAgICAgICAgICAgICAgZmlsdGVyOiBcInVybCgjcGlwZWxpbmUtZ2xvdylcIixcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHsvKiBDb21wbGV0ZSDigJQgc29saWQgZ2xvd2luZyBsaW5lICovfVxuICAgICAgICAgICAge2lzQ29tcGxldGUgJiYgKFxuICAgICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICAgIGQ9e2R9XG4gICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICAgIHN0cm9rZT17Y29sb3J9XG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezIuNX1cbiAgICAgICAgICAgICAgICBzdHJva2VPcGFjaXR5PXswLjd9XG4gICAgICAgICAgICAgICAgZmlsdGVyPVwidXJsKCNwaXBlbGluZS1nbG93KVwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgdHJhbnNpdGlvbjogXCJzdHJva2Utb3BhY2l0eSAwLjVzIGVhc2VcIiB9fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHsvKiBGbGFzaCBidXJzdCBvbiBwbGF5ZXIgYWN0aW9uICovfVxuICAgICAgICAgICAge2lzRmxhc2hpbmcgJiYgKFxuICAgICAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgICAgIGQ9e2R9XG4gICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICAgIHN0cm9rZT17Y29sb3J9XG4gICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezR9XG4gICAgICAgICAgICAgICAgc3Ryb2tlT3BhY2l0eT17MC45fVxuICAgICAgICAgICAgICAgIGZpbHRlcj1cInVybCgjcGlwZWxpbmUtZ2xvdylcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGFuaW1hdGlvbjogXCJwaXBlbGluZUZsYXNoIDAuMzVzIGVhc2Utb3V0IGZvcndhcmRzXCIgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9nPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9zdmc+XG4gICk7XG59XG5cbi8vIOKUgOKUgCBNYWluIEhvc3QgVmlldyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGZ1bmN0aW9uIEhvc3RWaWV3KCkge1xuICBjb25zdCBob3N0ID0gdXNlQWlySmFtSG9zdCgpO1xuICBjb25zdCBzdGF0ZSA9IHVzZUZhY3RvcnlTdG9yZSgoczogRmFjdG9yeVN0YXRlKSA9PiBzKTtcbiAgY29uc3QgYWN0aW9ucyA9IHVzZUZhY3RvcnlTdG9yZS51c2VBY3Rpb25zKCk7XG5cbiAgLy8g4pSA4pSAIFBlci1yb2xlIGZsYXNoIHN0YXRlICh0cmlnZ2VyZWQgYnkgaG9zdCBhY3Rpb24gbGlzdGVuZXIpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBbZmxhc2hlcywgc2V0Rmxhc2hlc10gPSB1c2VTdGF0ZTxSZWNvcmQ8UGxheWVyUm9sZSwgYm9vbGVhbj4+KHtcbiAgICBwb3dlcjogZmFsc2UsIGRhdGE6IGZhbHNlLCBzZWN1cml0eTogZmFsc2UsIG1vZGVsOiBmYWxzZSwgY29vbGluZzogZmFsc2UsXG4gIH0pO1xuICBjb25zdCBmbGFzaFRpbWVycyA9IHVzZVJlZjxQYXJ0aWFsPFJlY29yZDxQbGF5ZXJSb2xlLCBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0Pj4+Pih7fSk7XG5cbiAgZnVuY3Rpb24gdHJpZ2dlckZsYXNoKHJvbGU6IFBsYXllclJvbGUsIGR1cmF0aW9uTXMgPSAyMDApIHtcbiAgICBpZiAoZmxhc2hUaW1lcnMuY3VycmVudFtyb2xlXSkgY2xlYXJUaW1lb3V0KGZsYXNoVGltZXJzLmN1cnJlbnRbcm9sZV0pO1xuICAgIHNldEZsYXNoZXMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtyb2xlXTogdHJ1ZSB9KSk7XG4gICAgZmxhc2hUaW1lcnMuY3VycmVudFtyb2xlXSA9IHNldFRpbWVvdXQoXG4gICAgICAoKSA9PiBzZXRGbGFzaGVzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbcm9sZV06IGZhbHNlIH0pKSxcbiAgICAgIGR1cmF0aW9uTXMsXG4gICAgKTtcbiAgfVxuXG4gIHVzZUZhY3RvcnlTdG9yZS51c2VIb3N0QWN0aW9uTGlzdGVuZXIoKCkgPT4gdHJpZ2dlckZsYXNoKFwicG93ZXJcIiwgMTgwKSwgICAgIHsgYWN0aW9uTmFtZXM6IFtcInRhcFBvd2VyXCJdIH0pO1xuICB1c2VGYWN0b3J5U3RvcmUudXNlSG9zdEFjdGlvbkxpc3RlbmVyKCgpID0+IHRyaWdnZXJGbGFzaChcImRhdGFcIiwgMTgwKSwgICAgICB7IGFjdGlvbk5hbWVzOiBbXCJzb3J0RGF0YVwiXSB9KTtcbiAgdXNlRmFjdG9yeVN0b3JlLnVzZUhvc3RBY3Rpb25MaXN0ZW5lcigoKSA9PiB0cmlnZ2VyRmxhc2goXCJzZWN1cml0eVwiLCAxODApLCAgeyBhY3Rpb25OYW1lczogW1wiemlwWmFwXCJdIH0pO1xuICB1c2VGYWN0b3J5U3RvcmUudXNlSG9zdEFjdGlvbkxpc3RlbmVyKCgpID0+IHRyaWdnZXJGbGFzaChcIm1vZGVsXCIsIDI1MCksICAgICB7IGFjdGlvbk5hbWVzOiBbXCJzb2x2ZVB1enpsZVwiXSB9KTtcbiAgdXNlRmFjdG9yeVN0b3JlLnVzZUhvc3RBY3Rpb25MaXN0ZW5lcigoKSA9PiB0cmlnZ2VyRmxhc2goXCJjb29saW5nXCIsIDM1MCksICAgeyBhY3Rpb25OYW1lczogW1wiY29vbFRpY2tcIl0gfSk7XG5cbiAgLy8g4pSA4pSAIEhvc3QgZ2FtZSBsb29wIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICB1c2VIb3N0VGljayh7XG4gICAgbW9kZTogXCJpbnRlcnZhbFwiLFxuICAgIGludGVydmFsTXM6IDEwMDAsXG4gICAgb25UaWNrOiAoKSA9PiB7XG4gICAgICBpZiAoc3RhdGUucGhhc2UgPT09IFwicGxheWluZ1wiKSBhY3Rpb25zLnRpY2tUaW1lcigpO1xuICAgIH0sXG4gIH0pO1xuXG4gIC8vIOKUgOKUgCBEZXYgcGFuZWwgdG9nZ2xlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBbZGV2T3Blbiwgc2V0RGV2T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8g4pSA4pSAIERlcml2ZWQgdmFsdWVzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBhbGxDb21wbGV0ZSA9IChbXCJwb3dlclwiLCBcImRhdGFcIiwgXCJzZWN1cml0eVwiLCBcIm1vZGVsXCIsIFwiY29vbGluZ1wiXSBhcyBQbGF5ZXJSb2xlW10pLmV2ZXJ5KFxuICAgIChyKSA9PiBzdGF0ZVtyXS5zdGF0dXMgPT09IFwiY29tcGxldGVcIixcbiAgKTtcbiAgY29uc3QgY3VycmVudEV2ZW50ID0gc3RhdGUuYWN0aXZlRXZlbnRzW3N0YXRlLmFjdGl2ZUV2ZW50cy5sZW5ndGggLSAxXSA/PyBudWxsO1xuICBjb25zdCB0aW1lckRhbmdlciA9IHN0YXRlLnRpbWVSZW1haW5pbmcgPCAzMDtcbiAgY29uc3QgdGltZXJXYXJuaW5nID0gc3RhdGUudGltZVJlbWFpbmluZyA8IDYwICYmIHN0YXRlLnRpbWVSZW1haW5pbmcgPj0gMzA7XG5cbiAgLy8g4pSA4pSAIElETEUgU0NSRUVOIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBpZiAoc3RhdGUucGhhc2UgPT09IFwiaWRsZVwiKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxTdXJmYWNlVmlld3BvcnQgY2xhc3NOYW1lPVwiYmctWyMwNTBhMTRdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGgtZnVsbCB3LWZ1bGwgZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC04IHAtOCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxBbWJpZW50UGFydGljbGVzIC8+XG5cbiAgICAgICAgICAgIHsvKiBTY2FuIGxpbmUgb3ZlcmxheSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2Nhbi1saW5lIGFic29sdXRlIGluc2V0LTAgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG5cbiAgICAgICAgICAgIHsvKiBUaXRsZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgei0xMFwiPlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC02eGwgZm9udC1ibGFjayB0cmFja2luZy10aWdodFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMzOGJkZjhcIixcbiAgICAgICAgICAgICAgICAgIHRleHRTaGFkb3c6IFwiMCAwIDQwcHggcmdiYSg1NiwxODksMjQ4LDAuNiksIDAgMCA4MHB4IHJnYmEoNTYsMTg5LDI0OCwwLjIpXCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfj60gQUkgRkFDVE9SWVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1sZyBmb250LXNlbWlib2xkIHRyYWNraW5nLVswLjRlbV0gdXBwZXJjYXNlXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogXCIjNDc1NTY5XCIgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEJ1aWxkIOKAoiBCcmVhayDigKIgU3Vydml2ZVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1zbSB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogXCIjMzhiZGY4XCIsIG9wYWNpdHk6IDAuNyB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgNS1QbGF5ZXIgQ29vcGVyYXRpdmUgRW5naW5lZXJpbmcgTWlzc2lvblxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUVIgQ29kZSBwYW5lbCAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmFjdG9yeS1wYW5lbCB6LTEwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC00IHAtOFwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGJveFNoYWRvdzogXCIwIDAgNDBweCByZ2JhKDU2LDE4OSwyNDgsMC4xNSlcIiB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdHJhY2tpbmctWzAuM2VtXSB1cHBlcmNhc2VcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBcIiMzOGJkZjhcIiB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgU2NhbiB0byBKb2luXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7aG9zdC5qb2luVXJsID8gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEyLFxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIndoaXRlXCIsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOCxcbiAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBcIjAgMCAzMHB4IHJnYmEoNTYsMTg5LDI0OCwwLjMpXCIsXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb29tUXJDb2RlIHZhbHVlPXtob3N0LmpvaW5Vcmx9IHNpemU9ezE4MH0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtWzE4MHB4XSB3LVsxODBweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS02MDAgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgQ29ubmVjdGluZ+KAplxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHNcIiBzdHlsZT17eyBjb2xvcjogXCIjNDc1NTY5XCIgfX0+XG4gICAgICAgICAgICAgICAgUm9vbTp7XCIgXCJ9XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCIgc3R5bGU9e3sgY29sb3I6IFwiIzM4YmRmOFwiIH19PlxuICAgICAgICAgICAgICAgICAge2hvc3Qucm9vbUlkID8/IFwi4oCUXCJ9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgey8qIEhpZGRlbiBlbGVtZW50IGZvciBQbGF5d3JpZ2h0IEUyRSB0ZXN0cyB0byByZWFkIHRoZSBqb2luIFVSTCAqL31cbiAgICAgICAgICAgICAge2hvc3Quam9pblVybCAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiam9pbi11cmxcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogXCJub25lXCIgfX1cbiAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2hvc3Quam9pblVybH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFBsYXllciBjb3VudCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJsYWNrIHRleHQtd2hpdGVcIj57aG9zdC5wbGF5ZXJzLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwXCI+Lzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ibGFja1wiIHN0eWxlPXt7IGNvbG9yOiBcIiMxZTNhNWZcIiB9fT5cbiAgICAgICAgICAgICAgICB7R0FNRV9DT05GSUcubWF4UGxheWVyc31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIiBzdHlsZT17eyBjb2xvcjogXCIjNDc1NTY5XCIgfX0+XG4gICAgICAgICAgICAgICAgRW5naW5lZXJzXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7aG9zdC5wbGF5ZXJzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiei0xMCB0ZXh0LXhzIGFuaW1hdGUtcHVsc2VcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBcIiMzOGJkZjhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjE1ZW1cIiB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRW5naW5lZXJzIGpvaW5pbmfigKYgYXdhaXRpbmcgZnVsbCBjcmV3XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9TdXJmYWNlVmlld3BvcnQ+XG4gICAgICAgIDxIb3N0UHJldmlld0NvbnRyb2xsZXJXb3Jrc3BhY2UgLz5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICAvLyDilIDilIAgTE9CQlkgU0NSRUVOIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBpZiAoc3RhdGUucGhhc2UgPT09IFwibG9iYnlcIikge1xuICAgIGNvbnN0IHBsYXllckNvdW50ID0gT2JqZWN0LmtleXMoc3RhdGUucm9sZUFzc2lnbm1lbnRzKS5sZW5ndGg7XG4gICAgY29uc3QgYWxsRmlsbGVkID0gcGxheWVyQ291bnQgPj0gR0FNRV9DT05GSUcubWF4UGxheWVycztcblxuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8U3VyZmFjZVZpZXdwb3J0IGNsYXNzTmFtZT1cImJnLVsjMDUwYTE0XVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBoLWZ1bGwgdy1mdWxsIGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtNiBwLThcIj5cblxuICAgICAgICAgICAgey8qIFJlc2V0ICh0b3AtcmlnaHQpICovfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWN0aW9ucy5yZXNldEdhbWUoKX1cbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgICAgIHRvcDogMTYsXG4gICAgICAgICAgICAgICAgcmlnaHQ6IDE2LFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSgyMzksNjgsNjgsMC4wOClcIixcbiAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHJnYmEoMjM5LDY4LDY4LDAuMjUpXCIsXG4gICAgICAgICAgICAgICAgY29sb3I6IFwiI2Y4NzE3MVwiLFxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogOCxcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjRweCAxMHB4XCIsXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IDExLFxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcbiAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wOGVtXCIsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg4oa6IFJFU0VUXG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbXQtMlwiPlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ibGFja1wiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IFwiIzM4YmRmOFwiLCB0ZXh0U2hhZG93OiBcIjAgMCAzMHB4IHJnYmEoNTYsMTg5LDI0OCwwLjUpXCIgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfj60gQUkgRkFDVE9SWSBMT0JCWVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiIHN0eWxlPXt7IGNvbG9yOiBcIiM0NzU1NjlcIiB9fT5cbiAgICAgICAgICAgICAgICB7cGxheWVyQ291bnR9IC8ge0dBTUVfQ09ORklHLm1heFBsYXllcnN9IEVuZ2luZWVycyBSZWFkeVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUVIgY29kZSAqL31cbiAgICAgICAgICAgIHtob3N0LmpvaW5VcmwgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6IDEwLCBiYWNrZ3JvdW5kOiBcIndoaXRlXCIsIGJvcmRlclJhZGl1czogOCB9fT5cbiAgICAgICAgICAgICAgICA8Um9vbVFyQ29kZSB2YWx1ZT17aG9zdC5qb2luVXJsfSBzaXplPXsxMDB9IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFJvbGUgcm9zdGVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteGwgZmxleCBmbGV4LWNvbCBnYXAtM1wiPlxuICAgICAgICAgICAgICB7QUxMX1JPTEVTLm1hcCgocm9sZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFzc2lnbmVkUGxheWVySWQgPSBPYmplY3QuZW50cmllcyhzdGF0ZS5yb2xlQXNzaWdubWVudHMpLmZpbmQoXG4gICAgICAgICAgICAgICAgICAoWywgcl0pID0+IHIgPT09IHJvbGUsXG4gICAgICAgICAgICAgICAgKT8uWzBdO1xuICAgICAgICAgICAgICAgIGNvbnN0IHBsYXllciA9IGhvc3QucGxheWVycy5maW5kKChwKSA9PiBwLmlkID09PSBhc3NpZ25lZFBsYXllcklkKTtcbiAgICAgICAgICAgICAgICBjb25zdCBmaWxsZWQgPSAhIWFzc2lnbmVkUGxheWVySWQ7XG4gICAgICAgICAgICAgICAgY29uc3QgY29sb3IgPSBST0xFX0NPTE9SU1tyb2xlXTtcblxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17cm9sZX1cbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICAgICAgICAgIGdhcDogMTQsXG4gICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMnB4IDE2cHhcIixcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogYDEuNXB4IHNvbGlkICR7ZmlsbGVkID8gY29sb3IgKyBcIjcwXCIgOiBcInJnYmEoNTYsMTg5LDI0OCwwLjEpXCJ9YCxcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBmaWxsZWQgPyBjb2xvciArIFwiMTBcIiA6IFwicmdiYSgxMywyNCwzNywwLjYpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJhbGwgMC4zcyBlYXNlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBmaWxsZWQgPyBgMCAwIDIwcHggJHtjb2xvcn0yMGAgOiBcIm5vbmVcIixcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6IDI0IH19PntST0xFX0lDT05TW3JvbGVdfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAxIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxMixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMWVtXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Uk9MRV9MQUJFTFNbcm9sZV19XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogMTAsIGNvbG9yOiBcIiM0NzU1NjlcIiB9fT57Uk9MRV9NSU5JX0dBTUVbcm9sZV19PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHRleHRBbGlnbjogXCJyaWdodFwiIH19PlxuICAgICAgICAgICAgICAgICAgICAgIHtmaWxsZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAxMiwgZm9udFdlaWdodDogNzAwLCBjb2xvcjogXCIjNGFkZTgwXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4pyTIHtwbGF5ZXI/LmxhYmVsID8/IFwiRW5naW5lZXJcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDksIGNvbG9yOiBcIiMzMzQxNTVcIiwgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LW1vbm8pXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Fzc2lnbmVkUGxheWVySWQ/LnNsaWNlKDAsIDgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDEwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMzMzQxNTVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wOGVtXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFdhaXRpbmfigKZcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFN0YXJ0IC8gd2FpdGluZyAqL31cbiAgICAgICAgICAgIHthbGxGaWxsZWQgPyAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhY3Rpb25zLnN0YXJ0R2FtZSgpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJsaW5lYXItZ3JhZGllbnQoMTM1ZGVnLCAjMDM2OWExLCAjMzhiZGY4KVwiLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTYsXG4gICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjE2cHggNDhweFwiLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDIwLFxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwid2hpdGVcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIixcbiAgICAgICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsXG4gICAgICAgICAgICAgICAgICBib3hTaGFkb3c6IFwiMCAwIDQwcHggcmdiYSg1NiwxODksMjQ4LDAuNClcIixcbiAgICAgICAgICAgICAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcInRyYW5zZm9ybSAwLjFzLCBib3gtc2hhZG93IDAuMXNcIixcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg8J+agCBMQVVOQ0ggTUlTU0lPTlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhbmltYXRlLXB1bHNlIHRleHQtc21cIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBcIiM0NzU1NjlcIiwgbGV0dGVyU3BhY2luZzogXCIwLjEyZW1cIiwgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIiB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQXdhaXRpbmcge0dBTUVfQ09ORklHLm1heFBsYXllcnMgLSBwbGF5ZXJDb3VudH0gbW9yZSBlbmdpbmVlcntHQU1FX0NPTkZJRy5tYXhQbGF5ZXJzIC0gcGxheWVyQ291bnQgIT09IDEgPyBcInNcIiA6IFwiXCJ94oCmXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9TdXJmYWNlVmlld3BvcnQ+XG4gICAgICAgIDxIb3N0UHJldmlld0NvbnRyb2xsZXJXb3Jrc3BhY2UgLz5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICAvLyDilIDilIAgUExBWUlORyBTQ1JFRU4g4oCUIEFJIENvbnRyb2wgUm9vbSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgaWYgKHN0YXRlLnBoYXNlID09PSBcInBsYXlpbmdcIikge1xuICAgIGNvbnN0IHN0YXR1c2VzID0ge1xuICAgICAgcG93ZXI6IHN0YXRlLnBvd2VyLnN0YXR1cyxcbiAgICAgIGRhdGE6IHN0YXRlLmRhdGEuc3RhdHVzLFxuICAgICAgc2VjdXJpdHk6IHN0YXRlLnNlY3VyaXR5LnN0YXR1cyxcbiAgICAgIG1vZGVsOiBzdGF0ZS5tb2RlbC5zdGF0dXMsXG4gICAgICBjb29saW5nOiBzdGF0ZS5jb29saW5nLnN0YXR1cyxcbiAgICB9IGFzIFJlY29yZDxQbGF5ZXJSb2xlLCBzdHJpbmc+O1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxTdXJmYWNlVmlld3BvcnQgY2xhc3NOYW1lPVwiYmctWyMwNTBhMTRdXCI+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgICAgICAgICAgIG92ZXJmbG93OiBcImhpZGRlblwiLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7Lyog4pSA4pSAIFRvcCBCYXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwic3BhY2UtYmV0d2VlblwiLFxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTBweCAyMHB4XCIsXG4gICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCByZ2JhKDU2LDE4OSwyNDgsMC4xKVwiLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSg1LDEwLDIwLDAuOClcIixcbiAgICAgICAgICAgICAgICBmbGV4U2hyaW5rOiAwLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxOCxcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDkwMCxcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMzOGJkZjhcIixcbiAgICAgICAgICAgICAgICAgIHRleHRTaGFkb3c6IFwiMCAwIDIwcHggcmdiYSg1NiwxODksMjQ4LDAuNSlcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfj60gQUkgRkFDVE9SWVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU3RhdHMgY2x1c3RlciAqL31cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImZsZXhcIiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiwgZ2FwOiAyNCB9fT5cbiAgICAgICAgICAgICAgICB7LyogVGltZXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIgfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiA5LCBjb2xvcjogXCIjNDc1NTY5XCIsIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgVGltZVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17dGltZXJEYW5nZXIgPyBcInRpbWVyLWRhbmdlclwiIDogXCJcIn1cbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtbW9ubylcIixcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogMjgsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB0aW1lckRhbmdlciA/IFwiI2Y4NzE3MVwiIDogdGltZXJXYXJuaW5nID8gXCIjZmI5MjNjXCIgOiBcIiNmMGY5ZmZcIixcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcImNvbG9yIDAuNXMgZWFzZVwiLFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VGltZShzdGF0ZS50aW1lUmVtYWluaW5nKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEZhY3RvcnkgSGVhbHRoICovfVxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogOSwgY29sb3I6IFwiIzQ3NTU2OVwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMWVtXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIEZhY3RvcnkgSGVhbHRoXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtbW9ubylcIixcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogMjgsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBoZWFsdGhDb2xvcihzdGF0ZS5mYWN0b3J5SGVhbHRoKSxcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBcImNvbG9yIDAuNXMgZWFzZVwiLFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7c3RhdGUuZmFjdG9yeUhlYWx0aH0lXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBUZWFtIFNjb3JlICovfVxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogOSwgY29sb3I6IFwiIzQ3NTU2OVwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMWVtXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIFNjb3JlXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5OiBcInZhcigtLWZvbnQtbW9ubylcIixcbiAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogMjgsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMzOGJkZjhcIixcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3N0YXRlLnRlYW1TY29yZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiDilIDilIAgRXZlbnQgQmFubmVyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL31cbiAgICAgICAgICAgIHtjdXJyZW50RXZlbnQgJiYgPEV2ZW50QmFubmVyIG1lc3NhZ2U9e2N1cnJlbnRFdmVudC5tZXNzYWdlfSAvPn1cblxuICAgICAgICAgICAgey8qIOKUgOKUgCBGYWN0b3J5IEhlYWx0aCBCYXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovfVxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiBcIjZweCAyMHB4XCIsIGZsZXhTaHJpbms6IDAgfX0+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgcG9zaXRpb246IFwicmVsYXRpdmVcIixcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogOCxcbiAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogNCxcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiIzBmMTcyYVwiLFxuICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c6IFwiaGlkZGVuXCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2dyZXNzLWZpbGxcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgICAgICAgICAgaW5zZXQ6IFwiMCBhdXRvIDAgMFwiLFxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogYCR7c3RhdGUuZmFjdG9yeUhlYWx0aH0lYCxcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA0LFxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBgbGluZWFyLWdyYWRpZW50KDkwZGVnLCAke2hlYWx0aENvbG9yKHN0YXRlLmZhY3RvcnlIZWFsdGgpfTgwLCAke2hlYWx0aENvbG9yKHN0YXRlLmZhY3RvcnlIZWFsdGgpfSlgLFxuICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6IGAwIDAgMTBweCAke2hlYWx0aENvbG9yKHN0YXRlLmZhY3RvcnlIZWFsdGgpfTYwYCxcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIOKUgOKUgCBIdWItYW5kLVNwb2tlIEZhY3RvcnkgRmxvb3Ig4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsXG4gICAgICAgICAgICAgICAgZmxleDogMSxcbiAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6IDAsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHsvKiBTVkcgcGlwZWxpbmUgbGF5ZXIgKi99XG4gICAgICAgICAgICAgIDxQaXBlbGluZU92ZXJsYXkgZmxhc2hlcz17Zmxhc2hlc30gc3RhdHVzZXM9e3N0YXR1c2VzfSAvPlxuXG4gICAgICAgICAgICAgIHsvKiBQb3dlciDigJQgdG9wIGxlZnQgKi99XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgdG9wOiBcIjQlXCIsIGxlZnQ6IFwiNCVcIiB9fT5cbiAgICAgICAgICAgICAgICA8RGVwdFBhbmVsXG4gICAgICAgICAgICAgICAgICByb2xlPVwicG93ZXJcIlxuICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3M9e3N0YXRlLnBvd2VyLnByb2dyZXNzfVxuICAgICAgICAgICAgICAgICAgc3RhdHVzPXtzdGF0ZS5wb3dlci5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICBzY29yZT17c3RhdGUucG93ZXIuc2NvcmV9XG4gICAgICAgICAgICAgICAgICBmbGFzaGluZz17Zmxhc2hlcy5wb3dlcn1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRGF0YSDigJQgdG9wIHJpZ2h0ICovfVxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiBcImFic29sdXRlXCIsIHRvcDogXCI0JVwiLCByaWdodDogXCI0JVwiIH19PlxuICAgICAgICAgICAgICAgIDxEZXB0UGFuZWxcbiAgICAgICAgICAgICAgICAgIHJvbGU9XCJkYXRhXCJcbiAgICAgICAgICAgICAgICAgIHByb2dyZXNzPXtzdGF0ZS5kYXRhLnByb2dyZXNzfVxuICAgICAgICAgICAgICAgICAgc3RhdHVzPXtzdGF0ZS5kYXRhLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgIHNjb3JlPXtzdGF0ZS5kYXRhLnNjb3JlfVxuICAgICAgICAgICAgICAgICAgZmxhc2hpbmc9e2ZsYXNoZXMuZGF0YX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2VjdXJpdHkg4oCUIGJvdHRvbSBsZWZ0ICovfVxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGJvdHRvbTogXCIyNiVcIiwgbGVmdDogXCI0JVwiIH19PlxuICAgICAgICAgICAgICAgIDxEZXB0UGFuZWxcbiAgICAgICAgICAgICAgICAgIHJvbGU9XCJzZWN1cml0eVwiXG4gICAgICAgICAgICAgICAgICBwcm9ncmVzcz17c3RhdGUuc2VjdXJpdHkucHJvZ3Jlc3N9XG4gICAgICAgICAgICAgICAgICBzdGF0dXM9e3N0YXRlLnNlY3VyaXR5LnN0YXR1c31cbiAgICAgICAgICAgICAgICAgIHNjb3JlPXtzdGF0ZS5zZWN1cml0eS5zY29yZX1cbiAgICAgICAgICAgICAgICAgIGZsYXNoaW5nPXtmbGFzaGVzLnNlY3VyaXR5fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBNb2RlbCDigJQgYm90dG9tIHJpZ2h0ICovfVxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGJvdHRvbTogXCIyNiVcIiwgcmlnaHQ6IFwiNCVcIiB9fT5cbiAgICAgICAgICAgICAgICA8RGVwdFBhbmVsXG4gICAgICAgICAgICAgICAgICByb2xlPVwibW9kZWxcIlxuICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3M9e3N0YXRlLm1vZGVsLnByb2dyZXNzfVxuICAgICAgICAgICAgICAgICAgc3RhdHVzPXtzdGF0ZS5tb2RlbC5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICBzY29yZT17c3RhdGUubW9kZWwuc2NvcmV9XG4gICAgICAgICAgICAgICAgICBmbGFzaGluZz17Zmxhc2hlcy5tb2RlbH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQ29vbGluZyDigJQgYm90dG9tIGNlbnRyZSAqL31cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgICAgICAgYm90dG9tOiBcIjQlXCIsXG4gICAgICAgICAgICAgICAgICBsZWZ0OiBcIjUwJVwiLFxuICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZVgoLTUwJSlcIixcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPERlcHRQYW5lbFxuICAgICAgICAgICAgICAgICAgcm9sZT1cImNvb2xpbmdcIlxuICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3M9e3N0YXRlLmNvb2xpbmcucHJvZ3Jlc3N9XG4gICAgICAgICAgICAgICAgICBzdGF0dXM9e3N0YXRlLmNvb2xpbmcuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgc2NvcmU9e3N0YXRlLmNvb2xpbmcuc2NvcmV9XG4gICAgICAgICAgICAgICAgICBmbGFzaGluZz17Zmxhc2hlcy5jb29saW5nfVxuICAgICAgICAgICAgICAgICAgZXh0cmE9e1xuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1tb25vKVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDE0LFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNzAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlLmNvb2xpbmcudGVtcGVyYXR1cmUgPD0gR0FNRV9DT05GSUcuY29vbGluZ1NhZmVNYXhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiIzM0ZDM5OVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzdGF0ZS5jb29saW5nLnRlbXBlcmF0dXJlID4gODVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIjZjg3MTcxXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCIjZmI5MjNjXCIsXG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdGF0ZS5jb29saW5nLnRlbXBlcmF0dXJlLnRvRml4ZWQoMSl9wrBDXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBSSBDb3JlIOKAlCBjZW50cmUgKi99XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgICAgICAgIHRvcDogXCI1MCVcIixcbiAgICAgICAgICAgICAgICAgIGxlZnQ6IFwiNTAlXCIsXG4gICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKC01MCUsIC01MCUpXCIsXG4gICAgICAgICAgICAgICAgICB6SW5kZXg6IDEwLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QUlDb3JlXG4gICAgICAgICAgICAgICAgICBoZWFsdGg9e3N0YXRlLmZhY3RvcnlIZWFsdGh9XG4gICAgICAgICAgICAgICAgICBhbGxDb21wbGV0ZT17YWxsQ29tcGxldGV9XG4gICAgICAgICAgICAgICAgICB0ZW1wZXJhdHVyZT17c3RhdGUuY29vbGluZy50ZW1wZXJhdHVyZX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7Lyog4pSA4pSAIERldiBQYW5lbCB0b2dnbGUgKyBwYW5lbCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi99XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXREZXZPcGVuKChvKSA9PiAhbyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgICAgIGJvdHRvbTogOCxcbiAgICAgICAgICAgICAgICByaWdodDogOCxcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInJnYmEoMjQ1LDE1OCwxMSwwLjA4KVwiLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgcmdiYSgyNDUsMTU4LDExLDAuMilcIixcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgICAgICAgcGFkZGluZzogXCIzcHggOHB4XCIsXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IDEwLFxuICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNmNTllMGJcIixcbiAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxuICAgICAgICAgICAgICAgIHpJbmRleDogMjAsXG4gICAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjA2ZW1cIixcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIPCflKcge2Rldk9wZW4gPyBcIkNMT1NFXCIgOiBcIkRFVlwifVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIHtkZXZPcGVuICYmIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgICAgICAgICAgICAgICAgYm90dG9tOiAzNixcbiAgICAgICAgICAgICAgICAgIHJpZ2h0OiA4LFxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDE1LDMyLDUzLDAuOTgpXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHJnYmEoMjQ1LDE1OCwxMSwwLjMpXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEwLFxuICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxMnB4IDE0cHhcIixcbiAgICAgICAgICAgICAgICAgIHpJbmRleDogMjAsXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXG4gICAgICAgICAgICAgICAgICBnYXA6IDgsXG4gICAgICAgICAgICAgICAgICBtaW5XaWR0aDogMjYwLFxuICAgICAgICAgICAgICAgICAgYmFja2Ryb3BGaWx0ZXI6IFwiYmx1cig4cHgpXCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDksIGNvbG9yOiBcIiNmNTllMGJcIiwgZm9udFdlaWdodDogOTAwLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMWVtXCIsIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIgfX0+XG4gICAgICAgICAgICAgICAgICDwn5SnIERldiBUZXN0IFBhbmVsXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiBcImdyaWRcIiwgZ3JpZFRlbXBsYXRlQ29sdW1uczogXCIxZnIgMWZyXCIsIGdhcDogNiB9fT5cbiAgICAgICAgICAgICAgICAgIHsoW1wicG93ZXJcIiwgXCJkYXRhXCIsIFwic2VjdXJpdHlcIiwgXCJtb2RlbFwiXSBhcyBQbGF5ZXJSb2xlW10pLm1hcCgocm9sZSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtyb2xlfVxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocm9sZSA9PT0gXCJwb3dlclwiKSBhY3Rpb25zLmRldkluY3JlbWVudFBvd2VyKHsgYW1vdW50OiBHQU1FX0NPTkZJRy5kZXZJbmNyZW1lbnRBbW91bnQgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocm9sZSA9PT0gXCJkYXRhXCIpIGFjdGlvbnMuZGV2SW5jcmVtZW50RGF0YSh7IGFtb3VudDogR0FNRV9DT05GSUcuZGV2SW5jcmVtZW50QW1vdW50IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJvbGUgPT09IFwic2VjdXJpdHlcIikgYWN0aW9ucy5kZXZJbmNyZW1lbnRTZWN1cml0eSh7IGFtb3VudDogR0FNRV9DT05GSUcuZGV2SW5jcmVtZW50QW1vdW50IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJvbGUgPT09IFwibW9kZWxcIikgYWN0aW9ucy5kZXZJbmNyZW1lbnRNb2RlbCh7IGFtb3VudDogR0FNRV9DT05GSUcuZGV2SW5jcmVtZW50QW1vdW50IH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFJPTEVfQ09MT1JTW3JvbGVdICsgXCIxNVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Uk9MRV9DT0xPUlNbcm9sZV19NDBgLFxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCI1cHggOHB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogMTAsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogUk9MRV9DT0xPUlNbcm9sZV0sXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogNzAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWduOiBcImxlZnRcIixcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge1JPTEVfSUNPTlNbcm9sZV19ICt7R0FNRV9DT05GSUcuZGV2SW5jcmVtZW50QW1vdW50fSVcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN0cmwtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWN0aW9ucy5kZXZTZXRDb29saW5nVGVtcCh7IHRlbXBlcmF0dXJlOiBNYXRoLm1heCg1MCwgc3RhdGUuY29vbGluZy50ZW1wZXJhdHVyZSAtIDUpIH0pfVxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiIzM4YmRmODE1XCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjMzhiZGY4NDBcIixcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCI1cHggOHB4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDEwLFxuICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMzOGJkZjhcIixcbiAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiLFxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDcwMCxcbiAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwibGVmdFwiLFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDwn4yhIENvb2wg4oiSNcKwQ1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdHJsLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFjdGlvbnMucmVzZXRHYW1lKCl9XG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDIzOSw2OCw2OCwwLjEpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCByZ2JhKDIzOSw2OCw2OCwwLjMpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA2LFxuICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IFwiNXB4IDhweFwiLFxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxMCxcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjZjg3MTcxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOKGuiBSZXNldFxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogOSwgY29sb3I6IFwiIzMzNDE1NVwiIH19PlxuICAgICAgICAgICAgICAgICAge2hvc3QucGxheWVycy5sZW5ndGh9IGNvbnRyb2xsZXIocykgwrcge09iamVjdC5rZXlzKHN0YXRlLnJvbGVBc3NpZ25tZW50cykubGVuZ3RofSByb2xlKHMpXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9TdXJmYWNlVmlld3BvcnQ+XG4gICAgICAgIDxIb3N0UHJldmlld0NvbnRyb2xsZXJXb3Jrc3BhY2UgLz5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICAvLyDilIDilIAgRU5ERUQgU0NSRUVOIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByZXR1cm4gPEVuZGVkU2NyZWVuIHN0YXRlPXtzdGF0ZX0gYWN0aW9ucz17YWN0aW9uc30gLz47XG59XG5cbi8vIOKUgOKUgCBFbmRlZCBTY3JlZW4gKGV4dHJhY3RlZCB0byBhdm9pZCBob29rIG9yZGVyaW5nIGlzc3Vlcykg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIEVuZGVkU2NyZWVuKHtcbiAgc3RhdGUsXG4gIGFjdGlvbnMsXG59OiB7XG4gIHN0YXRlOiBGYWN0b3J5U3RhdGU7XG4gIGFjdGlvbnM6IFJldHVyblR5cGU8dHlwZW9mIHVzZUZhY3RvcnlTdG9yZS51c2VBY3Rpb25zPjtcbn0pIHtcbiAgY29uc3Qgc3VjY2VzcyA9IHN0YXRlLmZpbmFsUmVzdWx0ID09PSBcInN1Y2Nlc3NcIjtcbiAgY29uc3QgW2RlcGxveVBoYXNlLCBzZXREZXBsb3lQaGFzZV0gPSB1c2VTdGF0ZTxcImRlcGxveWluZ1wiIHwgXCJyZXZlYWxlZFwiPihcbiAgICBzdWNjZXNzID8gXCJkZXBsb3lpbmdcIiA6IFwicmV2ZWFsZWRcIixcbiAgKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzdWNjZXNzKSB7XG4gICAgICBjb25zdCB0ID0gc2V0VGltZW91dCgoKSA9PiBzZXREZXBsb3lQaGFzZShcInJldmVhbGVkXCIpLCAyNTAwKTtcbiAgICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodCk7XG4gICAgfVxuICB9LCBbc3VjY2Vzc10pO1xuXG4gIGNvbnN0IGNyaXRpY2FsTWluID0gR0FNRV9DT05GSUcuY3JpdGljYWxEZXB0TWluaW11bTtcblxuICBjb25zdCBkZXB0UmVzdWx0cyA9IEFMTF9ST0xFUy5tYXAoKHJvbGUpID0+IHtcbiAgICBjb25zdCBkZXB0ID0gc3RhdGVbcm9sZV0gYXMgeyBwcm9ncmVzczogbnVtYmVyOyBzY29yZTogbnVtYmVyOyBzdGF0dXM6IHN0cmluZyB9O1xuICAgIGNvbnN0IHBhc3NlZCA9IGRlcHQucHJvZ3Jlc3MgPj0gY3JpdGljYWxNaW47XG4gICAgcmV0dXJuIHsgcm9sZSwgcHJvZ3Jlc3M6IGRlcHQucHJvZ3Jlc3MsIHNjb3JlOiBkZXB0LnNjb3JlLCBwYXNzZWQgfTtcbiAgfSk7XG5cbiAgLy8g4pSA4pSAIERlcGxveWluZyBhbmltYXRpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGlmIChkZXBsb3lQaGFzZSA9PT0gXCJkZXBsb3lpbmdcIikge1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8U3VyZmFjZVZpZXdwb3J0IGNsYXNzTmFtZT1cImJnLVsjMDUwYTE0XVwiPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgaGVpZ2h0OiBcIjEwMCVcIixcbiAgICAgICAgICAgICAgZ2FwOiAzMixcbiAgICAgICAgICAgICAgcGFkZGluZzogNDAsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogNDgsXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsXG4gICAgICAgICAgICAgICAgY29sb3I6IFwiIzM4YmRmOFwiLFxuICAgICAgICAgICAgICAgIHRleHRTaGFkb3c6IFwiMCAwIDQwcHggcmdiYSg1NiwxODksMjQ4LDAuNylcIixcbiAgICAgICAgICAgICAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCIsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEFJIENPUkUgREVQTE9ZSU5HXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogMTQsXG4gICAgICAgICAgICAgICAgY29sb3I6IFwiIzQ3NTU2OVwiLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xNWVtXCIsXG4gICAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcbiAgICAgICAgICAgICAgICBhbmltYXRpb246IFwid2FybmluZ1B1bHNlIDFzIGVhc2UtaW4tb3V0IGluZmluaXRlXCIsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEluaXRpYWxpc2luZyBuZXVyYWwgcGF0aHdheXPigKZcbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRGVwbG95IHByb2dyZXNzIGJhciAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICB3aWR0aDogXCJtaW4oNDgwcHgsIDkwJSlcIixcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiMwZjE3MmFcIixcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxNixcbiAgICAgICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcbiAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHJnYmEoNTYsMTg5LDI0OCwwLjIpXCIsXG4gICAgICAgICAgICAgICAgYm94U2hhZG93OiBcIjAgMCAyMHB4IHJnYmEoNTYsMTg5LDI0OCwwLjE1KVwiLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcImxpbmVhci1ncmFkaWVudCg5MGRlZywgIzAzNjlhMSwgIzM4YmRmOCwgIzRhZGU4MClcIixcbiAgICAgICAgICAgICAgICAgIGJveFNoYWRvdzogXCIwIDAgMTJweCByZ2JhKDU2LDE4OSwyNDgsMC42KVwiLFxuICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uOiBcImRlcGxveUZpbGwgMi4ycyBlYXNlLW91dCBmb3J3YXJkc1wiLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogNjQgfX0+8J+kljwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L1N1cmZhY2VWaWV3cG9ydD5cbiAgICAgICAgPEhvc3RQcmV2aWV3Q29udHJvbGxlcldvcmtzcGFjZSAvPlxuICAgICAgPC8+XG4gICAgKTtcbiAgfVxuXG4gIC8vIOKUgOKUgCBSZXZlYWxlZCByZXN1bHQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxTdXJmYWNlVmlld3BvcnRcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBzdWNjZXNzXG4gICAgICAgICAgICA/IFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgY2VudGVyLCByZ2JhKDc0LDIyMiwxMjgsMC4wNikgMCUsICMwNTBhMTQgNzAlKVwiXG4gICAgICAgICAgICA6IFwicmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgY2VudGVyLCByZ2JhKDIzOSw2OCw2OCwwLjA4KSAwJSwgIzA1MGExNCA3MCUpXCIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgICAgICAgaGVpZ2h0OiBcIjEwMCVcIixcbiAgICAgICAgICAgIGdhcDogMjQsXG4gICAgICAgICAgICBwYWRkaW5nOiAzMixcbiAgICAgICAgICAgIG92ZXJmbG93OiBcImF1dG9cIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgey8qIE1haW4gcmVzdWx0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVzdWx0LXJldmVhbFwiIHN0eWxlPXt7IHRleHRBbGlnbjogXCJjZW50ZXJcIiB9fT5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogNTIsXG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNGVtXCIsXG4gICAgICAgICAgICAgICAgY29sb3I6IHN1Y2Nlc3MgPyBcIiM0YWRlODBcIiA6IFwiI2Y4NzE3MVwiLFxuICAgICAgICAgICAgICAgIHRleHRTaGFkb3c6IHN1Y2Nlc3NcbiAgICAgICAgICAgICAgICAgID8gXCIwIDAgNTBweCByZ2JhKDc0LDIyMiwxMjgsMC43KVwiXG4gICAgICAgICAgICAgICAgICA6IFwiMCAwIDUwcHggcmdiYSgyMzksNjgsNjgsMC43KVwiLFxuICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IDEuMSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3N1Y2Nlc3MgPyBcIvCfj60gQUkgRkFDVE9SWSBPTkxJTkVcIiA6IFwi8J+aqCBBSSBGQUNUT1JZIEZBSUxFRFwifVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgbWFyZ2luVG9wOiA4LFxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAyMCxcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXG4gICAgICAgICAgICAgICAgY29sb3I6IHN1Y2Nlc3MgPyBcIiM4NmVmYWNcIiA6IFwiI2ZjYTVhNVwiLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIixcbiAgICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7c3VjY2VzcyA/IFwiQUkgU3VjY2Vzc2Z1bGx5IERlcGxveWVkXCIgOiBcIkFJIERlcGxveW1lbnQgVW5zdWNjZXNzZnVsXCJ9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTY29yZSByb3cgKi99XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVzdWx0LXJldmVhbCByZXN1bHQtcmV2ZWFsLWRlbGF5LTFcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICAgICAgICAgIGdhcDogMzIsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSgxNSwzMiw1MywwLjgpXCIsXG4gICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgcmdiYSg1NiwxODksMjQ4LDAuMTUpXCIsXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTYsXG4gICAgICAgICAgICAgIHBhZGRpbmc6IFwiMTZweCAzMnB4XCIsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAxMSwgY29sb3I6IFwiIzQ3NTU2OVwiLCB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMWVtXCIgfX0+XG4gICAgICAgICAgICAgICAgRmFjdG9yeSBIZWFsdGhcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LW1vbm8pXCIsXG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogNDAsXG4gICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA5MDAsXG4gICAgICAgICAgICAgICAgICBjb2xvcjogaGVhbHRoQ29sb3Ioc3RhdGUuZmFjdG9yeUhlYWx0aCksXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtzdGF0ZS5mYWN0b3J5SGVhbHRofSVcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDEsIGJhY2tncm91bmQ6IFwicmdiYSg1NiwxODksMjQ4LDAuMSlcIiB9fSAvPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIgfX0+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDExLCBjb2xvcjogXCIjNDc1NTY5XCIsIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIiB9fT5cbiAgICAgICAgICAgICAgICBUZWFtIFNjb3JlXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IFwidmFyKC0tZm9udC1tb25vKVwiLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDQwLFxuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzM4YmRmOFwiLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7c3RhdGUudGVhbVNjb3JlLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRGVwYXJ0bWVudCBicmVha2Rvd24gKi99XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVzdWx0LXJldmVhbCByZXN1bHQtcmV2ZWFsLWRlbGF5LTJcIlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJncmlkXCIsXG4gICAgICAgICAgICAgIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwicmVwZWF0KDUsIDFmcilcIixcbiAgICAgICAgICAgICAgZ2FwOiAxMCxcbiAgICAgICAgICAgICAgd2lkdGg6IFwiMTAwJVwiLFxuICAgICAgICAgICAgICBtYXhXaWR0aDogNjQwLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7ZGVwdFJlc3VsdHMubWFwKCh7IHJvbGUsIHByb2dyZXNzLCBwYXNzZWQgfSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBjb2xvciA9IFJPTEVfQ09MT1JTW3JvbGVdO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17cm9sZX1cbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogcGFzc2VkID8gY29sb3IgKyBcIjEwXCIgOiBcInJnYmEoMjM5LDY4LDY4LDAuMDgpXCIsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogYDEuNXB4IHNvbGlkICR7cGFzc2VkID8gY29sb3IgKyBcIjUwXCIgOiBcInJnYmEoMjM5LDY4LDY4LDAuNClcIn1gLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcIjEwcHggNnB4XCIsXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6IDIwLCBtYXJnaW5Cb3R0b206IDQgfX0+e1JPTEVfSUNPTlNbcm9sZV19PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDksXG4gICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHBhc3NlZCA/IGNvbG9yIDogXCIjZjg3MTcxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogOTAwLFxuICAgICAgICAgICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjA2ZW1cIixcbiAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IDYsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtST0xFX0xBQkVMU1tyb2xlXS5yZXBsYWNlKFwiIEVuZ2luZWVyXCIsIFwiXCIpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseTogXCJ2YXIoLS1mb250LW1vbm8pXCIsXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDIyLFxuICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDkwMCxcbiAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogcGFzc2VkID8gY29sb3IgOiBcIiNmODcxNzFcIixcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3Byb2dyZXNzfSVcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogMTYsIG1hcmdpblRvcDogMiB9fT57cGFzc2VkID8gXCLinJNcIiA6IFwi4pyXXCJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGYWlsdXJlIHJlYXNvbiAqL31cbiAgICAgICAgICB7IXN1Y2Nlc3MgJiYgKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZXN1bHQtcmV2ZWFsIHJlc3VsdC1yZXZlYWwtZGVsYXktM1wiXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgY29sb3I6IFwiI2Y4NzE3MVwiLFxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxMixcbiAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXG4gICAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjFlbVwiLFxuICAgICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwidXBwZXJjYXNlXCIsXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCJyZ2JhKDIzOSw2OCw2OCwwLjA4KVwiLFxuICAgICAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgcmdiYSgyMzksNjgsNjgsMC4yNSlcIixcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDgsXG4gICAgICAgICAgICAgICAgcGFkZGluZzogXCI2cHggMTZweFwiLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7c3RhdGUuZmFjdG9yeUhlYWx0aCA8IEdBTUVfQ09ORklHLmZhY3RvcnlTdWNjZXNzVGhyZXNob2xkXG4gICAgICAgICAgICAgICAgPyBgRmFjdG9yeSBIZWFsdGggJHtzdGF0ZS5mYWN0b3J5SGVhbHRofSUg4oCUIFJlcXVpcmVkICR7R0FNRV9DT05GSUcuZmFjdG9yeVN1Y2Nlc3NUaHJlc2hvbGR9JWBcbiAgICAgICAgICAgICAgICA6IGBDcml0aWNhbCBkZXB0IGJlbG93ICR7R0FNRV9DT05GSUcuY3JpdGljYWxEZXB0TWluaW11bX0lIOKAlCAke1xuICAgICAgICAgICAgICAgICAgICBkZXB0UmVzdWx0cy5maW5kKChkKSA9PiAhZC5wYXNzZWQpXG4gICAgICAgICAgICAgICAgICAgICAgPyBST0xFX0xBQkVMU1tkZXB0UmVzdWx0cy5maW5kKChkKSA9PiAhZC5wYXNzZWQpIS5yb2xlXVxuICAgICAgICAgICAgICAgICAgICAgIDogXCJVbmtub3duXCJcbiAgICAgICAgICAgICAgICAgIH0gZmFpbGVkYH1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogUGxheSBBZ2FpbiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFjdGlvbnMucmVzZXRHYW1lKCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjdHJsLWJ1dHRvbiByZXN1bHQtcmV2ZWFsIHJlc3VsdC1yZXZlYWwtZGVsYXktNFwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBzdWNjZXNzXG4gICAgICAgICAgICAgICAgPyBcImxpbmVhci1ncmFkaWVudCgxMzVkZWcsICMxNDUzMmQsICM0YWRlODApXCJcbiAgICAgICAgICAgICAgICA6IFwibGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzFlM2E1ZiwgIzM4YmRmOClcIixcbiAgICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxNixcbiAgICAgICAgICAgICAgcGFkZGluZzogXCIxNnB4IDQ4cHhcIixcbiAgICAgICAgICAgICAgZm9udFNpemU6IDIwLFxuICAgICAgICAgICAgICBmb250V2VpZ2h0OiA5MDAsXG4gICAgICAgICAgICAgIGNvbG9yOiBcIndoaXRlXCIsXG4gICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIixcbiAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcbiAgICAgICAgICAgICAgY3Vyc29yOiBcInBvaW50ZXJcIixcbiAgICAgICAgICAgICAgYm94U2hhZG93OiBzdWNjZXNzXG4gICAgICAgICAgICAgICAgPyBcIjAgMCA0MHB4IHJnYmEoNzQsMjIyLDEyOCwwLjMpXCJcbiAgICAgICAgICAgICAgICA6IFwiMCAwIDQwcHggcmdiYSg1NiwxODksMjQ4LDAuMylcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3N1Y2Nlc3MgPyBcIvCfjokgUGxheSBBZ2FpblwiIDogXCLwn5SEIFRyeSBBZ2FpblwifVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU3VyZmFjZVZpZXdwb3J0PlxuICAgICAgPEhvc3RQcmV2aWV3Q29udHJvbGxlcldvcmtzcGFjZSAvPlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9BaUZhY3Rvcnkvc3JjL2hvc3QvaW5kZXgudHN4In0=