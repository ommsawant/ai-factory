import {
  createAirJamDiagnosticError,
  hostRuntimeContext,
  useAirJamContext,
  useAssertSessionScope,
  useShallow,
  useStore
} from "/node_modules/.vite/deps/chunk-B6OEUIDA.js?v=c74894a2";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-DOQUEKBH.js?v=c74894a2";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-DP4XHQAG.js?v=c74894a2";

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-E5PVHEAX.js
var import_react = __toESM(require_react(), 1);
var toHostState = (state) => ({
  roomId: state.roomId,
  connectionStatus: state.connectionStatus,
  players: state.players,
  controllers: state.controllerSessions,
  lastError: state.lastError,
  mode: state.mode,
  runtimeState: state.runtimeState
});
function useAirJamHost(selector) {
  useAssertSessionScope("host", "useAirJamHost");
  const { store } = useAirJamContext();
  const selectedState = useStore(
    store,
    useShallow((state) => {
      const hostState = toHostState(state);
      return selector ? selector(hostState) : hostState;
    })
  );
  const runtime = (0, import_react.useContext)(
    hostRuntimeContext
  );
  if (!runtime) {
    throw createAirJamDiagnosticError(
      "AJ_SCOPE_MISMATCH",
      "useAirJamHost requires a mounted host runtime boundary. Wrap the host tree with <AirJamHostRuntime> or <airjam.Host> before reading host state.",
      {
        hookName: "useAirJamHost",
        expectedScope: "host",
        receivedScope: "host"
      }
    );
  }
  if (selector) {
    return selectedState;
  }
  return {
    ...selectedState,
    ...runtime
  };
}
var alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
var generateControllerId = () => {
  const stamp = Math.floor(Date.now() % 1e5).toString().padStart(5, "0");
  const random = alphabet[Math.floor(Math.random() * alphabet.length)];
  return `C${random}${stamp}`;
};
var AIR_JAM_PREVIEW_FLAG_QUERY_PARAM = "aj_preview";
var AIR_JAM_PREVIEW_DEVICE_QUERY_PARAM = "aj_preview_device";
var generatePreviewDeviceId = () => {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return `pd_${crypto.randomUUID()}`;
  }
  return `pd_${generateControllerId()}_${Date.now().toString(36)}`;
};
var createPreviewControllerIdentity = () => ({
  controllerId: generateControllerId(),
  deviceId: generatePreviewDeviceId()
});
var normalizePreviewDeviceId = (value) => {
  if (!value) {
    return null;
  }
  const normalized = value.trim();
  return normalized.length >= 8 ? normalized : null;
};
var isPreviewControllerSearchParams = (params) => {
  const flag = params.get(AIR_JAM_PREVIEW_FLAG_QUERY_PARAM);
  return flag === "1" || flag === "true";
};
var readPreviewControllerDeviceIdFromSearchParams = (params) => {
  if (!isPreviewControllerSearchParams(params)) {
    return null;
  }
  return normalizePreviewDeviceId(
    params.get(AIR_JAM_PREVIEW_DEVICE_QUERY_PARAM)
  );
};
var readPreviewControllerDeviceIdFromLocation = () => {
  if (typeof window === "undefined") {
    return null;
  }
  return readPreviewControllerDeviceIdFromSearchParams(
    new URLSearchParams(window.location.search)
  );
};
var AIR_JAM_PREVIEW_CLOSE_REQUEST = "airjam.preview.close.request";
var AIR_JAM_PREVIEW_CLOSE_RESULT = "airjam.preview.close.result";
var isPreviewCloseRequestMessage = (value) => typeof value === "object" && value !== null && value.type === AIR_JAM_PREVIEW_CLOSE_REQUEST;
var isPreviewCloseResultMessage = (value) => typeof value === "object" && value !== null && value.type === AIR_JAM_PREVIEW_CLOSE_RESULT && typeof value.ok === "boolean";

export {
  useAirJamHost,
  generateControllerId,
  AIR_JAM_PREVIEW_FLAG_QUERY_PARAM,
  AIR_JAM_PREVIEW_DEVICE_QUERY_PARAM,
  createPreviewControllerIdentity,
  normalizePreviewDeviceId,
  isPreviewControllerSearchParams,
  readPreviewControllerDeviceIdFromSearchParams,
  readPreviewControllerDeviceIdFromLocation,
  AIR_JAM_PREVIEW_CLOSE_REQUEST,
  AIR_JAM_PREVIEW_CLOSE_RESULT,
  isPreviewCloseRequestMessage,
  isPreviewCloseResultMessage
};
//# sourceMappingURL=chunk-YTXXUP4X.js.map
