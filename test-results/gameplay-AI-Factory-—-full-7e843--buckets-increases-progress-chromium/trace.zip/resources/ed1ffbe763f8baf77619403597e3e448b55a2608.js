import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c74894a2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/AiFactory/src/app.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c74894a2"; const Suspense = __vite__cjsImport3_react["Suspense"]; const lazy = __vite__cjsImport3_react["lazy"];
import { Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=c74894a2";
import { airjam } from "/src/airjam.config.ts";
const HostView = lazy(_c = async () => {
  const module = await import("/src/host/index.tsx");
  return { default: module.HostView };
});
_c2 = HostView;
const ControllerView = lazy(_c3 = async () => {
  const module = await import("/src/controller/index.tsx");
  return { default: module.ControllerView };
});
_c4 = ControllerView;
const LoadingScreen = () => /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen w-screen items-center justify-center bg-neutral-950 text-neutral-300", children: /* @__PURE__ */ jsxDEV("div", { className: "text-xs tracking-[0.2em] text-neutral-500 uppercase", children: "Loading" }, void 0, false, {
  fileName: "D:/AiFactory/src/app.tsx",
  lineNumber: 42,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "D:/AiFactory/src/app.tsx",
  lineNumber: 41,
  columnNumber: 1
}, this);
_c5 = LoadingScreen;
export function App() {
  return /* @__PURE__ */ jsxDEV(Suspense, { fallback: /* @__PURE__ */ jsxDEV(LoadingScreen, {}, void 0, false, {
    fileName: "D:/AiFactory/src/app.tsx",
    lineNumber: 50,
    columnNumber: 25
  }, this), children: /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/",
        element: /* @__PURE__ */ jsxDEV(airjam.Host, { children: /* @__PURE__ */ jsxDEV(HostView, {}, void 0, false, {
          fileName: "D:/AiFactory/src/app.tsx",
          lineNumber: 56,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/AiFactory/src/app.tsx",
          lineNumber: 55,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/app.tsx",
        lineNumber: 52,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: airjam.paths.controller,
        element: /* @__PURE__ */ jsxDEV(airjam.Controller, { children: /* @__PURE__ */ jsxDEV(ControllerView, {}, void 0, false, {
          fileName: "D:/AiFactory/src/app.tsx",
          lineNumber: 64,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/AiFactory/src/app.tsx",
          lineNumber: 63,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/AiFactory/src/app.tsx",
        lineNumber: 60,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/AiFactory/src/app.tsx",
    lineNumber: 51,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/AiFactory/src/app.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_c6 = App;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "HostView$lazy");
$RefreshReg$(_c2, "HostView");
$RefreshReg$(_c3, "ControllerView$lazy");
$RefreshReg$(_c4, "ControllerView");
$RefreshReg$(_c5, "LoadingScreen");
$RefreshReg$(_c6, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/AiFactory/src/app.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/AiFactory/src/app.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJKLFNBQVNBLFVBQVVDLFlBQVk7QUFDL0IsU0FBU0MsT0FBT0MsY0FBYztBQUM5QixTQUFTQyxjQUFjO0FBRXZCLE1BQU1DLFdBQVdKLEtBQUlLLEtBQUMsWUFBWTtBQUNoQyxRQUFNQyxTQUFTLE1BQU0sT0FBTyxRQUFRO0FBQ3BDLFNBQU8sRUFBRUMsU0FBU0QsT0FBT0YsU0FBUztBQUNwQyxDQUFDO0FBQUVJLE1BSEdKO0FBS04sTUFBTUssaUJBQWlCVCxLQUFJVSxNQUFDLFlBQVk7QUFDdEMsUUFBTUosU0FBUyxNQUFNLE9BQU8sY0FBYztBQUMxQyxTQUFPLEVBQUVDLFNBQVNELE9BQU9HLGVBQWU7QUFDMUMsQ0FBQztBQUFFRSxNQUhHRjtBQUtOLE1BQU1HLGdCQUFnQkEsTUFDcEIsdUJBQUMsU0FBSSxXQUFVLHNGQUNiLGlDQUFDLFNBQUksV0FBVSx1REFBcUQsdUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FJQTtBQUNBQyxNQU5JRDtBQVFDLGdCQUFTRSxNQUFNO0FBQ3BCLFNBQ0UsdUJBQUMsWUFBUyxVQUFVLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBYyxHQUNoQyxpQ0FBQyxVQUNDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQ0UsdUJBQUMsT0FBTyxNQUFQLEVBQ0MsaUNBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVMsS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVIO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNWCxPQUFPWSxNQUFNQztBQUFBQSxRQUNuQixTQUNFLHVCQUFDLE9BQU8sWUFBUCxFQUNDLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxPQWZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNDLE1BdkJlSDtBQUFHLElBQUFULElBQUFHLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFJO0FBQUEsYUFBQVosSUFBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBSSxLQUFBIiwibmFtZXMiOlsiU3VzcGVuc2UiLCJsYXp5IiwiUm91dGUiLCJSb3V0ZXMiLCJhaXJqYW0iLCJIb3N0VmlldyIsIl9jIiwibW9kdWxlIiwiZGVmYXVsdCIsIl9jMiIsIkNvbnRyb2xsZXJWaWV3IiwiX2MzIiwiX2M0IiwiTG9hZGluZ1NjcmVlbiIsIl9jNSIsIkFwcCIsInBhdGhzIiwiY29udHJvbGxlciIsIl9jNiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogUm91dGUgc2hlbGwuIEhvc3QgKyBjb250cm9sbGVyIHZpZXdzIGFyZSBsYXp5LWxvYWRlZCBzbyBlYWNoIHN1cmZhY2Ugb25seVxuICogcHVsbHMgdGhlIGNvZGUgaXQgbmVlZHMuIFRoZSByZWFsIHN1cmZhY2VzIGxpdmUgaW4gYC4vaG9zdGAgYW5kXG4gKiBgLi9jb250cm9sbGVyYCwgYm90aCB3cmFwcGVkIGJ5IHRoZSBsaWZlY3ljbGUgcHJvdmlkZXJzIGZyb21cbiAqIGBhaXJqYW0uY29uZmlnLnRzYC5cbiAqL1xuaW1wb3J0IHsgU3VzcGVuc2UsIGxhenkgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFJvdXRlLCBSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgYWlyamFtIH0gZnJvbSBcIi4vYWlyamFtLmNvbmZpZ1wiO1xuXG5jb25zdCBIb3N0VmlldyA9IGxhenkoYXN5bmMgKCkgPT4ge1xuICBjb25zdCBtb2R1bGUgPSBhd2FpdCBpbXBvcnQoXCIuL2hvc3RcIik7XG4gIHJldHVybiB7IGRlZmF1bHQ6IG1vZHVsZS5Ib3N0VmlldyB9O1xufSk7XG5cbmNvbnN0IENvbnRyb2xsZXJWaWV3ID0gbGF6eShhc3luYyAoKSA9PiB7XG4gIGNvbnN0IG1vZHVsZSA9IGF3YWl0IGltcG9ydChcIi4vY29udHJvbGxlclwiKTtcbiAgcmV0dXJuIHsgZGVmYXVsdDogbW9kdWxlLkNvbnRyb2xsZXJWaWV3IH07XG59KTtcblxuY29uc3QgTG9hZGluZ1NjcmVlbiA9ICgpID0+IChcbiAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtc2NyZWVuIHctc2NyZWVuIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1uZXV0cmFsLTk1MCB0ZXh0LW5ldXRyYWwtMzAwXCI+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRyYWNraW5nLVswLjJlbV0gdGV4dC1uZXV0cmFsLTUwMCB1cHBlcmNhc2VcIj5cbiAgICAgIExvYWRpbmdcbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG4pO1xuXG5leHBvcnQgZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PExvYWRpbmdTY3JlZW4gLz59PlxuICAgICAgPFJvdXRlcz5cbiAgICAgICAgPFJvdXRlXG4gICAgICAgICAgcGF0aD1cIi9cIlxuICAgICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgICAgPGFpcmphbS5Ib3N0PlxuICAgICAgICAgICAgICA8SG9zdFZpZXcgLz5cbiAgICAgICAgICAgIDwvYWlyamFtLkhvc3Q+XG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgICA8Um91dGVcbiAgICAgICAgICBwYXRoPXthaXJqYW0ucGF0aHMuY29udHJvbGxlcn1cbiAgICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICAgIDxhaXJqYW0uQ29udHJvbGxlcj5cbiAgICAgICAgICAgICAgPENvbnRyb2xsZXJWaWV3IC8+XG4gICAgICAgICAgICA8L2FpcmphbS5Db250cm9sbGVyPlxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgIDwvUm91dGVzPlxuICAgIDwvU3VzcGVuc2U+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0FpRmFjdG9yeS9zcmMvYXBwLnRzeCJ9