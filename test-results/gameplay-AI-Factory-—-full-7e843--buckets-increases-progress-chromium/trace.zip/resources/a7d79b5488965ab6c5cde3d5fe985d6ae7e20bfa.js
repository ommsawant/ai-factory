import {
  AIR_JAM_SDK_VERSION,
  controllerOrientationSchema,
  controllerRuntimeContext,
  createAirJamDiagnosticError,
  createBridgeHandshake,
  normalizeRuntimeUrl,
  parseOptionalArcadeSurfaceFromSearchParams,
  parseRuntimeTopologyFromSearchParams,
  resolveRuntimeTopology,
  useAirJamContext,
  useAssertSessionScope,
  useShallow,
  useStore,
  v2HandshakeSchema
} from "/node_modules/.vite/deps/chunk-B6OEUIDA.js?v=c74894a2";
import {
  external_exports
} from "/node_modules/.vite/deps/chunk-KQIFYUJI.js?v=c74894a2";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-DOQUEKBH.js?v=c74894a2";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-DP4XHQAG.js?v=c74894a2";

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-CVYR5RJT.js
var import_react = __toESM(require_react(), 1);
var toControllerState = (state) => {
  const selfPlayer = state.controllerId ? state.players.find((player) => player.id === state.controllerId) ?? null : null;
  return {
    roomId: state.roomId,
    controllerId: state.controllerId,
    connectionStatus: state.connectionStatus,
    lastError: state.lastError,
    runtimeState: state.runtimeState,
    controllerOrientation: state.controllerOrientation,
    stateMessage: state.stateMessage,
    roomSettings: state.roomSettings,
    players: state.players,
    selfPlayer
  };
};
function useAirJamController(selector) {
  useAssertSessionScope("controller", "useAirJamController");
  const { store } = useAirJamContext();
  const selectedState = useStore(
    store,
    useShallow((state) => {
      const controllerState = toControllerState(state);
      return selector ? selector(controllerState) : controllerState;
    })
  );
  const runtime = (0, import_react.useContext)(
    controllerRuntimeContext
  );
  if (!runtime) {
    throw createAirJamDiagnosticError(
      "AJ_SCOPE_MISMATCH",
      "useAirJamController requires a mounted controller runtime boundary. Wrap the controller tree with <AirJamControllerRuntime> or <airjam.Controller> before reading controller state.",
      {
        hookName: "useAirJamController",
        expectedScope: "controller",
        receivedScope: "controller"
      }
    );
  }
  if (selector) {
    return selectedState;
  }
  return {
    ...selectedState,
    ...runtime
  };
}
var parseOrigin = (value) => {
  if (!value) {
    return null;
  }
  try {
    return new URL(value).origin;
  } catch {
    return null;
  }
};
var resolveLegacyEmbeddedTopology = ({
  surfaceRole,
  joinUrl
}) => {
  if (typeof window === "undefined") {
    return null;
  }
  const appOrigin = window.location.origin;
  const joinUrlOrigin = parseOrigin(joinUrl);
  const referrerOrigin = parseOrigin(document.referrer);
  const embedParentOrigin = joinUrlOrigin ?? referrerOrigin ?? appOrigin;
  const publicHost = joinUrlOrigin ?? appOrigin;
  const secureTransport = appOrigin.startsWith("https://") && publicHost.startsWith("https://") && embedParentOrigin.startsWith("https://");
  return resolveRuntimeTopology({
    runtimeMode: "arcade-live",
    surfaceRole,
    appOrigin,
    backendOrigin: appOrigin,
    socketOrigin: appOrigin,
    publicHost,
    assetBasePath: "/",
    secureTransport,
    embedded: true,
    embedParentOrigin,
    proxyStrategy: "none"
  });
};
var readChildHostRuntimeParams = () => {
  if (typeof window === "undefined") {
    return null;
  }
  const params = new URLSearchParams(window.location.search);
  const room = params.get("aj_room");
  const capabilityToken = params.get("aj_cap");
  if (!room || !capabilityToken) {
    return null;
  }
  const rawCapabilityExpiresAt = params.get("aj_cap_exp");
  const parsedCapabilityExpiresAt = rawCapabilityExpiresAt ? Number(rawCapabilityExpiresAt) : NaN;
  const joinUrl = params.get("aj_join_url");
  const normalizedJoinUrl = joinUrl ? normalizeRuntimeUrl(joinUrl) : null;
  const topology = parseRuntimeTopologyFromSearchParams(params) ?? resolveLegacyEmbeddedTopology({
    surfaceRole: "host",
    joinUrl: normalizedJoinUrl ?? void 0
  });
  if (!topology) {
    return null;
  }
  const arcadeSurface = parseOptionalArcadeSurfaceFromSearchParams(params);
  if (!arcadeSurface) {
    return null;
  }
  return {
    room,
    capabilityToken,
    capabilityExpiresAt: Number.isFinite(parsedCapabilityExpiresAt) ? parsedCapabilityExpiresAt : void 0,
    joinUrl: normalizedJoinUrl ?? void 0,
    topology,
    arcadeSurface
  };
};
var readEmbeddedControllerRuntimeParams = () => {
  var _a, _b;
  if (typeof window === "undefined") {
    return null;
  }
  const params = new URLSearchParams(window.location.search);
  const room = params.get("aj_room");
  const controllerId = params.get("aj_controller_id");
  if (!room || !controllerId) {
    return null;
  }
  const topology = parseRuntimeTopologyFromSearchParams(params) ?? resolveLegacyEmbeddedTopology({
    surfaceRole: "controller"
  });
  if (!topology) {
    return null;
  }
  const arcadeSurface = parseOptionalArcadeSurfaceFromSearchParams(params);
  if (!arcadeSurface) {
    return null;
  }
  const rawLabel = (_a = params.get("aj_player_label")) == null ? void 0 : _a.trim();
  const rawAvatarId = (_b = params.get("aj_player_avatar")) == null ? void 0 : _b.trim();
  const playerProfile = rawLabel || rawAvatarId ? {
    ...rawLabel ? { label: rawLabel } : {},
    ...rawAvatarId ? { avatarId: rawAvatarId } : {}
  } : void 0;
  return {
    room,
    controllerId,
    topology,
    arcadeSurface,
    ...playerProfile ? { playerProfile } : {}
  };
};

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-X24K52DG.js
var arcadeSurfaceRuntimeIdentitySchema = external_exports.object({
  epoch: external_exports.number().int().nonnegative(),
  kind: external_exports.enum(["browser", "game"]),
  gameId: external_exports.string().nullable()
}).strict();

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/chunk-KOB73SPD.js
var AIRJAM_CONTROLLER_BRIDGE_REQUEST = "AIRJAM_CONTROLLER_BRIDGE_REQUEST";
var AIRJAM_CONTROLLER_BRIDGE_ATTACH = "AIRJAM_CONTROLLER_BRIDGE_ATTACH";
var AIRJAM_CONTROLLER_BRIDGE_EVENT = "AIRJAM_CONTROLLER_BRIDGE_EVENT";
var AIRJAM_CONTROLLER_BRIDGE_EMIT = "AIRJAM_CONTROLLER_BRIDGE_EMIT";
var AIRJAM_CONTROLLER_BRIDGE_CLOSE = "AIRJAM_CONTROLLER_BRIDGE_CLOSE";
var AIRJAM_CONTROLLER_PRESENTATION_SYNC = "AIRJAM_CONTROLLER_PRESENTATION_SYNC";
var AIRJAM_CONTROLLER_BRIDGE_RESPONSE = "AIRJAM_CONTROLLER_BRIDGE_RESPONSE";
var controllerBridgeClientEvents = [
  "controller:input",
  "controller:action_rpc",
  "controller:state_sync_request",
  "controller:system",
  "controller:play_sound",
  "controller:updatePlayerProfile"
];
var controllerBridgeServerEvents = [
  "connect",
  "disconnect",
  "server:welcome",
  "server:controllerJoined",
  "server:controllerLeft",
  "server:state",
  "server:hostLeft",
  "server:error",
  "server:signal",
  "server:playSound",
  "server:playerUpdated",
  "airjam:state_sync"
];
var bridgeRequestSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_BRIDGE_REQUEST),
  payload: external_exports.object({
    handshake: v2HandshakeSchema,
    roomId: external_exports.string().min(1),
    controllerId: external_exports.string().min(1),
    arcadeSurface: arcadeSurfaceRuntimeIdentitySchema
  }).strict()
}).strict();
var bridgeAttachSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_BRIDGE_ATTACH),
  payload: external_exports.object({
    handshake: v2HandshakeSchema,
    snapshot: external_exports.object({
      roomId: external_exports.string().min(1),
      controllerId: external_exports.string().min(1),
      connected: external_exports.boolean(),
      socketId: external_exports.string().optional(),
      player: external_exports.unknown().optional(),
      players: external_exports.array(external_exports.unknown()).optional(),
      state: external_exports.unknown().optional(),
      arcadeSurface: arcadeSurfaceRuntimeIdentitySchema
    }).strict()
  }).strict()
}).strict();
var bridgeEventSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_BRIDGE_EVENT),
  payload: external_exports.object({
    event: external_exports.enum(controllerBridgeServerEvents),
    args: external_exports.array(external_exports.unknown()),
    requestId: external_exports.string().min(1).optional()
  }).strict()
}).strict();
var bridgeEmitSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_BRIDGE_EMIT),
  payload: external_exports.object({
    event: external_exports.enum(controllerBridgeClientEvents),
    args: external_exports.array(external_exports.unknown()),
    requestId: external_exports.string().min(1).optional()
  }).strict()
}).strict();
var bridgeResponseSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_BRIDGE_RESPONSE),
  payload: external_exports.object({
    requestId: external_exports.string().min(1),
    ack: external_exports.unknown()
  }).strict()
}).strict();
var bridgeCloseSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_BRIDGE_CLOSE),
  payload: external_exports.object({
    reason: external_exports.string().optional()
  }).strict()
}).strict();
var presentationSyncSchema = external_exports.object({
  type: external_exports.literal(AIRJAM_CONTROLLER_PRESENTATION_SYNC),
  payload: external_exports.object({
    orientation: controllerOrientationSchema,
    arcadeSurface: arcadeSurfaceRuntimeIdentitySchema
  }).strict()
}).strict();
var createControllerBridgeRequestMessage = (payload) => ({
  type: AIRJAM_CONTROLLER_BRIDGE_REQUEST,
  payload: {
    handshake: createBridgeHandshake({
      sdkVersion: AIR_JAM_SDK_VERSION,
      runtimeKind: "arcade-controller-iframe",
      capabilityFlags: {
        controllerBridge: true
      }
    }),
    roomId: payload.roomId,
    controllerId: payload.controllerId,
    arcadeSurface: payload.arcadeSurface
  }
});
var splitControllerBridgeArgs = (args) => {
  const maybeOptions = args[args.length - 1];
  const hasOptions = typeof maybeOptions === "object" && maybeOptions !== null && "requestId" in maybeOptions;
  return {
    eventArgs: hasOptions ? args.slice(0, -1) : args,
    ...hasOptions && maybeOptions.requestId ? { requestId: maybeOptions.requestId } : {}
  };
};
var createControllerBridgeEmitMessage = (event, ...args) => {
  const { eventArgs, requestId } = splitControllerBridgeArgs(args);
  return {
    type: AIRJAM_CONTROLLER_BRIDGE_EMIT,
    payload: {
      event,
      args: eventArgs,
      ...requestId ? { requestId } : {}
    }
  };
};
var createControllerBridgeCloseMessage = (reason) => ({
  type: AIRJAM_CONTROLLER_BRIDGE_CLOSE,
  payload: {
    reason
  }
});
var createControllerPresentationSyncMessage = (payload) => ({
  type: AIRJAM_CONTROLLER_PRESENTATION_SYNC,
  payload
});
var parseControllerBridgeAttachMessage = (value) => {
  const result = bridgeAttachSchema.safeParse(value);
  return result.success ? result.data : null;
};
var parseControllerBridgeEventMessage = (value) => {
  const result = bridgeEventSchema.safeParse(value);
  return result.success ? result.data : null;
};
var parseControllerBridgeResponseMessage = (value) => {
  const result = bridgeResponseSchema.safeParse(value);
  return result.success ? result.data : null;
};
var parseControllerBridgeCloseMessage = (value) => {
  const result = bridgeCloseSchema.safeParse(value);
  return result.success ? result.data : null;
};

export {
  useAirJamController,
  readChildHostRuntimeParams,
  readEmbeddedControllerRuntimeParams,
  arcadeSurfaceRuntimeIdentitySchema,
  createControllerBridgeRequestMessage,
  createControllerBridgeEmitMessage,
  createControllerBridgeCloseMessage,
  createControllerPresentationSyncMessage,
  parseControllerBridgeAttachMessage,
  parseControllerBridgeEventMessage,
  parseControllerBridgeResponseMessage,
  parseControllerBridgeCloseMessage
};
//# sourceMappingURL=chunk-FTUKOCBU.js.map
