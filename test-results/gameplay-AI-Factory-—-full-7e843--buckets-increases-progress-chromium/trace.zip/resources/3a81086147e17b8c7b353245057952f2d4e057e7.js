import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_AIR_JAM_APP_ID": "", "VITE_AIR_JAM_HOST_GRANT_ENDPOINT": "", "VITE_AIR_JAM_PUBLIC_HOST": "http://10.66.43.237:5173", "VITE_AIR_JAM_RUNTIME_TOPOLOGY": "{\"runtimeMode\":\"standalone-dev\",\"surfaceRole\":\"host\",\"appOrigin\":\"http://10.66.43.237:5173\",\"backendOrigin\":\"http://127.0.0.1:4000\",\"socketOrigin\":\"http://10.66.43.237:5173\",\"publicHost\":\"http://10.66.43.237:5173\",\"assetBasePath\":\"/\",\"secureTransport\":false,\"embedded\":false,\"proxyStrategy\":\"dev-proxy\"}", "VITE_AIR_JAM_SERVER_URL": "", "VITE_PORT": "5173"};import { createAirJamApp, env } from "/node_modules/.vite/deps/@air-jam_sdk.js?v=c74894a2";
import { defineAirJamGameMetadata } from "/node_modules/.vite/deps/@air-jam_sdk_metadata.js?v=c74894a2";
import { agentContract } from "/src/game/contracts/agent.ts";
import { gameInputSchema } from "/src/game/input.ts";
export const gameMetadata = defineAirJamGameMetadata({
  slug: "ai-factory",
  name: "AI Factory — Build • Break • Survive",
  tagline: "5-player cooperative game. Five engineers. One shared AI Factory. Deploy the AI before time runs out.",
  category: "party",
  minPlayers: 1,
  // allow 1 for dev/testing
  maxPlayers: 5,
  inputModalities: ["buttons", "touch", "motion"],
  supportedSdkRange: "^1.0.0",
  maintainer: { name: "Antigravity" },
  ageRating: "all-ages",
  tags: ["cooperative", "engineering", "ai", "expo", "mobile"]
});
export const airjam = createAirJamApp({
  runtime: env.vite(import.meta.env),
  metadata: gameMetadata,
  controllerPath: "/controller",
  agent: agentContract,
  input: {
    schema: gameInputSchema
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFpcmphbS5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBBaXIgSmFtIGFwcCBjb25maWcgZm9yIEFJIEZhY3Rvcnkg4oCUIEJ1aWxkIOKAoiBCcmVhayDigKIgU3Vydml2ZS5cbiAqXG4gKiBEZWNsYXJlcyBydW50aW1lIHRvcG9sb2d5LCBjb250cm9sbGVyIHN1Yi1yb3V0ZSwgaW5wdXQgc2NoZW1hIChDb29saW5nIGd5cm8pLFxuICogYW5kIHRoZSBzZW1hbnRpYyBhZ2VudCBjb250cmFjdC5cbiAqIGBlbnYudml0ZSguLi4pYCByZXNvbHZlcyB0b3BvbG9neSBmcm9tIGBWSVRFX0FJUl9KQU1fKmAgZW52IHZhcnMuXG4gKi9cbmltcG9ydCB7IGNyZWF0ZUFpckphbUFwcCwgZW52IH0gZnJvbSBcIkBhaXItamFtL3Nka1wiO1xuaW1wb3J0IHsgZGVmaW5lQWlySmFtR2FtZU1ldGFkYXRhIH0gZnJvbSBcIkBhaXItamFtL3Nkay9tZXRhZGF0YVwiO1xuaW1wb3J0IHsgYWdlbnRDb250cmFjdCB9IGZyb20gXCIuL2dhbWUvY29udHJhY3RzL2FnZW50XCI7XG5pbXBvcnQgeyBnYW1lSW5wdXRTY2hlbWEgfSBmcm9tIFwiLi9nYW1lL2lucHV0XCI7XG5cbmV4cG9ydCBjb25zdCBnYW1lTWV0YWRhdGEgPSBkZWZpbmVBaXJKYW1HYW1lTWV0YWRhdGEoe1xuICBzbHVnOiBcImFpLWZhY3RvcnlcIixcbiAgbmFtZTogXCJBSSBGYWN0b3J5IOKAlCBCdWlsZCDigKIgQnJlYWsg4oCiIFN1cnZpdmVcIixcbiAgdGFnbGluZTpcbiAgICBcIjUtcGxheWVyIGNvb3BlcmF0aXZlIGdhbWUuIEZpdmUgZW5naW5lZXJzLiBPbmUgc2hhcmVkIEFJIEZhY3RvcnkuIERlcGxveSB0aGUgQUkgYmVmb3JlIHRpbWUgcnVucyBvdXQuXCIsXG4gIGNhdGVnb3J5OiBcInBhcnR5XCIsXG4gIG1pblBsYXllcnM6IDEsICAgLy8gYWxsb3cgMSBmb3IgZGV2L3Rlc3RpbmdcbiAgbWF4UGxheWVyczogNSxcbiAgaW5wdXRNb2RhbGl0aWVzOiBbXCJidXR0b25zXCIsIFwidG91Y2hcIiwgXCJtb3Rpb25cIl0sXG4gIHN1cHBvcnRlZFNka1JhbmdlOiBcIl4xLjAuMFwiLFxuICBtYWludGFpbmVyOiB7IG5hbWU6IFwiQW50aWdyYXZpdHlcIiB9LFxuICBhZ2VSYXRpbmc6IFwiYWxsLWFnZXNcIixcbiAgdGFnczogW1wiY29vcGVyYXRpdmVcIiwgXCJlbmdpbmVlcmluZ1wiLCBcImFpXCIsIFwiZXhwb1wiLCBcIm1vYmlsZVwiXSxcbn0pO1xuXG5leHBvcnQgY29uc3QgYWlyamFtID0gY3JlYXRlQWlySmFtQXBwKHtcbiAgcnVudGltZTogZW52LnZpdGUoaW1wb3J0Lm1ldGEuZW52KSxcbiAgbWV0YWRhdGE6IGdhbWVNZXRhZGF0YSxcbiAgY29udHJvbGxlclBhdGg6IFwiL2NvbnRyb2xsZXJcIixcbiAgYWdlbnQ6IGFnZW50Q29udHJhY3QsXG4gIGlucHV0OiB7XG4gICAgc2NoZW1hOiBnYW1lSW5wdXRTY2hlbWEsXG4gIH0sXG59KTtcbiJdLCJtYXBwaW5ncyI6IkFBT0EsU0FBUyxpQkFBaUIsV0FBVztBQUNyQyxTQUFTLGdDQUFnQztBQUN6QyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHVCQUF1QjtBQUV6QixhQUFNLGVBQWUseUJBQXlCO0FBQUEsRUFDbkQsTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUFBLEVBQ04sU0FDRTtBQUFBLEVBQ0YsVUFBVTtBQUFBLEVBQ1YsWUFBWTtBQUFBO0FBQUEsRUFDWixZQUFZO0FBQUEsRUFDWixpQkFBaUIsQ0FBQyxXQUFXLFNBQVMsUUFBUTtBQUFBLEVBQzlDLG1CQUFtQjtBQUFBLEVBQ25CLFlBQVksRUFBRSxNQUFNLGNBQWM7QUFBQSxFQUNsQyxXQUFXO0FBQUEsRUFDWCxNQUFNLENBQUMsZUFBZSxlQUFlLE1BQU0sUUFBUSxRQUFRO0FBQzdELENBQUM7QUFFTSxhQUFNLFNBQVMsZ0JBQWdCO0FBQUEsRUFDcEMsU0FBUyxJQUFJLEtBQUssWUFBWSxHQUFHO0FBQUEsRUFDakMsVUFBVTtBQUFBLEVBQ1YsZ0JBQWdCO0FBQUEsRUFDaEIsT0FBTztBQUFBLEVBQ1AsT0FBTztBQUFBLElBQ0wsUUFBUTtBQUFBLEVBQ1Y7QUFDRixDQUFDOyIsIm5hbWVzIjpbXX0=