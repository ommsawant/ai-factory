export const GAME_CONFIG = {
  // --- Session ---
  maxPlayers: 5,
  gameDurationSeconds: 180,
  // 3 minutes
  // --- Department targets ---
  powerTarget: 100,
  dataTarget: 100,
  securityTarget: 100,
  modelTarget: 100,
  // --- Cooling safe range (°C) ---
  coolingTempStart: 95,
  // starting temperature
  coolingSafeMin: 70,
  coolingSafeMax: 75,
  // --- Cooling Engineer gyroscope mini-game ---
  /** Max tilt angle (degrees) that maps to the edge of the spirit-level bounds. */
  coolingMaxTiltAngle: 30,
  /** °C decrease per tick when bubble is perfectly centred (centeredness = 0). */
  coolingTempDecreasePerTick: 1.5,
  /** °C increase per tick when bubble is fully off-centre (centeredness = 1). */
  coolingTempIncreasePerTick: 2,
  /**
   * Fraction of the bounds radius within which the bubble is considered
   * "centred" and earns score.  0.25 = inner 25 % of the circle.
   */
  coolingCenteredThreshold: 0.25,
  /** How often the controller syncs its centeredness to the host (ms). */
  coolingTickThrottleMs: 500,
  // --- Scoring ---
  pointsPerPowerTap: 10,
  pointsPerDataSort: 25,
  // correct sort
  pointsPerDataMissort: 0,
  // incorrect sort (no penalty, just no gain)
  pointsPerZipZapHit: 15,
  pointsPerPuzzleStep: 50,
  // awarded per completed puzzle round
  pointsPerCoolingTick: 5,
  // --- Factory health thresholds ---
  factorySuccessThreshold: 70,
  // factory health % required to win
  criticalDeptMinimum: 40,
  // no dept may fall below this to win
  // --- Power mini-game ---
  /** Progress awarded for every valid controller tap (50 taps to complete). */
  powerIncrementPerTap: 2,
  // --- Data cleaning mini-game ---
  /** Progress awarded per correct sort (20 correct sorts to complete). */
  dataIncrementPerSort: 5,
  /** Throttle: min ms between sort submissions to prevent spam. */
  dataSortThrottleMs: 300,
  /** Number categories — these map to bucket 'numbers' */
  dataTokensNumbers: ["42", "7", "18", "91", "256", "3", "99", "1024", "0", "64"],
  /** AI term categories — these map to bucket 'ai_terms' */
  dataTokensAiTerms: ["AI", "ML", "DL", "GPU", "NLP", "LLM", "CNN", "GAN", "BERT", "API"],
  // --- Zip-Zap Firewall mini-game (Security Engineer) ---
  /** Progress awarded per correct button press (≈ 34 correct presses to complete). */
  securityIncrementPerHit: 3,
  /** Progress deducted per wrong button press (clamped to 0). */
  securityPenaltyPerMiss: 2,
  /** Starting length of the ZIP/ZAP sequence. */
  securitySequenceSeedLength: 4,
  /** Grow the sequence by 1 after every N correct hits. */
  securitySequenceGrowEvery: 6,
  /** Throttle: minimum ms between accepted inputs to prevent mashing. */
  securityHitThrottleMs: 150,
  // --- AI Core Puzzle mini-game (AI Model Engineer) ---
  /** Progress awarded per completed puzzle round (5 solves to reach 100%). */
  modelIncrementPerSolve: 20,
  // --- Dev/test increments (used by the dev test interface) ---
  devIncrementAmount: 10
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdhbWVDb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDZW50cmFsIGdhbWUgY29uZmlndXJhdGlvbi5cbiAqXG4gKiBBbGwgdHVuaW5nIGNvbnN0YW50cyBsaXZlIGhlcmUuIE5ldmVyIHNjYXR0ZXIgdGhlc2UgdmFsdWVzIGFjcm9zcyBjb21wb25lbnRzLlxuICogV2hlbiBwbGF5dGVzdGluZyByZXZlYWxzIGJhbGFuY2UgaXNzdWVzLCBjaGFuZ2UgdmFsdWVzIGhlcmUgb25seS5cbiAqL1xuZXhwb3J0IGNvbnN0IEdBTUVfQ09ORklHID0ge1xuICAvLyAtLS0gU2Vzc2lvbiAtLS1cbiAgbWF4UGxheWVyczogNSxcbiAgZ2FtZUR1cmF0aW9uU2Vjb25kczogMTgwLCAvLyAzIG1pbnV0ZXNcblxuICAvLyAtLS0gRGVwYXJ0bWVudCB0YXJnZXRzIC0tLVxuICBwb3dlclRhcmdldDogMTAwLFxuICBkYXRhVGFyZ2V0OiAxMDAsXG4gIHNlY3VyaXR5VGFyZ2V0OiAxMDAsXG4gIG1vZGVsVGFyZ2V0OiAxMDAsXG5cbiAgLy8gLS0tIENvb2xpbmcgc2FmZSByYW5nZSAowrBDKSAtLS1cbiAgY29vbGluZ1RlbXBTdGFydDogOTUsICAgLy8gc3RhcnRpbmcgdGVtcGVyYXR1cmVcbiAgY29vbGluZ1NhZmVNaW46IDcwLFxuICBjb29saW5nU2FmZU1heDogNzUsXG5cbiAgLy8gLS0tIENvb2xpbmcgRW5naW5lZXIgZ3lyb3Njb3BlIG1pbmktZ2FtZSAtLS1cbiAgLyoqIE1heCB0aWx0IGFuZ2xlIChkZWdyZWVzKSB0aGF0IG1hcHMgdG8gdGhlIGVkZ2Ugb2YgdGhlIHNwaXJpdC1sZXZlbCBib3VuZHMuICovXG4gIGNvb2xpbmdNYXhUaWx0QW5nbGU6IDMwLFxuICAvKiogwrBDIGRlY3JlYXNlIHBlciB0aWNrIHdoZW4gYnViYmxlIGlzIHBlcmZlY3RseSBjZW50cmVkIChjZW50ZXJlZG5lc3MgPSAwKS4gKi9cbiAgY29vbGluZ1RlbXBEZWNyZWFzZVBlclRpY2s6IDEuNSxcbiAgLyoqIMKwQyBpbmNyZWFzZSBwZXIgdGljayB3aGVuIGJ1YmJsZSBpcyBmdWxseSBvZmYtY2VudHJlIChjZW50ZXJlZG5lc3MgPSAxKS4gKi9cbiAgY29vbGluZ1RlbXBJbmNyZWFzZVBlclRpY2s6IDIuMCxcbiAgLyoqXG4gICAqIEZyYWN0aW9uIG9mIHRoZSBib3VuZHMgcmFkaXVzIHdpdGhpbiB3aGljaCB0aGUgYnViYmxlIGlzIGNvbnNpZGVyZWRcbiAgICogXCJjZW50cmVkXCIgYW5kIGVhcm5zIHNjb3JlLiAgMC4yNSA9IGlubmVyIDI1ICUgb2YgdGhlIGNpcmNsZS5cbiAgICovXG4gIGNvb2xpbmdDZW50ZXJlZFRocmVzaG9sZDogMC4yNSxcbiAgLyoqIEhvdyBvZnRlbiB0aGUgY29udHJvbGxlciBzeW5jcyBpdHMgY2VudGVyZWRuZXNzIHRvIHRoZSBob3N0IChtcykuICovXG4gIGNvb2xpbmdUaWNrVGhyb3R0bGVNczogNTAwLFxuXG4gIC8vIC0tLSBTY29yaW5nIC0tLVxuICBwb2ludHNQZXJQb3dlclRhcDogMTAsXG4gIHBvaW50c1BlckRhdGFTb3J0OiAyNSwgICAgLy8gY29ycmVjdCBzb3J0XG4gIHBvaW50c1BlckRhdGFNaXNzb3J0OiAwLCAgLy8gaW5jb3JyZWN0IHNvcnQgKG5vIHBlbmFsdHksIGp1c3Qgbm8gZ2FpbilcbiAgcG9pbnRzUGVyWmlwWmFwSGl0OiAxNSxcbiAgcG9pbnRzUGVyUHV6emxlU3RlcDogNTAsICAvLyBhd2FyZGVkIHBlciBjb21wbGV0ZWQgcHV6emxlIHJvdW5kXG4gIHBvaW50c1BlckNvb2xpbmdUaWNrOiA1LFxuXG4gIC8vIC0tLSBGYWN0b3J5IGhlYWx0aCB0aHJlc2hvbGRzIC0tLVxuICBmYWN0b3J5U3VjY2Vzc1RocmVzaG9sZDogNzAsIC8vIGZhY3RvcnkgaGVhbHRoICUgcmVxdWlyZWQgdG8gd2luXG4gIGNyaXRpY2FsRGVwdE1pbmltdW06IDQwLCAgICAgLy8gbm8gZGVwdCBtYXkgZmFsbCBiZWxvdyB0aGlzIHRvIHdpblxuXG4gIC8vIC0tLSBQb3dlciBtaW5pLWdhbWUgLS0tXG4gIC8qKiBQcm9ncmVzcyBhd2FyZGVkIGZvciBldmVyeSB2YWxpZCBjb250cm9sbGVyIHRhcCAoNTAgdGFwcyB0byBjb21wbGV0ZSkuICovXG4gIHBvd2VySW5jcmVtZW50UGVyVGFwOiAyLFxuXG4gIC8vIC0tLSBEYXRhIGNsZWFuaW5nIG1pbmktZ2FtZSAtLS1cbiAgLyoqIFByb2dyZXNzIGF3YXJkZWQgcGVyIGNvcnJlY3Qgc29ydCAoMjAgY29ycmVjdCBzb3J0cyB0byBjb21wbGV0ZSkuICovXG4gIGRhdGFJbmNyZW1lbnRQZXJTb3J0OiA1LFxuICAvKiogVGhyb3R0bGU6IG1pbiBtcyBiZXR3ZWVuIHNvcnQgc3VibWlzc2lvbnMgdG8gcHJldmVudCBzcGFtLiAqL1xuICBkYXRhU29ydFRocm90dGxlTXM6IDMwMCxcbiAgLyoqIE51bWJlciBjYXRlZ29yaWVzIOKAlCB0aGVzZSBtYXAgdG8gYnVja2V0ICdudW1iZXJzJyAqL1xuICBkYXRhVG9rZW5zTnVtYmVyczogW1wiNDJcIiwgXCI3XCIsIFwiMThcIiwgXCI5MVwiLCBcIjI1NlwiLCBcIjNcIiwgXCI5OVwiLCBcIjEwMjRcIiwgXCIwXCIsIFwiNjRcIl0gYXMgY29uc3QsXG4gIC8qKiBBSSB0ZXJtIGNhdGVnb3JpZXMg4oCUIHRoZXNlIG1hcCB0byBidWNrZXQgJ2FpX3Rlcm1zJyAqL1xuICBkYXRhVG9rZW5zQWlUZXJtczogW1wiQUlcIiwgXCJNTFwiLCBcIkRMXCIsIFwiR1BVXCIsIFwiTkxQXCIsIFwiTExNXCIsIFwiQ05OXCIsIFwiR0FOXCIsIFwiQkVSVFwiLCBcIkFQSVwiXSBhcyBjb25zdCxcblxuICAvLyAtLS0gWmlwLVphcCBGaXJld2FsbCBtaW5pLWdhbWUgKFNlY3VyaXR5IEVuZ2luZWVyKSAtLS1cbiAgLyoqIFByb2dyZXNzIGF3YXJkZWQgcGVyIGNvcnJlY3QgYnV0dG9uIHByZXNzICjiiYggMzQgY29ycmVjdCBwcmVzc2VzIHRvIGNvbXBsZXRlKS4gKi9cbiAgc2VjdXJpdHlJbmNyZW1lbnRQZXJIaXQ6IDMsXG4gIC8qKiBQcm9ncmVzcyBkZWR1Y3RlZCBwZXIgd3JvbmcgYnV0dG9uIHByZXNzIChjbGFtcGVkIHRvIDApLiAqL1xuICBzZWN1cml0eVBlbmFsdHlQZXJNaXNzOiAyLFxuICAvKiogU3RhcnRpbmcgbGVuZ3RoIG9mIHRoZSBaSVAvWkFQIHNlcXVlbmNlLiAqL1xuICBzZWN1cml0eVNlcXVlbmNlU2VlZExlbmd0aDogNCxcbiAgLyoqIEdyb3cgdGhlIHNlcXVlbmNlIGJ5IDEgYWZ0ZXIgZXZlcnkgTiBjb3JyZWN0IGhpdHMuICovXG4gIHNlY3VyaXR5U2VxdWVuY2VHcm93RXZlcnk6IDYsXG4gIC8qKiBUaHJvdHRsZTogbWluaW11bSBtcyBiZXR3ZWVuIGFjY2VwdGVkIGlucHV0cyB0byBwcmV2ZW50IG1hc2hpbmcuICovXG4gIHNlY3VyaXR5SGl0VGhyb3R0bGVNczogMTUwLFxuXG4gIC8vIC0tLSBBSSBDb3JlIFB1enpsZSBtaW5pLWdhbWUgKEFJIE1vZGVsIEVuZ2luZWVyKSAtLS1cbiAgLyoqIFByb2dyZXNzIGF3YXJkZWQgcGVyIGNvbXBsZXRlZCBwdXp6bGUgcm91bmQgKDUgc29sdmVzIHRvIHJlYWNoIDEwMCUpLiAqL1xuICBtb2RlbEluY3JlbWVudFBlclNvbHZlOiAyMCxcblxuICAvLyAtLS0gRGV2L3Rlc3QgaW5jcmVtZW50cyAodXNlZCBieSB0aGUgZGV2IHRlc3QgaW50ZXJmYWNlKSAtLS1cbiAgZGV2SW5jcmVtZW50QW1vdW50OiAxMCxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCB0eXBlIEdhbWVDb25maWcgPSB0eXBlb2YgR0FNRV9DT05GSUc7XG4iXSwibWFwcGluZ3MiOiJBQU1PLGFBQU0sY0FBYztBQUFBO0FBQUEsRUFFekIsWUFBWTtBQUFBLEVBQ1oscUJBQXFCO0FBQUE7QUFBQTtBQUFBLEVBR3JCLGFBQWE7QUFBQSxFQUNiLFlBQVk7QUFBQSxFQUNaLGdCQUFnQjtBQUFBLEVBQ2hCLGFBQWE7QUFBQTtBQUFBLEVBR2Isa0JBQWtCO0FBQUE7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixnQkFBZ0I7QUFBQTtBQUFBO0FBQUEsRUFJaEIscUJBQXFCO0FBQUE7QUFBQSxFQUVyQiw0QkFBNEI7QUFBQTtBQUFBLEVBRTVCLDRCQUE0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLNUIsMEJBQTBCO0FBQUE7QUFBQSxFQUUxQix1QkFBdUI7QUFBQTtBQUFBLEVBR3ZCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUFBO0FBQUEsRUFDbkIsc0JBQXNCO0FBQUE7QUFBQSxFQUN0QixvQkFBb0I7QUFBQSxFQUNwQixxQkFBcUI7QUFBQTtBQUFBLEVBQ3JCLHNCQUFzQjtBQUFBO0FBQUEsRUFHdEIseUJBQXlCO0FBQUE7QUFBQSxFQUN6QixxQkFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlyQixzQkFBc0I7QUFBQTtBQUFBO0FBQUEsRUFJdEIsc0JBQXNCO0FBQUE7QUFBQSxFQUV0QixvQkFBb0I7QUFBQTtBQUFBLEVBRXBCLG1CQUFtQixDQUFDLE1BQU0sS0FBSyxNQUFNLE1BQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxLQUFLLElBQUk7QUFBQTtBQUFBLEVBRTlFLG1CQUFtQixDQUFDLE1BQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxPQUFPLE9BQU8sT0FBTyxRQUFRLEtBQUs7QUFBQTtBQUFBO0FBQUEsRUFJdEYseUJBQXlCO0FBQUE7QUFBQSxFQUV6Qix3QkFBd0I7QUFBQTtBQUFBLEVBRXhCLDRCQUE0QjtBQUFBO0FBQUEsRUFFNUIsMkJBQTJCO0FBQUE7QUFBQSxFQUUzQix1QkFBdUI7QUFBQTtBQUFBO0FBQUEsRUFJdkIsd0JBQXdCO0FBQUE7QUFBQSxFQUd4QixvQkFBb0I7QUFDdEI7IiwibmFtZXMiOltdfQ==