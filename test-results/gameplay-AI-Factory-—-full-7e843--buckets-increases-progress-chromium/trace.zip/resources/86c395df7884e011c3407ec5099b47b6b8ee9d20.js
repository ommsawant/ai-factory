import {
  createAirJamStore,
  rejectAirJamAction
} from "/node_modules/.vite/deps/@air-jam_sdk.js?v=c74894a2";
import { GAME_CONFIG } from "/src/game/config/gameConfig.ts";
import { calculateFactoryHealth, evaluateFinalResult } from "/src/game/domain/factoryHealth.ts";
import { ALL_ROLES } from "/src/game/domain/types.ts";
const EVENT_DURATION_MS = 2e4;
const SCHEDULED_EVENTS = {
  135: {
    type: "power_surge",
    message: "⚡ POWER SURGE — Stabilise the power grid!",
    affectedRole: "power"
  },
  105: {
    type: "cyber_attack",
    message: "🛡 CYBER ATTACK — Firewall under assault!",
    affectedRole: "security"
  },
  75: {
    type: "data_corruption",
    message: "💾 DATA CORRUPTION — Incoming data contaminated!",
    affectedRole: "data"
  },
  45: {
    type: "model_drift",
    message: "🧠 MODEL DRIFT — AI accuracy dropping!",
    affectedRole: "model"
  },
  20: {
    type: "critical_temperature",
    message: "🔥 CRITICAL TEMPERATURE — AI Core overheating!",
    affectedRole: "cooling"
  }
};
function makeDept(progress = 0) {
  return { progress, status: "inactive", score: 0 };
}
function clamp(n, min = 0, max = 100) {
  return Math.min(max, Math.max(min, n));
}
function deriveStatus(progress) {
  if (progress >= 100) return "complete";
  if (progress >= 70) return "stable";
  if (progress > 0) return "working";
  return "inactive";
}
export function createInitialFactoryState() {
  return {
    phase: "idle",
    timeRemaining: GAME_CONFIG.gameDurationSeconds,
    roleAssignments: {},
    power: makeDept(),
    data: makeDept(),
    security: makeDept(),
    model: makeDept(),
    cooling: {
      ...makeDept(),
      temperature: GAME_CONFIG.coolingTempStart
    },
    factoryHealth: 0,
    teamScore: 0,
    activeEvents: [],
    finalResult: null
  };
}
export const useFactoryStore = createAirJamStore((set, get) => ({
  ...createInitialFactoryState(),
  actions: {
    // ── Lobby ────────────────────────────────────────────────────────────
    requestRole: ({ actorId, role }) => {
      if (role !== "controller") {
        return rejectAirJamAction("host_cannot_request_role", "Host cannot request a player role.");
      }
      set((state) => {
        if (actorId && state.roleAssignments[actorId]) return state;
        if (state.phase !== "idle" && state.phase !== "lobby") {
          return state;
        }
        const takenRoles = new Set(Object.values(state.roleAssignments));
        const nextRole = ALL_ROLES.find((r) => !takenRoles.has(r));
        if (!nextRole || !actorId) return state;
        const newAssignments = { ...state.roleAssignments, [actorId]: nextRole };
        const newPhase = "lobby";
        return { ...state, roleAssignments: newAssignments, phase: newPhase };
      });
    },
    startGame: ({ role }) => {
      if (role !== "host") {
        return rejectAirJamAction("only_host", "Only the host can start the game.");
      }
      const current = get();
      const playerCount = Object.keys(current.roleAssignments).length;
      if (playerCount < GAME_CONFIG.maxPlayers) {
        return rejectAirJamAction(
          "not_enough_players",
          `Need ${GAME_CONFIG.maxPlayers} players, have ${playerCount}.`
        );
      }
      set((state) => ({
        ...state,
        phase: "playing",
        timeRemaining: GAME_CONFIG.gameDurationSeconds,
        power: { ...state.power, status: "working" },
        data: { ...state.data, status: "working" },
        security: { ...state.security, status: "working" },
        model: { ...state.model, status: "working" },
        cooling: { ...state.cooling, status: "working" }
      }));
    },
    resetGame: ({ role }) => {
      if (role !== "host") {
        return rejectAirJamAction("only_host", "Only the host can reset.");
      }
      set(() => ({ ...createInitialFactoryState() }));
    },
    // ── Power mini-game ───────────────────────────────────────────────────
    tapPower: ({ actorId, role }) => {
      const current = get();
      if (current.phase !== "playing") {
        return rejectAirJamAction("not_playing", "Game is not in playing phase.");
      }
      if (role === "controller") {
        const assignedRole = actorId ? current.roleAssignments[actorId] : void 0;
        if (assignedRole !== "power") {
          return rejectAirJamAction(
            "wrong_role",
            "Only the Power Engineer may tap the power button."
          );
        }
      }
      set((state) => {
        if (state.phase !== "playing") return state;
        if (state.power.progress >= 100) return state;
        const newProgress = clamp(state.power.progress + GAME_CONFIG.powerIncrementPerTap);
        const bonus = GAME_CONFIG.pointsPerPowerTap;
        const newPower = {
          ...state.power,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.power.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, power: newPower });
        return {
          ...state,
          power: newPower,
          teamScore: state.teamScore + bonus,
          factoryHealth
        };
      });
    },
    // ── Data mini-game ────────────────────────────────────────────────────
    sortData: ({ actorId, role }, { correct }) => {
      const current = get();
      if (current.phase !== "playing") {
        return rejectAirJamAction("not_playing", "Game is not in playing phase.");
      }
      if (role === "controller") {
        const assignedRole = actorId ? current.roleAssignments[actorId] : void 0;
        if (assignedRole !== "data") {
          return rejectAirJamAction(
            "wrong_role",
            "Only the Data Engineer may sort data."
          );
        }
      }
      if (!correct) return;
      set((state) => {
        if (state.phase !== "playing") return state;
        if (state.data.progress >= 100) return state;
        const newProgress = clamp(state.data.progress + GAME_CONFIG.dataIncrementPerSort);
        const bonus = GAME_CONFIG.pointsPerDataSort;
        const newData = {
          ...state.data,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.data.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, data: newData });
        return {
          ...state,
          data: newData,
          teamScore: state.teamScore + bonus,
          factoryHealth
        };
      });
    },
    // ── Security mini-game ─────────────────────────────────────────────────
    zipZap: ({ actorId, role }, { hit }) => {
      const current = get();
      if (current.phase !== "playing") {
        return rejectAirJamAction("not_playing", "Game is not in playing phase.");
      }
      if (role === "controller") {
        const assignedRole = actorId ? current.roleAssignments[actorId] : void 0;
        if (assignedRole !== "security") {
          return rejectAirJamAction(
            "wrong_role",
            "Only the Security Engineer may use the Zip-Zap firewall."
          );
        }
      }
      set((state) => {
        if (state.phase !== "playing") return state;
        if (state.security.progress >= 100) return state;
        if (hit) {
          const newProgress = clamp(state.security.progress + GAME_CONFIG.securityIncrementPerHit);
          const bonus = GAME_CONFIG.pointsPerZipZapHit;
          const newSecurity = {
            ...state.security,
            progress: newProgress,
            status: deriveStatus(newProgress),
            score: state.security.score + bonus
          };
          const factoryHealth = calculateFactoryHealth({ ...state, security: newSecurity });
          return {
            ...state,
            security: newSecurity,
            teamScore: state.teamScore + bonus,
            factoryHealth
          };
        } else {
          const newProgress = clamp(state.security.progress - GAME_CONFIG.securityPenaltyPerMiss);
          const newSecurity = {
            ...state.security,
            progress: newProgress,
            status: deriveStatus(newProgress)
          };
          const factoryHealth = calculateFactoryHealth({ ...state, security: newSecurity });
          return { ...state, security: newSecurity, factoryHealth };
        }
      });
    },
    // ── AI Model mini-game ──────────────────────────────────────────────────
    solvePuzzle: ({ actorId, role }) => {
      const current = get();
      if (current.phase !== "playing") {
        return rejectAirJamAction("not_playing", "Game is not in playing phase.");
      }
      if (role === "controller") {
        const assignedRole = actorId ? current.roleAssignments[actorId] : void 0;
        if (assignedRole !== "model") {
          return rejectAirJamAction(
            "wrong_role",
            "Only the AI Model Engineer may solve the AI Core puzzle."
          );
        }
      }
      set((state) => {
        if (state.phase !== "playing") return state;
        if (state.model.progress >= 100) return state;
        const newProgress = clamp(state.model.progress + GAME_CONFIG.modelIncrementPerSolve);
        const bonus = GAME_CONFIG.pointsPerPuzzleStep;
        const newModel = {
          ...state.model,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.model.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, model: newModel });
        return {
          ...state,
          model: newModel,
          teamScore: state.teamScore + bonus,
          factoryHealth
        };
      });
    },
    // ── Dev/test actions ──────────────────────────────────────────────────
    devIncrementPower: (_ctx, { amount }) => {
      set((state) => {
        if (state.phase !== "playing") return state;
        const newProgress = clamp(state.power.progress + amount);
        const bonus = amount * GAME_CONFIG.pointsPerPowerTap;
        const newPower = {
          ...state.power,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.power.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, power: newPower });
        return { ...state, power: newPower, teamScore: state.teamScore + bonus, factoryHealth };
      });
    },
    devIncrementData: (_ctx, { amount }) => {
      set((state) => {
        if (state.phase !== "playing") return state;
        const newProgress = clamp(state.data.progress + amount);
        const bonus = Math.round(amount * (GAME_CONFIG.pointsPerDataSort / 10));
        const newData = {
          ...state.data,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.data.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, data: newData });
        return { ...state, data: newData, teamScore: state.teamScore + bonus, factoryHealth };
      });
    },
    devIncrementSecurity: (_ctx, { amount }) => {
      set((state) => {
        if (state.phase !== "playing") return state;
        const newProgress = clamp(state.security.progress + amount);
        const bonus = Math.round(amount * (GAME_CONFIG.pointsPerZipZapHit / 10));
        const newSecurity = {
          ...state.security,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.security.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, security: newSecurity });
        return { ...state, security: newSecurity, teamScore: state.teamScore + bonus, factoryHealth };
      });
    },
    devIncrementModel: (_ctx, { amount }) => {
      set((state) => {
        if (state.phase !== "playing") return state;
        const newProgress = clamp(state.model.progress + amount);
        const bonus = Math.round(amount * (GAME_CONFIG.pointsPerPuzzleStep / 10));
        const newModel = {
          ...state.model,
          progress: newProgress,
          status: deriveStatus(newProgress),
          score: state.model.score + bonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, model: newModel });
        return { ...state, model: newModel, teamScore: state.teamScore + bonus, factoryHealth };
      });
    },
    devSetCoolingTemp: (_ctx, { temperature }) => {
      set((state) => {
        if (state.phase !== "playing") return state;
        const temp = Math.max(50, Math.min(120, temperature));
        const inSafeZone = temp >= GAME_CONFIG.coolingSafeMin && temp <= GAME_CONFIG.coolingSafeMax;
        const safeCenter = (GAME_CONFIG.coolingSafeMin + GAME_CONFIG.coolingSafeMax) / 2;
        const maxDeviation = GAME_CONFIG.coolingTempStart - GAME_CONFIG.coolingSafeMin;
        const deviation = Math.abs(temp - safeCenter);
        const coolingProgress = clamp(Math.round(100 - deviation / maxDeviation * 100));
        const newCooling = {
          ...state.cooling,
          temperature: temp,
          progress: coolingProgress,
          status: inSafeZone ? "stable" : temp > 80 ? "warning" : "working",
          score: inSafeZone ? state.cooling.score + GAME_CONFIG.pointsPerCoolingTick : state.cooling.score
        };
        const factoryHealth = calculateFactoryHealth({ ...state, cooling: newCooling });
        return {
          ...state,
          cooling: newCooling,
          teamScore: inSafeZone ? state.teamScore + GAME_CONFIG.pointsPerCoolingTick : state.teamScore,
          factoryHealth
        };
      });
    },
    // ── Cooling mini-game ──────────────────────────────────────────────────
    coolTick: ({ actorId, role }, { centeredness }) => {
      const current = get();
      if (current.phase !== "playing") {
        return rejectAirJamAction("not_playing", "Game is not in playing phase.");
      }
      if (role === "controller") {
        const assignedRole = actorId ? current.roleAssignments[actorId] : void 0;
        if (assignedRole !== "cooling") {
          return rejectAirJamAction(
            "wrong_role",
            "Only the Cooling Engineer may send cooling ticks."
          );
        }
      }
      set((state) => {
        if (state.phase !== "playing") return state;
        const c = Math.min(1, Math.max(0, centeredness));
        const delta = -GAME_CONFIG.coolingTempDecreasePerTick + c * (GAME_CONFIG.coolingTempDecreasePerTick + GAME_CONFIG.coolingTempIncreasePerTick);
        const rawTemp = state.cooling.temperature + delta;
        const temp = Math.max(50, Math.min(120, rawTemp));
        const inSafeZone = temp >= GAME_CONFIG.coolingSafeMin && temp <= GAME_CONFIG.coolingSafeMax;
        const isCentered = c <= GAME_CONFIG.coolingCenteredThreshold;
        const scoreBonus = isCentered ? GAME_CONFIG.pointsPerCoolingTick : 0;
        const safeCenter = (GAME_CONFIG.coolingSafeMin + GAME_CONFIG.coolingSafeMax) / 2;
        const maxDeviation = GAME_CONFIG.coolingTempStart - GAME_CONFIG.coolingSafeMin;
        const deviation = Math.abs(temp - safeCenter);
        const coolingProgress = clamp(Math.round(100 - deviation / maxDeviation * 100));
        const newStatus = inSafeZone ? "stable" : temp > 85 ? "critical" : temp > 78 ? "warning" : "working";
        const newCooling = {
          ...state.cooling,
          temperature: temp,
          progress: coolingProgress,
          status: newStatus,
          score: state.cooling.score + scoreBonus
        };
        const factoryHealth = calculateFactoryHealth({ ...state, cooling: newCooling });
        return {
          ...state,
          cooling: newCooling,
          teamScore: state.teamScore + scoreBonus,
          factoryHealth
        };
      });
    },
    // ── Timer tick ────────────────────────────────────────────────────────
    tickTimer: ({ role }) => {
      if (role !== "host") return;
      set((state) => {
        if (state.phase !== "playing") return state;
        const newTime = state.timeRemaining - 1;
        const now = Date.now();
        if (newTime <= 0) {
          const finalResult = evaluateFinalResult(
            state,
            GAME_CONFIG.factorySuccessThreshold,
            GAME_CONFIG.criticalDeptMinimum
          );
          return { ...state, timeRemaining: 0, phase: "ended", finalResult, activeEvents: [] };
        }
        const liveEvents = state.activeEvents.filter(
          (e) => now - e.startedAt < EVENT_DURATION_MS
        );
        const scheduled = SCHEDULED_EVENTS[newTime];
        if (scheduled) {
          const alreadyActive = liveEvents.some((e) => e.type === scheduled.type);
          if (!alreadyActive) {
            const newEvent = {
              id: `${scheduled.type}-${newTime}`,
              type: scheduled.type,
              message: scheduled.message,
              affectedRole: scheduled.affectedRole,
              startedAt: now
            };
            liveEvents.push(newEvent);
          }
        }
        return { ...state, timeRemaining: newTime, activeEvents: liveEvents };
      });
    }
  }
}));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZhY3RvcnlTdG9yZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEFJIEZhY3Rvcnkg4oCUIG5ldHdvcmtlZCwgaG9zdC1hdXRob3JpdGF0aXZlIGdhbWUgc3RvcmUuXG4gKlxuICogU3RhdGUgbGFuZS4gQWxsIGF1dGhvcml0YXRpdmUgZ2FtZSBkYXRhIGxpdmVzIGhlcmUuXG4gKiBIb3N0IGFwcGxpZXMgYWN0aW9uczsgY29udHJvbGxlcnMgcmVjZWl2ZSBicm9hZGNhc3Qgc3RhdGUuXG4gKlxuICogQWN0aW9uIGNvbnRyYWN0OlxuICogICAtIChjdHgsIHBheWxvYWQpID0+IHZvaWQgICBmb3Igbm9ybWFsIG11dGF0aW9uc1xuICogICAtIHJlamVjdEFpckphbUFjdGlvbiguLi4pICBtdXN0IGJlIHJldHVybmVkIE9VVFNJREUgb2Ygc2V0KClcbiAqXG4gKiBSZWR1Y2VycyB1c2UgYHNldChzdGF0ZSA9PiAuLi4pYC5cbiAqIEtlZXAgcGVyLWZyYW1lIGNvbnRyb2xsZXIgaW5wdXQgT1VUIG9mIHRoaXMgc3RvcmUg4oCUIHVzZSB0aGUgaW5wdXQgbGFuZS5cbiAqL1xuaW1wb3J0IHtcbiAgY3JlYXRlQWlySmFtU3RvcmUsXG4gIHJlamVjdEFpckphbUFjdGlvbixcbiAgdHlwZSBBaXJKYW1BY3Rpb25Db250ZXh0LFxufSBmcm9tIFwiQGFpci1qYW0vc2RrXCI7XG5cbmltcG9ydCB7IEdBTUVfQ09ORklHIH0gZnJvbSBcIi4uL2NvbmZpZy9nYW1lQ29uZmlnXCI7XG5pbXBvcnQgeyBjYWxjdWxhdGVGYWN0b3J5SGVhbHRoLCBldmFsdWF0ZUZpbmFsUmVzdWx0IH0gZnJvbSBcIi4uL2RvbWFpbi9mYWN0b3J5SGVhbHRoXCI7XG5pbXBvcnQgdHlwZSB7XG4gIERlcGFydG1lbnRTdGF0ZSxcbiAgRmFjdG9yeVN0YXRlRGF0YSxcbiAgRmFjdG9yeUV2ZW50LFxuICBHYW1lUGhhc2UsXG4gIFBsYXllclJvbGUsXG59IGZyb20gXCIuLi9kb21haW4vdHlwZXNcIjtcbmltcG9ydCB7IEFMTF9ST0xFUyB9IGZyb20gXCIuLi9kb21haW4vdHlwZXNcIjtcblxuLy8g4pSA4pSAIFNjcmlwdGVkIGZhY3RvcnkgZXZlbnRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gRXZlbnRzIGZpcmUgd2hlbiB0aW1lUmVtYWluaW5nIG1hdGNoZXMgdGhlc2UgdmFsdWVzLlxuLy8gVmlzdWFsLW9ubHk6IHRoZXkgY3JlYXRlIHVyZ2VuY3kgd2l0aG91dCBwZW5hbGlzaW5nIHByb2dyZXNzLlxuXG5jb25zdCBFVkVOVF9EVVJBVElPTl9NUyA9IDIwXzAwMDtcblxuaW50ZXJmYWNlIFNjaGVkdWxlZEV2ZW50IHtcbiAgdHlwZTogRmFjdG9yeUV2ZW50W1widHlwZVwiXTtcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBhZmZlY3RlZFJvbGU6IFBsYXllclJvbGU7XG59XG5cbmNvbnN0IFNDSEVEVUxFRF9FVkVOVFM6IFJlY29yZDxudW1iZXIsIFNjaGVkdWxlZEV2ZW50PiA9IHtcbiAgMTM1OiB7XG4gICAgdHlwZTogXCJwb3dlcl9zdXJnZVwiLFxuICAgIG1lc3NhZ2U6IFwi4pqhIFBPV0VSIFNVUkdFIOKAlCBTdGFiaWxpc2UgdGhlIHBvd2VyIGdyaWQhXCIsXG4gICAgYWZmZWN0ZWRSb2xlOiBcInBvd2VyXCIsXG4gIH0sXG4gIDEwNToge1xuICAgIHR5cGU6IFwiY3liZXJfYXR0YWNrXCIsXG4gICAgbWVzc2FnZTogXCLwn5uhIENZQkVSIEFUVEFDSyDigJQgRmlyZXdhbGwgdW5kZXIgYXNzYXVsdCFcIixcbiAgICBhZmZlY3RlZFJvbGU6IFwic2VjdXJpdHlcIixcbiAgfSxcbiAgNzU6IHtcbiAgICB0eXBlOiBcImRhdGFfY29ycnVwdGlvblwiLFxuICAgIG1lc3NhZ2U6IFwi8J+SviBEQVRBIENPUlJVUFRJT04g4oCUIEluY29taW5nIGRhdGEgY29udGFtaW5hdGVkIVwiLFxuICAgIGFmZmVjdGVkUm9sZTogXCJkYXRhXCIsXG4gIH0sXG4gIDQ1OiB7XG4gICAgdHlwZTogXCJtb2RlbF9kcmlmdFwiLFxuICAgIG1lc3NhZ2U6IFwi8J+noCBNT0RFTCBEUklGVCDigJQgQUkgYWNjdXJhY3kgZHJvcHBpbmchXCIsXG4gICAgYWZmZWN0ZWRSb2xlOiBcIm1vZGVsXCIsXG4gIH0sXG4gIDIwOiB7XG4gICAgdHlwZTogXCJjcml0aWNhbF90ZW1wZXJhdHVyZVwiLFxuICAgIG1lc3NhZ2U6IFwi8J+UpSBDUklUSUNBTCBURU1QRVJBVFVSRSDigJQgQUkgQ29yZSBvdmVyaGVhdGluZyFcIixcbiAgICBhZmZlY3RlZFJvbGU6IFwiY29vbGluZ1wiLFxuICB9LFxufTtcblxuLy8g4pSA4pSAIEhlbHBlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIG1ha2VEZXB0KHByb2dyZXNzID0gMCk6IERlcGFydG1lbnRTdGF0ZSB7XG4gIHJldHVybiB7IHByb2dyZXNzLCBzdGF0dXM6IFwiaW5hY3RpdmVcIiwgc2NvcmU6IDAgfTtcbn1cblxuZnVuY3Rpb24gY2xhbXAobjogbnVtYmVyLCBtaW4gPSAwLCBtYXggPSAxMDApOiBudW1iZXIge1xuICByZXR1cm4gTWF0aC5taW4obWF4LCBNYXRoLm1heChtaW4sIG4pKTtcbn1cblxuZnVuY3Rpb24gZGVyaXZlU3RhdHVzKHByb2dyZXNzOiBudW1iZXIpOiBEZXBhcnRtZW50U3RhdGVbXCJzdGF0dXNcIl0ge1xuICBpZiAocHJvZ3Jlc3MgPj0gMTAwKSByZXR1cm4gXCJjb21wbGV0ZVwiO1xuICBpZiAocHJvZ3Jlc3MgPj0gNzApIHJldHVybiBcInN0YWJsZVwiO1xuICBpZiAocHJvZ3Jlc3MgPiAwKSByZXR1cm4gXCJ3b3JraW5nXCI7XG4gIHJldHVybiBcImluYWN0aXZlXCI7XG59XG5cbi8vIOKUgOKUgCBJbml0aWFsIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5pdGlhbEZhY3RvcnlTdGF0ZSgpOiBGYWN0b3J5U3RhdGVEYXRhIHtcbiAgcmV0dXJuIHtcbiAgICBwaGFzZTogXCJpZGxlXCIsXG4gICAgdGltZVJlbWFpbmluZzogR0FNRV9DT05GSUcuZ2FtZUR1cmF0aW9uU2Vjb25kcyxcbiAgICByb2xlQXNzaWdubWVudHM6IHt9LFxuICAgIHBvd2VyOiBtYWtlRGVwdCgpLFxuICAgIGRhdGE6IG1ha2VEZXB0KCksXG4gICAgc2VjdXJpdHk6IG1ha2VEZXB0KCksXG4gICAgbW9kZWw6IG1ha2VEZXB0KCksXG4gICAgY29vbGluZzoge1xuICAgICAgLi4ubWFrZURlcHQoKSxcbiAgICAgIHRlbXBlcmF0dXJlOiBHQU1FX0NPTkZJRy5jb29saW5nVGVtcFN0YXJ0LFxuICAgIH0sXG4gICAgZmFjdG9yeUhlYWx0aDogMCxcbiAgICB0ZWFtU2NvcmU6IDAsXG4gICAgYWN0aXZlRXZlbnRzOiBbXSxcbiAgICBmaW5hbFJlc3VsdDogbnVsbCxcbiAgfTtcbn1cblxuLy8g4pSA4pSAIFN0b3JlIGludGVyZmFjZSAoc3RhdGUgKyBhY3Rpb25zKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGludGVyZmFjZSBGYWN0b3J5U3RhdGUgZXh0ZW5kcyBGYWN0b3J5U3RhdGVEYXRhIHtcbiAgYWN0aW9uczoge1xuICAgIC8vIOKUgOKUgCBMb2JieSDilIDilIBcbiAgICAvKiogQ2FsbGVkIGJ5IGVhY2ggY29udHJvbGxlciB3aGVuIHRoZXkgam9pbi4gSG9zdCBhc3NpZ25zIHRoZW0gYSByb2xlLiAqL1xuICAgIHJlcXVlc3RSb2xlOiAoY3R4OiBBaXJKYW1BY3Rpb25Db250ZXh0LCBwYXlsb2FkOiB1bmRlZmluZWQpID0+IHZvaWQ7XG5cbiAgICAvKiogSG9zdC1vbmx5OiBzdGFydCB0aGUgZ2FtZSB3aGVuIGFsbCA1IHJvbGVzIGFyZSBmaWxsZWQuICovXG4gICAgc3RhcnRHYW1lOiAoY3R4OiBBaXJKYW1BY3Rpb25Db250ZXh0LCBwYXlsb2FkOiB1bmRlZmluZWQpID0+IHZvaWQ7XG5cbiAgICAvKiogSG9zdC1vbmx5OiByZXNldCB0aGUgZW50aXJlIHNlc3Npb24gYmFjayB0byBpZGxlLiAqL1xuICAgIHJlc2V0R2FtZTogKGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCwgcGF5bG9hZDogdW5kZWZpbmVkKSA9PiB2b2lkO1xuXG4gICAgLy8g4pSA4pSAIFBvd2VyIG1pbmktZ2FtZTogcmVhbCB0YXAgYWN0aW9uIOKUgOKUgFxuICAgIC8qKiBTZW50IGJ5IHRoZSBQb3dlciBFbmdpbmVlciBjb250cm9sbGVyIG9uIGV2ZXJ5IHRhcC4gKi9cbiAgICB0YXBQb3dlcjogKGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCwgcGF5bG9hZDogdW5kZWZpbmVkKSA9PiB2b2lkO1xuXG4gICAgLy8g4pSA4pSAIERhdGEgbWluaS1nYW1lOiByZWFsIHNvcnQgYWN0aW9uIOKUgOKUgFxuICAgIC8qKiBTZW50IGJ5IHRoZSBEYXRhIEVuZ2luZWVyIGNvbnRyb2xsZXIgZm9yIGVhY2ggZGF0YSB0b2tlbiBwbGFjZW1lbnQuICovXG4gICAgc29ydERhdGE6IChcbiAgICAgIGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCxcbiAgICAgIHBheWxvYWQ6IHsgdG9rZW46IHN0cmluZzsgYnVja2V0OiBcIm51bWJlcnNcIiB8IFwiYWlfdGVybXNcIjsgY29ycmVjdDogYm9vbGVhbiB9LFxuICAgICkgPT4gdm9pZDtcblxuICAgIC8vIOKUgOKUgCBTZWN1cml0eSBtaW5pLWdhbWU6IHJlYWwgWmlwLVphcCBhY3Rpb24g4pSA4pSAXG4gICAgLyoqXG4gICAgICogU2VudCBieSB0aGUgU2VjdXJpdHkgRW5naW5lZXIgY29udHJvbGxlciBmb3IgZWFjaCBaSVAgb3IgWkFQIGJ1dHRvbiBwcmVzcy5cbiAgICAgKiBgaGl0OiB0cnVlYCAg4oaSIHRoZSBwbGF5ZXIgcHJlc3NlZCB0aGUgY29ycmVjdCBidXR0b24gaW4gdGhlIHNlcXVlbmNlLlxuICAgICAqIGBoaXQ6IGZhbHNlYCDihpIgdGhlIHBsYXllciBwcmVzc2VkIHRoZSB3cm9uZyBidXR0b24uXG4gICAgICogU2VxdWVuY2UgZ2VuZXJhdGlvbiBsaXZlcyBpbiB0aGUgY29udHJvbGxlciBhcyBsb2NhbCBVSSBzdGF0ZS5cbiAgICAgKi9cbiAgICB6aXBaYXA6IChjdHg6IEFpckphbUFjdGlvbkNvbnRleHQsIHBheWxvYWQ6IHsgaGl0OiBib29sZWFuIH0pID0+IHZvaWQ7XG5cbiAgICAvLyDilIDilIAgQUkgTW9kZWwgbWluaS1nYW1lOiBwaXBlbGluZSBwdXp6bGUgc29sdmUg4pSA4pSAXG4gICAgLyoqXG4gICAgICogU2VudCBieSB0aGUgQUkgTW9kZWwgRW5naW5lZXIgY29udHJvbGxlciB3aGVuIHRoZXkgY29ycmVjdGx5IGFycmFuZ2VcbiAgICAgKiB0aGUgcGlwZWxpbmUgc3RlcHMuIEFsd2F5cyBjYWxsZWQgb24gc3VjY2VzcyBvbmx5IOKAlCBjb250cm9sbGVyIG93bnNcbiAgICAgKiB0aGUgcHV6emxlIHZhbGlkYXRpb24gbG9jYWxseS5cbiAgICAgKi9cbiAgICBzb2x2ZVB1enpsZTogKGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCwgcGF5bG9hZDogdW5kZWZpbmVkKSA9PiB2b2lkO1xuXG4gICAgLy8g4pSA4pSAIERldi90ZXN0OiBkaXJlY3QgZGVwYXJ0bWVudCBpbmNyZW1lbnRzIOKUgOKUgFxuICAgIGRldkluY3JlbWVudFBvd2VyOiAoY3R4OiBBaXJKYW1BY3Rpb25Db250ZXh0LCBwYXlsb2FkOiB7IGFtb3VudDogbnVtYmVyIH0pID0+IHZvaWQ7XG4gICAgZGV2SW5jcmVtZW50RGF0YTogKGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCwgcGF5bG9hZDogeyBhbW91bnQ6IG51bWJlciB9KSA9PiB2b2lkO1xuICAgIGRldkluY3JlbWVudFNlY3VyaXR5OiAoY3R4OiBBaXJKYW1BY3Rpb25Db250ZXh0LCBwYXlsb2FkOiB7IGFtb3VudDogbnVtYmVyIH0pID0+IHZvaWQ7XG4gICAgZGV2SW5jcmVtZW50TW9kZWw6IChjdHg6IEFpckphbUFjdGlvbkNvbnRleHQsIHBheWxvYWQ6IHsgYW1vdW50OiBudW1iZXIgfSkgPT4gdm9pZDtcbiAgICBkZXZTZXRDb29saW5nVGVtcDogKGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCwgcGF5bG9hZDogeyB0ZW1wZXJhdHVyZTogbnVtYmVyIH0pID0+IHZvaWQ7XG5cbiAgICAvLyDilIDilIAgQ29vbGluZyBtaW5pLWdhbWU6IGd5cm9zY29wZSAvIHRvdWNoIHRpY2sg4pSA4pSAXG4gICAgLyoqXG4gICAgICogU2VudCBieSB0aGUgQ29vbGluZyBFbmdpbmVlciBjb250cm9sbGVyIHBlcmlvZGljYWxseS5cbiAgICAgKiBgY2VudGVyZWRuZXNzYCBpcyAwIChwZXJmZWN0IGNlbnRyZSkg4oaSIDEgKGVkZ2Ugb2YgYm91bmRzKS5cbiAgICAgKiBIb3N0IGFkanVzdHMgdGVtcGVyYXR1cmUgYW5kIGF3YXJkcyBzY29yZSBhY2NvcmRpbmdseS5cbiAgICAgKi9cbiAgICBjb29sVGljazogKGN0eDogQWlySmFtQWN0aW9uQ29udGV4dCwgcGF5bG9hZDogeyBjZW50ZXJlZG5lc3M6IG51bWJlciB9KSA9PiB2b2lkO1xuXG4gICAgLy8g4pSA4pSAIEdhbWUgbGlmZWN5Y2xlICh0aW1lciB0aWNrLCBkcml2ZW4gYnkgaG9zdCBsb29wKSDilIDilIBcbiAgICB0aWNrVGltZXI6IChjdHg6IEFpckphbUFjdGlvbkNvbnRleHQsIHBheWxvYWQ6IHVuZGVmaW5lZCkgPT4gdm9pZDtcbiAgfTtcbn1cblxuLy8g4pSA4pSAIFN0b3JlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgY29uc3QgdXNlRmFjdG9yeVN0b3JlID0gY3JlYXRlQWlySmFtU3RvcmU8RmFjdG9yeVN0YXRlPigoc2V0LCBnZXQpID0+ICh7XG4gIC4uLmNyZWF0ZUluaXRpYWxGYWN0b3J5U3RhdGUoKSxcblxuICBhY3Rpb25zOiB7XG4gICAgLy8g4pSA4pSAIExvYmJ5IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gICAgcmVxdWVzdFJvbGU6ICh7IGFjdG9ySWQsIHJvbGUgfSkgPT4ge1xuICAgICAgLy8gT25seSBjb250cm9sbGVycyBtYXkgcmVxdWVzdCBhIHJvbGUuXG4gICAgICBpZiAocm9sZSAhPT0gXCJjb250cm9sbGVyXCIpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdEFpckphbUFjdGlvbihcImhvc3RfY2Fubm90X3JlcXVlc3Rfcm9sZVwiLCBcIkhvc3QgY2Fubm90IHJlcXVlc3QgYSBwbGF5ZXIgcm9sZS5cIik7XG4gICAgICB9XG5cbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgLy8gQWxyZWFkeSBoYXMgYSByb2xlIOKGkiBrZWVwIGl0LlxuICAgICAgICBpZiAoYWN0b3JJZCAmJiBzdGF0ZS5yb2xlQXNzaWdubWVudHNbYWN0b3JJZF0pIHJldHVybiBzdGF0ZTtcblxuICAgICAgICAvLyBPbmx5IGFzc2lnbiByb2xlcyB3aGlsZSBpbiBpZGxlIG9yIGxvYmJ5IHBoYXNlLlxuICAgICAgICBpZiAoc3RhdGUucGhhc2UgIT09IFwiaWRsZVwiICYmIHN0YXRlLnBoYXNlICE9PSBcImxvYmJ5XCIpIHtcbiAgICAgICAgICByZXR1cm4gc3RhdGU7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0YWtlblJvbGVzID0gbmV3IFNldChPYmplY3QudmFsdWVzKHN0YXRlLnJvbGVBc3NpZ25tZW50cykpO1xuICAgICAgICBjb25zdCBuZXh0Um9sZSA9IEFMTF9ST0xFUy5maW5kKChyKSA9PiAhdGFrZW5Sb2xlcy5oYXMocikpO1xuXG4gICAgICAgIGlmICghbmV4dFJvbGUgfHwgIWFjdG9ySWQpIHJldHVybiBzdGF0ZTsgLy8gbm8gZnJlZSBzbG90XG5cbiAgICAgICAgY29uc3QgbmV3QXNzaWdubWVudHMgPSB7IC4uLnN0YXRlLnJvbGVBc3NpZ25tZW50cywgW2FjdG9ySWRdOiBuZXh0Um9sZSB9O1xuICAgICAgICBjb25zdCBuZXdQaGFzZTogR2FtZVBoYXNlID0gXCJsb2JieVwiO1xuXG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCByb2xlQXNzaWdubWVudHM6IG5ld0Fzc2lnbm1lbnRzLCBwaGFzZTogbmV3UGhhc2UgfTtcbiAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBzdGFydEdhbWU6ICh7IHJvbGUgfSkgPT4ge1xuICAgICAgaWYgKHJvbGUgIT09IFwiaG9zdFwiKSB7XG4gICAgICAgIHJldHVybiByZWplY3RBaXJKYW1BY3Rpb24oXCJvbmx5X2hvc3RcIiwgXCJPbmx5IHRoZSBob3N0IGNhbiBzdGFydCB0aGUgZ2FtZS5cIik7XG4gICAgICB9XG5cbiAgICAgIC8vIENoZWNrIHBsYXllciBjb3VudCBCRUZPUkUgZW50ZXJpbmcgc2V0IHRvIGFsbG93IGVhcmx5IHJlamVjdGlvbi5cbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBnZXQoKTtcbiAgICAgIGNvbnN0IHBsYXllckNvdW50ID0gT2JqZWN0LmtleXMoY3VycmVudC5yb2xlQXNzaWdubWVudHMpLmxlbmd0aDtcbiAgICAgIGlmIChwbGF5ZXJDb3VudCA8IEdBTUVfQ09ORklHLm1heFBsYXllcnMpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdEFpckphbUFjdGlvbihcbiAgICAgICAgICBcIm5vdF9lbm91Z2hfcGxheWVyc1wiLFxuICAgICAgICAgIGBOZWVkICR7R0FNRV9DT05GSUcubWF4UGxheWVyc30gcGxheWVycywgaGF2ZSAke3BsYXllckNvdW50fS5gLFxuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBzZXQoKHN0YXRlKSA9PiAoe1xuICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgcGhhc2U6IFwicGxheWluZ1wiLFxuICAgICAgICB0aW1lUmVtYWluaW5nOiBHQU1FX0NPTkZJRy5nYW1lRHVyYXRpb25TZWNvbmRzLFxuICAgICAgICBwb3dlcjogeyAuLi5zdGF0ZS5wb3dlciwgc3RhdHVzOiBcIndvcmtpbmdcIiB9LFxuICAgICAgICBkYXRhOiB7IC4uLnN0YXRlLmRhdGEsIHN0YXR1czogXCJ3b3JraW5nXCIgfSxcbiAgICAgICAgc2VjdXJpdHk6IHsgLi4uc3RhdGUuc2VjdXJpdHksIHN0YXR1czogXCJ3b3JraW5nXCIgfSxcbiAgICAgICAgbW9kZWw6IHsgLi4uc3RhdGUubW9kZWwsIHN0YXR1czogXCJ3b3JraW5nXCIgfSxcbiAgICAgICAgY29vbGluZzogeyAuLi5zdGF0ZS5jb29saW5nLCBzdGF0dXM6IFwid29ya2luZ1wiIH0sXG4gICAgICB9KSk7XG4gICAgfSxcblxuICAgIHJlc2V0R2FtZTogKHsgcm9sZSB9KSA9PiB7XG4gICAgICBpZiAocm9sZSAhPT0gXCJob3N0XCIpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdEFpckphbUFjdGlvbihcIm9ubHlfaG9zdFwiLCBcIk9ubHkgdGhlIGhvc3QgY2FuIHJlc2V0LlwiKTtcbiAgICAgIH1cbiAgICAgIHNldCgoKSA9PiAoeyAuLi5jcmVhdGVJbml0aWFsRmFjdG9yeVN0YXRlKCkgfSkpO1xuICAgIH0sXG5cbiAgICAvLyDilIDilIAgUG93ZXIgbWluaS1nYW1lIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gICAgdGFwUG93ZXI6ICh7IGFjdG9ySWQsIHJvbGUgfSkgPT4ge1xuICAgICAgLy8gT25seSBjb250cm9sbGVycyBtYXkgdGFwOyBob3N0IGNhbiBhbHNvIHRhcCBmb3IgZGV2IGNvbnZlbmllbmNlLlxuICAgICAgLy8gTXVzdCBiZSBpbiBwbGF5aW5nIHBoYXNlLlxuICAgICAgY29uc3QgY3VycmVudCA9IGdldCgpO1xuICAgICAgaWYgKGN1cnJlbnQucGhhc2UgIT09IFwicGxheWluZ1wiKSB7XG4gICAgICAgIHJldHVybiByZWplY3RBaXJKYW1BY3Rpb24oXCJub3RfcGxheWluZ1wiLCBcIkdhbWUgaXMgbm90IGluIHBsYXlpbmcgcGhhc2UuXCIpO1xuICAgICAgfVxuXG4gICAgICAvLyBHdWFyZDogb25seSB0aGUgYXNzaWduZWQgUG93ZXIgZW5naW5lZXIgKG9yIGhvc3QpIG1heSB0YXAuXG4gICAgICBpZiAocm9sZSA9PT0gXCJjb250cm9sbGVyXCIpIHtcbiAgICAgICAgY29uc3QgYXNzaWduZWRSb2xlID0gYWN0b3JJZCA/IGN1cnJlbnQucm9sZUFzc2lnbm1lbnRzW2FjdG9ySWRdIDogdW5kZWZpbmVkO1xuICAgICAgICBpZiAoYXNzaWduZWRSb2xlICE9PSBcInBvd2VyXCIpIHtcbiAgICAgICAgICByZXR1cm4gcmVqZWN0QWlySmFtQWN0aW9uKFxuICAgICAgICAgICAgXCJ3cm9uZ19yb2xlXCIsXG4gICAgICAgICAgICBcIk9ubHkgdGhlIFBvd2VyIEVuZ2luZWVyIG1heSB0YXAgdGhlIHBvd2VyIGJ1dHRvbi5cIixcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICAvLyBDYXAgYXQgMTAwIOKAlCBwcmV2ZW50IG92ZXJzaG9vdC5cbiAgICAgICAgaWYgKHN0YXRlLnBvd2VyLnByb2dyZXNzID49IDEwMCkgcmV0dXJuIHN0YXRlO1xuXG4gICAgICAgIGNvbnN0IG5ld1Byb2dyZXNzID0gY2xhbXAoc3RhdGUucG93ZXIucHJvZ3Jlc3MgKyBHQU1FX0NPTkZJRy5wb3dlckluY3JlbWVudFBlclRhcCk7XG4gICAgICAgIGNvbnN0IGJvbnVzID0gR0FNRV9DT05GSUcucG9pbnRzUGVyUG93ZXJUYXA7XG4gICAgICAgIGNvbnN0IG5ld1Bvd2VyOiBEZXBhcnRtZW50U3RhdGUgPSB7XG4gICAgICAgICAgLi4uc3RhdGUucG93ZXIsXG4gICAgICAgICAgcHJvZ3Jlc3M6IG5ld1Byb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICBzY29yZTogc3RhdGUucG93ZXIuc2NvcmUgKyBib251cyxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgcG93ZXI6IG5ld1Bvd2VyIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgIHBvd2VyOiBuZXdQb3dlcixcbiAgICAgICAgICB0ZWFtU2NvcmU6IHN0YXRlLnRlYW1TY29yZSArIGJvbnVzLFxuICAgICAgICAgIGZhY3RvcnlIZWFsdGgsXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9LFxuXG4gICAgLy8g4pSA4pSAIERhdGEgbWluaS1nYW1lIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gICAgc29ydERhdGE6ICh7IGFjdG9ySWQsIHJvbGUgfSwgeyBjb3JyZWN0IH0pID0+IHtcbiAgICAgIC8vIE11c3QgYmUgaW4gcGxheWluZyBwaGFzZS5cbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBnZXQoKTtcbiAgICAgIGlmIChjdXJyZW50LnBoYXNlICE9PSBcInBsYXlpbmdcIikge1xuICAgICAgICByZXR1cm4gcmVqZWN0QWlySmFtQWN0aW9uKFwibm90X3BsYXlpbmdcIiwgXCJHYW1lIGlzIG5vdCBpbiBwbGF5aW5nIHBoYXNlLlwiKTtcbiAgICAgIH1cblxuICAgICAgLy8gR3VhcmQ6IG9ubHkgdGhlIGFzc2lnbmVkIERhdGEgZW5naW5lZXIgKG9yIGhvc3QpIG1heSBzb3J0LlxuICAgICAgaWYgKHJvbGUgPT09IFwiY29udHJvbGxlclwiKSB7XG4gICAgICAgIGNvbnN0IGFzc2lnbmVkUm9sZSA9IGFjdG9ySWQgPyBjdXJyZW50LnJvbGVBc3NpZ25tZW50c1thY3RvcklkXSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKGFzc2lnbmVkUm9sZSAhPT0gXCJkYXRhXCIpIHtcbiAgICAgICAgICByZXR1cm4gcmVqZWN0QWlySmFtQWN0aW9uKFxuICAgICAgICAgICAgXCJ3cm9uZ19yb2xlXCIsXG4gICAgICAgICAgICBcIk9ubHkgdGhlIERhdGEgRW5naW5lZXIgbWF5IHNvcnQgZGF0YS5cIixcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEluY29ycmVjdCBzb3J0OiBubyBwcm9ncmVzcywgbm8gc2NvcmUg4oCUIGp1c3QgYWNrbm93bGVkZ2UuXG4gICAgICBpZiAoIWNvcnJlY3QpIHJldHVybjtcblxuICAgICAgc2V0KChzdGF0ZSkgPT4ge1xuICAgICAgICBpZiAoc3RhdGUucGhhc2UgIT09IFwicGxheWluZ1wiKSByZXR1cm4gc3RhdGU7XG4gICAgICAgIGlmIChzdGF0ZS5kYXRhLnByb2dyZXNzID49IDEwMCkgcmV0dXJuIHN0YXRlO1xuXG4gICAgICAgIGNvbnN0IG5ld1Byb2dyZXNzID0gY2xhbXAoc3RhdGUuZGF0YS5wcm9ncmVzcyArIEdBTUVfQ09ORklHLmRhdGFJbmNyZW1lbnRQZXJTb3J0KTtcbiAgICAgICAgY29uc3QgYm9udXMgPSBHQU1FX0NPTkZJRy5wb2ludHNQZXJEYXRhU29ydDtcbiAgICAgICAgY29uc3QgbmV3RGF0YTogRGVwYXJ0bWVudFN0YXRlID0ge1xuICAgICAgICAgIC4uLnN0YXRlLmRhdGEsXG4gICAgICAgICAgcHJvZ3Jlc3M6IG5ld1Byb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICBzY29yZTogc3RhdGUuZGF0YS5zY29yZSArIGJvbnVzLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBmYWN0b3J5SGVhbHRoID0gY2FsY3VsYXRlRmFjdG9yeUhlYWx0aCh7IC4uLnN0YXRlLCBkYXRhOiBuZXdEYXRhIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgIGRhdGE6IG5ld0RhdGEsXG4gICAgICAgICAgdGVhbVNjb3JlOiBzdGF0ZS50ZWFtU2NvcmUgKyBib251cyxcbiAgICAgICAgICBmYWN0b3J5SGVhbHRoLFxuICAgICAgICB9O1xuICAgICAgfSk7XG4gICAgfSxcblxuICAgIC8vIOKUgOKUgCBTZWN1cml0eSBtaW5pLWdhbWUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgICB6aXBaYXA6ICh7IGFjdG9ySWQsIHJvbGUgfSwgeyBoaXQgfSkgPT4ge1xuICAgICAgLy8gTXVzdCBiZSBpbiBwbGF5aW5nIHBoYXNlLlxuICAgICAgY29uc3QgY3VycmVudCA9IGdldCgpO1xuICAgICAgaWYgKGN1cnJlbnQucGhhc2UgIT09IFwicGxheWluZ1wiKSB7XG4gICAgICAgIHJldHVybiByZWplY3RBaXJKYW1BY3Rpb24oXCJub3RfcGxheWluZ1wiLCBcIkdhbWUgaXMgbm90IGluIHBsYXlpbmcgcGhhc2UuXCIpO1xuICAgICAgfVxuXG4gICAgICAvLyBHdWFyZDogb25seSB0aGUgYXNzaWduZWQgU2VjdXJpdHkgZW5naW5lZXIgKG9yIGhvc3QpIG1heSB6aXAtemFwLlxuICAgICAgaWYgKHJvbGUgPT09IFwiY29udHJvbGxlclwiKSB7XG4gICAgICAgIGNvbnN0IGFzc2lnbmVkUm9sZSA9IGFjdG9ySWQgPyBjdXJyZW50LnJvbGVBc3NpZ25tZW50c1thY3RvcklkXSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKGFzc2lnbmVkUm9sZSAhPT0gXCJzZWN1cml0eVwiKSB7XG4gICAgICAgICAgcmV0dXJuIHJlamVjdEFpckphbUFjdGlvbihcbiAgICAgICAgICAgIFwid3Jvbmdfcm9sZVwiLFxuICAgICAgICAgICAgXCJPbmx5IHRoZSBTZWN1cml0eSBFbmdpbmVlciBtYXkgdXNlIHRoZSBaaXAtWmFwIGZpcmV3YWxsLlwiLFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgc2V0KChzdGF0ZSkgPT4ge1xuICAgICAgICBpZiAoc3RhdGUucGhhc2UgIT09IFwicGxheWluZ1wiKSByZXR1cm4gc3RhdGU7XG4gICAgICAgIGlmIChzdGF0ZS5zZWN1cml0eS5wcm9ncmVzcyA+PSAxMDApIHJldHVybiBzdGF0ZTtcblxuICAgICAgICBpZiAoaGl0KSB7XG4gICAgICAgICAgLy8gQ29ycmVjdCBwcmVzcyDigJQgYWR2YW5jZSBmaXJld2FsbC5cbiAgICAgICAgICBjb25zdCBuZXdQcm9ncmVzcyA9IGNsYW1wKHN0YXRlLnNlY3VyaXR5LnByb2dyZXNzICsgR0FNRV9DT05GSUcuc2VjdXJpdHlJbmNyZW1lbnRQZXJIaXQpO1xuICAgICAgICAgIGNvbnN0IGJvbnVzID0gR0FNRV9DT05GSUcucG9pbnRzUGVyWmlwWmFwSGl0O1xuICAgICAgICAgIGNvbnN0IG5ld1NlY3VyaXR5OiBEZXBhcnRtZW50U3RhdGUgPSB7XG4gICAgICAgICAgICAuLi5zdGF0ZS5zZWN1cml0eSxcbiAgICAgICAgICAgIHByb2dyZXNzOiBuZXdQcm9ncmVzcyxcbiAgICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICAgIHNjb3JlOiBzdGF0ZS5zZWN1cml0eS5zY29yZSArIGJvbnVzLFxuICAgICAgICAgIH07XG4gICAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgc2VjdXJpdHk6IG5ld1NlY3VyaXR5IH0pO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgIHNlY3VyaXR5OiBuZXdTZWN1cml0eSxcbiAgICAgICAgICAgIHRlYW1TY29yZTogc3RhdGUudGVhbVNjb3JlICsgYm9udXMsXG4gICAgICAgICAgICBmYWN0b3J5SGVhbHRoLFxuICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gV3JvbmcgcHJlc3Mg4oCUIGFwcGx5IHBlbmFsdHkgKG5vIHNjb3JlIGNoYW5nZSkuXG4gICAgICAgICAgY29uc3QgbmV3UHJvZ3Jlc3MgPSBjbGFtcChzdGF0ZS5zZWN1cml0eS5wcm9ncmVzcyAtIEdBTUVfQ09ORklHLnNlY3VyaXR5UGVuYWx0eVBlck1pc3MpO1xuICAgICAgICAgIGNvbnN0IG5ld1NlY3VyaXR5OiBEZXBhcnRtZW50U3RhdGUgPSB7XG4gICAgICAgICAgICAuLi5zdGF0ZS5zZWN1cml0eSxcbiAgICAgICAgICAgIHByb2dyZXNzOiBuZXdQcm9ncmVzcyxcbiAgICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IGZhY3RvcnlIZWFsdGggPSBjYWxjdWxhdGVGYWN0b3J5SGVhbHRoKHsgLi4uc3RhdGUsIHNlY3VyaXR5OiBuZXdTZWN1cml0eSB9KTtcbiAgICAgICAgICByZXR1cm4geyAuLi5zdGF0ZSwgc2VjdXJpdHk6IG5ld1NlY3VyaXR5LCBmYWN0b3J5SGVhbHRoIH07XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0sXG5cbiAgICAvLyDilIDilIAgQUkgTW9kZWwgbWluaS1nYW1lIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gICAgc29sdmVQdXp6bGU6ICh7IGFjdG9ySWQsIHJvbGUgfSkgPT4ge1xuICAgICAgY29uc3QgY3VycmVudCA9IGdldCgpO1xuICAgICAgaWYgKGN1cnJlbnQucGhhc2UgIT09IFwicGxheWluZ1wiKSB7XG4gICAgICAgIHJldHVybiByZWplY3RBaXJKYW1BY3Rpb24oXCJub3RfcGxheWluZ1wiLCBcIkdhbWUgaXMgbm90IGluIHBsYXlpbmcgcGhhc2UuXCIpO1xuICAgICAgfVxuXG4gICAgICAvLyBHdWFyZDogb25seSB0aGUgYXNzaWduZWQgQUkgTW9kZWwgZW5naW5lZXIgKG9yIGhvc3QpIG1heSBzb2x2ZS5cbiAgICAgIGlmIChyb2xlID09PSBcImNvbnRyb2xsZXJcIikge1xuICAgICAgICBjb25zdCBhc3NpZ25lZFJvbGUgPSBhY3RvcklkID8gY3VycmVudC5yb2xlQXNzaWdubWVudHNbYWN0b3JJZF0gOiB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChhc3NpZ25lZFJvbGUgIT09IFwibW9kZWxcIikge1xuICAgICAgICAgIHJldHVybiByZWplY3RBaXJKYW1BY3Rpb24oXG4gICAgICAgICAgICBcIndyb25nX3JvbGVcIixcbiAgICAgICAgICAgIFwiT25seSB0aGUgQUkgTW9kZWwgRW5naW5lZXIgbWF5IHNvbHZlIHRoZSBBSSBDb3JlIHB1enpsZS5cIixcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICBpZiAoc3RhdGUubW9kZWwucHJvZ3Jlc3MgPj0gMTAwKSByZXR1cm4gc3RhdGU7XG5cbiAgICAgICAgY29uc3QgbmV3UHJvZ3Jlc3MgPSBjbGFtcChzdGF0ZS5tb2RlbC5wcm9ncmVzcyArIEdBTUVfQ09ORklHLm1vZGVsSW5jcmVtZW50UGVyU29sdmUpO1xuICAgICAgICBjb25zdCBib251cyA9IEdBTUVfQ09ORklHLnBvaW50c1BlclB1enpsZVN0ZXA7XG4gICAgICAgIGNvbnN0IG5ld01vZGVsOiBEZXBhcnRtZW50U3RhdGUgPSB7XG4gICAgICAgICAgLi4uc3RhdGUubW9kZWwsXG4gICAgICAgICAgcHJvZ3Jlc3M6IG5ld1Byb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICBzY29yZTogc3RhdGUubW9kZWwuc2NvcmUgKyBib251cyxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgbW9kZWw6IG5ld01vZGVsIH0pO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgIG1vZGVsOiBuZXdNb2RlbCxcbiAgICAgICAgICB0ZWFtU2NvcmU6IHN0YXRlLnRlYW1TY29yZSArIGJvbnVzLFxuICAgICAgICAgIGZhY3RvcnlIZWFsdGgsXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9LFxuXG4gICAgLy8g4pSA4pSAIERldi90ZXN0IGFjdGlvbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgICBkZXZJbmNyZW1lbnRQb3dlcjogKF9jdHgsIHsgYW1vdW50IH0pID0+IHtcbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICBjb25zdCBuZXdQcm9ncmVzcyA9IGNsYW1wKHN0YXRlLnBvd2VyLnByb2dyZXNzICsgYW1vdW50KTtcbiAgICAgICAgY29uc3QgYm9udXMgPSBhbW91bnQgKiBHQU1FX0NPTkZJRy5wb2ludHNQZXJQb3dlclRhcDtcbiAgICAgICAgY29uc3QgbmV3UG93ZXIgPSB7XG4gICAgICAgICAgLi4uc3RhdGUucG93ZXIsXG4gICAgICAgICAgcHJvZ3Jlc3M6IG5ld1Byb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICBzY29yZTogc3RhdGUucG93ZXIuc2NvcmUgKyBib251cyxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgcG93ZXI6IG5ld1Bvd2VyIH0pO1xuICAgICAgICByZXR1cm4geyAuLi5zdGF0ZSwgcG93ZXI6IG5ld1Bvd2VyLCB0ZWFtU2NvcmU6IHN0YXRlLnRlYW1TY29yZSArIGJvbnVzLCBmYWN0b3J5SGVhbHRoIH07XG4gICAgICB9KTtcbiAgICB9LFxuXG4gICAgZGV2SW5jcmVtZW50RGF0YTogKF9jdHgsIHsgYW1vdW50IH0pID0+IHtcbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICBjb25zdCBuZXdQcm9ncmVzcyA9IGNsYW1wKHN0YXRlLmRhdGEucHJvZ3Jlc3MgKyBhbW91bnQpO1xuICAgICAgICBjb25zdCBib251cyA9IE1hdGgucm91bmQoYW1vdW50ICogKEdBTUVfQ09ORklHLnBvaW50c1BlckRhdGFTb3J0IC8gMTApKTtcbiAgICAgICAgY29uc3QgbmV3RGF0YSA9IHtcbiAgICAgICAgICAuLi5zdGF0ZS5kYXRhLFxuICAgICAgICAgIHByb2dyZXNzOiBuZXdQcm9ncmVzcyxcbiAgICAgICAgICBzdGF0dXM6IGRlcml2ZVN0YXR1cyhuZXdQcm9ncmVzcyksXG4gICAgICAgICAgc2NvcmU6IHN0YXRlLmRhdGEuc2NvcmUgKyBib251cyxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgZGF0YTogbmV3RGF0YSB9KTtcbiAgICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGRhdGE6IG5ld0RhdGEsIHRlYW1TY29yZTogc3RhdGUudGVhbVNjb3JlICsgYm9udXMsIGZhY3RvcnlIZWFsdGggfTtcbiAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBkZXZJbmNyZW1lbnRTZWN1cml0eTogKF9jdHgsIHsgYW1vdW50IH0pID0+IHtcbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICBjb25zdCBuZXdQcm9ncmVzcyA9IGNsYW1wKHN0YXRlLnNlY3VyaXR5LnByb2dyZXNzICsgYW1vdW50KTtcbiAgICAgICAgY29uc3QgYm9udXMgPSBNYXRoLnJvdW5kKGFtb3VudCAqIChHQU1FX0NPTkZJRy5wb2ludHNQZXJaaXBaYXBIaXQgLyAxMCkpO1xuICAgICAgICBjb25zdCBuZXdTZWN1cml0eSA9IHtcbiAgICAgICAgICAuLi5zdGF0ZS5zZWN1cml0eSxcbiAgICAgICAgICBwcm9ncmVzczogbmV3UHJvZ3Jlc3MsXG4gICAgICAgICAgc3RhdHVzOiBkZXJpdmVTdGF0dXMobmV3UHJvZ3Jlc3MpLFxuICAgICAgICAgIHNjb3JlOiBzdGF0ZS5zZWN1cml0eS5zY29yZSArIGJvbnVzLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBmYWN0b3J5SGVhbHRoID0gY2FsY3VsYXRlRmFjdG9yeUhlYWx0aCh7IC4uLnN0YXRlLCBzZWN1cml0eTogbmV3U2VjdXJpdHkgfSk7XG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBzZWN1cml0eTogbmV3U2VjdXJpdHksIHRlYW1TY29yZTogc3RhdGUudGVhbVNjb3JlICsgYm9udXMsIGZhY3RvcnlIZWFsdGggfTtcbiAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBkZXZJbmNyZW1lbnRNb2RlbDogKF9jdHgsIHsgYW1vdW50IH0pID0+IHtcbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICBjb25zdCBuZXdQcm9ncmVzcyA9IGNsYW1wKHN0YXRlLm1vZGVsLnByb2dyZXNzICsgYW1vdW50KTtcbiAgICAgICAgY29uc3QgYm9udXMgPSBNYXRoLnJvdW5kKGFtb3VudCAqIChHQU1FX0NPTkZJRy5wb2ludHNQZXJQdXp6bGVTdGVwIC8gMTApKTtcbiAgICAgICAgY29uc3QgbmV3TW9kZWwgPSB7XG4gICAgICAgICAgLi4uc3RhdGUubW9kZWwsXG4gICAgICAgICAgcHJvZ3Jlc3M6IG5ld1Byb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogZGVyaXZlU3RhdHVzKG5ld1Byb2dyZXNzKSxcbiAgICAgICAgICBzY29yZTogc3RhdGUubW9kZWwuc2NvcmUgKyBib251cyxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgbW9kZWw6IG5ld01vZGVsIH0pO1xuICAgICAgICByZXR1cm4geyAuLi5zdGF0ZSwgbW9kZWw6IG5ld01vZGVsLCB0ZWFtU2NvcmU6IHN0YXRlLnRlYW1TY29yZSArIGJvbnVzLCBmYWN0b3J5SGVhbHRoIH07XG4gICAgICB9KTtcbiAgICB9LFxuXG4gICAgZGV2U2V0Q29vbGluZ1RlbXA6IChfY3R4LCB7IHRlbXBlcmF0dXJlIH0pID0+IHtcbiAgICAgIHNldCgoc3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHN0YXRlLnBoYXNlICE9PSBcInBsYXlpbmdcIikgcmV0dXJuIHN0YXRlO1xuICAgICAgICBjb25zdCB0ZW1wID0gTWF0aC5tYXgoNTAsIE1hdGgubWluKDEyMCwgdGVtcGVyYXR1cmUpKTtcbiAgICAgICAgY29uc3QgaW5TYWZlWm9uZSA9XG4gICAgICAgICAgdGVtcCA+PSBHQU1FX0NPTkZJRy5jb29saW5nU2FmZU1pbiAmJiB0ZW1wIDw9IEdBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWF4O1xuXG4gICAgICAgIGNvbnN0IHNhZmVDZW50ZXIgPSAoR0FNRV9DT05GSUcuY29vbGluZ1NhZmVNaW4gKyBHQU1FX0NPTkZJRy5jb29saW5nU2FmZU1heCkgLyAyO1xuICAgICAgICBjb25zdCBtYXhEZXZpYXRpb24gPSBHQU1FX0NPTkZJRy5jb29saW5nVGVtcFN0YXJ0IC0gR0FNRV9DT05GSUcuY29vbGluZ1NhZmVNaW47XG4gICAgICAgIGNvbnN0IGRldmlhdGlvbiA9IE1hdGguYWJzKHRlbXAgLSBzYWZlQ2VudGVyKTtcbiAgICAgICAgY29uc3QgY29vbGluZ1Byb2dyZXNzID0gY2xhbXAoTWF0aC5yb3VuZCgxMDAgLSAoZGV2aWF0aW9uIC8gbWF4RGV2aWF0aW9uKSAqIDEwMCkpO1xuXG4gICAgICAgIGNvbnN0IG5ld0Nvb2xpbmcgPSB7XG4gICAgICAgICAgLi4uc3RhdGUuY29vbGluZyxcbiAgICAgICAgICB0ZW1wZXJhdHVyZTogdGVtcCxcbiAgICAgICAgICBwcm9ncmVzczogY29vbGluZ1Byb2dyZXNzLFxuICAgICAgICAgIHN0YXR1czogKGluU2FmZVpvbmVcbiAgICAgICAgICAgID8gXCJzdGFibGVcIlxuICAgICAgICAgICAgOiB0ZW1wID4gODBcbiAgICAgICAgICAgICAgPyBcIndhcm5pbmdcIlxuICAgICAgICAgICAgICA6IFwid29ya2luZ1wiKSBhcyBEZXBhcnRtZW50U3RhdGVbXCJzdGF0dXNcIl0sXG4gICAgICAgICAgc2NvcmU6IGluU2FmZVpvbmVcbiAgICAgICAgICAgID8gc3RhdGUuY29vbGluZy5zY29yZSArIEdBTUVfQ09ORklHLnBvaW50c1BlckNvb2xpbmdUaWNrXG4gICAgICAgICAgICA6IHN0YXRlLmNvb2xpbmcuc2NvcmUsXG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgZmFjdG9yeUhlYWx0aCA9IGNhbGN1bGF0ZUZhY3RvcnlIZWFsdGgoeyAuLi5zdGF0ZSwgY29vbGluZzogbmV3Q29vbGluZyB9KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICBjb29saW5nOiBuZXdDb29saW5nLFxuICAgICAgICAgIHRlYW1TY29yZTogaW5TYWZlWm9uZVxuICAgICAgICAgICAgPyBzdGF0ZS50ZWFtU2NvcmUgKyBHQU1FX0NPTkZJRy5wb2ludHNQZXJDb29saW5nVGlja1xuICAgICAgICAgICAgOiBzdGF0ZS50ZWFtU2NvcmUsXG4gICAgICAgICAgZmFjdG9yeUhlYWx0aCxcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgIH0sXG5cbiAgICAvLyDilIDilIAgQ29vbGluZyBtaW5pLWdhbWUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgICBjb29sVGljazogKHsgYWN0b3JJZCwgcm9sZSB9LCB7IGNlbnRlcmVkbmVzcyB9KSA9PiB7XG4gICAgICBjb25zdCBjdXJyZW50ID0gZ2V0KCk7XG4gICAgICBpZiAoY3VycmVudC5waGFzZSAhPT0gXCJwbGF5aW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdEFpckphbUFjdGlvbihcIm5vdF9wbGF5aW5nXCIsIFwiR2FtZSBpcyBub3QgaW4gcGxheWluZyBwaGFzZS5cIik7XG4gICAgICB9XG5cbiAgICAgIC8vIEd1YXJkOiBvbmx5IHRoZSBhc3NpZ25lZCBDb29saW5nIGVuZ2luZWVyIChvciBob3N0KSBtYXkgc2VuZCB0aWNrcy5cbiAgICAgIGlmIChyb2xlID09PSBcImNvbnRyb2xsZXJcIikge1xuICAgICAgICBjb25zdCBhc3NpZ25lZFJvbGUgPSBhY3RvcklkID8gY3VycmVudC5yb2xlQXNzaWdubWVudHNbYWN0b3JJZF0gOiB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChhc3NpZ25lZFJvbGUgIT09IFwiY29vbGluZ1wiKSB7XG4gICAgICAgICAgcmV0dXJuIHJlamVjdEFpckphbUFjdGlvbihcbiAgICAgICAgICAgIFwid3Jvbmdfcm9sZVwiLFxuICAgICAgICAgICAgXCJPbmx5IHRoZSBDb29saW5nIEVuZ2luZWVyIG1heSBzZW5kIGNvb2xpbmcgdGlja3MuXCIsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBzZXQoKHN0YXRlKSA9PiB7XG4gICAgICAgIGlmIChzdGF0ZS5waGFzZSAhPT0gXCJwbGF5aW5nXCIpIHJldHVybiBzdGF0ZTtcblxuICAgICAgICAvLyBDbGFtcCBjZW50ZXJlZG5lc3MgMOKAkzEgZGVmZW5zaXZlbHkgKGNvbnRyb2xsZXIgaXMgdW50cnVzdGVkIG5ldHdvcmsgc291cmNlKS5cbiAgICAgICAgY29uc3QgYyA9IE1hdGgubWluKDEsIE1hdGgubWF4KDAsIGNlbnRlcmVkbmVzcykpO1xuXG4gICAgICAgIC8vIEludGVycG9sYXRlIHRlbXBlcmF0dXJlIGNoYW5nZTogcGVyZmVjdGx5IGNlbnRyZWQgPSBjb29sLCBmdWxseSBvZmYgPSBoZWF0LlxuICAgICAgICAvLyBBdCBjPTAgd2Ugc3VidHJhY3QgY29vbGluZ1RlbXBEZWNyZWFzZVBlclRpY2s7XG4gICAgICAgIC8vIGF0IGM9MSB3ZSBhZGQgY29vbGluZ1RlbXBJbmNyZWFzZVBlclRpY2suXG4gICAgICAgIGNvbnN0IGRlbHRhID1cbiAgICAgICAgICAtR0FNRV9DT05GSUcuY29vbGluZ1RlbXBEZWNyZWFzZVBlclRpY2sgK1xuICAgICAgICAgIGMgKiAoR0FNRV9DT05GSUcuY29vbGluZ1RlbXBEZWNyZWFzZVBlclRpY2sgKyBHQU1FX0NPTkZJRy5jb29saW5nVGVtcEluY3JlYXNlUGVyVGljayk7XG5cbiAgICAgICAgY29uc3QgcmF3VGVtcCA9IHN0YXRlLmNvb2xpbmcudGVtcGVyYXR1cmUgKyBkZWx0YTtcbiAgICAgICAgY29uc3QgdGVtcCA9IE1hdGgubWF4KDUwLCBNYXRoLm1pbigxMjAsIHJhd1RlbXApKTtcblxuICAgICAgICBjb25zdCBpblNhZmVab25lID1cbiAgICAgICAgICB0ZW1wID49IEdBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWluICYmIHRlbXAgPD0gR0FNRV9DT05GSUcuY29vbGluZ1NhZmVNYXg7XG4gICAgICAgIGNvbnN0IGlzQ2VudGVyZWQgPSBjIDw9IEdBTUVfQ09ORklHLmNvb2xpbmdDZW50ZXJlZFRocmVzaG9sZDtcbiAgICAgICAgY29uc3Qgc2NvcmVCb251cyA9IGlzQ2VudGVyZWQgPyBHQU1FX0NPTkZJRy5wb2ludHNQZXJDb29saW5nVGljayA6IDA7XG5cbiAgICAgICAgLy8gRGVyaXZlIHByb2dyZXNzOiBmdWxsIHNjb3JlIHdoZW4gaW5zaWRlIHNhZmUgem9uZS5cbiAgICAgICAgY29uc3Qgc2FmZUNlbnRlciA9IChHQU1FX0NPTkZJRy5jb29saW5nU2FmZU1pbiArIEdBTUVfQ09ORklHLmNvb2xpbmdTYWZlTWF4KSAvIDI7XG4gICAgICAgIGNvbnN0IG1heERldmlhdGlvbiA9IEdBTUVfQ09ORklHLmNvb2xpbmdUZW1wU3RhcnQgLSBHQU1FX0NPTkZJRy5jb29saW5nU2FmZU1pbjtcbiAgICAgICAgY29uc3QgZGV2aWF0aW9uID0gTWF0aC5hYnModGVtcCAtIHNhZmVDZW50ZXIpO1xuICAgICAgICBjb25zdCBjb29saW5nUHJvZ3Jlc3MgPSBjbGFtcChNYXRoLnJvdW5kKDEwMCAtIChkZXZpYXRpb24gLyBtYXhEZXZpYXRpb24pICogMTAwKSk7XG5cbiAgICAgICAgY29uc3QgbmV3U3RhdHVzOiBEZXBhcnRtZW50U3RhdGVbXCJzdGF0dXNcIl0gPSBpblNhZmVab25lXG4gICAgICAgICAgPyBcInN0YWJsZVwiXG4gICAgICAgICAgOiB0ZW1wID4gODVcbiAgICAgICAgICAgID8gXCJjcml0aWNhbFwiXG4gICAgICAgICAgICA6IHRlbXAgPiA3OFxuICAgICAgICAgICAgICA/IFwid2FybmluZ1wiXG4gICAgICAgICAgICAgIDogXCJ3b3JraW5nXCI7XG5cbiAgICAgICAgY29uc3QgbmV3Q29vbGluZyA9IHtcbiAgICAgICAgICAuLi5zdGF0ZS5jb29saW5nLFxuICAgICAgICAgIHRlbXBlcmF0dXJlOiB0ZW1wLFxuICAgICAgICAgIHByb2dyZXNzOiBjb29saW5nUHJvZ3Jlc3MsXG4gICAgICAgICAgc3RhdHVzOiBuZXdTdGF0dXMsXG4gICAgICAgICAgc2NvcmU6IHN0YXRlLmNvb2xpbmcuc2NvcmUgKyBzY29yZUJvbnVzLFxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGZhY3RvcnlIZWFsdGggPSBjYWxjdWxhdGVGYWN0b3J5SGVhbHRoKHsgLi4uc3RhdGUsIGNvb2xpbmc6IG5ld0Nvb2xpbmcgfSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgY29vbGluZzogbmV3Q29vbGluZyxcbiAgICAgICAgICB0ZWFtU2NvcmU6IHN0YXRlLnRlYW1TY29yZSArIHNjb3JlQm9udXMsXG4gICAgICAgICAgZmFjdG9yeUhlYWx0aCxcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgIH0sXG5cbiAgICAvLyDilIDilIAgVGltZXIgdGljayDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAgIHRpY2tUaW1lcjogKHsgcm9sZSB9KSA9PiB7XG4gICAgICBpZiAocm9sZSAhPT0gXCJob3N0XCIpIHJldHVybjtcblxuICAgICAgc2V0KChzdGF0ZSkgPT4ge1xuICAgICAgICBpZiAoc3RhdGUucGhhc2UgIT09IFwicGxheWluZ1wiKSByZXR1cm4gc3RhdGU7XG5cbiAgICAgICAgY29uc3QgbmV3VGltZSA9IHN0YXRlLnRpbWVSZW1haW5pbmcgLSAxO1xuICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuXG4gICAgICAgIGlmIChuZXdUaW1lIDw9IDApIHtcbiAgICAgICAgICBjb25zdCBmaW5hbFJlc3VsdCA9IGV2YWx1YXRlRmluYWxSZXN1bHQoXG4gICAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICAgIEdBTUVfQ09ORklHLmZhY3RvcnlTdWNjZXNzVGhyZXNob2xkLFxuICAgICAgICAgICAgR0FNRV9DT05GSUcuY3JpdGljYWxEZXB0TWluaW11bSxcbiAgICAgICAgICApO1xuICAgICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCB0aW1lUmVtYWluaW5nOiAwLCBwaGFzZTogXCJlbmRlZFwiLCBmaW5hbFJlc3VsdCwgYWN0aXZlRXZlbnRzOiBbXSB9O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRXhwaXJlIG9sZCBldmVudHMuXG4gICAgICAgIGNvbnN0IGxpdmVFdmVudHMgPSBzdGF0ZS5hY3RpdmVFdmVudHMuZmlsdGVyKFxuICAgICAgICAgIChlKSA9PiBub3cgLSBlLnN0YXJ0ZWRBdCA8IEVWRU5UX0RVUkFUSU9OX01TLFxuICAgICAgICApO1xuXG4gICAgICAgIC8vIFNwYXduIGEgbmV3IHNjaGVkdWxlZCBldmVudCBpZiBvbmUgaXMgZHVlIGF0IHRoaXMgc2Vjb25kLlxuICAgICAgICBjb25zdCBzY2hlZHVsZWQgPSBTQ0hFRFVMRURfRVZFTlRTW25ld1RpbWVdO1xuICAgICAgICBpZiAoc2NoZWR1bGVkKSB7XG4gICAgICAgICAgLy8gRG9uJ3QgcmUtYWRkIHRoZSBzYW1lIGV2ZW50IHR5cGUgaWYgaXQncyBhbHJlYWR5IGFjdGl2ZS5cbiAgICAgICAgICBjb25zdCBhbHJlYWR5QWN0aXZlID0gbGl2ZUV2ZW50cy5zb21lKChlKSA9PiBlLnR5cGUgPT09IHNjaGVkdWxlZC50eXBlKTtcbiAgICAgICAgICBpZiAoIWFscmVhZHlBY3RpdmUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0V2ZW50OiBGYWN0b3J5RXZlbnQgPSB7XG4gICAgICAgICAgICAgIGlkOiBgJHtzY2hlZHVsZWQudHlwZX0tJHtuZXdUaW1lfWAsXG4gICAgICAgICAgICAgIHR5cGU6IHNjaGVkdWxlZC50eXBlLFxuICAgICAgICAgICAgICBtZXNzYWdlOiBzY2hlZHVsZWQubWVzc2FnZSxcbiAgICAgICAgICAgICAgYWZmZWN0ZWRSb2xlOiBzY2hlZHVsZWQuYWZmZWN0ZWRSb2xlLFxuICAgICAgICAgICAgICBzdGFydGVkQXQ6IG5vdyxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBsaXZlRXZlbnRzLnB1c2gobmV3RXZlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB7IC4uLnN0YXRlLCB0aW1lUmVtYWluaW5nOiBuZXdUaW1lLCBhY3RpdmVFdmVudHM6IGxpdmVFdmVudHMgfTtcbiAgICAgIH0pO1xuICAgIH0sXG4gIH0sXG59KSk7XG4iXSwibWFwcGluZ3MiOiJBQWFBO0FBQUEsRUFDRTtBQUFBLEVBQ0E7QUFBQSxPQUVLO0FBRVAsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx3QkFBd0IsMkJBQTJCO0FBUTVELFNBQVMsaUJBQWlCO0FBTTFCLE1BQU0sb0JBQW9CO0FBUTFCLE1BQU0sbUJBQW1EO0FBQUEsRUFDdkQsS0FBSztBQUFBLElBQ0gsTUFBTTtBQUFBLElBQ04sU0FBUztBQUFBLElBQ1QsY0FBYztBQUFBLEVBQ2hCO0FBQUEsRUFDQSxLQUFLO0FBQUEsSUFDSCxNQUFNO0FBQUEsSUFDTixTQUFTO0FBQUEsSUFDVCxjQUFjO0FBQUEsRUFDaEI7QUFBQSxFQUNBLElBQUk7QUFBQSxJQUNGLE1BQU07QUFBQSxJQUNOLFNBQVM7QUFBQSxJQUNULGNBQWM7QUFBQSxFQUNoQjtBQUFBLEVBQ0EsSUFBSTtBQUFBLElBQ0YsTUFBTTtBQUFBLElBQ04sU0FBUztBQUFBLElBQ1QsY0FBYztBQUFBLEVBQ2hCO0FBQUEsRUFDQSxJQUFJO0FBQUEsSUFDRixNQUFNO0FBQUEsSUFDTixTQUFTO0FBQUEsSUFDVCxjQUFjO0FBQUEsRUFDaEI7QUFDRjtBQUlBLFNBQVMsU0FBUyxXQUFXLEdBQW9CO0FBQy9DLFNBQU8sRUFBRSxVQUFVLFFBQVEsWUFBWSxPQUFPLEVBQUU7QUFDbEQ7QUFFQSxTQUFTLE1BQU0sR0FBVyxNQUFNLEdBQUcsTUFBTSxLQUFhO0FBQ3BELFNBQU8sS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssQ0FBQyxDQUFDO0FBQ3ZDO0FBRUEsU0FBUyxhQUFhLFVBQTZDO0FBQ2pFLE1BQUksWUFBWSxJQUFLLFFBQU87QUFDNUIsTUFBSSxZQUFZLEdBQUksUUFBTztBQUMzQixNQUFJLFdBQVcsRUFBRyxRQUFPO0FBQ3pCLFNBQU87QUFDVDtBQUlPLGdCQUFTLDRCQUE4QztBQUM1RCxTQUFPO0FBQUEsSUFDTCxPQUFPO0FBQUEsSUFDUCxlQUFlLFlBQVk7QUFBQSxJQUMzQixpQkFBaUIsQ0FBQztBQUFBLElBQ2xCLE9BQU8sU0FBUztBQUFBLElBQ2hCLE1BQU0sU0FBUztBQUFBLElBQ2YsVUFBVSxTQUFTO0FBQUEsSUFDbkIsT0FBTyxTQUFTO0FBQUEsSUFDaEIsU0FBUztBQUFBLE1BQ1AsR0FBRyxTQUFTO0FBQUEsTUFDWixhQUFhLFlBQVk7QUFBQSxJQUMzQjtBQUFBLElBQ0EsZUFBZTtBQUFBLElBQ2YsV0FBVztBQUFBLElBQ1gsY0FBYyxDQUFDO0FBQUEsSUFDZixhQUFhO0FBQUEsRUFDZjtBQUNGO0FBa0VPLGFBQU0sa0JBQWtCLGtCQUFnQyxDQUFDLEtBQUssU0FBUztBQUFBLEVBQzVFLEdBQUcsMEJBQTBCO0FBQUEsRUFFN0IsU0FBUztBQUFBO0FBQUEsSUFHUCxhQUFhLENBQUMsRUFBRSxTQUFTLEtBQUssTUFBTTtBQUVsQyxVQUFJLFNBQVMsY0FBYztBQUN6QixlQUFPLG1CQUFtQiw0QkFBNEIsb0NBQW9DO0FBQUEsTUFDNUY7QUFFQSxVQUFJLENBQUMsVUFBVTtBQUViLFlBQUksV0FBVyxNQUFNLGdCQUFnQixPQUFPLEVBQUcsUUFBTztBQUd0RCxZQUFJLE1BQU0sVUFBVSxVQUFVLE1BQU0sVUFBVSxTQUFTO0FBQ3JELGlCQUFPO0FBQUEsUUFDVDtBQUVBLGNBQU0sYUFBYSxJQUFJLElBQUksT0FBTyxPQUFPLE1BQU0sZUFBZSxDQUFDO0FBQy9ELGNBQU0sV0FBVyxVQUFVLEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUV6RCxZQUFJLENBQUMsWUFBWSxDQUFDLFFBQVMsUUFBTztBQUVsQyxjQUFNLGlCQUFpQixFQUFFLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsU0FBUztBQUN2RSxjQUFNLFdBQXNCO0FBRTVCLGVBQU8sRUFBRSxHQUFHLE9BQU8saUJBQWlCLGdCQUFnQixPQUFPLFNBQVM7QUFBQSxNQUN0RSxDQUFDO0FBQUEsSUFDSDtBQUFBLElBRUEsV0FBVyxDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQ3ZCLFVBQUksU0FBUyxRQUFRO0FBQ25CLGVBQU8sbUJBQW1CLGFBQWEsbUNBQW1DO0FBQUEsTUFDNUU7QUFHQSxZQUFNLFVBQVUsSUFBSTtBQUNwQixZQUFNLGNBQWMsT0FBTyxLQUFLLFFBQVEsZUFBZSxFQUFFO0FBQ3pELFVBQUksY0FBYyxZQUFZLFlBQVk7QUFDeEMsZUFBTztBQUFBLFVBQ0w7QUFBQSxVQUNBLFFBQVEsWUFBWSxVQUFVLGtCQUFrQixXQUFXO0FBQUEsUUFDN0Q7QUFBQSxNQUNGO0FBRUEsVUFBSSxDQUFDLFdBQVc7QUFBQSxRQUNkLEdBQUc7QUFBQSxRQUNILE9BQU87QUFBQSxRQUNQLGVBQWUsWUFBWTtBQUFBLFFBQzNCLE9BQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxRQUFRLFVBQVU7QUFBQSxRQUMzQyxNQUFNLEVBQUUsR0FBRyxNQUFNLE1BQU0sUUFBUSxVQUFVO0FBQUEsUUFDekMsVUFBVSxFQUFFLEdBQUcsTUFBTSxVQUFVLFFBQVEsVUFBVTtBQUFBLFFBQ2pELE9BQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxRQUFRLFVBQVU7QUFBQSxRQUMzQyxTQUFTLEVBQUUsR0FBRyxNQUFNLFNBQVMsUUFBUSxVQUFVO0FBQUEsTUFDakQsRUFBRTtBQUFBLElBQ0o7QUFBQSxJQUVBLFdBQVcsQ0FBQyxFQUFFLEtBQUssTUFBTTtBQUN2QixVQUFJLFNBQVMsUUFBUTtBQUNuQixlQUFPLG1CQUFtQixhQUFhLDBCQUEwQjtBQUFBLE1BQ25FO0FBQ0EsVUFBSSxPQUFPLEVBQUUsR0FBRywwQkFBMEIsRUFBRSxFQUFFO0FBQUEsSUFDaEQ7QUFBQTtBQUFBLElBSUEsVUFBVSxDQUFDLEVBQUUsU0FBUyxLQUFLLE1BQU07QUFHL0IsWUFBTSxVQUFVLElBQUk7QUFDcEIsVUFBSSxRQUFRLFVBQVUsV0FBVztBQUMvQixlQUFPLG1CQUFtQixlQUFlLCtCQUErQjtBQUFBLE1BQzFFO0FBR0EsVUFBSSxTQUFTLGNBQWM7QUFDekIsY0FBTSxlQUFlLFVBQVUsUUFBUSxnQkFBZ0IsT0FBTyxJQUFJO0FBQ2xFLFlBQUksaUJBQWlCLFNBQVM7QUFDNUIsaUJBQU87QUFBQSxZQUNMO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBSSxNQUFNLFVBQVUsVUFBVyxRQUFPO0FBRXRDLFlBQUksTUFBTSxNQUFNLFlBQVksSUFBSyxRQUFPO0FBRXhDLGNBQU0sY0FBYyxNQUFNLE1BQU0sTUFBTSxXQUFXLFlBQVksb0JBQW9CO0FBQ2pGLGNBQU0sUUFBUSxZQUFZO0FBQzFCLGNBQU0sV0FBNEI7QUFBQSxVQUNoQyxHQUFHLE1BQU07QUFBQSxVQUNULFVBQVU7QUFBQSxVQUNWLFFBQVEsYUFBYSxXQUFXO0FBQUEsVUFDaEMsT0FBTyxNQUFNLE1BQU0sUUFBUTtBQUFBLFFBQzdCO0FBQ0EsY0FBTSxnQkFBZ0IsdUJBQXVCLEVBQUUsR0FBRyxPQUFPLE9BQU8sU0FBUyxDQUFDO0FBQzFFLGVBQU87QUFBQSxVQUNMLEdBQUc7QUFBQSxVQUNILE9BQU87QUFBQSxVQUNQLFdBQVcsTUFBTSxZQUFZO0FBQUEsVUFDN0I7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBO0FBQUEsSUFJQSxVQUFVLENBQUMsRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLFFBQVEsTUFBTTtBQUU1QyxZQUFNLFVBQVUsSUFBSTtBQUNwQixVQUFJLFFBQVEsVUFBVSxXQUFXO0FBQy9CLGVBQU8sbUJBQW1CLGVBQWUsK0JBQStCO0FBQUEsTUFDMUU7QUFHQSxVQUFJLFNBQVMsY0FBYztBQUN6QixjQUFNLGVBQWUsVUFBVSxRQUFRLGdCQUFnQixPQUFPLElBQUk7QUFDbEUsWUFBSSxpQkFBaUIsUUFBUTtBQUMzQixpQkFBTztBQUFBLFlBQ0w7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBR0EsVUFBSSxDQUFDLFFBQVM7QUFFZCxVQUFJLENBQUMsVUFBVTtBQUNiLFlBQUksTUFBTSxVQUFVLFVBQVcsUUFBTztBQUN0QyxZQUFJLE1BQU0sS0FBSyxZQUFZLElBQUssUUFBTztBQUV2QyxjQUFNLGNBQWMsTUFBTSxNQUFNLEtBQUssV0FBVyxZQUFZLG9CQUFvQjtBQUNoRixjQUFNLFFBQVEsWUFBWTtBQUMxQixjQUFNLFVBQTJCO0FBQUEsVUFDL0IsR0FBRyxNQUFNO0FBQUEsVUFDVCxVQUFVO0FBQUEsVUFDVixRQUFRLGFBQWEsV0FBVztBQUFBLFVBQ2hDLE9BQU8sTUFBTSxLQUFLLFFBQVE7QUFBQSxRQUM1QjtBQUNBLGNBQU0sZ0JBQWdCLHVCQUF1QixFQUFFLEdBQUcsT0FBTyxNQUFNLFFBQVEsQ0FBQztBQUN4RSxlQUFPO0FBQUEsVUFDTCxHQUFHO0FBQUEsVUFDSCxNQUFNO0FBQUEsVUFDTixXQUFXLE1BQU0sWUFBWTtBQUFBLFVBQzdCO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQTtBQUFBLElBSUEsUUFBUSxDQUFDLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFFdEMsWUFBTSxVQUFVLElBQUk7QUFDcEIsVUFBSSxRQUFRLFVBQVUsV0FBVztBQUMvQixlQUFPLG1CQUFtQixlQUFlLCtCQUErQjtBQUFBLE1BQzFFO0FBR0EsVUFBSSxTQUFTLGNBQWM7QUFDekIsY0FBTSxlQUFlLFVBQVUsUUFBUSxnQkFBZ0IsT0FBTyxJQUFJO0FBQ2xFLFlBQUksaUJBQWlCLFlBQVk7QUFDL0IsaUJBQU87QUFBQSxZQUNMO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBSSxNQUFNLFVBQVUsVUFBVyxRQUFPO0FBQ3RDLFlBQUksTUFBTSxTQUFTLFlBQVksSUFBSyxRQUFPO0FBRTNDLFlBQUksS0FBSztBQUVQLGdCQUFNLGNBQWMsTUFBTSxNQUFNLFNBQVMsV0FBVyxZQUFZLHVCQUF1QjtBQUN2RixnQkFBTSxRQUFRLFlBQVk7QUFDMUIsZ0JBQU0sY0FBK0I7QUFBQSxZQUNuQyxHQUFHLE1BQU07QUFBQSxZQUNULFVBQVU7QUFBQSxZQUNWLFFBQVEsYUFBYSxXQUFXO0FBQUEsWUFDaEMsT0FBTyxNQUFNLFNBQVMsUUFBUTtBQUFBLFVBQ2hDO0FBQ0EsZ0JBQU0sZ0JBQWdCLHVCQUF1QixFQUFFLEdBQUcsT0FBTyxVQUFVLFlBQVksQ0FBQztBQUNoRixpQkFBTztBQUFBLFlBQ0wsR0FBRztBQUFBLFlBQ0gsVUFBVTtBQUFBLFlBQ1YsV0FBVyxNQUFNLFlBQVk7QUFBQSxZQUM3QjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLE9BQU87QUFFTCxnQkFBTSxjQUFjLE1BQU0sTUFBTSxTQUFTLFdBQVcsWUFBWSxzQkFBc0I7QUFDdEYsZ0JBQU0sY0FBK0I7QUFBQSxZQUNuQyxHQUFHLE1BQU07QUFBQSxZQUNULFVBQVU7QUFBQSxZQUNWLFFBQVEsYUFBYSxXQUFXO0FBQUEsVUFDbEM7QUFDQSxnQkFBTSxnQkFBZ0IsdUJBQXVCLEVBQUUsR0FBRyxPQUFPLFVBQVUsWUFBWSxDQUFDO0FBQ2hGLGlCQUFPLEVBQUUsR0FBRyxPQUFPLFVBQVUsYUFBYSxjQUFjO0FBQUEsUUFDMUQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxJQUlBLGFBQWEsQ0FBQyxFQUFFLFNBQVMsS0FBSyxNQUFNO0FBQ2xDLFlBQU0sVUFBVSxJQUFJO0FBQ3BCLFVBQUksUUFBUSxVQUFVLFdBQVc7QUFDL0IsZUFBTyxtQkFBbUIsZUFBZSwrQkFBK0I7QUFBQSxNQUMxRTtBQUdBLFVBQUksU0FBUyxjQUFjO0FBQ3pCLGNBQU0sZUFBZSxVQUFVLFFBQVEsZ0JBQWdCLE9BQU8sSUFBSTtBQUNsRSxZQUFJLGlCQUFpQixTQUFTO0FBQzVCLGlCQUFPO0FBQUEsWUFDTDtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLENBQUMsVUFBVTtBQUNiLFlBQUksTUFBTSxVQUFVLFVBQVcsUUFBTztBQUN0QyxZQUFJLE1BQU0sTUFBTSxZQUFZLElBQUssUUFBTztBQUV4QyxjQUFNLGNBQWMsTUFBTSxNQUFNLE1BQU0sV0FBVyxZQUFZLHNCQUFzQjtBQUNuRixjQUFNLFFBQVEsWUFBWTtBQUMxQixjQUFNLFdBQTRCO0FBQUEsVUFDaEMsR0FBRyxNQUFNO0FBQUEsVUFDVCxVQUFVO0FBQUEsVUFDVixRQUFRLGFBQWEsV0FBVztBQUFBLFVBQ2hDLE9BQU8sTUFBTSxNQUFNLFFBQVE7QUFBQSxRQUM3QjtBQUNBLGNBQU0sZ0JBQWdCLHVCQUF1QixFQUFFLEdBQUcsT0FBTyxPQUFPLFNBQVMsQ0FBQztBQUMxRSxlQUFPO0FBQUEsVUFDTCxHQUFHO0FBQUEsVUFDSCxPQUFPO0FBQUEsVUFDUCxXQUFXLE1BQU0sWUFBWTtBQUFBLFVBQzdCO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQTtBQUFBLElBSUEsbUJBQW1CLENBQUMsTUFBTSxFQUFFLE9BQU8sTUFBTTtBQUN2QyxVQUFJLENBQUMsVUFBVTtBQUNiLFlBQUksTUFBTSxVQUFVLFVBQVcsUUFBTztBQUN0QyxjQUFNLGNBQWMsTUFBTSxNQUFNLE1BQU0sV0FBVyxNQUFNO0FBQ3ZELGNBQU0sUUFBUSxTQUFTLFlBQVk7QUFDbkMsY0FBTSxXQUFXO0FBQUEsVUFDZixHQUFHLE1BQU07QUFBQSxVQUNULFVBQVU7QUFBQSxVQUNWLFFBQVEsYUFBYSxXQUFXO0FBQUEsVUFDaEMsT0FBTyxNQUFNLE1BQU0sUUFBUTtBQUFBLFFBQzdCO0FBQ0EsY0FBTSxnQkFBZ0IsdUJBQXVCLEVBQUUsR0FBRyxPQUFPLE9BQU8sU0FBUyxDQUFDO0FBQzFFLGVBQU8sRUFBRSxHQUFHLE9BQU8sT0FBTyxVQUFVLFdBQVcsTUFBTSxZQUFZLE9BQU8sY0FBYztBQUFBLE1BQ3hGLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFFQSxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNO0FBQ3RDLFVBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBSSxNQUFNLFVBQVUsVUFBVyxRQUFPO0FBQ3RDLGNBQU0sY0FBYyxNQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU07QUFDdEQsY0FBTSxRQUFRLEtBQUssTUFBTSxVQUFVLFlBQVksb0JBQW9CLEdBQUc7QUFDdEUsY0FBTSxVQUFVO0FBQUEsVUFDZCxHQUFHLE1BQU07QUFBQSxVQUNULFVBQVU7QUFBQSxVQUNWLFFBQVEsYUFBYSxXQUFXO0FBQUEsVUFDaEMsT0FBTyxNQUFNLEtBQUssUUFBUTtBQUFBLFFBQzVCO0FBQ0EsY0FBTSxnQkFBZ0IsdUJBQXVCLEVBQUUsR0FBRyxPQUFPLE1BQU0sUUFBUSxDQUFDO0FBQ3hFLGVBQU8sRUFBRSxHQUFHLE9BQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxZQUFZLE9BQU8sY0FBYztBQUFBLE1BQ3RGLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFFQSxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNO0FBQzFDLFVBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBSSxNQUFNLFVBQVUsVUFBVyxRQUFPO0FBQ3RDLGNBQU0sY0FBYyxNQUFNLE1BQU0sU0FBUyxXQUFXLE1BQU07QUFDMUQsY0FBTSxRQUFRLEtBQUssTUFBTSxVQUFVLFlBQVkscUJBQXFCLEdBQUc7QUFDdkUsY0FBTSxjQUFjO0FBQUEsVUFDbEIsR0FBRyxNQUFNO0FBQUEsVUFDVCxVQUFVO0FBQUEsVUFDVixRQUFRLGFBQWEsV0FBVztBQUFBLFVBQ2hDLE9BQU8sTUFBTSxTQUFTLFFBQVE7QUFBQSxRQUNoQztBQUNBLGNBQU0sZ0JBQWdCLHVCQUF1QixFQUFFLEdBQUcsT0FBTyxVQUFVLFlBQVksQ0FBQztBQUNoRixlQUFPLEVBQUUsR0FBRyxPQUFPLFVBQVUsYUFBYSxXQUFXLE1BQU0sWUFBWSxPQUFPLGNBQWM7QUFBQSxNQUM5RixDQUFDO0FBQUEsSUFDSDtBQUFBLElBRUEsbUJBQW1CLENBQUMsTUFBTSxFQUFFLE9BQU8sTUFBTTtBQUN2QyxVQUFJLENBQUMsVUFBVTtBQUNiLFlBQUksTUFBTSxVQUFVLFVBQVcsUUFBTztBQUN0QyxjQUFNLGNBQWMsTUFBTSxNQUFNLE1BQU0sV0FBVyxNQUFNO0FBQ3ZELGNBQU0sUUFBUSxLQUFLLE1BQU0sVUFBVSxZQUFZLHNCQUFzQixHQUFHO0FBQ3hFLGNBQU0sV0FBVztBQUFBLFVBQ2YsR0FBRyxNQUFNO0FBQUEsVUFDVCxVQUFVO0FBQUEsVUFDVixRQUFRLGFBQWEsV0FBVztBQUFBLFVBQ2hDLE9BQU8sTUFBTSxNQUFNLFFBQVE7QUFBQSxRQUM3QjtBQUNBLGNBQU0sZ0JBQWdCLHVCQUF1QixFQUFFLEdBQUcsT0FBTyxPQUFPLFNBQVMsQ0FBQztBQUMxRSxlQUFPLEVBQUUsR0FBRyxPQUFPLE9BQU8sVUFBVSxXQUFXLE1BQU0sWUFBWSxPQUFPLGNBQWM7QUFBQSxNQUN4RixDQUFDO0FBQUEsSUFDSDtBQUFBLElBRUEsbUJBQW1CLENBQUMsTUFBTSxFQUFFLFlBQVksTUFBTTtBQUM1QyxVQUFJLENBQUMsVUFBVTtBQUNiLFlBQUksTUFBTSxVQUFVLFVBQVcsUUFBTztBQUN0QyxjQUFNLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssV0FBVyxDQUFDO0FBQ3BELGNBQU0sYUFDSixRQUFRLFlBQVksa0JBQWtCLFFBQVEsWUFBWTtBQUU1RCxjQUFNLGNBQWMsWUFBWSxpQkFBaUIsWUFBWSxrQkFBa0I7QUFDL0UsY0FBTSxlQUFlLFlBQVksbUJBQW1CLFlBQVk7QUFDaEUsY0FBTSxZQUFZLEtBQUssSUFBSSxPQUFPLFVBQVU7QUFDNUMsY0FBTSxrQkFBa0IsTUFBTSxLQUFLLE1BQU0sTUFBTyxZQUFZLGVBQWdCLEdBQUcsQ0FBQztBQUVoRixjQUFNLGFBQWE7QUFBQSxVQUNqQixHQUFHLE1BQU07QUFBQSxVQUNULGFBQWE7QUFBQSxVQUNiLFVBQVU7QUFBQSxVQUNWLFFBQVMsYUFDTCxXQUNBLE9BQU8sS0FDTCxZQUNBO0FBQUEsVUFDTixPQUFPLGFBQ0gsTUFBTSxRQUFRLFFBQVEsWUFBWSx1QkFDbEMsTUFBTSxRQUFRO0FBQUEsUUFDcEI7QUFFQSxjQUFNLGdCQUFnQix1QkFBdUIsRUFBRSxHQUFHLE9BQU8sU0FBUyxXQUFXLENBQUM7QUFDOUUsZUFBTztBQUFBLFVBQ0wsR0FBRztBQUFBLFVBQ0gsU0FBUztBQUFBLFVBQ1QsV0FBVyxhQUNQLE1BQU0sWUFBWSxZQUFZLHVCQUM5QixNQUFNO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUE7QUFBQSxJQUlBLFVBQVUsQ0FBQyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsYUFBYSxNQUFNO0FBQ2pELFlBQU0sVUFBVSxJQUFJO0FBQ3BCLFVBQUksUUFBUSxVQUFVLFdBQVc7QUFDL0IsZUFBTyxtQkFBbUIsZUFBZSwrQkFBK0I7QUFBQSxNQUMxRTtBQUdBLFVBQUksU0FBUyxjQUFjO0FBQ3pCLGNBQU0sZUFBZSxVQUFVLFFBQVEsZ0JBQWdCLE9BQU8sSUFBSTtBQUNsRSxZQUFJLGlCQUFpQixXQUFXO0FBQzlCLGlCQUFPO0FBQUEsWUFDTDtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLENBQUMsVUFBVTtBQUNiLFlBQUksTUFBTSxVQUFVLFVBQVcsUUFBTztBQUd0QyxjQUFNLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsWUFBWSxDQUFDO0FBSy9DLGNBQU0sUUFDSixDQUFDLFlBQVksNkJBQ2IsS0FBSyxZQUFZLDZCQUE2QixZQUFZO0FBRTVELGNBQU0sVUFBVSxNQUFNLFFBQVEsY0FBYztBQUM1QyxjQUFNLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxDQUFDO0FBRWhELGNBQU0sYUFDSixRQUFRLFlBQVksa0JBQWtCLFFBQVEsWUFBWTtBQUM1RCxjQUFNLGFBQWEsS0FBSyxZQUFZO0FBQ3BDLGNBQU0sYUFBYSxhQUFhLFlBQVksdUJBQXVCO0FBR25FLGNBQU0sY0FBYyxZQUFZLGlCQUFpQixZQUFZLGtCQUFrQjtBQUMvRSxjQUFNLGVBQWUsWUFBWSxtQkFBbUIsWUFBWTtBQUNoRSxjQUFNLFlBQVksS0FBSyxJQUFJLE9BQU8sVUFBVTtBQUM1QyxjQUFNLGtCQUFrQixNQUFNLEtBQUssTUFBTSxNQUFPLFlBQVksZUFBZ0IsR0FBRyxDQUFDO0FBRWhGLGNBQU0sWUFBdUMsYUFDekMsV0FDQSxPQUFPLEtBQ0wsYUFDQSxPQUFPLEtBQ0wsWUFDQTtBQUVSLGNBQU0sYUFBYTtBQUFBLFVBQ2pCLEdBQUcsTUFBTTtBQUFBLFVBQ1QsYUFBYTtBQUFBLFVBQ2IsVUFBVTtBQUFBLFVBQ1YsUUFBUTtBQUFBLFVBQ1IsT0FBTyxNQUFNLFFBQVEsUUFBUTtBQUFBLFFBQy9CO0FBRUEsY0FBTSxnQkFBZ0IsdUJBQXVCLEVBQUUsR0FBRyxPQUFPLFNBQVMsV0FBVyxDQUFDO0FBQzlFLGVBQU87QUFBQSxVQUNMLEdBQUc7QUFBQSxVQUNILFNBQVM7QUFBQSxVQUNULFdBQVcsTUFBTSxZQUFZO0FBQUEsVUFDN0I7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBO0FBQUEsSUFJQSxXQUFXLENBQUMsRUFBRSxLQUFLLE1BQU07QUFDdkIsVUFBSSxTQUFTLE9BQVE7QUFFckIsVUFBSSxDQUFDLFVBQVU7QUFDYixZQUFJLE1BQU0sVUFBVSxVQUFXLFFBQU87QUFFdEMsY0FBTSxVQUFVLE1BQU0sZ0JBQWdCO0FBQ3RDLGNBQU0sTUFBTSxLQUFLLElBQUk7QUFFckIsWUFBSSxXQUFXLEdBQUc7QUFDaEIsZ0JBQU0sY0FBYztBQUFBLFlBQ2xCO0FBQUEsWUFDQSxZQUFZO0FBQUEsWUFDWixZQUFZO0FBQUEsVUFDZDtBQUNBLGlCQUFPLEVBQUUsR0FBRyxPQUFPLGVBQWUsR0FBRyxPQUFPLFNBQVMsYUFBYSxjQUFjLENBQUMsRUFBRTtBQUFBLFFBQ3JGO0FBR0EsY0FBTSxhQUFhLE1BQU0sYUFBYTtBQUFBLFVBQ3BDLENBQUMsTUFBTSxNQUFNLEVBQUUsWUFBWTtBQUFBLFFBQzdCO0FBR0EsY0FBTSxZQUFZLGlCQUFpQixPQUFPO0FBQzFDLFlBQUksV0FBVztBQUViLGdCQUFNLGdCQUFnQixXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxVQUFVLElBQUk7QUFDdEUsY0FBSSxDQUFDLGVBQWU7QUFDbEIsa0JBQU0sV0FBeUI7QUFBQSxjQUM3QixJQUFJLEdBQUcsVUFBVSxJQUFJLElBQUksT0FBTztBQUFBLGNBQ2hDLE1BQU0sVUFBVTtBQUFBLGNBQ2hCLFNBQVMsVUFBVTtBQUFBLGNBQ25CLGNBQWMsVUFBVTtBQUFBLGNBQ3hCLFdBQVc7QUFBQSxZQUNiO0FBQ0EsdUJBQVcsS0FBSyxRQUFRO0FBQUEsVUFDMUI7QUFBQSxRQUNGO0FBRUEsZUFBTyxFQUFFLEdBQUcsT0FBTyxlQUFlLFNBQVMsY0FBYyxXQUFXO0FBQUEsTUFDdEUsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0YsRUFBRTsiLCJuYW1lcyI6W119