import {
  Button,
  Slider,
  cn,
  shellInsetPanelClassName,
  shellPanelClassName,
  shellUtilityButtonClassName
} from "/node_modules/.vite/deps/chunk-PH4EEG7B.js?v=c74894a2";
import {
  AIR_JAM_PREVIEW_CLOSE_REQUEST,
  AIR_JAM_PREVIEW_DEVICE_QUERY_PARAM,
  AIR_JAM_PREVIEW_FLAG_QUERY_PARAM,
  createPreviewControllerIdentity,
  isPreviewCloseResultMessage,
  isPreviewControllerSearchParams,
  normalizePreviewDeviceId,
  readPreviewControllerDeviceIdFromLocation,
  readPreviewControllerDeviceIdFromSearchParams,
  useAirJamHost
} from "/node_modules/.vite/deps/chunk-YTXXUP4X.js?v=c74894a2";
import {
  Bot,
  ChevronDown,
  ChevronUp,
  LoaderCircle,
  Minus,
  MonitorSmartphone,
  Plus,
  SlidersHorizontal,
  Smartphone,
  TabletSmartphone,
  TriangleAlert,
  X,
  appendRuntimeQueryParams,
  getRuntimeUrlOrigin,
  isLocalDevControlSurfaceRuntimeMode,
  normalizeRuntimeUrl,
  parseOptionalArcadeSurfaceFromSearchParams,
  useAirJamConfig,
  useOptionalPlatformSettingsOwnerApi,
  useResolvedPlatformSettingsSnapshot
} from "/node_modules/.vite/deps/chunk-B6OEUIDA.js?v=c74894a2";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-GZR6XUHA.js?v=c74894a2";
import "/node_modules/.vite/deps/chunk-KQIFYUJI.js?v=c74894a2";
import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-FA4F7MSV.js?v=c74894a2";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-DOQUEKBH.js?v=c74894a2";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-DP4XHQAG.js?v=c74894a2";

// node_modules/.pnpm/@air-jam+sdk@0.9.2_@types+r_505686c9f477e039bbf34d708d2bfe6b/node_modules/@air-jam/sdk/dist/preview.js
var import_react = __toESM(require_react());
var import_react_dom = __toESM(require_react_dom());
var import_react2 = __toESM(require_react());
var import_react3 = __toESM(require_react());
var import_jsx_runtime = __toESM(require_jsx_runtime());
var import_jsx_runtime2 = __toESM(require_jsx_runtime());
var import_jsx_runtime3 = __toESM(require_jsx_runtime());
var readDevelopmentRuntime = () => {
  var _a;
  try {
    const meta = import.meta;
    const env = meta.env;
    if (typeof (env == null ? void 0 : env.DEV) === "boolean") {
      return env.DEV;
    }
  } catch {
  }
  const processLike = globalThis.process;
  return ((_a = processLike == null ? void 0 : processLike.env) == null ? void 0 : _a.NODE_ENV) !== "production";
};
var readWindowSearchParams = () => {
  if (typeof window === "undefined") {
    return new URLSearchParams();
  }
  return new URLSearchParams(window.location.search);
};
var toSearchParams = (value) => {
  if (typeof value === "string") {
    return new URLSearchParams(value);
  }
  return value ?? readWindowSearchParams();
};
var isEmbeddedArcadeRuntimeSearchParams = (searchParams) => parseOptionalArcadeSurfaceFromSearchParams(toSearchParams(searchParams)) != null;
var resolveHostPreviewControllerWorkspaceEnabled = ({
  enabled = "auto",
  topology,
  isDevelopmentRuntime = readDevelopmentRuntime(),
  searchParams
} = {}) => {
  if (typeof enabled === "boolean") {
    return enabled;
  }
  const localDevControlSurfacesEnabled = topology != null ? isLocalDevControlSurfaceRuntimeMode(topology.runtimeMode) : isDevelopmentRuntime;
  return localDevControlSurfacesEnabled && !isEmbeddedArcadeRuntimeSearchParams(searchParams);
};
var PREVIEW_WORKSPACE_Z_INDEX = 2147483e3;
var PREVIEW_WINDOW_TITLEBAR_HEIGHT = 38;
var PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE = 12;
var PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE = 20;
var IPHONE_16_PREVIEW_DEVICE = {
  id: "iphone-16",
  label: "iPhone 16 browser",
  portrait: {
    width: 393,
    height: 740
  }
};
var DEFAULT_PREVIEW_CONTROLLER_DEVICE = IPHONE_16_PREVIEW_DEVICE;
var DEFAULT_PREVIEW_CONTROLLER_SCALE = 0.8;
var PREVIEW_CONTROLLER_MIN_SCALE = 0.55;
var PREVIEW_CONTROLLER_MAX_SCALE = 1.12;
var getPreviewControllerViewportSize = (orientation, device = DEFAULT_PREVIEW_CONTROLLER_DEVICE) => orientation === "portrait" ? device.portrait : {
  width: device.portrait.height,
  height: device.portrait.width
};
var getPreviewControllerScaleConstraints = () => ({
  min: PREVIEW_CONTROLLER_MIN_SCALE,
  max: PREVIEW_CONTROLLER_MAX_SCALE
});
var getPreviewWindowBoundsForScale = (orientation, scale, device = DEFAULT_PREVIEW_CONTROLLER_DEVICE) => {
  const viewport = getPreviewControllerViewportSize(orientation, device);
  return {
    width: viewport.width * scale,
    height: PREVIEW_WINDOW_TITLEBAR_HEIGHT + viewport.height * scale
  };
};
var getPreviewControllerScaleForBounds = (orientation, bounds, mode = "fit", device = DEFAULT_PREVIEW_CONTROLLER_DEVICE) => {
  const viewport = getPreviewControllerViewportSize(orientation, device);
  const widthScale = bounds.width / viewport.width;
  const heightScale = (bounds.height - PREVIEW_WINDOW_TITLEBAR_HEIGHT) / viewport.height;
  const rawScale = mode === "grow" ? Math.max(widthScale, heightScale) : mode === "shrink" ? Math.min(widthScale, heightScale) : Math.min(widthScale, heightScale);
  const constraints = getPreviewControllerScaleConstraints();
  return Math.min(Math.max(rawScale, constraints.min), constraints.max);
};
var getPreviewControllerScaleForResize = ({
  orientation,
  bounds,
  originBounds,
  handle,
  device = DEFAULT_PREVIEW_CONTROLLER_DEVICE
}) => {
  const viewport = getPreviewControllerViewportSize(orientation, device);
  const widthScale = bounds.width / viewport.width;
  const heightScale = (bounds.height - PREVIEW_WINDOW_TITLEBAR_HEIGHT) / viewport.height;
  if (handle === "e" || handle === "w") {
    const constraints2 = getPreviewControllerScaleConstraints();
    return Math.min(Math.max(widthScale, constraints2.min), constraints2.max);
  }
  if (handle === "n" || handle === "s") {
    const constraints2 = getPreviewControllerScaleConstraints();
    return Math.min(Math.max(heightScale, constraints2.min), constraints2.max);
  }
  const widthDelta = Math.abs(bounds.width - originBounds.width);
  const heightDelta = Math.abs(bounds.height - originBounds.height);
  const rawScale = widthDelta / viewport.width >= heightDelta / viewport.height ? widthScale : heightScale;
  const constraints = getPreviewControllerScaleConstraints();
  return Math.min(Math.max(rawScale, constraints.min), constraints.max);
};
var PREVIEW_WINDOW_DEFAULT_BOUNDS = {
  portrait: getPreviewWindowBoundsForScale(
    "portrait",
    DEFAULT_PREVIEW_CONTROLLER_SCALE
  ),
  landscape: getPreviewWindowBoundsForScale(
    "landscape",
    DEFAULT_PREVIEW_CONTROLLER_SCALE
  )
};
var PREVIEW_WINDOW_SIZE_CONSTRAINTS = {
  portrait: {
    minWidth: getPreviewWindowBoundsForScale(
      "portrait",
      PREVIEW_CONTROLLER_MIN_SCALE
    ).width,
    minHeight: getPreviewWindowBoundsForScale(
      "portrait",
      PREVIEW_CONTROLLER_MIN_SCALE
    ).height,
    maxWidth: getPreviewWindowBoundsForScale(
      "portrait",
      PREVIEW_CONTROLLER_MAX_SCALE
    ).width,
    maxHeight: getPreviewWindowBoundsForScale(
      "portrait",
      PREVIEW_CONTROLLER_MAX_SCALE
    ).height
  },
  landscape: {
    minWidth: getPreviewWindowBoundsForScale(
      "landscape",
      PREVIEW_CONTROLLER_MIN_SCALE
    ).width,
    minHeight: getPreviewWindowBoundsForScale(
      "landscape",
      PREVIEW_CONTROLLER_MIN_SCALE
    ).height,
    maxWidth: getPreviewWindowBoundsForScale(
      "landscape",
      PREVIEW_CONTROLLER_MAX_SCALE
    ).width,
    maxHeight: getPreviewWindowBoundsForScale(
      "landscape",
      PREVIEW_CONTROLLER_MAX_SCALE
    ).height
  }
};
var getDefaultPreviewWindowBounds = (orientation) => PREVIEW_WINDOW_DEFAULT_BOUNDS[orientation];
var getPreviewWindowSizeConstraints = (orientation) => PREVIEW_WINDOW_SIZE_CONSTRAINTS[orientation];
var getResizedPreviewBounds = (bounds, handle, deltaX, deltaY) => {
  const resizingWest = handle.includes("w");
  const resizingEast = handle.includes("e");
  const resizingNorth = handle.includes("n");
  const resizingSouth = handle.includes("s");
  return {
    x: resizingWest ? bounds.x + deltaX : bounds.x,
    y: resizingNorth ? bounds.y + deltaY : bounds.y,
    width: bounds.width + (resizingEast ? deltaX : 0) - (resizingWest ? deltaX : 0),
    height: bounds.height + (resizingSouth ? deltaY : 0) - (resizingNorth ? deltaY : 0)
  };
};
var normalizeAllowedOrigins = (allowedOrigins) => {
  if (!allowedOrigins || allowedOrigins.length === 0) {
    return [];
  }
  return allowedOrigins.map((origin) => getRuntimeUrlOrigin(origin)).filter((origin) => origin !== null);
};
var buildPreviewControllerUrl = ({
  joinUrl,
  controllerId,
  previewDeviceId,
  allowedOrigins,
  embedOrigin
}) => {
  const normalizedJoinUrl = normalizeRuntimeUrl(joinUrl);
  if (!normalizedJoinUrl) {
    return null;
  }
  const joinOrigin = getRuntimeUrlOrigin(normalizedJoinUrl);
  const normalizedAllowedOrigins = normalizeAllowedOrigins(allowedOrigins);
  if (normalizedAllowedOrigins.length > 0 && (!joinOrigin || !normalizedAllowedOrigins.includes(joinOrigin))) {
    return null;
  }
  const previewBaseUrl = (() => {
    if (!embedOrigin) {
      return normalizedJoinUrl;
    }
    const normalizedEmbedOrigin = getRuntimeUrlOrigin(embedOrigin);
    if (!normalizedEmbedOrigin) {
      return null;
    }
    const nextUrl = new URL(normalizedJoinUrl);
    const nextOrigin = new URL(normalizedEmbedOrigin);
    nextUrl.protocol = nextOrigin.protocol;
    nextUrl.host = nextOrigin.host;
    return nextUrl.toString();
  })();
  if (!previewBaseUrl) {
    return null;
  }
  return appendRuntimeQueryParams(previewBaseUrl, {
    controllerId,
    [AIR_JAM_PREVIEW_FLAG_QUERY_PARAM]: "1",
    [AIR_JAM_PREVIEW_DEVICE_QUERY_PARAM]: previewDeviceId
  });
};
var createPreviewControllerLaunch = ({
  joinUrl,
  allowedOrigins,
  embedOrigin
}) => {
  const identity = createPreviewControllerIdentity();
  const url = buildPreviewControllerUrl({
    joinUrl,
    controllerId: identity.controllerId,
    previewDeviceId: identity.deviceId,
    allowedOrigins,
    embedOrigin
  });
  if (!url) {
    return null;
  }
  return {
    ...identity,
    url
  };
};
var DEFAULT_VIEWPORT_WIDTH = 1440;
var DEFAULT_VIEWPORT_HEIGHT = 900;
var PREVIEW_WINDOW_MARGIN = 24;
var PREVIEW_WINDOW_CASCADE_OFFSET = 28;
var DEFAULT_PREVIEW_CONTROLLER_ORIENTATION = "portrait";
var getViewportSize = () => {
  if (typeof window === "undefined") {
    return {
      width: DEFAULT_VIEWPORT_WIDTH,
      height: DEFAULT_VIEWPORT_HEIGHT
    };
  }
  return {
    width: window.innerWidth,
    height: window.innerHeight
  };
};
var getJoinRoomIdentity = (joinUrl) => {
  if (!joinUrl) {
    return null;
  }
  try {
    const normalizedJoinUrl = normalizeRuntimeUrl(joinUrl) ?? joinUrl;
    const roomId = new URL(normalizedJoinUrl).searchParams.get("room");
    return roomId && roomId.trim().length > 0 ? roomId : normalizedJoinUrl;
  } catch {
    return joinUrl;
  }
};
var clampSize = (orientation, width, height) => {
  const viewport = getViewportSize();
  const constraints = getPreviewWindowSizeConstraints(orientation);
  const maxWidth = Math.max(
    constraints.minWidth,
    Math.min(constraints.maxWidth, viewport.width - PREVIEW_WINDOW_MARGIN * 2)
  );
  const maxHeight = Math.max(
    constraints.minHeight,
    Math.min(
      constraints.maxHeight,
      viewport.height - PREVIEW_WINDOW_MARGIN * 2
    )
  );
  return {
    width: Math.min(Math.max(constraints.minWidth, width), maxWidth),
    height: Math.min(Math.max(constraints.minHeight, height), maxHeight)
  };
};
var clampScaleForViewport = (orientation, scale) => {
  const viewport = getViewportSize();
  const deviceViewport = getPreviewControllerViewportSize(orientation);
  const constraints = getPreviewControllerScaleConstraints();
  const maxByViewport = Math.min(
    (viewport.width - PREVIEW_WINDOW_MARGIN * 2) / deviceViewport.width,
    (viewport.height - PREVIEW_WINDOW_MARGIN * 2 - PREVIEW_WINDOW_TITLEBAR_HEIGHT) / deviceViewport.height
  );
  return Math.min(
    Math.max(scale, constraints.min),
    Math.max(constraints.min, Math.min(constraints.max, maxByViewport))
  );
};
var getPreviewWindowBounds = (orientation, scale) => {
  const displayScale = clampScaleForViewport(orientation, scale);
  const viewport = getPreviewControllerViewportSize(orientation);
  const bounds = getPreviewWindowBoundsForScale(orientation, displayScale);
  return {
    ...bounds,
    viewportWidth: viewport.width,
    viewportHeight: viewport.height,
    displayScale
  };
};
var clampPosition = (orientation, x, y, width = getDefaultPreviewWindowBounds(DEFAULT_PREVIEW_CONTROLLER_ORIENTATION).width, height = getDefaultPreviewWindowBounds(DEFAULT_PREVIEW_CONTROLLER_ORIENTATION).height) => {
  const viewport = getViewportSize();
  const nextSize = clampSize(orientation, width, height);
  const maxX = Math.max(
    PREVIEW_WINDOW_MARGIN,
    viewport.width - nextSize.width - PREVIEW_WINDOW_MARGIN
  );
  const maxY = Math.max(
    PREVIEW_WINDOW_MARGIN,
    viewport.height - nextSize.height - PREVIEW_WINDOW_MARGIN
  );
  return {
    x: Math.min(Math.max(PREVIEW_WINDOW_MARGIN, x), maxX),
    y: Math.min(Math.max(PREVIEW_WINDOW_MARGIN, y), maxY)
  };
};
var clampBounds = (orientation, bounds, options = {}, currentBounds) => {
  const right = bounds.x + bounds.width;
  const bottom = bounds.y + bounds.height;
  const resizeMode = currentBounds && (bounds.width < currentBounds.width || bounds.height < currentBounds.height) ? "shrink" : "grow";
  const scale = options.resizeHandle && options.originBounds ? getPreviewControllerScaleForResize({
    orientation,
    bounds,
    originBounds: options.originBounds,
    handle: options.resizeHandle
  }) : getPreviewControllerScaleForBounds(orientation, bounds, resizeMode);
  const nextWindowBounds = getPreviewWindowBounds(orientation, scale);
  const { width, height } = nextWindowBounds;
  const x = options.preserveRight ? right - width : bounds.x;
  const y = options.preserveBottom ? bottom - height : bounds.y;
  const position = clampPosition(orientation, x, y, width, height);
  return {
    x: position.x,
    y: position.y,
    width,
    height
  };
};
var getInitialWindowPosition = (sessions, orientation) => {
  const viewport = getViewportSize();
  const defaultBounds = getPreviewWindowBounds(
    orientation,
    DEFAULT_PREVIEW_CONTROLLER_SCALE
  );
  const cascadeCount = Math.min(sessions.length, 3);
  const offset = cascadeCount * PREVIEW_WINDOW_CASCADE_OFFSET;
  const defaultX = (viewport.width - defaultBounds.width) / 2 + offset;
  const defaultY = (viewport.height - defaultBounds.height) / 2 + offset;
  const anchored = clampPosition(
    orientation,
    defaultX,
    defaultY,
    defaultBounds.width,
    defaultBounds.height
  );
  return {
    x: anchored.x,
    y: anchored.y
  };
};
var getNextTopSessionId = (sessions) => {
  var _a;
  return ((_a = sessions.filter((session) => !session.minimized).sort((left, right) => right.zIndex - left.zIndex)[0]) == null ? void 0 : _a.id) ?? null;
};
var activateSession = (sessions, id, nextZIndex) => sessions.map(
  (session) => session.id === id ? {
    ...session,
    active: true,
    minimized: false,
    zIndex: nextZIndex
  } : { ...session, active: false }
);
var normalizeActiveSession = (sessions) => {
  const nextActiveId = getNextTopSessionId(sessions);
  return sessions.map((session) => ({
    ...session,
    active: nextActiveId !== null && session.id === nextActiveId
  }));
};
var mapSessionsAndNormalizeActive = (sessions, mapSession) => normalizeActiveSession(sessions.map(mapSession));
var usePreviewControllerManager = ({
  joinUrl,
  enabled = true,
  maxControllers = 2,
  allowedOrigins,
  embedOrigin
}) => {
  const [sessions, setSessions] = (0, import_react2.useState)([]);
  const nextSessionIdRef = (0, import_react2.useRef)(1);
  const nextOrdinalRef = (0, import_react2.useRef)(1);
  const nextZIndexRef = (0, import_react2.useRef)(1);
  const previousJoinRoomRef = (0, import_react2.useRef)(
    getJoinRoomIdentity(joinUrl)
  );
  (0, import_react2.useEffect)(() => {
    const nextJoinRoom = getJoinRoomIdentity(joinUrl);
    const previousJoinRoom = previousJoinRoomRef.current;
    if (!enabled || previousJoinRoom !== null && nextJoinRoom !== null && previousJoinRoom !== nextJoinRoom) {
      setSessions([]);
      nextSessionIdRef.current = 1;
      nextOrdinalRef.current = 1;
      nextZIndexRef.current = 1;
    }
    previousJoinRoomRef.current = nextJoinRoom;
  }, [enabled, joinUrl]);
  const canSpawn = enabled && typeof joinUrl === "string" && joinUrl.trim().length > 0 && sessions.length < maxControllers;
  const spawnPreviewController = (0, import_react2.useCallback)(() => {
    if (!enabled || !joinUrl) {
      return null;
    }
    let nextSession = null;
    setSessions((current) => {
      if (current.length >= maxControllers) {
        return current;
      }
      const launch = createPreviewControllerLaunch({
        joinUrl,
        allowedOrigins,
        embedOrigin
      });
      if (!launch) {
        return current;
      }
      const ordinal = nextOrdinalRef.current++;
      const zIndex = nextZIndexRef.current++;
      const sessionId = `preview_session_${nextSessionIdRef.current++}`;
      const orientation = DEFAULT_PREVIEW_CONTROLLER_ORIENTATION;
      const defaultBounds = getPreviewWindowBounds(
        orientation,
        DEFAULT_PREVIEW_CONTROLLER_SCALE
      );
      const position = getInitialWindowPosition(current, orientation);
      nextSession = {
        id: sessionId,
        ordinal,
        label: `Preview ${ordinal}`,
        controllerId: launch.controllerId,
        deviceId: launch.deviceId,
        url: launch.url,
        surfaceState: "loading",
        orientation,
        minimized: false,
        active: true,
        x: position.x,
        y: position.y,
        width: defaultBounds.width,
        height: defaultBounds.height,
        viewportWidth: defaultBounds.viewportWidth,
        viewportHeight: defaultBounds.viewportHeight,
        displayScale: defaultBounds.displayScale,
        zIndex
      };
      return [
        ...current.map((session) => ({ ...session, active: false })),
        nextSession
      ];
    });
    return nextSession;
  }, [allowedOrigins, embedOrigin, enabled, joinUrl, maxControllers]);
  const removePreviewController = (0, import_react2.useCallback)((id) => {
    setSessions(
      (current) => normalizeActiveSession(current.filter((session) => session.id !== id))
    );
  }, []);
  const clearPreviewControllers = (0, import_react2.useCallback)(() => {
    setSessions([]);
    nextSessionIdRef.current = 1;
    nextOrdinalRef.current = 1;
    nextZIndexRef.current = 1;
  }, []);
  const minimizePreviewController = (0, import_react2.useCallback)((id) => {
    setSessions(
      (current) => normalizeActiveSession(
        current.map(
          (session) => session.id === id ? { ...session, minimized: true, active: false } : session
        )
      )
    );
  }, []);
  const focusPreviewController = (0, import_react2.useCallback)((id) => {
    const nextZIndex = nextZIndexRef.current++;
    setSessions((current) => activateSession(current, id, nextZIndex));
  }, []);
  const restorePreviewController = (0, import_react2.useCallback)((id) => {
    const nextZIndex = nextZIndexRef.current++;
    setSessions((current) => activateSession(current, id, nextZIndex));
  }, []);
  const setPreviewControllerPosition = (0, import_react2.useCallback)(
    (id, x, y) => {
      setSessions(
        (current) => mapSessionsAndNormalizeActive(current, (session) => {
          if (session.id !== id) {
            return session;
          }
          const nextPosition = clampPosition(
            session.orientation,
            x,
            y,
            session.width,
            session.height
          );
          return {
            ...session,
            x: nextPosition.x,
            y: nextPosition.y
          };
        })
      );
    },
    []
  );
  const setPreviewControllerBounds = (0, import_react2.useCallback)(
    (id, bounds, options = {}) => {
      setSessions(
        (current) => mapSessionsAndNormalizeActive(current, (session) => {
          if (session.id !== id) {
            return session;
          }
          const nextBounds = clampBounds(session.orientation, bounds, options, {
            x: session.x,
            y: session.y,
            width: session.width,
            height: session.height
          });
          const nextWindowBounds = getPreviewWindowBounds(
            session.orientation,
            getPreviewControllerScaleForBounds(session.orientation, nextBounds)
          );
          return {
            ...session,
            width: nextWindowBounds.width,
            height: nextWindowBounds.height,
            viewportWidth: nextWindowBounds.viewportWidth,
            viewportHeight: nextWindowBounds.viewportHeight,
            displayScale: nextWindowBounds.displayScale,
            x: nextBounds.x,
            y: nextBounds.y
          };
        })
      );
    },
    []
  );
  const rotatePreviewController = (0, import_react2.useCallback)((id) => {
    setSessions(
      (current) => mapSessionsAndNormalizeActive(current, (session) => {
        if (session.id !== id) {
          return session;
        }
        const nextOrientation = session.orientation === "portrait" ? "landscape" : "portrait";
        const centerX = session.x + session.width / 2;
        const centerY = session.y + session.height / 2;
        const nextWindowBounds = getPreviewWindowBounds(
          nextOrientation,
          session.displayScale
        );
        const nextBounds = clampBounds(
          nextOrientation,
          {
            x: centerX - nextWindowBounds.width / 2,
            y: centerY - nextWindowBounds.height / 2,
            width: nextWindowBounds.width,
            height: nextWindowBounds.height
          },
          {}
        );
        const clampedWindowBounds = getPreviewWindowBounds(
          nextOrientation,
          getPreviewControllerScaleForBounds(nextOrientation, nextBounds)
        );
        return {
          ...session,
          orientation: nextOrientation,
          x: nextBounds.x,
          y: nextBounds.y,
          width: clampedWindowBounds.width,
          height: clampedWindowBounds.height,
          viewportWidth: clampedWindowBounds.viewportWidth,
          viewportHeight: clampedWindowBounds.viewportHeight,
          displayScale: clampedWindowBounds.displayScale
        };
      })
    );
  }, []);
  const markPreviewControllerReady = (0, import_react2.useCallback)((id) => {
    setSessions(
      (current) => mapSessionsAndNormalizeActive(
        current,
        (session) => session.id === id ? { ...session, surfaceState: "ready" } : session
      )
    );
  }, []);
  const markPreviewControllerFailed = (0, import_react2.useCallback)((id) => {
    setSessions(
      (current) => mapSessionsAndNormalizeActive(
        current,
        (session) => session.id === id ? { ...session, surfaceState: "failed" } : session
      )
    );
  }, []);
  return {
    sessions,
    canSpawn,
    spawnPreviewController,
    removePreviewController,
    minimizePreviewController,
    restorePreviewController,
    focusPreviewController,
    setPreviewControllerPosition,
    setPreviewControllerBounds,
    rotatePreviewController,
    markPreviewControllerReady,
    markPreviewControllerFailed,
    clearPreviewControllers
  };
};
var PREVIEW_WINDOW_SETTINGS_SHELF_HEIGHT = 52;
var PREVIEW_CLOSE_TIMEOUT_MS = 1e3;
var requestPreviewControllerClose = async (iframe, sessionUrl) => {
  const frameWindow = iframe == null ? void 0 : iframe.contentWindow;
  if (!frameWindow) {
    return;
  }
  const targetOrigin = new URL(sessionUrl).origin;
  await new Promise((resolve) => {
    let settled = false;
    const timeout = window.setTimeout(() => {
      cleanup();
      resolve();
    }, PREVIEW_CLOSE_TIMEOUT_MS);
    const handleMessage = (event) => {
      if (event.source !== frameWindow || event.origin !== targetOrigin) {
        return;
      }
      if (!isPreviewCloseResultMessage(event.data)) {
        return;
      }
      cleanup();
      resolve();
    };
    const cleanup = () => {
      if (settled) {
        return;
      }
      settled = true;
      window.clearTimeout(timeout);
      window.removeEventListener("message", handleMessage);
    };
    window.addEventListener("message", handleMessage);
    frameWindow.postMessage(
      {
        type: AIR_JAM_PREVIEW_CLOSE_REQUEST
      },
      targetOrigin
    );
  });
};
var previewControllerWindowStateLabel = {
  loading: "Loading",
  ready: "Ready",
  failed: "Blocked"
};
var RESIZE_HANDLES = [
  {
    handle: "n",
    cursor: "ns-resize",
    style: {
      top: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      left: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      right: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      height: PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE
    }
  },
  {
    handle: "s",
    cursor: "ns-resize",
    style: {
      bottom: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      left: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      right: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      height: PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE
    }
  },
  {
    handle: "e",
    cursor: "ew-resize",
    style: {
      top: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      right: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      bottom: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      width: PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE
    }
  },
  {
    handle: "w",
    cursor: "ew-resize",
    style: {
      top: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      left: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      bottom: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      width: PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE
    }
  },
  {
    handle: "ne",
    cursor: "nesw-resize",
    style: {
      top: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      right: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      width: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      height: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE
    }
  },
  {
    handle: "nw",
    cursor: "nwse-resize",
    style: {
      top: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      left: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      width: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      height: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE
    }
  },
  {
    handle: "se",
    cursor: "nwse-resize",
    style: {
      right: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      bottom: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      width: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      height: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE
    }
  },
  {
    handle: "sw",
    cursor: "nesw-resize",
    style: {
      left: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      bottom: -(PREVIEW_WINDOW_RESIZE_EDGE_HIT_SIZE / 2),
      width: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE,
      height: PREVIEW_WINDOW_RESIZE_CORNER_HIT_SIZE
    }
  }
];
var PreviewControllerWindow = ({
  session,
  activeOpacity,
  highContrast = false,
  dragging = false,
  onFocus,
  onMinimize,
  onRemove,
  onRotate,
  onActiveOpacityChange,
  onReady,
  onFailed,
  onTitlePointerDown,
  onTitlePointerMove,
  onTitlePointerUp,
  onTitlePointerCancel,
  onResizePointerDown,
  onResizePointerMove,
  onResizePointerUp,
  onResizePointerCancel,
  resizing = false
}) => {
  const [windowHovered, setWindowHovered] = (0, import_react3.useState)(false);
  const [settingsOpen, setSettingsOpen] = (0, import_react3.useState)(false);
  const iframeRef = (0, import_react3.useRef)(null);
  const isVisible = dragging || resizing || windowHovered;
  const windowOpacity = isVisible ? activeOpacity : Math.min(activeOpacity, 0.62);
  const settingsShelfHeight = settingsOpen && onActiveOpacityChange ? PREVIEW_WINDOW_SETTINGS_SHELF_HEIGHT : 0;
  const contentHeight = Math.max(
    session.height - PREVIEW_WINDOW_TITLEBAR_HEIGHT,
    0
  );
  const nextOrientationLabel = session.orientation === "portrait" ? "landscape" : "portrait";
  const statusToneClassName = session.surfaceState === "failed" ? "bg-amber-300" : session.surfaceState === "ready" ? "bg-emerald-300" : "bg-white/45";
  return (0, import_jsx_runtime.jsxs)(
    "div",
    {
      className: "absolute",
      style: {
        left: session.x,
        top: session.y,
        width: session.width,
        height: session.height + settingsShelfHeight,
        zIndex: session.zIndex,
        pointerEvents: "none"
      },
      onPointerEnter: () => setWindowHovered(true),
      onPointerLeave: () => setWindowHovered(false),
      children: [
        (0, import_jsx_runtime.jsxs)(
          "section",
          {
            className: cn(
              "relative overflow-hidden border-white/10 transition-opacity duration-150",
              shellPanelClassName,
              highContrast && "border-white/30",
              dragging && "shadow-[0_28px_90px_rgba(0,0,0,0.55)]"
            ),
            style: {
              width: "100%",
              height: "100%",
              opacity: windowOpacity,
              pointerEvents: "auto"
            },
            children: [
              (0, import_jsx_runtime.jsxs)(
                "div",
                {
                  className: "flex h-9 items-center gap-2 border-b border-white/8 px-2.5",
                  style: {
                    cursor: dragging ? "grabbing" : "grab",
                    touchAction: "none",
                    userSelect: "none"
                  },
                  onPointerDown: onTitlePointerDown,
                  onPointerMove: onTitlePointerMove,
                  onPointerUp: onTitlePointerUp,
                  onPointerCancel: onTitlePointerCancel,
                  children: [
                    (0, import_jsx_runtime.jsxs)("div", { className: "flex min-w-0 flex-1 items-center gap-2", children: [
                      (0, import_jsx_runtime.jsx)("div", { className: "flex h-5 w-5 items-center justify-center rounded-full border border-white/10 bg-white/[0.05]", children: (0, import_jsx_runtime.jsx)(MonitorSmartphone, { className: "h-3 w-3 text-white/80" }) }),
                      (0, import_jsx_runtime.jsx)("div", { className: "min-w-0", children: (0, import_jsx_runtime.jsx)("div", { className: "truncate text-[12px] leading-none font-semibold text-white/92", children: session.label }) }),
                      (0, import_jsx_runtime.jsx)(
                        "span",
                        {
                          className: cn(
                            "ml-1 h-1.5 w-1.5 rounded-full",
                            statusToneClassName
                          ),
                          title: previewControllerWindowStateLabel[session.surfaceState]
                        }
                      )
                    ] }),
                    (0, import_jsx_runtime.jsxs)("div", { className: "flex items-center gap-1", children: [
                      (0, import_jsx_runtime.jsx)(
                        Button,
                        {
                          type: "button",
                          variant: "ghost",
                          size: "icon-sm",
                          className: "h-6 w-6 rounded-full text-white/70 hover:bg-white/[0.08] hover:text-white",
                          style: { pointerEvents: "auto" },
                          onPointerDown: (event) => event.stopPropagation(),
                          onClick: onRotate,
                          "aria-label": `Rotate ${session.label} to ${nextOrientationLabel}`,
                          title: `Rotate to ${nextOrientationLabel}`,
                          children: (0, import_jsx_runtime.jsx)(TabletSmartphone, { className: "h-3.5 w-3.5" })
                        }
                      ),
                      onActiveOpacityChange ? (0, import_jsx_runtime.jsx)(
                        Button,
                        {
                          type: "button",
                          variant: "ghost",
                          size: "icon-sm",
                          className: cn(
                            "h-6 w-6 rounded-full text-white/70 hover:bg-white/[0.08] hover:text-white",
                            settingsOpen && "bg-white/[0.08] text-white"
                          ),
                          style: { pointerEvents: "auto" },
                          onPointerDown: (event) => event.stopPropagation(),
                          onClick: () => setSettingsOpen((current) => !current),
                          "aria-label": `Adjust ${session.label} opacity`,
                          title: `Adjust opacity (${Math.round(activeOpacity * 100)}%)`,
                          children: (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-3.5 w-3.5" })
                        }
                      ) : null,
                      (0, import_jsx_runtime.jsx)(
                        Button,
                        {
                          type: "button",
                          variant: "ghost",
                          size: "icon-sm",
                          className: "h-6 w-6 rounded-full text-white/70 hover:bg-white/[0.08] hover:text-white",
                          style: { pointerEvents: "auto" },
                          onPointerDown: (event) => event.stopPropagation(),
                          onClick: onMinimize,
                          "aria-label": `Minimize ${session.label}`,
                          title: "Minimize controller",
                          children: (0, import_jsx_runtime.jsx)(Minus, { className: "h-3.5 w-3.5" })
                        }
                      ),
                      (0, import_jsx_runtime.jsx)(
                        Button,
                        {
                          type: "button",
                          variant: "ghost",
                          size: "icon-sm",
                          className: "h-6 w-6 rounded-full text-white/70 hover:bg-white/[0.08] hover:text-white",
                          style: { pointerEvents: "auto" },
                          onPointerDown: (event) => event.stopPropagation(),
                          onClick: () => {
                            void requestPreviewControllerClose(
                              iframeRef.current,
                              session.url
                            ).catch(() => void 0).finally(() => onRemove());
                          },
                          "aria-label": `Close ${session.label}`,
                          title: "Close controller",
                          children: (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
                        }
                      )
                    ] })
                  ]
                }
              ),
              settingsOpen && onActiveOpacityChange ? (0, import_jsx_runtime.jsxs)(
                "div",
                {
                  className: "border-b border-white/8 bg-black/72 px-3 py-2.5 backdrop-blur-sm",
                  onPointerDown: (event) => event.stopPropagation(),
                  children: [
                    (0, import_jsx_runtime.jsxs)("div", { className: "mb-2 flex items-center justify-between gap-3", children: [
                      (0, import_jsx_runtime.jsx)("p", { className: "text-[11px] font-semibold tracking-[0.16em] text-slate-300 uppercase", children: "Opacity" }),
                      (0, import_jsx_runtime.jsxs)("span", { className: "font-mono text-[11px] text-slate-400", children: [
                        Math.round(activeOpacity * 100),
                        "%"
                      ] })
                    ] }),
                    (0, import_jsx_runtime.jsx)(
                      Slider,
                      {
                        value: [activeOpacity * 100],
                        onValueChange: (values) => onActiveOpacityChange(values[0] / 100),
                        min: 35,
                        max: 100,
                        step: 1,
                        "aria-label": "Preview controller opacity"
                      }
                    )
                  ]
                }
              ) : null,
              (0, import_jsx_runtime.jsx)(
                "div",
                {
                  className: "relative",
                  onPointerDownCapture: () => {
                    if (!session.active) {
                      onFocus();
                    }
                  },
                  children: (0, import_jsx_runtime.jsxs)(
                    "div",
                    {
                      className: "relative overflow-hidden bg-black",
                      style: {
                        width: session.width,
                        height: contentHeight
                      },
                      children: [
                        (0, import_jsx_runtime.jsx)(
                          "div",
                          {
                            className: "origin-top-left",
                            style: {
                              width: session.viewportWidth,
                              height: session.viewportHeight,
                              transform: `scale(${session.displayScale})`,
                              transformOrigin: "top left"
                            },
                            children: (0, import_jsx_runtime.jsx)(
                              "iframe",
                              {
                                ref: iframeRef,
                                src: session.url,
                                title: `${session.label} controller`,
                                "data-testid": `preview-controller-frame-${session.ordinal}`,
                                className: "border-none bg-black",
                                style: {
                                  width: session.viewportWidth,
                                  height: session.viewportHeight
                                },
                                allow: "vibrate; gyroscope; accelerometer; autoplay; fullscreen",
                                sandbox: "allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals",
                                onLoad: onReady,
                                onError: onFailed
                              }
                            )
                          }
                        ),
                        session.surfaceState === "loading" ? (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 flex items-center justify-center bg-black/34 backdrop-blur-[1px]", children: (0, import_jsx_runtime.jsxs)("div", { className: "flex items-center gap-2 rounded-full border border-white/10 bg-black/70 px-3 py-1.5 text-[11px] text-slate-200 shadow-lg", children: [
                          (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-3.5 w-3.5 animate-spin" }),
                          "Loading"
                        ] }) }) : null,
                        session.surfaceState === "failed" ? (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 flex items-center justify-center bg-black/84 px-5 text-center backdrop-blur-[2px]", children: (0, import_jsx_runtime.jsxs)("div", { className: "max-w-[14rem] space-y-2.5", children: [
                          (0, import_jsx_runtime.jsx)("div", { className: "mx-auto flex h-8 w-8 items-center justify-center rounded-full border border-amber-400/22 bg-amber-400/8 text-amber-200", children: (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3.5 w-3.5" }) }),
                          (0, import_jsx_runtime.jsx)("div", { className: "text-sm font-semibold text-white", children: "Controller did not load" }),
                          (0, import_jsx_runtime.jsx)("p", { className: "text-[11px] leading-5 text-slate-300", children: "Close it and open a fresh controller once the route is ready again." })
                        ] }) }) : null
                      ]
                    }
                  )
                }
              )
            ]
          }
        ),
        RESIZE_HANDLES.map(({ handle, cursor, style }) => (0, import_jsx_runtime.jsx)(
          "div",
          {
            "data-testid": `preview-controller-resize-${handle}-${session.ordinal}`,
            className: "absolute",
            style: {
              ...style,
              cursor,
              pointerEvents: "auto",
              touchAction: "none"
            },
            onPointerDown: (event) => onResizePointerDown(handle, event),
            onPointerMove: onResizePointerMove,
            onPointerUp: onResizePointerUp,
            onPointerCancel: onResizePointerCancel,
            title: "Resize controller"
          },
          handle
        ))
      ]
    }
  );
};
var getControllerSourceLabel = (source) => {
  if (source === "virtual") {
    return "Agent";
  }
  return source === "preview" ? "Preview" : "Phone";
};
var getControllerSourceIcon = (source) => {
  if (source === "virtual") {
    return Bot;
  }
  if (source === "preview") {
    return MonitorSmartphone;
  }
  return Smartphone;
};
var PreviewControllerWorkspace = ({
  joinUrl,
  embedOrigin,
  controllers = [],
  onRemoveController,
  onResetRoom,
  enabled = false,
  highContrast = false,
  onActiveOpacityChange,
  className,
  dockAccessory,
  maxControllers = 2,
  launcherLabel = "Controllers",
  waitingLabel = "Waiting for room"
}) => {
  const [mounted, setMounted] = (0, import_react.useState)(false);
  const [dragState, setDragState] = (0, import_react.useState)(null);
  const [resizeState, setResizeState] = (0, import_react.useState)(null);
  const [launcherOpen, setLauncherOpen] = (0, import_react.useState)(false);
  const [removingControllerId, setRemovingControllerId] = (0, import_react.useState)(null);
  const [resettingRoom, setResettingRoom] = (0, import_react.useState)(false);
  const dockRef = (0, import_react.useRef)(null);
  const resolvedEmbedOrigin = embedOrigin ?? (typeof window !== "undefined" ? window.location.origin : null);
  const {
    sessions,
    canSpawn,
    spawnPreviewController,
    clearPreviewControllers,
    removePreviewController,
    minimizePreviewController,
    restorePreviewController,
    focusPreviewController,
    setPreviewControllerPosition,
    setPreviewControllerBounds,
    rotatePreviewController,
    markPreviewControllerReady,
    markPreviewControllerFailed
  } = usePreviewControllerManager({
    joinUrl,
    embedOrigin: resolvedEmbedOrigin,
    enabled,
    maxControllers
  });
  const platformSettings = useResolvedPlatformSettingsSnapshot();
  const activeOpacity = platformSettings.previewControllers.activeOpacity;
  const sortedSessions = (0, import_react.useMemo)(
    () => [...sessions].sort((left, right) => left.ordinal - right.ordinal),
    [sessions]
  );
  (0, import_react.useEffect)(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);
  (0, import_react.useEffect)(() => {
    if (!launcherOpen || typeof document === "undefined") {
      return;
    }
    const handlePointerDown = (event) => {
      var _a;
      const target = event.target;
      if (!(target instanceof Node)) {
        return;
      }
      if ((_a = dockRef.current) == null ? void 0 : _a.contains(target)) {
        return;
      }
      setLauncherOpen(false);
    };
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setLauncherOpen(false);
      }
    };
    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [launcherOpen]);
  const minimizedSessions = (0, import_react.useMemo)(
    () => sessions.filter((session) => session.minimized).sort((left, right) => left.ordinal - right.ordinal),
    [sessions]
  );
  const openSessions = (0, import_react.useMemo)(
    () => sessions.filter((session) => !session.minimized),
    [sessions]
  );
  const sortedControllers = (0, import_react.useMemo)(
    () => [...controllers].sort(
      (left, right) => left.controllerId.localeCompare(right.controllerId)
    ),
    [controllers]
  );
  const controllerRoster = (0, import_react.useMemo)(() => {
    const sessionsByControllerId = new Map(
      sortedSessions.map((session) => [session.controllerId, session])
    );
    const controllerItems = sortedControllers.map((controller) => {
      var _a;
      const session = sessionsByControllerId.get(controller.controllerId) ?? null;
      return {
        id: controller.controllerId,
        controllerId: controller.controllerId,
        label: ((_a = controller.player) == null ? void 0 : _a.label) ?? controller.nickname ?? controller.controllerId,
        source: controller.source,
        connected: controller.connected,
        resumable: Boolean(controller.resumeLeaseExpiresAt),
        session,
        controller
      };
    });
    const connectedControllerIds = new Set(
      sortedControllers.map((controller) => controller.controllerId)
    );
    const pendingPreviewItems = sortedSessions.filter((session) => !connectedControllerIds.has(session.controllerId)).map((session) => ({
      id: session.id,
      controllerId: session.controllerId,
      label: session.label,
      source: "preview",
      connected: session.surfaceState === "ready",
      resumable: false,
      session,
      controller: null
    }));
    return [...controllerItems, ...pendingPreviewItems].sort((left, right) => {
      if (left.source !== right.source) {
        const weight = {
          phone: 0,
          preview: 1,
          virtual: 2
        };
        return weight[left.source] - weight[right.source];
      }
      return left.label.localeCompare(right.label);
    });
  }, [sortedControllers, sortedSessions]);
  if (!enabled || !mounted || typeof document === "undefined") {
    return null;
  }
  return (0, import_react_dom.createPortal)(
    (0, import_jsx_runtime2.jsxs)(
      "div",
      {
        className: "fixed inset-0",
        style: { zIndex: PREVIEW_WORKSPACE_Z_INDEX, pointerEvents: "none" },
        children: [
          openSessions.map((session) => (0, import_jsx_runtime2.jsx)(
            PreviewControllerWindow,
            {
              session,
              activeOpacity,
              highContrast,
              dragging: (dragState == null ? void 0 : dragState.id) === session.id,
              resizing: (resizeState == null ? void 0 : resizeState.id) === session.id,
              onFocus: () => focusPreviewController(session.id),
              onMinimize: () => minimizePreviewController(session.id),
              onRemove: () => removePreviewController(session.id),
              onRotate: () => rotatePreviewController(session.id),
              onActiveOpacityChange,
              onReady: () => markPreviewControllerReady(session.id),
              onFailed: () => markPreviewControllerFailed(session.id),
              onTitlePointerDown: (event) => {
                if (event.button !== 0) {
                  return;
                }
                event.currentTarget.setPointerCapture(event.pointerId);
                focusPreviewController(session.id);
                setDragState({
                  id: session.id,
                  originX: session.x,
                  originY: session.y,
                  startClientX: event.clientX,
                  startClientY: event.clientY,
                  pointerId: event.pointerId
                });
                event.preventDefault();
              },
              onTitlePointerMove: (event) => {
                if (resizeState || !dragState || dragState.id !== session.id || dragState.pointerId !== event.pointerId) {
                  return;
                }
                setPreviewControllerPosition(
                  dragState.id,
                  dragState.originX + (event.clientX - dragState.startClientX),
                  dragState.originY + (event.clientY - dragState.startClientY)
                );
              },
              onTitlePointerUp: (event) => {
                if ((dragState == null ? void 0 : dragState.pointerId) !== event.pointerId) {
                  return;
                }
                if (event.currentTarget.hasPointerCapture(event.pointerId)) {
                  event.currentTarget.releasePointerCapture(event.pointerId);
                }
                setDragState(null);
              },
              onTitlePointerCancel: (event) => {
                if ((dragState == null ? void 0 : dragState.pointerId) !== event.pointerId) {
                  return;
                }
                if (event.currentTarget.hasPointerCapture(event.pointerId)) {
                  event.currentTarget.releasePointerCapture(event.pointerId);
                }
                setDragState(null);
              },
              onResizePointerDown: (handle, event) => {
                if (event.button !== 0) {
                  return;
                }
                event.stopPropagation();
                event.currentTarget.setPointerCapture(event.pointerId);
                focusPreviewController(session.id);
                setResizeState({
                  id: session.id,
                  handle,
                  originBounds: {
                    x: session.x,
                    y: session.y,
                    width: session.width,
                    height: session.height
                  },
                  startClientX: event.clientX,
                  startClientY: event.clientY,
                  pointerId: event.pointerId
                });
                event.preventDefault();
              },
              onResizePointerMove: (event) => {
                if (!resizeState || resizeState.id !== session.id || resizeState.pointerId !== event.pointerId) {
                  return;
                }
                setPreviewControllerBounds(
                  resizeState.id,
                  getResizedPreviewBounds(
                    resizeState.originBounds,
                    resizeState.handle,
                    event.clientX - resizeState.startClientX,
                    event.clientY - resizeState.startClientY
                  ),
                  {
                    preserveRight: resizeState.handle.includes("w"),
                    preserveBottom: resizeState.handle.includes("n"),
                    resizeHandle: resizeState.handle,
                    originBounds: resizeState.originBounds
                  }
                );
              },
              onResizePointerUp: (event) => {
                if ((resizeState == null ? void 0 : resizeState.pointerId) !== event.pointerId) {
                  return;
                }
                if (event.currentTarget.hasPointerCapture(event.pointerId)) {
                  event.currentTarget.releasePointerCapture(event.pointerId);
                }
                setResizeState(null);
              },
              onResizePointerCancel: (event) => {
                if ((resizeState == null ? void 0 : resizeState.pointerId) !== event.pointerId) {
                  return;
                }
                if (event.currentTarget.hasPointerCapture(event.pointerId)) {
                  event.currentTarget.releasePointerCapture(event.pointerId);
                }
                setResizeState(null);
              }
            },
            session.id
          )),
          (0, import_jsx_runtime2.jsxs)(
            "div",
            {
              ref: dockRef,
              className: cn(
                "fixed flex max-w-[calc(100vw-2rem)] flex-col items-end gap-2",
                className ?? "right-4 bottom-4 sm:right-6 sm:bottom-6"
              ),
              style: { pointerEvents: "none" },
              children: [
                (0, import_jsx_runtime2.jsxs)(
                  "div",
                  {
                    className: "flex items-start justify-end gap-2",
                    style: { pointerEvents: "auto" },
                    children: [
                      dockAccessory,
                      (0, import_jsx_runtime2.jsxs)(
                        Button,
                        {
                          type: "button",
                          variant: "ghost",
                          size: "sm",
                          className: cn(
                            "rounded-full border border-white/25 bg-black/35 px-3 text-white backdrop-blur-sm hover:bg-black/55 disabled:border-white/10 disabled:bg-black/25 disabled:text-white/40"
                          ),
                          "aria-expanded": launcherOpen,
                          "aria-label": launcherOpen ? "Hide preview controllers" : "Show preview controllers",
                          title: !joinUrl ? waitingLabel : launcherLabel,
                          onClick: () => setLauncherOpen((current) => !current),
                          children: [
                            (0, import_jsx_runtime2.jsx)(MonitorSmartphone, { className: "h-4 w-4" }),
                            (0, import_jsx_runtime2.jsx)("span", { className: "text-[11px] font-semibold tracking-[0.16em] uppercase", children: launcherLabel }),
                            (0, import_jsx_runtime2.jsx)("span", { className: "rounded-full border border-white/12 bg-white/6 px-1.5 py-0.5 text-[10px] leading-none font-semibold text-white/88", children: sessions.length }),
                            launcherOpen ? (0, import_jsx_runtime2.jsx)(ChevronUp, { className: "h-4 w-4 text-white/60" }) : (0, import_jsx_runtime2.jsx)(ChevronDown, { className: "h-4 w-4 text-white/60" })
                          ]
                        }
                      )
                    ]
                  }
                ),
                launcherOpen ? (0, import_jsx_runtime2.jsx)(
                  "section",
                  {
                    className: cn(
                      "w-88 max-w-[calc(100vw-2rem)] overflow-hidden p-4",
                      shellPanelClassName,
                      highContrast && "border-white/30"
                    ),
                    style: { pointerEvents: "auto" },
                    children: (0, import_jsx_runtime2.jsx)("div", { className: "space-y-4", children: (0, import_jsx_runtime2.jsxs)("div", { className: "space-y-4", children: [
                      controllerRoster.length > 0 || onResetRoom ? (0, import_jsx_runtime2.jsxs)("div", { className: "space-y-3", children: [
                        (0, import_jsx_runtime2.jsxs)("div", { className: "flex items-start justify-between gap-3", children: [
                          (0, import_jsx_runtime2.jsxs)("div", { className: "min-w-0", children: [
                            (0, import_jsx_runtime2.jsx)("p", { className: "text-[11px] font-semibold tracking-[0.18em] text-white/54 uppercase", children: "Controllers" }),
                            (0, import_jsx_runtime2.jsx)("p", { className: "mt-2 text-sm text-white/86", children: controllerRoster.length === 0 ? "No controllers yet" : `${controllerRoster.length} controller${controllerRoster.length === 1 ? "" : "s"} connected` })
                          ] }),
                          (0, import_jsx_runtime2.jsxs)("div", { className: "flex shrink-0 items-center gap-1.5", children: [
                            onResetRoom ? (0, import_jsx_runtime2.jsx)(
                              Button,
                              {
                                type: "button",
                                variant: "ghost",
                                size: "sm",
                                className: "h-7 rounded-full px-3 text-[10px] text-amber-100 hover:bg-amber-400/10 hover:text-amber-50 disabled:text-white/35",
                                disabled: resettingRoom,
                                onClick: async () => {
                                  try {
                                    setResettingRoom(true);
                                    await onResetRoom();
                                  } finally {
                                    setResettingRoom(false);
                                  }
                                },
                                children: "Reset room"
                              }
                            ) : null,
                            sessions.length > 0 ? (0, import_jsx_runtime2.jsx)(
                              Button,
                              {
                                type: "button",
                                variant: "ghost",
                                size: "icon-sm",
                                className: "h-7 w-7 rounded-full text-white/72 hover:bg-white/8 hover:text-white",
                                onClick: () => clearPreviewControllers(),
                                title: "Close all preview controllers",
                                children: (0, import_jsx_runtime2.jsx)(X, { className: "h-4 w-4" })
                              }
                            ) : null
                          ] })
                        ] }),
                        (0, import_jsx_runtime2.jsx)("div", { className: "space-y-2", children: controllerRoster.map((item) => {
                          var _a, _b;
                          const SourceIcon = getControllerSourceIcon(item.source);
                          const previewSession = item.session;
                          return (0, import_jsx_runtime2.jsxs)(
                            "div",
                            {
                              "data-airjam-controller-row": true,
                              "data-controller-id": item.controllerId,
                              "data-controller-source": item.source,
                              className: cn(
                                "flex items-center gap-2.5 rounded-2xl px-3 py-2.5",
                                shellInsetPanelClassName
                              ),
                              children: [
                                (0, import_jsx_runtime2.jsx)("div", { className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70", children: (0, import_jsx_runtime2.jsx)(SourceIcon, { className: "h-4 w-4" }) }),
                                (0, import_jsx_runtime2.jsx)("div", { className: "min-w-0 flex-1", children: (0, import_jsx_runtime2.jsxs)("div", { className: "flex items-center gap-2", children: [
                                  (0, import_jsx_runtime2.jsx)("span", { className: "truncate text-sm font-semibold text-white/92", children: item.label }),
                                  (0, import_jsx_runtime2.jsx)(
                                    "span",
                                    {
                                      "data-airjam-controller-source-badge": true,
                                      className: "rounded-full border border-white/12 bg-white/6 px-1.5 py-0.5 text-[9px] leading-none font-semibold tracking-[0.12em] text-white/70 uppercase",
                                      children: getControllerSourceLabel(item.source)
                                    }
                                  ),
                                  (0, import_jsx_runtime2.jsx)(
                                    "span",
                                    {
                                      className: cn(
                                        "h-1.5 w-1.5 rounded-full",
                                        ((_a = item.session) == null ? void 0 : _a.surfaceState) === "failed" ? "bg-amber-300" : item.connected ? "bg-emerald-300" : "bg-white/45"
                                      ),
                                      title: ((_b = item.session) == null ? void 0 : _b.minimized) ? "Minimized" : item.session ? item.session.surfaceState === "ready" ? "Visible" : previewControllerWindowStateLabel[item.session.surfaceState] : item.connected ? "Connected" : "Disconnected"
                                    }
                                  ),
                                  item.resumable ? (0, import_jsx_runtime2.jsx)("span", { className: "rounded-full border border-white/10 bg-white/5 px-1.5 py-0.5 text-[9px] leading-none font-semibold tracking-[0.12em] text-white/55 uppercase", children: "Resume" }) : null
                                ] }) }),
                                (0, import_jsx_runtime2.jsxs)("div", { className: "flex items-center gap-2", children: [
                                  (previewSession == null ? void 0 : previewSession.minimized) ? (0, import_jsx_runtime2.jsx)(
                                    Button,
                                    {
                                      type: "button",
                                      variant: "outline",
                                      size: "sm",
                                      className: cn(
                                        "h-7 rounded-full px-3 text-[10px]",
                                        shellUtilityButtonClassName
                                      ),
                                      onClick: () => restorePreviewController(previewSession.id),
                                      children: "Restore"
                                    }
                                  ) : null,
                                  item.controller && onRemoveController ? (0, import_jsx_runtime2.jsx)(
                                    Button,
                                    {
                                      type: "button",
                                      variant: "ghost",
                                      size: "sm",
                                      className: "h-7 rounded-full px-3 text-[10px] text-rose-200 hover:bg-rose-400/10 hover:text-rose-100 disabled:text-white/35",
                                      disabled: removingControllerId === item.controller.controllerId,
                                      onClick: async () => {
                                        if (!item.controller) {
                                          return;
                                        }
                                        try {
                                          setRemovingControllerId(
                                            item.controller.controllerId
                                          );
                                          await onRemoveController(
                                            item.controller.controllerId
                                          );
                                        } finally {
                                          setRemovingControllerId(
                                            (current) => {
                                              var _a2;
                                              return current === ((_a2 = item.controller) == null ? void 0 : _a2.controllerId) ? null : current;
                                            }
                                          );
                                        }
                                      },
                                      children: "Kick"
                                    }
                                  ) : null,
                                  previewSession ? (0, import_jsx_runtime2.jsx)(
                                    Button,
                                    {
                                      type: "button",
                                      variant: "ghost",
                                      size: "icon-sm",
                                      className: "h-7 w-7 rounded-full text-white/68 hover:bg-white/8 hover:text-white",
                                      onClick: () => removePreviewController(previewSession.id),
                                      title: `Close ${item.label}`,
                                      children: (0, import_jsx_runtime2.jsx)(X, { className: "h-4 w-4" })
                                    }
                                  ) : null
                                ] })
                              ]
                            },
                            item.id
                          );
                        }) }),
                        (0, import_jsx_runtime2.jsx)("div", { className: "h-px bg-white/10" })
                      ] }) : (0, import_jsx_runtime2.jsx)("div", { className: cn("px-4 py-4", shellInsetPanelClassName), children: (0, import_jsx_runtime2.jsx)("p", { className: "text-sm leading-6 text-white/58", children: "Open a controller preview here to test the host flow without using a phone." }) }),
                      minimizedSessions.length > 0 ? (0, import_jsx_runtime2.jsxs)("p", { className: "text-[11px] tracking-[0.14em] text-white/46 uppercase", children: [
                        minimizedSessions.length,
                        " minimized"
                      ] }) : null,
                      (0, import_jsx_runtime2.jsxs)(
                        Button,
                        {
                          type: "button",
                          variant: "outline",
                          className: cn(
                            "h-10 w-full rounded-2xl",
                            shellUtilityButtonClassName
                          ),
                          disabled: !canSpawn,
                          onClick: () => {
                            spawnPreviewController();
                          },
                          children: [
                            (0, import_jsx_runtime2.jsx)(Plus, { className: "h-4 w-4" }),
                            !joinUrl ? waitingLabel : "Add controller"
                          ]
                        }
                      )
                    ] }) })
                  }
                ) : null
              ]
            }
          )
        ]
      }
    ),
    document.body
  );
};
var HostPreviewControllerWorkspace = ({
  enabled = "auto",
  className,
  ...props
}) => {
  const host = useAirJamHost();
  const config = useAirJamConfig();
  const platformSettingsOwner = useOptionalPlatformSettingsOwnerApi();
  const resolvedEnabled = resolveHostPreviewControllerWorkspaceEnabled({
    enabled,
    topology: config.topology
  });
  const joinUrl = host.joinUrlStatus === "ready" && host.joinUrl ? host.joinUrl : null;
  const handleResetRoom = async () => {
    const ack = await host.resetRoom();
    if (!ack.ok || typeof window === "undefined") {
      return ack;
    }
    window.location.reload();
    return ack;
  };
  return (0, import_jsx_runtime3.jsx)(
    PreviewControllerWorkspace,
    {
      enabled: resolvedEnabled,
      joinUrl,
      controllers: host.controllers,
      onRemoveController: host.removeController,
      onResetRoom: handleResetRoom,
      onActiveOpacityChange: (activeOpacity) => platformSettingsOwner == null ? void 0 : platformSettingsOwner.updatePreviewControllers({ activeOpacity }),
      className: cn("right-4 bottom-4 z-60 sm:right-6 sm:bottom-6", className),
      ...props
    }
  );
};
export {
  AIR_JAM_PREVIEW_DEVICE_QUERY_PARAM,
  AIR_JAM_PREVIEW_FLAG_QUERY_PARAM,
  HostPreviewControllerWorkspace,
  PreviewControllerWindow,
  PreviewControllerWorkspace,
  buildPreviewControllerUrl,
  createPreviewControllerIdentity,
  createPreviewControllerLaunch,
  isEmbeddedArcadeRuntimeSearchParams,
  isPreviewControllerSearchParams,
  normalizePreviewDeviceId,
  previewControllerWindowStateLabel,
  readPreviewControllerDeviceIdFromLocation,
  readPreviewControllerDeviceIdFromSearchParams,
  resolveHostPreviewControllerWorkspaceEnabled,
  usePreviewControllerManager
};
//# sourceMappingURL=@air-jam_sdk_preview.js.map
